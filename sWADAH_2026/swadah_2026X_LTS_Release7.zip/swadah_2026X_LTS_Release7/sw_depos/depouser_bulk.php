<?php
/*
Filename: sw_admin/adduser_bulk.php
Usage: Bulk add new users - patron only
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Bulk Patron User";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
    
    <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
            // Database connection

            $file = $_FILES['csv_file']['tmp_name'];
            if (!is_uploaded_file($file)) {
                die("Upload failed.");
            }

            $row_number = 1;
            $error_rows = [];

            if (($handle = fopen($file, 'r')) !== false) {
                echo "<h3>Processing uploaded file...</h3>";
                while (($data = fgetcsv($handle, 1000, ',', '"', '\\')) !== false) {
                    $row_number++;

                    if (count($data) < 3) {
                        $error_rows[] = $row_number;
                        continue;
                    }

                    list($username, $name, $totalpost) = $data;

                    // Trim whitespace from all fields
                    $username = trim($username);
                    $name = trim($name);
                    $totalpost = trim($totalpost);
                    $regtimestamp = time();
                    $registerkey = md5(microtime() . rand() . $username);
                    $activation = 'ACTIVE';

                    // Clean fields by removing invalid characters (keep only alphanumeric and spaces)
                    $original_username = $username;
                    $original_name = $name;
                    $original_totalpost = $totalpost;
                    
                    $username = preg_replace('/[^a-zA-Z0-9._-]/', '', $username);
                    $name = preg_replace('/[^a-zA-Z0-9\s._-]/', '', $name);
                    $totalpost = preg_replace('/[^a-zA-Z0-9\s]/', '', $totalpost);
                    
                    try {
                        // Check if username already exists
                        $check_stmt = $new_conn->prepare("SELECT COUNT(*) FROM eg_auth_depo WHERE useridentity = ?");
                        $check_stmt->execute([$username]);
                        $result = $check_stmt->get_result();
                        $count = $result->fetch_row()[0];
                        
                        if ($count > 0) {
                            // Username already exists, skip this row
                            echo "<p>Row $row_number: Username '$username' already exists, skipping...</p>";
                            continue;
                        }
                        
                        $stmt = $new_conn->prepare("
                            INSERT INTO eg_auth_depo
                            (useridentity, userpass, fullname, totalpost, regtimestamp, registerkey, activation)
                            VALUES (?, AES_ENCRYPT('$default_create_password', ?), ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$username, $aes_key, $name, $totalpost, $regtimestamp, $registerkey, $activation]);
                    } catch (Exception $e) {
                        $error_rows[] = $row_number;
                    }
                }
                fclose($handle);

                if (!empty($error_rows)) {
                    echo "<p>Import completed with errors on rows: " . implode(", ", $error_rows) . "</p>";
                } else {
                    echo "<p>All rows imported successfully! Default password for all users is $default_create_password</p>";
                }

                echo '<p><a href="' . $_SERVER['PHP_SELF'] . '">Upload another file</a></p>';
            } else {
                echo "Unable to read uploaded file.";
            }

            exit;
        }
        
    ?>
    
    <?php if (!isset($_REQUEST["submitted"]) || $_REQUEST["submitted"] != "Upload and Import") { ?>
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Bulk depositor uploader. All users will be create with default password of <em><?= $default_create_password;?></em>.</strong></td></tr>
            <tr class=greyHeaderCenter><td style='width:370;'><br/>
            <form action="depouser_bulk.php" method="POST" enctype="multipart/form-data">
                <label>Select CSV file (format: username, full name, totalpost)<br/>Maximum 5MB, please do in segments for large files:</label><br/><br/>
                <input type="file" name="csv_file" accept=".csv" required>
                <br><br>
                <input type="hidden" name="submitted" value="Upload and Import">
                <input type="submit" value="Upload and Import">
            </form>
            </td></tr>
        </table><br/>
    <?php } ?>
    
    <div style='text-align:center;'><a class='sButton' href='depouser.php?show=NOTACTIVE'><span class='fas fa-arrow-circle-left'></span> Back to depositor account page</a></div>
    
    <hr>

    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
