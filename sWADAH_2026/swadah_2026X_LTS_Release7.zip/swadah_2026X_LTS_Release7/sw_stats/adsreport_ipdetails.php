<?php
/*
Filename: sw_stats/adsreport_ipdetails.php
Usage: Hits details for a searches (by IPs)
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "IP Search Log Report";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php //include_once '../sw_inc/loggedinfo.php'; ?>
    
    <br/>

    <div style="text-align:center">

    <?php
            
        echo "<table class=whiteHeaderNoCenter style='width:480'>";
            echo "<tr class=$color_scheme"."HeaderCenter><td colspan=4><strong>IP search log sort by : </strong>";
                echo " <select name=\"sortby\" ONCHANGE=\"location = this.options[this.selectedIndex].value;\">";
                    echo "<option value=\"adsreport_ipdetails.php?page=1&sortby=ip\"";
                    if (isset($_GET["sortby"]) && $_GET["sortby"] == 'ip') {
                        echo " selected";
                        $sortby = '38ipaddr';
                        $sortbyf = 'ip';
                    }
                    echo ">IP</option>";
                    echo "<option value=\"adsreport_ipdetails.php?page=1&sortby=hits\"";
                    if (!isset($_GET["sortby"]) || $_GET["sortby"] == 'hits') {
                        echo " selected";
                        $sortby = 'total1c';
                        $sortbyf = 'hits';
                    }
                    echo " >Hits</option>";
                echo "</select>";
            echo "</td></tr>";
        
            $query_iplog = "select count(distinct id, substring_index(`38ipaddr`,'.',3)) as total1c, substring_index(`38ipaddr`,'.',3) as `38ipaddr` from eg_userlog_det group by substring_index(`38ipaddr`,'.',3) order by $sortby desc LIMIT 100";
            $result_iplog = mysqli_query($GLOBALS["conn"], $query_iplog);
                                                            
            echo "<tr class=whiteHeaderNoCenter><td width=50><strong></strong></td><td width=150><strong>IP Address</strong></td><td width=80><strong>Frequency</strong></td><td><strong>Last logged</strong></td></tr>";
                                                        
            $n = 1;
            while ($myrow_iplog = mysqli_fetch_array($result_iplog)) {
                $ipaddr = $myrow_iplog["38ipaddr"];
                $total = $myrow_iplog["total1c"];
                $query_lastlog = "select `38logdate` as last1d from eg_userlog_det where substring_index(`38ipaddr`,'.',3)='$ipaddr' ORDER BY id DESC LIMIT 1 ";
                $result_lastlog = mysqli_query($GLOBALS["conn"], $query_lastlog);
                $myrow_lastlog = mysqli_fetch_array($result_lastlog);
                echo "<tr class=$color_scheme"."Hover><td><strong>$n</strong></td><td>$ipaddr.*</td><td>$total</td><td>".$myrow_lastlog["last1d"]."</td></tr>";
                $n = $n +1 ;
            }
        echo "</table>";
                                            
    ?>
        
        <br/>
        <br/>
        <a class='sButton' href='javascript:window.close();'><span class="fa-solid fa-rectangle-xmark"></span> Close</a>

    </div>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
