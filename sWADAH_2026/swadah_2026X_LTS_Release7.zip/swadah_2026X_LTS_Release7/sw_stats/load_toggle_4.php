<?php
/*
Filename: sw_stats/load_toggle_4.php (Bookmark)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change: -
*/

    include_once '../sw_inc/access_isset.php';

    // Memeriksa jika $_REQUEST['hitsDateL'] $_REQUEST['lyearly'] atau  dihantar
    if (!empty($_REQUEST['hitsDateL'])) {
        $dateParts = explode('/', $_REQUEST['hitsDateL']);
        if (count($dateParts) === 3) {
            $_SESSION[$ssn.'lyearly'] = $dateParts[2];
        }
    } elseif (!empty($_REQUEST['lyearly'])) {
        $_SESSION[$ssn.'lyearly'] = $_REQUEST['lyearly'];
    }
?>
<?php
    function sw_countBmrkHitsForMonth($monthStr)
    {
        if (strpos($monthStr, "/00") !== false) {
            return "0";
        } else {
            $t = preg_replace("/\D/", "", $monthStr);

            if (file_exists("../".$GLOBALS["system_statcache_directory"]."/bookmarkstat/$t".".txt") && (substr($t, 2) < date('Y'))) {
                $lines = file("../".$GLOBALS["system_statcache_directory"]."/bookmarkstat/$t".".txt");
                $to_return = $lines[0];
            } else {
                $querySTAT = "select count(id) as totalhitSTAT from eg_item_charge where DATE_FORMAT(FROM_UNIXTIME(`39charged_on`), '%m/%Y') = '$monthStr'";
                $resultSTAT = mysqli_query($GLOBALS["conn"], $querySTAT);
                $myrowSTAT = mysqli_fetch_array($resultSTAT);
                file_put_contents("../".$GLOBALS["system_statcache_directory"]."/bookmarkstat/$t".".txt", $myrowSTAT["totalhitSTAT"]."\n".time());
                $to_return = $myrowSTAT["totalhitSTAT"];
            }
            return $to_return;
        }
    }
    
    if (file_exists("../$system_statcache_directory/total_bookmark_sum.txt") && $report_count_generator == 'daily') {
        $lines = file("../$system_statcache_directory/total_bookmark_sum.txt");
        $diff = time() - $lines[1];
        $reported_timestamp = $lines[1];
        if ((isset($diff) && $diff < 86400)  && $report_count_generator == 'daily') {
            $numSUMl = $lines[0];
        } else {
            $querySUMl = "select count(id) as totalLoan from eg_item_charge";
            $resultSUMl = mysqli_query($GLOBALS["conn"], $querySUMl);
            $myrowSUMl = mysqli_fetch_array($resultSUMl);
            $numSUMl = $myrowSUMl["totalLoan"];
            file_put_contents("../$system_statcache_directory/total_bookmark_sum.txt", $numSUMl."\n".time());
            $reported_timestamp = time();
        }
    } else {
        $querySUMl = "select count(id) as totalLoan from eg_item_charge";
        $resultSUMl = mysqli_query($GLOBALS["conn"], $querySUMl);
        $myrowSUMl = mysqli_fetch_array($resultSUMl);
        $numSUMl = $myrowSUMl["totalLoan"];
        file_put_contents("../$system_statcache_directory/total_bookmark_sum.txt", $numSUMl."\n".time());
        $reported_timestamp = time();
    }
        
?>
<table class=whiteHeader>
    <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong>Bookmarks Statistic</strong></td></tr>
    <tr style='background-color:#EDF0F6;'><td colspan=2>
        <br/>Total items bookmarked (all time) : <br/>
        <span style='font-size:22px;'><strong><?php echo "$numSUMl";?></strong></span>
        <?php if ($report_count_generator == 'daily' && isset($lines[1])) {?><br/><em>Statistic generated date and time: <?php echo date('Y-m-d H:i:s', $reported_timestamp) ?><br/>Statistic is valid for that date and time. New statistic will be generated 24 hours later.</em><?php }?>
        <br/><br/>
    </td></tr>
    
    <tr style='text-align:center'><td colspan=2 class='<?php echo $color_scheme."Back"; ?>'>Choose one of the following report generators:</td></tr>
    
    <tr style='background-color:#EDF0F6;text-align:center'><td colspan=2>
        <form name="getMonthStat" action="adsreport.php?toggle=4" method=post>
            Yearly stats: <input type="text" name="lyearly" size="5" <?php if (isset($_SESSION[$ssn.'lyearly']) && is_numeric($_SESSION[$ssn.'lyearly'])) {echo 'value="'.$_SESSION[$ssn.'lyearly'].'"';}?> maxlength="4"/>
        </form><br/>
        <?php
                if (isset($_SESSION[$ssn.'lyearly']) && is_numeric($_SESSION[$ssn.'lyearly'])) {
                    $yearly = $_SESSION[$ssn.'lyearly'];
                }  else {
                    $yearly = '00';
                }

                function sw_create3month_comparetablestatB($leftHead, $rightHead, $year_select)
                {
                    echo "<table style='text-align:center;border:1px solid;display: inline-block;'>";
                    echo "<tr style='background-color:lightgrey;'><td style='text-align:center;border:1px solid;'>$leftHead</td><td style='text-align:center;border:1px solid;'>$rightHead</td></tr>";
                    $total = 0;
                    for ($x = 1; $x <= 12; $x++) {
                        $y = ($x < 10) ? "0$x" : $x;
                        ${"j".$x} = sw_countBmrkHitsForMonth("$y/$year_select");
                        echo "<tr style='text-align:center;border:1px solid;'><td>$y/$year_select</td><td>".${"j".$x}."</td></tr>";
                        $total = $total + ${"j".$x};
                    }
                    echo "<tr><td style='text-align:center;border:1px solid;'>TOTAL:</td><td style='text-align:center;border:1px solid;'>$total</td></tr>";
                    echo "</table> ";
                }
                sw_create3month_comparetablestatB('Month', 'Bookmark', $yearly);
        ?>
    </td></tr>
    
    <tr style='background-color:#EDF0F6;text-align:left'>
        <td>
            <form name="getMonthStat" action="adsreport.php?toggle=4" method="post">Bookmarks by month :
                <br/><br/>
                <?php
                    $lmonths = [
                        '01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr',
                        '05' => 'May', '06' => 'June', '07' => 'Jul', '08' => 'Aug',
                        '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec'
                    ];
                ?>
                <select name='lmonthly'>
                    <option value='' hidden>Choose</option>
                    <?php foreach ($lmonths as $value => $name): ?>
                        <option value='<?= $value ?>' <?= (isset($_POST['lmonthly']) && $_POST['lmonthly'] == $value) ? 'selected' : '' ?>><?= $name ?></option>
                    <?php endforeach; ?>
                </select>

                and year :
                <input type="text" name="lyearly" size="5" <?php if (isset($_SESSION[$ssn.'lyearly']) && is_numeric($_SESSION[$ssn.'lyearly'])) {echo 'value="'.$_SESSION[$ssn.'lyearly'].'"';}?> maxlength="4"/>
                <br/><br/><input type="submit" value="Submit Query">
            </form>
        </td>
        <td>
            <?php
                if (isset($_POST['lmonthly']) && is_numeric($_POST['lmonthly']) && isset($_POST['lyearly']) && is_numeric($_POST['lyearly'])) {
                    $hitsSTRINGl = $_POST['lmonthly'].'/'.$_POST['lyearly'];
                    $stmt_count = $new_conn->prepare("select count(id) as totalhitSTAT from eg_item_charge where DATE_FORMAT(FROM_UNIXTIME(`39charged_on`), '%m/%Y') = ?");
                    $stmt_count->bind_param("s", $hitsSTRINGl);
                    $stmt_count->execute();
                    $stmt_count->bind_result($numSTATl);
                    $stmt_count->fetch();$stmt_count->close();
                    
                    echo "<a onclick='return js_openPopup(this.href,950,580);' href='adsreport_loandetails.php?hitsDate=$hitsSTRINGl'>$numSTATl transactions</a>";
                }
            ?>
        </td>
    </tr>

    <tr style='background-color:#EDF0F6;text-align:left'><td>Bookmarks by date :
        <form name="getTarikhL" action="adsreport.php?toggle=4" method="post">
            <script>DateInput('hitsDateL', true, 'DD/MM/YYYY' <?php if (isset($_POST['hitsDateL'])) {echo ",'".$_POST['hitsDateL']."'"; } ?>)</script>
            <input type="submit" value="Submit Query">
        </form>
    </td>
    <td>
    <?php
        if (isset($_POST['hitsDateL'])) {
            $hitsDateL = $_POST['hitsDateL'];
            $stmt_count = $new_conn->prepare("select count(id) as totalhitSUMselect from eg_item_charge where DATE_FORMAT(FROM_UNIXTIME(`39charged_on`), '%d/%m/%Y') = ?");
            $stmt_count->bind_param("s", $hitsDateL);
            $stmt_count->execute();
            $stmt_count->bind_result($numSUMselectL);
            $stmt_count->fetch();$stmt_count->close();
        
            if ($numSUMselectL <> 0) {
                echo "<a onclick='return js_openPopup(this.href,950,580);' href='adsreport_loandetails.php?hitsDate=$hitsDateL'>$numSUMselectL transactions</a>";
            } else {
                echo '0 transactions.<br/><br/>';
            }
        }
    ?>
    </td></tr>
</table>
