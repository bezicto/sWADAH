<?php
/*
Filename: sw_stats/adsreport_typesession_more.php
Usage: Display details with items accessed (sessions) within the time frame
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Type Session Details - More";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';

    if (!is_numeric($_GET["type"])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Invalid parameter detected.</h2><em>Please contact the system administrator if you see this message.</em></div>";
        mysqli_close($GLOBALS["conn"]); exit();
    }
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <div style="text-align:center">
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Access details for <?php echo $_GET['acstat'];?></strong> :</td></tr>
        </table>
        
        <table class=whiteHeaderNoCenter>
            <tr class=whiteHeaderNoCenter><td style='width:50;'></td><td>IP Address / Session</td><td>Date</td><td>Total access</td></tr>
            <?php
                $n = 1;
                $stmt_fsb = $new_conn->prepare("
                select eg_item_access.`39ipaddr` as aip, SUBSTRING_INDEX(eg_item_access.`39logdate`,' ', 2) as adate, count(eg_item_access.id) as totalid
                            from eg_item_access inner join eg_item on eg_item_access.eg_item_id=eg_item.id
                            where eg_item.`38typeid`=? and DATE_FORMAT(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p'), '/%m/%Y') = ?
                            group by aip, adate
                ");
                $stmt_fsb->bind_param("is", $_GET["type"], $_GET["acstat"]);
                $stmt_fsb->execute();
                $result_fsb = $stmt_fsb->get_result();
                while ($myrow_fsb = $result_fsb->fetch_assoc()) {
                    $aip_fsb = $myrow_fsb["aip"];
                    $adate_fsb = $myrow_fsb["adate"];
                    $totalid_fsb = $myrow_fsb["totalid"];
                
                    echo "<tr class=$color_scheme"."Hover><td style='width:50px;'>$n</td><td>$aip_fsb</td><td>$adate_fsb</td><td>$totalid_fsb</td></tr>";
                    
                    $n=$n+1;
                }
            ?>
        </table>

        <br/><br/><a class='sButton' href='javascript:history.go(-1)'><span class='fas fa-arrow-circle-left'></span> Back to previous page</a>
    </div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
