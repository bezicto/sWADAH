<?php
/*
Filename: sw_stats/load_toggle_2b.php (Access)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change:
20250619.1433 introducing new queries to count session,access,download
*/

    include_once '../sw_inc/access_isset.php';
?>
<table class=whiteHeader><tr class=<?php echo $color_scheme."HeaderCenter";?>><td>
    <form name="getMonthStat" action="adsreport.php?toggle=2" method=post>
        Yearly stats: <input type="text" name="acyearly" size="5" <?php if (isset($_REQUEST['acyearly']) && is_numeric($_REQUEST['acyearly'])) {echo 'value="'.$_REQUEST['acyearly'].'"';}?> maxlength="4"/>
    </form>
</td></tr></table>

<table class=whiteHeader>
<tr class=whiteHeaderCenterUnderline><td></td><td style='text-align:left;'><?php echo $type_as;?></td>
    <td style='width:20%;'>Total Item</td>
    <td style='width:20%;'>Total Session</td>
    <td style='width:20%;'>Total Access</td>
    <td style='width:20%;'>Total Download</td>
</tr>
<?php
    $query2r = "select `38type`, `38typeid`, `38synonym` from eg_item_type";
    $result2r = mysqli_query($GLOBALS["conn"], $query2r);
    $m2r = 1;
    $total_item2r = 0;
    $total_session2r = 0;
    $total_access2r = 0;
    $total_download2r = 0;

    $inputyear = (isset($_REQUEST["acyearly"]) && is_numeric($_REQUEST["acyearly"])) ? $_REQUEST["acyearly"] : date('Y');

    $endts = strtotime($inputyear."-12-31 23:59:59");

    // Solution 4: Pre-pass – collect all types and check per-type cache in one loop
    $statcache_alltypstat = "../".$GLOBALS["system_statcache_directory"]."/alltypstat";
    $all_types_rows      = [];
    $cached_type_stats   = [];   // tid => [item, session, hits, download]
    $types_needing_fresh = [];
    $timestamp_recorded  = null;

    while ($row_pre = mysqli_fetch_array($result2r)) {
        $tid = $row_pre["38typeid"];
        $all_types_rows[] = $row_pre;
        $cache_file_pre   = "$statcache_alltypstat/$inputyear"."_".$tid.".txt";
        $loaded = false;

        if (file_exists($cache_file_pre)) {
            $lines_pre = file($cache_file_pre);
            if (date('Y') > $inputyear) {
                $cached_type_stats[$tid] = [trim($lines_pre[0]), trim($lines_pre[1]), trim($lines_pre[2]), trim($lines_pre[3])];
                $loaded = true;
            } else {
                $ts_pre = trim($lines_pre[4]);
                if (time() - $ts_pre <= 86400) {
                    $cached_type_stats[$tid] = [trim($lines_pre[0]), trim($lines_pre[1]), trim($lines_pre[2]), trim($lines_pre[3])];
                    $timestamp_recorded = $ts_pre;
                    $loaded = true;
                }
            }
        }
        if (!$loaded) {
            $types_needing_fresh[] = $tid;
        }
    }

    // Solution 3+4: Run 3 batch queries for ALL types needing fresh data at once
    $batch_type_stats = [];
    if (!empty($types_needing_fresh)) {
        foreach ($types_needing_fresh as $tid) {
            $batch_type_stats[$tid] = ['item' => 0, 'session' => 0, 'hits' => 0, 'download' => 0];
        }
        $tids_in = "'" . implode("','", $types_needing_fresh) . "'";

        // batch 1: item count grouped by typeid
        $q_batch_item = "SELECT `38typeid`, COUNT(id) AS totalid
                         FROM eg_item
                         WHERE `38typeid` IN ($tids_in) AND `41instimestamp` <= $endts
                         GROUP BY `38typeid`";
        $r_batch_item = mysqli_query($GLOBALS["conn"], $q_batch_item);
        while ($row_b = mysqli_fetch_array($r_batch_item)) {
            $batch_type_stats[$row_b['38typeid']]['item'] = $row_b['totalid'];
        }

        // batch 2: session + access combined in one query grouped by typeid (Solution 3)
        $q_batch_combined = "SELECT eg_item.`38typeid`,
                             COUNT(eg_item_access.id) AS totalhits,
                             COUNT(DISTINCT CONCAT(eg_item_access.`39ipaddr`, SUBSTRING_INDEX(eg_item_access.`39logdate`,' ', 2))) AS ccount
                             FROM eg_item_access
                             INNER JOIN eg_item ON eg_item_access.eg_item_id = eg_item.id
                             WHERE eg_item.`38typeid` IN ($tids_in)
                             AND YEAR(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p')) = $inputyear
                             GROUP BY eg_item.`38typeid`";
        $r_batch_combined = mysqli_query($GLOBALS["conn"], $q_batch_combined);
        while ($row_b = mysqli_fetch_array($r_batch_combined)) {
            $batch_type_stats[$row_b['38typeid']]['hits']    = $row_b['totalhits'];
            $batch_type_stats[$row_b['38typeid']]['session'] = $row_b['ccount'];
        }

        // batch 3: download grouped by typeid
        $q_batch_download = "SELECT eg_item.`38typeid`, COUNT(eg_item_download.id) AS totalid
                             FROM eg_item_download
                             INNER JOIN eg_item ON eg_item_download.eg_item_id = eg_item.id
                             WHERE eg_item.`38typeid` IN ($tids_in)
                             AND YEAR(STR_TO_DATE(eg_item_download.`39logdate`, '%a %d/%m/%Y %l:%i %p')) = $inputyear
                             GROUP BY eg_item.`38typeid`";
        $r_batch_download = mysqli_query($GLOBALS["conn"], $q_batch_download);
        while ($row_b = mysqli_fetch_array($r_batch_download)) {
            $batch_type_stats[$row_b['38typeid']]['download'] = $row_b['totalid'];
        }

        // write cache for each fresh type
        $now_ts = time();
        foreach ($types_needing_fresh as $tid) {
            $s = $batch_type_stats[$tid];
            file_put_contents("$statcache_alltypstat/$inputyear"."_".$tid.".txt",
                $s['item']."\n".$s['session']."\n".$s['hits']."\n".$s['download']."\n".$now_ts);
        }
        $timestamp_recorded = $now_ts;
    }

    // Display loop – uses pre-fetched cache or batch data; no DB queries here
    foreach ($all_types_rows as $myrow2r) {
        $typestatement2r = $myrow2r["38typeid"];
        $typedesc2r      = $myrow2r["38type"];
        $typesynonym2r   = $myrow2r["38synonym"];

        if (isset($cached_type_stats[$typestatement2r])) {
            [$item_total_ts, $session_total_ts, $hits_total_ts, $num_download_ts] = $cached_type_stats[$typestatement2r];
        } else {
            $s = $batch_type_stats[$typestatement2r] ?? ['item' => 0, 'session' => 0, 'hits' => 0, 'download' => 0];
            $item_total_ts    = $s['item'];
            $session_total_ts = $s['session'];
            $hits_total_ts    = $s['hits'];
            $num_download_ts  = $s['download'];
        }

        $total_item2r     = $total_item2r + $item_total_ts;
        $total_session2r  = $total_session2r + $session_total_ts;
        $total_access2r   = $total_access2r + $hits_total_ts;
        $total_download2r = $total_download2r + $num_download_ts;

        echo "<tr><td>$m2r</td><td style='text-align:left;'>$typesynonym2r</td><td>$item_total_ts</td><td>$session_total_ts</td><td>$hits_total_ts</td><td>$num_download_ts</td></tr>";
        $m2r=$m2r+1;
    }

    // compute total session for the year using a single DISTINCT query across all existing types
    // (summing per-type DISTINCT values overcounts visitors who accessed multiple types in the same day)
    $cache_file_yr_session = "../".$GLOBALS["system_statcache_directory"]."/alltypstat/$inputyear"."_TOTAL_SESSION.txt";
    $get_new_yr_session = true;

    if (file_exists($cache_file_yr_session) && (date('Y') > $inputyear)) {
        $yr_session_lines = file($cache_file_yr_session);
        $total_session2r = trim($yr_session_lines[0]);
        $get_new_yr_session = false;
    } elseif (file_exists($cache_file_yr_session)) {
        $yr_session_lines = file($cache_file_yr_session);
        $diff_yr_session = time() - trim($yr_session_lines[1]);
        if ($diff_yr_session <= 86400) {
            $total_session2r = trim($yr_session_lines[0]);
            $get_new_yr_session = false;
        }
    }

    if ($get_new_yr_session) {
        $query_yr_session_total = "select count(DISTINCT(concat(eg_item_access.`39ipaddr`, SUBSTRING_INDEX(eg_item_access.`39logdate`,' ', 2)))) as ccount
                                   from eg_item_access
                                   inner join eg_item on eg_item_access.eg_item_id=eg_item.id
                                   inner join eg_item_type on eg_item.`38typeid`=eg_item_type.`38typeid`
                                   where YEAR(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p')) = $inputyear";
        $result_yr_session_total = mysqli_query($GLOBALS["conn"], $query_yr_session_total);
        $myrow_yr_session_total = mysqli_fetch_array($result_yr_session_total);
        $total_session2r = $myrow_yr_session_total["ccount"];
        file_put_contents($cache_file_yr_session, $total_session2r."\n".time());
    }
?>
<tr style='background-color:lightgrey'><td colspan=2 style='text-align:right;background-color:white;'><em>Total</em></td>
    <td style='width:20%;'><em><?php echo $total_item2r;?></em></td>
    <td style='width:20%;'><em><?php echo $total_session2r;?></em></td>
    <td style='width:20%;'><em><?php echo $total_access2r;?></em></td>
    <td style='width:20%;'><em><?php echo $total_download2r;?></em></td>
</tr>
</table>



<table style='margin-top:10px;width:100%;'><tr><td>
    <strong>Total item:</strong> All item cumulatively <u>since the beginning of system</u> until the selected year.
    <br/><strong>Total session:</strong> Total session ONLY for the selected year.
    <br/><strong>Total Acccess:</strong> Total hits/page access ONLY for the selected year.
    <?php
    if ($inputyear == date('Y')) {
        echo "<br/><br/><em>Statistic generated date and time: ".date('Y-m-d H:i:s', $timestamp_recorded)."<br/>
        Statistic is valid for that date and time. New statistic will be generated 24 hours later.</em>";
    }
    ?>
</td></tr></table>

<table class=whiteHeader style='margin-top:20px;'>
<tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=6>Monthly Breakdown for Year <?php echo $inputyear; ?></td></tr>
<tr class=whiteHeaderCenterUnderline>
    <td></td>
    <td style='text-align:left;'>Month</td>
    <td style='width:20%;'>Total Item</td>
    <td style='width:20%;'>Total Session</td>
    <td style='width:20%;'>Total Access</td>
    <td style='width:20%;'>Total Download</td>
</tr>
<?php
    $month_names = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    $total_item_mth  = 0;
    $total_session_mth = 0;
    $total_access_mth  = 0;
    $total_download_mth = 0;
    $last_mth_ts_recorded = null;
    $cache_dir_mth = "../".$GLOBALS["system_statcache_directory"]."/monthstat";

    // Solution 4: Pre-pass – check monthly cache for all 12 months
    $cached_mth_stats    = [];   // mth => [item, session, hits, download]
    $months_needing_fresh = [];  // mth => ['start'=>..., 'end'=>..., 'cache_file'=>...]

    for ($mth = 1; $mth <= 12; $mth++) {
        $mth_padded    = str_pad($mth, 2, '0', STR_PAD_LEFT);
        $days_in_month = cal_days_in_month(CAL_GREGORIAN, $mth, $inputyear);
        $start_of_mth  = strtotime("$inputyear-$mth_padded-01 00:00:00");
        $end_of_mth    = strtotime("$inputyear-$mth_padded-$days_in_month 23:59:59");
        $cache_file_mth = "$cache_dir_mth/$inputyear"."_".$mth_padded.".txt";
        $loaded_mth = false;

        if (file_exists($cache_file_mth)) {
            $lines_mth_pre = file($cache_file_mth);
            if (date('Y') > $inputyear) {
                $cached_mth_stats[$mth] = [trim($lines_mth_pre[0]), trim($lines_mth_pre[1]), trim($lines_mth_pre[2]), trim($lines_mth_pre[3])];
                $loaded_mth = true;
            } else {
                $ts_mth_pre = trim($lines_mth_pre[4]);
                if (time() - $ts_mth_pre <= 86400) {
                    $cached_mth_stats[$mth] = [trim($lines_mth_pre[0]), trim($lines_mth_pre[1]), trim($lines_mth_pre[2]), trim($lines_mth_pre[3])];
                    $last_mth_ts_recorded = $ts_mth_pre;
                    $loaded_mth = true;
                }
            }
        }
        if (!$loaded_mth) {
            $months_needing_fresh[$mth] = ['start' => $start_of_mth, 'end' => $end_of_mth, 'cache_file' => $cache_file_mth];
        }
    }

    // Solution 3+4: Run 3 batch queries for ALL months needing fresh data at once
    $batch_mth_stats = [];
    if (!empty($months_needing_fresh)) {
        foreach (array_keys($months_needing_fresh) as $mnth) {
            $batch_mth_stats[$mnth] = ['item' => 0, 'session' => 0, 'hits' => 0, 'download' => 0];
        }
        $mths_in   = implode(',', array_keys($months_needing_fresh));
        $min_start = min(array_column($months_needing_fresh, 'start'));
        $max_end   = max(array_column($months_needing_fresh, 'end'));

        // batch 1: item count grouped by month
        $q_batch_item_mth = "SELECT MONTH(FROM_UNIXTIME(eg_item.`41instimestamp`)) AS mth,
                              COUNT(eg_item.id) AS totalid
                              FROM eg_item
                              INNER JOIN eg_item_type ON eg_item.`38typeid` = eg_item_type.`38typeid`
                              WHERE eg_item.`41instimestamp` >= $min_start AND eg_item.`41instimestamp` <= $max_end
                              AND MONTH(FROM_UNIXTIME(eg_item.`41instimestamp`)) IN ($mths_in)
                              GROUP BY MONTH(FROM_UNIXTIME(eg_item.`41instimestamp`))";
        $r_batch_item_mth = mysqli_query($GLOBALS["conn"], $q_batch_item_mth);
        while ($row_b = mysqli_fetch_array($r_batch_item_mth)) {
            $batch_mth_stats[(int)$row_b['mth']]['item'] = $row_b['totalid'];
        }

        // batch 2: session + access combined grouped by month (Solution 3)
        $q_batch_combined_mth = "SELECT MONTH(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p')) AS mth,
                                  COUNT(eg_item_access.id) AS totalhits,
                                  COUNT(DISTINCT CONCAT(eg_item_access.`39ipaddr`, SUBSTRING_INDEX(eg_item_access.`39logdate`,' ', 2))) AS ccount
                                  FROM eg_item_access
                                  INNER JOIN eg_item ON eg_item_access.eg_item_id = eg_item.id
                                  INNER JOIN eg_item_type ON eg_item.`38typeid` = eg_item_type.`38typeid`
                                  WHERE YEAR(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p')) = $inputyear
                                  AND MONTH(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p')) IN ($mths_in)
                                  GROUP BY MONTH(STR_TO_DATE(eg_item_access.`39logdate`, '%a %d/%m/%Y %l:%i %p'))";
        $r_batch_combined_mth = mysqli_query($GLOBALS["conn"], $q_batch_combined_mth);
        while ($row_b = mysqli_fetch_array($r_batch_combined_mth)) {
            $batch_mth_stats[(int)$row_b['mth']]['hits']    = $row_b['totalhits'];
            $batch_mth_stats[(int)$row_b['mth']]['session'] = $row_b['ccount'];
        }

        // batch 3: download grouped by month
        $q_batch_download_mth = "SELECT MONTH(STR_TO_DATE(eg_item_download.`39logdate`, '%a %d/%m/%Y %l:%i %p')) AS mth,
                                  COUNT(eg_item_download.id) AS totalid
                                  FROM eg_item_download
                                  INNER JOIN eg_item ON eg_item_download.eg_item_id = eg_item.id
                                  INNER JOIN eg_item_type ON eg_item.`38typeid` = eg_item_type.`38typeid`
                                  WHERE YEAR(STR_TO_DATE(eg_item_download.`39logdate`, '%a %d/%m/%Y %l:%i %p')) = $inputyear
                                  AND MONTH(STR_TO_DATE(eg_item_download.`39logdate`, '%a %d/%m/%Y %l:%i %p')) IN ($mths_in)
                                  GROUP BY MONTH(STR_TO_DATE(eg_item_download.`39logdate`, '%a %d/%m/%Y %l:%i %p'))";
        $r_batch_download_mth = mysqli_query($GLOBALS["conn"], $q_batch_download_mth);
        while ($row_b = mysqli_fetch_array($r_batch_download_mth)) {
            $batch_mth_stats[(int)$row_b['mth']]['download'] = $row_b['totalid'];
        }

        // write cache for each fresh month
        if (!file_exists($cache_dir_mth)) { mkdir($cache_dir_mth, 0755, true); }
        $now_mth_ts = time();
        foreach ($months_needing_fresh as $mnth => $minfo) {
            $s = $batch_mth_stats[$mnth];
            file_put_contents($minfo['cache_file'], $s['item']."\n".$s['session']."\n".$s['hits']."\n".$s['download']."\n".$now_mth_ts);
        }
        $last_mth_ts_recorded = $now_mth_ts;
    }

    // Display loop – uses pre-fetched cache or batch data; no DB queries here
    for ($mth = 1; $mth <= 12; $mth++) {
        if (isset($cached_mth_stats[$mth])) {
            [$item_total_mth, $session_total_mth, $hits_total_mth, $num_download_mth] = $cached_mth_stats[$mth];
        } else {
            $s = $batch_mth_stats[$mth] ?? ['item' => 0, 'session' => 0, 'hits' => 0, 'download' => 0];
            $item_total_mth    = $s['item'];
            $session_total_mth = $s['session'];
            $hits_total_mth    = $s['hits'];
            $num_download_mth  = $s['download'];
        }

        $total_item_mth     += $item_total_mth;
        $total_session_mth  += $session_total_mth;
        $total_access_mth   += $hits_total_mth;
        $total_download_mth += $num_download_mth;

        echo "<tr><td>$mth</td><td style='text-align:left;'>".$month_names[$mth-1]."</td><td>$item_total_mth</td><td>$session_total_mth</td><td>$hits_total_mth</td><td>$num_download_mth</td></tr>";
    }
?>
<tr style='background-color:lightgrey'><td colspan=2 style='text-align:right;background-color:white;'><em>Total</em></td>
    <td style='width:20%;'><em><?php echo $total_item_mth;?></em></td>
    <td style='width:20%;'><em><?php echo $total_session_mth;?></em></td>
    <td style='width:20%;'><em><?php echo $total_access_mth;?></em></td>
    <td style='width:20%;'><em><?php echo $total_download_mth;?></em></td>
</tr>
</table>

<table style='margin-top:10px;width:100%;'><tr><td>
    <strong>Total item:</strong> Items deposited in each specific month of the selected year.
    <br/><strong>Total session:</strong> Total session for each month of the selected year.
    <br/><strong>Total Access:</strong> Total hits/page access for each month of the selected year.
    <br/><strong>Total Download:</strong> Total downloads for each month of the selected year.
    <?php
    if ($inputyear == date('Y') && $last_mth_ts_recorded !== null) {
        echo "<br/><br/><em>Statistic generated date and time: ".date('Y-m-d H:i:s', $last_mth_ts_recorded)."<br/>
        Statistic is valid for that date and time. New statistic will be generated 24 hours later.</em>";
    }
    ?>
</td></tr></table>
