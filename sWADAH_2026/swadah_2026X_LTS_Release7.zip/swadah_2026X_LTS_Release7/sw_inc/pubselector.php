<?php
/*
Filename: sw_inc/pubselector.php
Usage: Publisher selector for reg.php
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Publisher Selector";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
?>

<html lang='en'>

<head></head>

<body class='<?php echo $color_scheme;?>'>
    <script language="JavaScript">
        function js_pick(symbol) {
          if (window.opener && !window.opener.closed)
            {
                window.opener.document.mainform.publication1_b.value = symbol;
            }
             window.close();
        }
    </script>
    
    Select a publisher related to the item :
    
    <hr>
                        
    <u>ID</u> <u>Publisher</u>
        
    <br/><br/>
    
    <?php
        $queryC = "select `43publisher`, `43acronym` from eg_publisher order by `43acronym`";
        $resultC = mysqli_query($GLOBALS["conn"], $queryC);
        
        while ($myrowC = mysqli_fetch_array($resultC)) {
            $publisher = $myrowC["43publisher"];
            $pubAcr = $myrowC["43acronym"];
            echo "<span style='font-size:14px'>$pubAcr : <a href=\"javascript:js_pick('$publisher')\">$publisher</a></span><br/><br/>";
        }
    ?>
    
    <br/><br/>

    <div style="text-align:center">[<a href='javascript:window.close();'>Close</a>]</div>
    <br/>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
