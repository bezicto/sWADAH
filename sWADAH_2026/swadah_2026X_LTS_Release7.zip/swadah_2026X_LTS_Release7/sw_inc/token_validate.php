<?php
/*
Filename: sw_inc/token_validate.php
Usage: Check if token is valid or not before proceeding. This is to prevent cross site scripting
Version: 20250101.0801
Last change: -
*/
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    if (isset($_POST) && !empty($_POST)) {
        if (isset($_POST['token']) && $_POST['token'] == $_SESSION[$ssn.'token']) {
            $proceedAfterToken = true;
        } else {
            $proceedAfterToken = false;
            echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>405</strong></span><h2>Forbidden: Failed Token Check</h2><em>Please contact the system administrator if you see this message.</em></div>";
            exit;
        }
    }

    $_SESSION[$ssn.'token'] = md5(uniqid(mt_rand(), true)).openssl_encrypt(uniqid(time()), "AES-128-CTR", time().$aes_key, 0, "1234567891011121");
