<?php
/*
Filename: sw_brows/folderbrowser.php
Usage: List all created folders
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Folders";
    session_start();define('includeExist', true);

    include_once '../core.php';
    
    // keep this page in user browser for 12 hours
    if (!isset($_SESSION[$ssn.'username']) && !isset($_SESSION[$ssn.'username_guest'])) {
        header("Cache-Control: public, max-age=43200, immutable");
        header("Expires: " . gmdate("D, d M Y H:i:s", time() + 43200) . " GMT");
        header_remove("Pragma");
    }

    include_once '../sw_inc/functions.php';
    sfx_check_is_blocked("../$recorded_incidents_directory/", "../");

    $_SESSION[$ssn.'previous_url'] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<html lang='en'>

<head>
    <?php
        include_once '../sw_inc/header.php';
        //autologout
        echo isset($_SESSION[$ssn.'lls']) ? '<meta http-equiv="refresh" content="1800;url=../index.php?c=ls" />' : '';

    ?>
</head>

<body class='<?php echo $color_scheme;?>'>

    <?php include_once '../sw_inc/loggedinfo.php'; ?>

    <hr>
    
    <div style='text-align:center;overflow-x:auto;width:100%;'>
        <table class=whiteHeaderNoCenter>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong>Available folders</strong><br/></td></tr>
            <tr>
                <?php
                    
                    $query = "select * from eg_item_folder order by 38foldername";
                    $result = mysqli_query($GLOBALS["conn"], $query);
                    $num_results_affected = mysqli_num_rows($result);

                    $n=1;
                    while ($row = mysqli_fetch_array($result)) {
                        $foldername = $row['38foldername'];
                        $folderid = $row['38folderid'];

                        if ((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) {
                            $auth_user = $_SESSION[$ssn.'username'] ?? $_SESSION[$ssn.'username_guest'] ?? null;
                            $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$folderid'";
                            $result_user = mysqli_query($GLOBALS["conn"], $query_user);
                            $num_results_affected_user = mysqli_num_rows($result_user);
                        } else {
                            $num_results_affected_user = 1;
                        }
                        
                        if ($num_results_affected_user == 1) {
                            if ($n == 1) {
                                echo "<td style='text-align:left;vertical-align:top;'>";
                            }
                            echo "<img src='../sw_asset/img/bw_folder.png' style='width:16px;'> <a class=thisonly href='folderbrowser_details.php?subacr=$folderid'>$foldername</a>";
                            if ($n == ceil($num_results_affected/2)) {
                                echo "</td><td style='text-align:left;vertical-align:top;'>";
                            }
                            if ($n == $num_results_affected) {
                                echo "</td>";
                            }
                            $n=$n+1;
                        }
                    }
                ?>
            </tr>
        </table>
    </div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
