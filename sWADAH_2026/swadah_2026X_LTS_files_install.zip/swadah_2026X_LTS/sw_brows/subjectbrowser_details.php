<?php
/*
Filename: sw_brows/subjectbrowser_details.php
Usage: List all items related to current selected subject heading
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/functions.php';
    $thisPageTitle = "$subject_heading_as -Details";
    $_SESSION[$ssn.'whichbrowser'] = "sj";

    $get_subacr = htmlspecialchars($_GET["subacr"]);
    if (!is_numeric($get_subacr)) {
        sfx_echoPopupAlert("Illegal operation.","link","subjectbrowser.php");
        mysqli_close($GLOBALS["conn"]);
        exit();
    }
?>

<html lang='en'>

<head>
    <?php
        include_once '../sw_inc/header.php';
        //autologout
        echo isset($_SESSION[$ssn.'lls']) ? '<meta http-equiv="refresh" content="1800;url=../index.php?c=ls" />' : '';

    ?>
</head>

<body class='<?php echo $color_scheme;?>'>

    <div style='text-align:center;'>
    
    <?php
        include_once '../sw_inc/loggedinfo.php';
        
        echo "<hr>";

        $query_sub = "select 43subject, 43acronym from eg_subjectheading where 43subjectid=".$get_subacr;
        $result_sub = mysqli_query($GLOBALS["conn"], $query_sub);
        $row_sub = mysqli_fetch_array($result_sub);

        if (mysqli_num_rows($result_sub) >= 1) {
            $sub_name = $row_sub['43subject'];
            $sub_acronym = $row_sub['43acronym'];

            if (isset($_GET['page'])) {$currentPage = $_GET['page'];}
            include_once '../sw_inc/paging-p1.php';
            
            if ($subject_heading_selectable == "multi") {
                $query1 = "
                select id, 38title, 38typeid, 38source
                 from eg_item
                 where (41subjectheading like '%$sub_acronym".$subject_heading_delimiter."%'
                 or  41subjectheading like '$sub_acronym".$subject_heading_delimiter."%'
                 or  41subjectheading like '$sub_acronym')
                 and 50item_status='1' and 38status!='UNLISTED'
                  order by 38title LIMIT $offset, $rowsPerPage";
            } else {
                $query1 = "
                select id, 38title, 38typeid
                 from eg_item
                  where 41subjectheading like '$sub_acronym'
                  and 50item_status='1' and 38status!='UNLISTED'
                   order by 38title LIMIT $offset, $rowsPerPage";
            }
            
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
            
            if ($subject_heading_selectable == "multi") {
                $query_count = "select count(id) as total from eg_item where 41subjectheading like '%$sub_acronym".$subject_heading_delimiter."%' or  41subjectheading like '$sub_acronym".$subject_heading_delimiter."%'  or  41subjectheading like '$sub_acronym'";
            } else {
                $query_count = "select count(id) as total from eg_item where 41subjectheading like '$sub_acronym'";
            }
            
            $result_count = mysqli_query($GLOBALS["conn"], $query_count);

            $paging_type = 2;
            include_once '../sw_inc/paging-p2.php';
    ?>

            <table class=<?php echo $color_scheme."Header";?>>
                <tr><td><?php echo $subject_heading_as;?>:
                <?php
                    echo "<strong>$sub_name</strong> (<em>$num_results_affected_paging items</em>)";
                ?>
                </td></tr>
            </table>

            <table class=whiteHeaderNoCenter>
                <tr class=whiteHeader style='text-decoration:underline;'><td></td><td>Title</td><td style='width:150;'><?php echo $type_as;?></td></tr></tr>
                <?php
                        $n = $offset + 1;
                        
                        while ($myrow1 = mysqli_fetch_array($result1)) {
                            echo "<tr class=$color_scheme"."Hover>";
                                $id2 = $myrow1["id"];
                                $type2 = $myrow1["38typeid"];
                                $title2 = $myrow1["38title"];
                                
                                if (!isset($_SESSION[$ssn.'username'])) {
                                    $exploded_removed_words = explode(',', $remove_word_from_title);
                                    foreach ($exploded_removed_words as $value) {
                                        $title2 = str_replace($value, "", $title2);
                                    }
                                    $title2 = htmlspecialchars_decode($title2);
                                }
                                
                                echo "<td width=40>$n</td>";
                                echo "<td style='text-align:left;'>";
                                    if (!isset($_SESSION[$ssn.'username'])) {
                                        echo "<a class=thisonly href='../detailsg.php?det=$id2'>$title2</a>";
                                    } else {
                                        echo "<a class=thisonly href='../sw_admin/details.php?det=$id2'>$title2</a>";
                                    }
                                echo"</td>";
                                echo "<td>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $type2)."</td>";
                            echo "</tr>";
                                                                    
                            $n = $n +1 ;
                        }
                ?>
            </table>
            
            <?php
                $appendpaging = "&subacr=$get_subacr";
                include_once '../sw_inc/paging-p3.php';
            ?>
        
            <br/>
        
    <?php
        } else {
            echo "<br/>No result found.<br/><br/>";
        }
        
        echo "<a class='sButton' href='subjectbrowser.php'><span class='fas fa-arrow-circle-left'></span> Go to $subject_heading_as browser</a> ";
    ?>
        
    </div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
