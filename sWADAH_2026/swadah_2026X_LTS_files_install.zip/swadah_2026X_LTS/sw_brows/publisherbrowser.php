<?php
/*
Filename: sw_brows/publisherbrowser.php
Usage: List all created publishers
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    
    include_once '../core.php';

    // keep this page in user browser for 12 hours
    if (!isset($_SESSION[$ssn.'username']) && !isset($_SESSION[$ssn.'username_guest'])) {
        header("Cache-Control: public, max-age=43200, immutable");
        header("Expires: " . gmdate("D, d M Y H:i:s", time() + 43200) . " GMT");
        header_remove("Pragma");
    }

    include_once '../sw_inc/functions.php';
    $thisPageTitle = "$publisher_as Browser";
    sfx_check_is_blocked("../$recorded_incidents_directory/", "../");

    $_SESSION[$ssn.'previous_url'] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<html lang='en'>

<head>
    <?php
        include_once '../sw_inc/header.php';
        //autologout
        echo isset($_SESSION[$ssn.'lls']) ? '<meta http-equiv="refresh" content="1800;url=../index.php?c=ls" />' : '';

    ?>
</head>

<body class='<?php echo $color_scheme;?>'>

    <?php include_once '../sw_inc/loggedinfo.php'; ?>

    <hr>
    
    <div style='text-align:center;overflow-x:auto;width:100%;'>
        <table class=whiteHeaderNoCenter style='max-width:100%;overflow-x: auto;'>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong><?php echo $publisher_as;?> Browser</strong><br/></td></tr>
            <tr>
                <?php
                    
                    $query_pub = "select 43pubid, 43acronym, 43publisher, 43count, 43lastcount_timestamp from eg_publisher";
                    $result_pub = mysqli_query($GLOBALS["conn"], $query_pub);
                    $num_results_affected = mysqli_num_rows($result_pub);

                    $n=1;
                    while ($row_pub = mysqli_fetch_array($result_pub)) {
                        $id = $row_pub['43pubid'];
                        $acronym = $row_pub['43acronym'];
                        $publisher = $row_pub['43publisher'];
                        $count = $row_pub['43count'];
                        $lastcount_timestamp = $row_pub['43lastcount_timestamp'];

                        if ($n == 1) {
                            echo "<td style='text-align:left;vertical-align:top;display: inline-block;min-width:450px;vertical-align:top;'>";
                        }
                        
                        echo "<img src='../sw_asset/img/bw_publisher.png' style='width:16px;' alt='Year_icon'> <a class=thisonly href='publisherbrowser_details.php?subacr=$id'>$publisher</a>";
                        
                        $diff = time() - $lastcount_timestamp;
                        if ($diff <= 86400 && $item_count_generator == 'daily') {
                            $updated_timestamp = $lastcount_timestamp;
                            echo " ($count)</a>";
                        } else {
                            $updated_timestamp = time();
                            echo "
                            <script>
                            $(document).ready(function() {
                                $.ajax({
                                    url: '../sw_inc/ajax_loadpublishercount.php?p=$publisher&pid=$id',
                                    success: function(data) {
                                        $('#loadpubcount$id').html(data);
                                    }
                                })
                            });
                            </script>
                            ";
                            echo " (<span id='loadpubcount$id'></span>)</a>";
                        }
                        echo "<br/><br/>";
                                                
                        if ($n == ceil($num_results_affected/2)) {
                            echo "</td><td style='text-align:left;vertical-align:top;display: inline-block;min-width:450px;vertical-align:top;'>";
                        }
                        if ($n == $num_results_affected) {
                            echo "</td>";
                        }
                        $n=$n+1;
                    }
                ?>
            </tr>
        </table>
        <table class=whiteHeaderNoCenter><tr><td><em>Last update: <?php echo date('d M Y H:i', $updated_timestamp);?></em><br/>Publisher counts are valid for that date and time. New counts will be generated 24 hours later.</td></tr></table>
    </div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
