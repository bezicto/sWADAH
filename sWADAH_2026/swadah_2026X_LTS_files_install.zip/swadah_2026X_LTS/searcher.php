<?php
/*
Filename: searcher.php
Usage: Main search page for guests
Qualification: access point page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Guest Mode";
    session_start();define('includeExist', true);
    header("Cache-Control: max-age=3600"); // keep this page in user browser for 1 hours
    
    include_once 'core.php';
    if (!isset($_SESSION[$ssn.'username']) && !isset($_SESSION[$ssn.'username_guest'])) {
        include_once 'sw_inc/access_ip.php';
    }
    include_once 'sw_inc/functions.php';
    
    //set ref to this page
    $_SESSION[$ssn.'ref'] = 'searcher.php';
    //set what previous url user are coming from to a session variable
    $_SESSION[$ssn.'previous_url'] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    //loginless check, if loginless is for this page
    include_once 'sw_inc/loginless_check.php';
    
    //check if user current ip in on the block list for the day of access
    sfx_check_is_blocked("$recorded_incidents_directory/", "");

    if (isset($_GET['sc']) && $_GET['sc'] == 'cl') {
        //clear all session variable for searching if sc = cl
        unset($_SESSION[$ssn.'sear_scstr']);
        unset($_SESSION[$ssn.'sear_scstr_form']);
        unset($_SESSION[$ssn.'sear_ft']);
        unset($_SESSION[$ssn.'sear_sctype']);
        unset($_SESSION[$ssn.'sear_page']);
        $_SESSION[$ssn.'sear_period'] = 0;

        //if user from loginless login, find out if the daily search token limit has been crossed
        if (isset($_SESSION[$ssn.'lls']) && $_SESSION[$ssn.'lls']) {
            $stmt_fdb = $new_conn->prepare("select 44counts from eg_loginlesslog where 43date='".date('Y-m-d')."' and 43tokenid=".$_SESSION[$ssn.'lls_id']);
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            $myrow_fdb = $result_fdb->fetch_assoc();
            
            $currentdate = date('Y-m-d');

            if (isset($myrow_fdb["44counts"])) {
                if ($myrow_fdb["44counts"] > $_SESSION[$ssn.'lls_tokenlimit']) {
                    sfx_echoPopupAlert("Search has been disabled. Daily limit exceeded. Contact your administrator.","link","searcher.php");
                    $_SESSION[$ssn.'disableSearch'] = true;
                    exit;
                } else {
                    //update the counts for this date
                    $currentcount = $myrow_fdb["44counts"] + 1;
                    $stmt_update = $new_conn->prepare("update eg_loginlesslog set 44counts=? where 43tokenid=? and 43date=?");
                    $stmt_update->bind_param("iis", $currentcount, $_SESSION[$ssn.'lls_id'], $currentdate);
                    $stmt_update->execute();$stmt_update->close();
                }
            } else {
                //insert new log for this date
                $newcount = 1;
                $stmt_insert = $new_conn->prepare("insert into eg_loginlesslog values(DEFAULT,?,?,?)");
                $stmt_insert->bind_param("isi", $_SESSION[$ssn.'lls_id'], $currentdate, $newcount );
                $stmt_insert->execute();$stmt_insert->close();
            }
        }

    } elseif (isset($_GET['sc']) && $_GET['sc'] != 'cl') {
        //limitation of use of sc variable. make sure that only cl is permitted. or will result in complete banned (to be implemented later.).
        sfx_record_block("$recorded_incidents_directory/");
    }

    //handling back from other pages -- if user manipulated the query string using url, and alter the scstr value, it will automatically unset the current page the user is in
    if (
        (isset($_GET['scstr']) && isset($_SESSION[$ssn.'sear_scstr']) && $_GET['scstr'] != $_SESSION[$ssn.'sear_scstr'])
        || (isset($_GET['sctype']) && isset($_SESSION[$ssn.'sear_sctype']) && $_GET['sctype'] != $_SESSION[$ssn.'sear_sctype'])
        ) {
        unset($_SESSION[$ssn.'sear_page']);
        if ($debug_mode == 'yes') {echo "back_handling | ";}
    }

    //handling scstr from search fields
    if (isset($_GET['scstr']) && $_GET['scstr'] != '') {
        //new 20250624 -- to make sure commo words are removed from the search term
        $scstr_term = sfx_filterCommonWords($_GET['scstr']);
        $_SESSION[$ssn.'sear_scstr'] = htmlspecialchars($scstr_term);

        $_SESSION[$ssn.'sear_scstr'] = preg_replace('/\s+/', ' +', "+".sfx_just_clean($_SESSION[$ssn.'sear_scstr']));//add plus sign in front of every word
        $_SESSION[$ssn.'sear_scstr_form'] = sfx_just_clean($_SESSION[$ssn.'sear_scstr']);
        $all_upper_scstr = strtoupper($_SESSION[$ssn.'sear_scstr']);//change them to upper
        sfx_checkstring_Exist_And_redirect_to_parent($all_upper_scstr, "SCSTR", "searcher.php?sc=cl");//prevent user misusing scstr
    }

    //handling sctype from search fields
    if (isset($_GET['sctype'])) {
        $_SESSION[$ssn.'sear_sctype'] = htmlspecialchars($_GET['sctype']);
        if (!is_numeric($_SESSION[$ssn.'sear_sctype']) && $_SESSION[$ssn.'sear_sctype'] != 'EveryThing') {
            sfx_record_block("$recorded_incidents_directory/");
        }
    }

    //handling specific period search
    if (isset($_GET['p']) && strlen($_GET['p']) <= 4) {
        $periodMap = [
            '1y' => 1,
            '3y' => 3,
            '5y' => 5
        ];
        
        $_SESSION[$ssn.'sear_period'] = isset($periodMap[$_GET['p']]) ? $periodMap[$_GET['p']] : 0;
    }

    //handling search full text checkbox
    if (isset($_GET['sear_ft'])) {
        $_SESSION[$ssn.'sear_ft'] = ($_GET['sear_ft'] == 1) ? 1 : 0;
    }
    
    //handling page from pagination
    if (isset($_GET['page'])) {
        $_SESSION[$ssn.'sear_page'] = htmlspecialchars($_GET['page']);
        if (!is_numeric($_SESSION[$ssn.'sear_page'])) {
            sfx_record_block("$recorded_incidents_directory/");
        }
    }
    
    //debugging
    if ($debug_mode == 'yes') {
        $debug_output = "<span style='color:pink;'>Debugging Mode Running: </span> ".session_id();
    }

    //if from app
    if (isset($_GET['from']) && $_GET['from'] == 'app') {
        $_SESSION[$ssn.'fromapp'] = true;
    }
?>
<html lang='en'>

<head>
    <?php
        include_once 'sw_inc/header.php';
        
        //autologout
        if (isset($_SESSION[$ssn.'lls'])) {
            echo "<meta http-equiv=\"refresh\" content=\"1800;url=index.php?c=ls\" />";
        }
    ?>
    
    <link rel="stylesheet" type="text/css" href="<?= $appendroot;?>sw_asset/css/searcher.css<?= "$refresh_component";?>"/>

    <script>
        // Fungsi untuk memuatkan semula kandungan div
        function js_loadDivContent() {
            const xhr = new XMLHttpRequest();
            const url = 'sw_inc/load_readitems.php?t=' + new Date().getTime();// Tambah timestamp untuk mengelakkan cache
            xhr.open('GET', url, true);  // Gantikan dengan fail atau endpoint yang mengandungi data yang diingini
            xhr.onload = function () {
                if (xhr.status === 200) {
                    document.getElementById('refreshDiv1').innerHTML = xhr.responseText;
                    // Simpan state selepas kandungan dimuat
                    history.pushState({ html: xhr.responseText }, '');
                }
            };
            xhr.send();
        }

        // Event listener untuk mengesan butang 'Back'
        window.addEventListener('popstate', function(event) {
            if (event.state) {
                // Muatkan kandungan dari state yang disimpan
                document.getElementById('refreshDiv1').innerHTML = event.state.html;
            }
        });

        // Muatkan kandungan semasa page di-load
        window.onload = function () {
            // Muatkan kandungan semasa halaman dimuatkan
            js_loadDivContent();
            // Simpan state semasa halaman pertama kali dimuatkan
            history.replaceState({ html: document.getElementById('refreshDiv1').innerHTML }, '');
        };

        window.addEventListener('pageshow', function (event) {
            // Semak jika halaman dimuat dari cache
            if (event.persisted) {
                js_loadDivContent(); // Muatkan semula kandungan
            }
        });
    </script>
</head>

<body class='<?= $color_scheme;?>'>
    <div id="navbar" style='text-align:center;z-index:1000;'>
        <?php include 'sw_inc/index2_s_form.php'; ?>
    </div>
    
    <?php include_once 'sw_inc/loggedinfo.php'; ?>

    <hr>

    <?php
        if (!isset($_SESSION[$ssn.'sear_scstr']) && $searcher_active_popular_keyword) {
            include_once 'sw_inc/popularkeywords.php';
        }
    ?>
    <table class=whiteHeader>
        <tr><td>
            <?php
                include 'sw_inc/index2_s_form.php';
            ?>
        </td></tr>
        <tr><td>
            <?php
                if ($show_browser_bar_guest) {
                    include_once 'sw_inc/browser_bar.php';
                }
            ?>
        </td></tr>
    </table>

    <div style='text-align:center;'>
        <?php
            //start paging 1
            if (isset($_SESSION[$ssn.'sear_page'])) {
                $currentPage = $_SESSION[$ssn.'sear_page'];
            }

            include_once 'sw_inc/paging-p1.php';
            
            if (isset($_SESSION[$ssn.'sear_scstr']) || isset($_SESSION[$ssn.'sear_sctype'])) {
                $latest = "FALSE";
                $scstr_term = $_SESSION[$ssn.'sear_scstr'] ?? '';
                $scstr_period = $_SESSION[$ssn.'sear_period'] ?? 0;
                include_once 'sw_inc/index2_insertintostat.php';//insert search term into log table
                include_once 'sw_inc/index2_s_allseing.php';
            } else {
                //for first time run
                $latest = "TRUE";
                $scstr_term = "";
                $query1 = "select SQL_CALC_FOUND_ROWS
                eg_item.id as id, eg_item.38title as 38title, eg_item.38folderid as 38folderid, eg_item.38typeid as 38typeid,
                eg_item.38author as 38author, eg_item.38source as 38source, eg_item.39inputdate as 39inputdate, eg_item.41hits as 41hits,
                eg_item.38link as 38link, eg_item.41fulltexta as 41fulltexta, eg_item.41isabstract as 41isabstract, eg_item.38localcallnum as 38localcallnum,
                    eg_item.38publication as 38publication, eg_item.41instimestamp as 41instimestamp,
                    eg_item2.38publication_c as 38publication_c
                    from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id where eg_item.id<>0
                    and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' order by eg_item.id desc LIMIT $offset, $rowsPerPage";
                    }
                                                                        
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
            
            //start paging 2
            include_once 'sw_inc/paging-p2.php';
            
            //show table header depending on the user interaction with the page
            if ($latest == "FALSE") {
                echo "<table class=whiteHeaderNoCenter><tr><td>Total records found : $num_results_affected_paging</td></tr></table>";
                include_once 'sw_inc/index2_sgmtdsrch.php';//load segmented search box
            } else {
                echo "<table class=whiteHeaderNoCenter><tr><td><strong>Latest addition to the database :</strong></td></tr></table>";
            }
            
            //if function other than photo mode
            if ($system_function != 'photo') {
                //responsive 2 divs inside a container
                echo "<div class=\"container\">";
                    //first div
                    echo "<div class=\"first-div\">";
                        $n = $offset + 1;
                        echo "<table class=whiteHeaderNoCenter>";
                        while ($myrow1 = mysqli_fetch_array($result1)) {
                            
                            $id2 = $myrow1["id"];
                            $titlestatement2 = $myrow1["38title"];
                            $folderid2 = $myrow1["38folderid"];
                            $typestatement2 = $myrow1["38typeid"];
                            $authorname2 = $myrow1["38author"];
                            $sumber2 = $myrow1["38source"];
                            $inputdate2 = $myrow1["39inputdate"];
                                $dir_year2 = substr("$inputdate2", 0, 4);
                            $hits2 = $myrow1["41hits"];
                            $link2 = $myrow1["38link"];
                            $fulltext2 = $myrow1["41fulltexta"];
                            $isabstract2 = $myrow1["41isabstract"];
                            $localcallnum2 = $myrow1["38localcallnum"];
                            $publication2 = $myrow1["38publication"];
                            $instimestamp2 = $myrow1["41instimestamp"];
                            $yearofpublication = !empty($myrow1["38publication_c"]) && is_int((int)$myrow1["38publication_c"]) ? (int)$myrow1["38publication_c"] : 0;

                                echo "<tr class=$color_scheme"."Hover>";
                                    echo "<td style='text-align:center;vertical-align:top;width:50px;'><strong>$n</strong></td>";
                                    
                                    echo "<td style='text-align:center;vertical-align:top;color:#0066CC;font-size:10px;' width=28>";
                                        if ($yearofpublication <> 0) {
                                            echo "$yearofpublication<br/>";
                                        }
                                        echo "<strong>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $typestatement2)."</strong><br/><i style='font-size:16px;margin-top:5px;' class=\"fas fa-file\"></i>";
                                    echo "</td>";
                                    
                                    echo "<td style='text-align:left;position:relative;'>";

                                        //title
                                        $exploded_removed_words = explode(',', $remove_word_from_title);
                                        foreach ($exploded_removed_words as $value) {
                                            $titlestatement2 = str_replace($value, "", $titlestatement2);
                                        }
                                        $converted_title = htmlspecialchars_decode($titlestatement2);
                                        if (isset($scstr_term) && $scstr_term <> null) {
                                            echo " <a style='font-size:$searcher_title_font_size;' title='Click here to view detail' class='myclassOri' href='detailsg.php?det=$id2&highlight=$scstr_term'>".sfx_highlight($converted_title, $scstr_term)."</a>";
                                        } else {
                                            echo " <a style='font-size:$searcher_title_font_size;' title='Click here to view detail' class='myclassOri' href='detailsg.php?det=$id2'>$converted_title</a>";
                                        }

                                        //show locked icon for item unpermitted for current user
                                        if (((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) && $folderid2 != 0) {
                                            if (isset($_SESSION[$ssn.'username'])) {
                                                $auth_user = $_SESSION[$ssn.'username'];
                                            } elseif (isset($_SESSION[$ssn.'username_guest'])) {
                                                $auth_user = $_SESSION[$ssn.'username_guest'];
                                            }
                                            
                                            $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$folderid2'";
                                            $result_user = mysqli_query($GLOBALS["conn"], $query_user);
                                            if (mysqli_num_rows($result_user) != 1) {
                                                echo " <img src='sw_asset/img/cu_locked.png' width=16 alt='Click to view' title='Item locked to you'>";
                                            }
                                        } elseif ($folderid2 != 0) {
                                            echo " <img src='sw_asset/img/cu_locked.png' width=16 alt='Click to view' title='Item locked to you'>";
                                        }
                                        
                                        //author
                                        if ($authorname2 != '') {
                                            echo "<br/><a style='font-size:$searcher_author_font_size;' title='Click here to search more titles from this author' class=myclass2 href='searcher.php?scstr=$authorname2&sctype=EveryThing&sc=cl'>$authorname2</a>";
                                        } else {
                                            if ($publication2 != '') {
                                                echo "<br/><span style='font-size:$searcher_author_font_size;'>$publication2</span><br/>";
                                            } else {
                                                echo "<br/><em>Unknown author</em><br/>";
                                            }
                                        }
                                        
                                        if ($fulltext2 != null && $isabstract2 == 1) {
                                            echo "<br/><input type='button' class='form-green-button-noshadow' style='font-size:8pt' value='ABSTRACT'> <div style='font-weight:normal;'>".sfx_highlight(sfx_cutText(strip_tags(html_entity_decode($fulltext2)),1000), $scstr_term ?? '')."..</div><br/>";
                                        }

                                        //indicators
                                        if ($searcher_show_icon_indicator) {
                                            echo "<br/>";
                                            if ($fulltext2 != null && $fulltext2 != '<html />') {
                                                if ($isabstract2 == 1) {
                                                    echo "<img src='sw_asset/img/ind_abstract_yes.png' width=24 alt='Click to view' title='HTML Abstract'>";
                                                } else {
                                                    echo "<img src='sw_asset/img/ind_html_yes.png' width=24 alt='Click to view' title='HTML Full Text'>";
                                                }
                                            }

                                            if ($link2 <> null) {
                                                $link2 = urldecode($link2);
                                                if (substr($link2, 0, 4) != 'http') {
                                                    $link2 = 'http://'.$link2;
                                                }
                                                if (isset($link2) && strpos($link2, 'youtube.com') !== false && $youtube_detector) {
                                                    echo "<img src='sw_asset/img/ind_youtube.png' width=24 alt='Click to view' title='Quick access to YouTube for this item.'>";
                                                } else {
                                                    echo " <img src='sw_asset/img/ind_url_yes.png' width=24 alt='Click to view' title='HTML Link Available'>";
                                                }
                                            }

                                            if (is_file("$system_docs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf")) {
                                                echo " <img src='sw_asset/img/ind_pdf_yes.png' width=24 alt='Click to view' title='PDF Available'>";
                                            }
                                            
                                            //for handling freetype
                                            if (is_dir("$system_isofile_directory/$dir_year2")) {
                                                $files_scanned = scandir("$system_isofile_directory/$dir_year2");
                                                foreach ($files_scanned as $fileitem) {
                                                    if (preg_match("/$id2"."_"."$instimestamp2/i", $fileitem) == 1) {
                                                        echo " <img src='sw_asset/img/ind_general_file.png' width=24 alt='Click to view' title='$system_isofile_name Available'>";
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //hits view
                                        echo "<div style='position:absolute;bottom:20px;right:5px;font-size:$searcher_hits_font_size;'>$hits2 hits</div>";
                                        echo "<hr style='border-top: 1px solid #e8feff;'>";
                                    echo "</td>";

                                echo "</tr>";
                                $n = $n +1 ;
                        }
                        echo "</table>";

                        //start paging 3
                        if ($maxPage > 1) {
                            include_once 'sw_inc/paging-p3.php';
                        }
                    echo "</div>";//end of first div
                    
                    //second div
                    echo "<div class=\"second-div\">";
                        echo "<div style='width:100%;overflow:hidden;word-wrap:break-word;'>";
                            echo "<table class='$color_scheme"."Widget' style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;'>
                                <tr><td>Filter</td></tr>
                                <tr style='background-color:white;'><td style='text-align:left;'>
                                    <div id=\"results\">
                                        <div style='margin-top:10px;'><em>Loading results...</em></div>
                                    </div>";
                                //20241118 - possible slower filter, will recheck later
                                sfx_echoAjaxOutput("sw_inc/load_filter1.php?scstr=$scstr_term&nump=".$num_results_affected_paging,"results");
                            echo "<br/></td></tr></table><br/><br/>";

                            echo "<table class='$color_scheme"."Widget' style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;'>
                                <tr><td>Specific Period</td></tr>
                                <tr style='background-color:white;'><td style='text-align:left;'>
                                    <div id=\"results2\">
                                        <div style='margin-top:10px;'><em>Loading results...</em></div>
                                    </div>";
                                sfx_echoAjaxOutput("sw_inc/load_filter2.php?scstr=$scstr_term&scsel=$sctype_select&nump=$num_results_affected_paging","results2");
                            echo "<br/></td></tr></table><br/><br/>";

                            echo "<table class='$color_scheme"."Widget' style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;'>
                                <tr><td>Top 5 related keywords (beta)</td></tr>
                                <tr style='background-color:white;'><td style='text-align:left;'><br/>
                                    <div id=\"results3\"><div style='margin-top:10px;'><em>Loading results...</em></div></div>";
                                    sfx_echoAjaxOutput("sw_inc/load_filter3.php?scstr=$scstr_term","results3");
                                    echo "<br/></td></tr>
                            </table><br/><br/>";

                            echo "<table class='$color_scheme"."Widget' style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;'>
                                <tr><td>Recently Access Item</td></tr><tr style='background-color:white;'><td style='text-align:left;'><br/>
                                    <div id=\"refreshDiv1\"></div>
                            <br/></td></tr></table>";
                        echo "</div>";
                    echo "</div>";//end of second div
                echo "</div>";//container
            } elseif ($system_function == 'photo') {
                //for photo mode
                echo "<table style='background-color:white;border: 0px solid black; width:100%;overflow-x: auto;'><tr>";
                    $n = $offset + 1;
                    while ($myrow1 = mysqli_fetch_array($result1)) {
                        $id2 = $myrow1["id"];

                        $titlestatement2 = $myrow1["38title"];
                        $exploded_removed_words = explode(',', $remove_word_from_title);
                        foreach ($exploded_removed_words as $value) {
                            $titlestatement2 = str_replace($value, "", $titlestatement2);
                        }
                        
                        $authorname2 = !empty($myrow1["38author"]) ? $myrow1["38author"] : "N/A";
                        $dir_year2 = substr($myrow1["39inputdate"], 0, 4);
                        $instimestamp2 = $myrow1["41instimestamp"];
                        
                        echo "<td style='font-size:8pt;display: inline-block;'><div style='width:350px;height:360px;overflow:hidden;word-wrap:break-word;'>
                            <table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>
                            <tr><td style='text-align:center;'>
                                <a title='Click here to view detail' class='myclassOri' href='detailsg.php?det=$id2'>";
                                        if (is_file("$system_albums_watermark_directory/$dir_year2/$id2"."_"."$instimestamp2.jpg")) {
                                            echo "<img style='border-radius: 10px;' class='centered-and-cropped' src='sw_inc/image.php?d=$id2&t=t' width=300px height=300px>";
                                        } else {
                                            echo "<img style='border-radius: 10px;' src='sw_asset/img/no_image.png' width=300px width=300px>";
                                        }
                                echo "</a>";
                                echo "<br/><span title='$titlestatement2'>".sfx_cutText($titlestatement2,40)."</span><br/><span style='color:green;'>$authorname2</span>";
                                if ($system_function == 'photo') {
                                    $total_photos = sfx_countImageForID($appendroot,$id2);//will take a look this code later to make it more fast
                                    echo "<br/><em style='color:green;'>$total_photos photos</em>";
                                    mysqli_query($GLOBALS["conn"], "update eg_item set 52photo_count=$total_photos where id=$id2");
                                }
                            echo "</td></tr>
                            </table>";
                        echo "</div></td>";
                        $n = $n +1 ;
                    }
                echo "</tr></table>";

                //start paging 3
                if ($maxPage > 1) {
                    include_once 'sw_inc/paging-p3.php';
                }
            }
        ?>
    </div>
    
    <br/><hr>
    
    <?php include_once 'sw_inc/footer.php'; ?>

    <script>
        window.onscroll = function() {
            var navbar = document.getElementById("navbar");
            if (window.pageYOffset > 100) {
                navbar.classList.add("show");
            } else {
                navbar.classList.remove("show");
            }
        };
    </script>

    <?php
    if ($debug_mode == 'yes') {
    ?>
        <div class='footer' style='width:100%;text-align:center;'>
        <?php
            echo "<span style='font-size:8pt;'>$debug_output <span style='color:cyan;'>Final query:</span> <span style='color:yellow;'>".$query1."</span></span> ";
            include_once 'sw_inc/view_storedSession.php';
            echo ($print_sessvar ?? '') . " <strong>URL:</strong> <span style='color:lightgrey;'>" . sfx_getCurrentBaseURL() . "</span> <strong>Accessed from:</strong> " . sfx_get_ip();
        ?>
        </div>
    <?php
    }
    ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
