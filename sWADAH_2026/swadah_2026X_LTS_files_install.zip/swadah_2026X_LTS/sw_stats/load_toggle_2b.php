<?php
/*
Filename: sw_stats/load_toggle_2b.php (Access)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change:
20250619.1433 introducing new queries to count session,access,download
*/

    include_once '../sw_inc/access_isset.php';
?>
<table class=whiteHeader><tr class=<?php echo $color_scheme."HeaderCenter";?>><td>
    <form name="getMonthStat" action="adsreport.php?toggle=2b" method=post>
        Yearly stats: <input type="text" name="acyearly" size="5" <?php if (isset($_REQUEST['acyearly']) && is_numeric($_REQUEST['acyearly'])) {echo 'value="'.$_REQUEST['acyearly'].'"';}?> maxlength="4"/>
    </form>
</td></tr></table>

<table class=whiteHeader>
<tr class=whiteHeaderCenterUnderline><td></td><td style='text-align:left;'><?php echo $type_as;?></td>
    <td style='width:20%;'>Total Item</td>
    <td style='width:20%;'>Total Session</td>
    <td style='width:20%;'>Total Access</td>
    <td style='width:20%;'>Total Download</td>
</tr>
<?php
    $query2r = "select 38type, 38typeid, 38synonym from eg_item_type";
    $result2r = mysqli_query($GLOBALS["conn"], $query2r);
    $m2r = 1;
    $total_item2r = 0;
    $total_session2r = 0;
    $total_access2r = 0;
    $total_download2r = 0;

    $inputyear = (isset($_REQUEST["acyearly"]) && is_numeric($_REQUEST["acyearly"])) ? $_REQUEST["acyearly"] : date('Y');

    $endts = strtotime($_REQUEST['acyearly']."-12-31 23:59:59");

    while ($myrow2r = mysqli_fetch_array($result2r)) {
        $typestatement2r = $myrow2r["38typeid"];
        $typedesc2r = $myrow2r["38type"];
        $typesynonym2r = $myrow2r["38synonym"];

        //new to cache count on file 31102023
        if (file_exists("../".$GLOBALS["system_statcache_directory"]."/alltypstat/$inputyear"."_".$typestatement2r.".txt") && (date('Y') > $inputyear)) {
            $lines = file("../".$GLOBALS["system_statcache_directory"]."/alltypstat/$inputyear"."_".$typestatement2r.".txt");
            $item_total_ts = $lines[0];
            $session_total_ts = $lines[1];
            $hits_total_ts = $lines[2];
            $num_download_ts = $lines[3];
        } else {
            $get_new_value = true;
            if (file_exists("../".$GLOBALS["system_statcache_directory"]."/alltypstat/$inputyear"."_".$typestatement2r.".txt"))
            {
                $lines = file("../".$GLOBALS["system_statcache_directory"]."/alltypstat/$inputyear"."_".$typestatement2r.".txt");
                $timestamp_recorded = $lines[4];
                $diff = time() - $timestamp_recorded;
                if ($diff <= 86400) {
                    $item_total_ts = $lines[0];
                    $session_total_ts = $lines[1];
                    $hits_total_ts = $lines[2];
                    $num_download_ts = $lines[3];
                    $get_new_value = false;
                }
            }
            if ($get_new_value) {
                //count by 41instimestamp
                //count total number of item for all type
                $query_totalcount_ts = "select count(id) as totalid from eg_item where 38typeid='$typestatement2r' and 41instimestamp<=$endts";
                $result_totalcount_ts = mysqli_query($GLOBALS["conn"], $query_totalcount_ts);
                $myrow_totalcount_ts = mysqli_fetch_array($result_totalcount_ts);
                $item_total_ts = $myrow_totalcount_ts["totalid"];

                //count total session of all item for all type (group by similarly ippaddress and logdate to prevent multiple counting)
                $query_totalsession_ts = "select count(DISTINCT(concat(eg_item_access.39ipaddr, SUBSTRING_INDEX(eg_item_access.39logdate,' ', 2)))) as ccount
                                    from eg_item_access inner join eg_item on eg_item_access.eg_item_id=eg_item.id
                                    where eg_item.38typeid='$typestatement2r' and YEAR(STR_TO_DATE(eg_item_access.39logdate, '%a %d/%m/%Y %l:%i %p')) = $inputyear";
                $result_totalsession_ts = mysqli_query($GLOBALS["conn"], $query_totalsession_ts);
                $myrow_totalsession_ts = mysqli_fetch_array($result_totalsession_ts);
                $session_total_ts = $myrow_totalsession_ts["ccount"];
             
                //count total hits/access for all type
                $query_access_ts = "select count(eg_item_access.id) as totalhits
                                    from eg_item_access inner join eg_item on eg_item_access.eg_item_id=eg_item.id
                                     where eg_item.38typeid='$typestatement2r' and YEAR(STR_TO_DATE(eg_item_access.39logdate, '%a %d/%m/%Y %l:%i %p')) = $inputyear";
                $result_access_ts = mysqli_query($GLOBALS["conn"], $query_access_ts);
                $myrow_access_ts = mysqli_fetch_array($result_access_ts);
                $hits_total_ts = $myrow_access_ts["totalhits"];

                //count download for all type -- 20250619 beta
                $query_download_ts = "select count(eg_item_download.id) as totalid
                                     from eg_item_download inner join eg_item on eg_item_download.eg_item_id=eg_item.id
                                      where eg_item.38typeid='$typestatement2r' and YEAR(STR_TO_DATE(eg_item_download.39logdate, '%a %d/%m/%Y %l:%i %p')) = $inputyear";
                $result_download_ts = mysqli_query($GLOBALS["conn"], $query_download_ts);
                $myrow_download_ts = mysqli_fetch_array($result_download_ts);
                $num_download_ts = $myrow_download_ts["totalid"];

                file_put_contents("../".$GLOBALS["system_statcache_directory"]."/alltypstat/$inputyear"."_".$typestatement2r.".txt", $item_total_ts."\n".$session_total_ts."\n".$hits_total_ts."\n".$num_download_ts."\n".time());
                $timestamp_recorded = time();
            }
        }
        //end

        $total_item2r = $total_item2r + $item_total_ts;
        $total_session2r = $total_session2r + $session_total_ts;
        $total_access2r = $total_access2r + $hits_total_ts;
        $total_download2r = $total_download2r + $num_download_ts;

        echo "<tr><td>$m2r</td><td style='text-align:left;'>$typesynonym2r</td><td>$item_total_ts</td><td>$session_total_ts</td><td>$hits_total_ts</td><td>$num_download_ts</td></tr>";
        $m2r=$m2r+1;
    }
?>
<tr style='background-color:lightgrey'><td colspan=2 style='text-align:right;background-color:white;'><em>Total</em></td>
    <td style='width:20%;'><em><?php echo $total_item2r;?></em></td>
    <td style='width:20%;'><em><?php echo $total_session2r;?></em></td>
    <td style='width:20%;'><em><?php echo $total_access2r;?></em></td>
    <td style='width:20%;'><em><?php echo $total_download2r;?></em></td>
</tr>
</table>

<table style='margin-top:10px;width:100%;'><tr><td>
    <strong>Total item:</strong> All item cumulatively <u>since the beginning of system</u> until the selected year.
    <br/><strong>Total session:</strong> Total session ONLY for the selected year.
    <br/><strong>Total Acccess:</strong> Total hits/page access ONLY for the selected year.
    <?php
    if ($inputyear == date('Y')) {
        echo "<br/><br/><em>Statistic generated date and time: ".date('Y-m-d H:i:s', $timestamp_recorded)."<br/>
        Statistic is valid for that date and time. New statistic will be generated 24 hours later.</em>";
    }
    ?>
</td></tr></table>
