<?php
/*
Filename: sw_stats/adsreport_typedetails.php
Usage: Total input report by type segmented by month/year
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Type Details";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/functions.php';

    $typeid = $_GET["type"];
    $typetext = sfx_sGetValue('38synonym', 'eg_item_type', '38typeid', $typeid);

    if (!is_numeric($typeid)) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Invalid parameter detected.</h2><em>sWADAH Response Code</em></div>";
        mysqli_close($GLOBALS["conn"]); exit();
    }

    if (!is_dir("../$system_statcache_directory/itmtypstat")) {
        mkdir("../$system_statcache_directory/itmtypstat", 0755, true);
        file_put_contents("../$system_statcache_directory/itmtypstat/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/itmtypstat/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
    }

    if (!is_dir("../$system_statcache_directory/itmtypstat/$typeid")) {
        mkdir("../$system_statcache_directory/itmtypstat/$typeid", 0755, true);
        file_put_contents("../$system_statcache_directory/itmtypstat/$typeid/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/itmtypstat/$typeid/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
    }
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
        
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
                    
    <hr>

    <div style="text-align:center">
    <?php
        
    
        echo "<table class=$color_scheme"."Header"."300 style='width:450px;'><tr><td>";
            $query_year = "select distinct SUBSTRING(39inputdate,1,4) AS inputyear from eg_item order by inputyear";
            $result_year = mysqli_query($GLOBALS["conn"], $query_year);
            echo "<strong>Select year</strong> : ";
                        
            echo "<select name=\"inputyear\" ONCHANGE=\"location = this.options[this.selectedIndex].value;\">";
            echo "<option value='adsreport_typedetails.php?inputyear=".date('Y')."&type=$typeid'>-Current Year-</option>";
            while ($myrow_year = mysqli_fetch_array($result_year)) {
                $inputyear = $myrow_year["inputyear"];
                echo "<option value=\"adsreport_typedetails.php?inputyear=$inputyear&type=$typeid\"";
                if ((isset($_GET["inputyear"]) && $_GET["inputyear"] == $inputyear) || (!isset($_GET["inputyear"]) && $inputyear == date('Y'))) {
                    echo " selected";
                }
                echo ">$inputyear</option>";
            }
            echo "</select>";
        echo "</td></tr></table>";
    
        echo "<table class=$color_scheme"."Header"."300 style='width:450px;'>";
            echo "<tr><td><strong>$typetext Statistics</strong> : ";
        echo "</td></tr></table>";
                                                
        echo "<table class=whiteHeader300 style='width:450px;'>";
            echo "<tr><td>Month</td><td width=80>Total Index</td><td width=80>Total Index (Cumulative)</td></tr>";

            $inputyear = (isset($_GET["inputyear"]) && is_numeric($_GET["inputyear"])) ? $_GET["inputyear"] : date('Y');

            $lastyear = $inputyear-1;
            $lastyear_ts = strtotime("$lastyear-12-31 23:59:59");
            $query_total_lastyear = "select count(id) as totalid from eg_item where 38typeid='$typeid' and 41instimestamp < $lastyear_ts";
            $result_total_lastyear = mysqli_query($GLOBALS["conn"], $query_total_lastyear);
            $myrow_total_lastyear = mysqli_fetch_array($result_total_lastyear);
            $num_results_affected_lastyear = $myrow_total_lastyear["totalid"];
            echo "<tr><td colspan=2 style='color:blue;text-align:right;'>Total from last year ($lastyear)</td><td width=80 style='color:blue;'>$num_results_affected_lastyear</td></tr>";
                                                                                            
            $total_counter = 0;

            for ($counter = 1; $counter <= 12; $counter += 1) {
                $counterc = ($counter <= 9) ? "0$counter" : "$counter";
                $query_total = "select count(id) as totalid from eg_item where 38typeid='$typeid' and 39inputdate like '$inputyear-$counterc%'";

                if (file_exists("../".$GLOBALS["system_statcache_directory"]."/itmtypstat/$typeid/$counterc".$inputyear."_totalindex.txt") && (date('Y') > substr($counterc.$inputyear, 2))) {
                    $lines = file("../".$GLOBALS["system_statcache_directory"]."/itmtypstat/$typeid/$counterc".$inputyear."_totalindex.txt");
                    $num_results_affected = $lines[0];
                } else {
                    $result_total = mysqli_query($GLOBALS["conn"], $query_total);
                    $myrow_total = mysqli_fetch_array($result_total);
                    $num_results_affected = $myrow_total["totalid"];
                    file_put_contents("../".$GLOBALS["system_statcache_directory"]."/itmtypstat/$typeid/$counterc".$inputyear."_totalindex.txt", $num_results_affected."\n".time());
                }
            
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$counter/$inputyear</td>";
                    $total_counter = $total_counter + $num_results_affected;
                    echo "<td>$num_results_affected</td><td>$total_counter</td>";
                echo "</tr>";
            }
                
           echo "<tr style='background-color:lightgrey;'><td style='color:green;'>Total</td><td style='color:green;'>$total_counter</td><td style='color:green;'>".$total_counter+$num_results_affected_lastyear."</td></tr>";
        echo "</table>";
    ?>

    <br/><br/><a class='sButton' href='adsreport.php?toggle=2a'><span class='fas fa-arrow-circle-left'></span> Back to report page</a>
    
    </div>
    
    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
