<?php
/*
Filename: sw_stats/adsreport_depodetails.php
Usage: Details for all deposited item within the hitsDate provided by $_GET
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Deposit Activity Report";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>

    <div style="text-align:center">
    
        <?php
            
            $hitsDate = $_GET['hitsDate'];

            $param = "%".$hitsDate."%";
            $stmt_fsb = $new_conn->prepare("select SQL_CALC_FOUND_ROWS * from eg_item_depo where DATE_FORMAT(FROM_UNIXTIME(timestamp), '%d/%m/%Y') like ? order by timestamp desc");
            $stmt_fsb->bind_param("s", $param);//s string
            $stmt_fsb->execute();
            $result_fsb = $stmt_fsb->get_result();
            $num_results_affected = $result_fsb->num_rows;
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=$color_scheme"."HeaderCenter><td colspan=5>Total deposit : <strong>$num_results_affected</strong> for <strong>$hitsDate</strong></td></tr>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'><td></td><td><strong>Item</strong></td><td><strong>Depositor</strong></td><td><strong>Deposit Date</strong></td><td><strong>Current Status</strong></td></tr>";
                                                                
                $n = 1;
                
                while ($myrow_fsb = $result_fsb->fetch_assoc()) {
                    echo "<tr class=$color_scheme"."Hover>";
                        $query_title = "select 29titlestatement as title,inputby,timestamp,itemstatus from eg_item_depo where id=".$myrow_fsb["id"];
                        $result_title = mysqli_query($GLOBALS["conn"], $query_title);
                        $myrow_title = mysqli_fetch_array($result_title);
                            $title_fsb = stripslashes($myrow_title['title']);
                            $inputby_fsb = $myrow_title['inputby'];
                            $submitted_fsb = date('d/m/Y H:i:s', $myrow_fsb["timestamp"]);
                            $itemstatus_fsb = $myrow_title['itemstatus'];
                        
                        echo "<td>$n</td><td style='text-align:left;'>$title_fsb</td><td>$inputby_fsb</td><td>$submitted_fsb</td><td>$itemstatus_fsb</td>";
                    echo "</tr>";
                    $n = $n +1 ;
                }
            echo "</table>";
                                                            
        ?>
        
        <br/><br/>
        <a class='sButton' href='javascript:window.close();'><span class="fa-solid fa-rectangle-xmark"></span> Close</a>
    
    </div>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
