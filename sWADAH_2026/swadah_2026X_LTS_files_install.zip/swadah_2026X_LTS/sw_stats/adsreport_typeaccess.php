<?php
/*
Filename: sw_stats/adsreport_typeaccess.php
Usage: Access details by type includes session,access,download
Version: 20250408.1208
Last change: -
20250408.1208 introducing caching mechnism for session,access,download to prevent multiple query to database
20250619.1433 introducing new queries to count session,access,download
*/
?>
<!DOCTYPE HTML>
<?php
    set_time_limit(0);
    $thisPageTitle = "Type Access Details";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/functions.php';

    $typeid = $_GET["type"];
    $typetext = sfx_sGetValue('38synonym', 'eg_item_type', '38typeid', $typeid);
    
    if (!is_numeric($typeid)) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Invalid parameter detected.</h2><em>sWADAH Response Code</em></div>";
        mysqli_close($GLOBALS["conn"]); exit();
    }

    if (!is_dir("../$system_statcache_directory/acsdwlstat")) {
        mkdir("../$system_statcache_directory/acsdwlstat", 0755, true);
        file_put_contents("../$system_statcache_directory/acsdwlstat/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/acsdwlstat/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
    }

    if (!is_dir("../$system_statcache_directory/acsdwlstat/$typeid")) {
        mkdir("../$system_statcache_directory/acsdwlstat/$typeid", 0755, true);
        file_put_contents("../$system_statcache_directory/acsdwlstat/$typeid/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/acsdwlstat/$typeid/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
    }
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
                    
    <div style="text-align:center">
        <?php
                $inputyear = (isset($_GET["inputyear"]) && is_numeric($_GET["inputyear"])) ? $_GET["inputyear"] : date('Y');
                
                //input years listing
                echo "<table class=$color_scheme"."Header"."300 style='width:450px;'><tr class=$color_scheme"."HeaderCenter><td>";
                    echo "<strong>Select year</strong> : ";
                    echo "<input type='text' id='inputyear' maxlength=4 size=10 name='inputyear' value='$inputyear'> <input type='button' value='Generate' onclick=\"window.location='adsreport_typeaccess.php?inputyear='+document.getElementById('inputyear').value+'&type=$typeid'\">";
                echo "</td></tr></table>";

                if (isset($_GET["inputyear"]) && is_numeric($_GET["inputyear"])) {
                    echo "<table class=$color_scheme"."Header"."300 style='width:450px;'>";
                        echo "<tr class=$color_scheme"."HeaderCenter><td><strong>$typetext access statistics</strong> : </td></tr>";
                    echo "</table>";
                
                    echo "<table class=whiteHeader300 style='width:450px;'>";
                        echo "<tr><td width=80>Month</td><td width=80>Session</td><td width=80>Access</td>";
                            if ($system_function != "photo") {
                                echo "<td width=80>Download</td>";
                            }
                        echo "</tr>";
                        
                        $total_t_access = 0;
                        $total_t_session = 0;
                        $total_d_web = 0;

                        for ($counter = 1; $counter <= 12; $counter += 1) {
                            $counterc = ($counter <= 9) ? "0$counter" : "$counter";
                            
                            if ($inputyear == date('Y') && $counter > date('m')) {
                                $rowcount_affected_session = 0;
                                $num_results_affected_access = 0;
                                $num_results_affected_web = 0;
                            } else {
                                //session
                                if (file_exists("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_session.txt") && (date('Y') > substr($counterc.$inputyear, 2) || (substr($counterc.$inputyear, 2) == date('Y') && substr($counterc.$inputyear, 0, 2) < date('m')))) {
                                    $lines = file("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_session.txt");
                                    $rowcount_affected_session = $lines[0];
                                } else {
                                    $query_session = "select count(DISTINCT(concat(eg_item_access.39ipaddr, SUBSTRING_INDEX(eg_item_access.39logdate,' ', 2)))) as ccount
                                    from eg_item_access inner join eg_item on eg_item_access.eg_item_id=eg_item.id
                                    where eg_item.38typeid='$typeid' and DATE_FORMAT(STR_TO_DATE(eg_item_access.39logdate, '%a %d/%m/%Y %l:%i %p'), '%m/%Y') = '$counterc/$inputyear'";
                                    $result_session = mysqli_query($GLOBALS["conn"],$query_session);
                                    $myrow_session = mysqli_fetch_array($result_session);
                                    $rowcount_affected_session = $myrow_session["ccount"];

                                    file_put_contents("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_session.txt", $rowcount_affected_session."\n".time());
                                }
                                
                                //access
                                if (file_exists("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_access.txt") && (date('Y') > substr($counterc.$inputyear, 2) || (substr($counterc.$inputyear, 2) == date('Y') && substr($counterc.$inputyear, 0, 2) < date('m')))) {
                                    $lines = file("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_access.txt");
                                    $num_results_affected_access = $lines[0];
                                } else {
                                    $query_access = "select count(eg_item_access.id) as totalid
                                     from eg_item_access inner join eg_item on eg_item_access.eg_item_id=eg_item.id
                                      where eg_item.38typeid='$typeid' and DATE_FORMAT(STR_TO_DATE(eg_item_access.39logdate, '%a %d/%m/%Y %l:%i %p'), '%m/%Y') = '$counterc/$inputyear'";
                                    $result_access = mysqli_query($GLOBALS["conn"], $query_access);
                                    $myrow_access = mysqli_fetch_array($result_access);
                                    $num_results_affected_access = $myrow_access["totalid"];
                                    file_put_contents("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_access.txt", $num_results_affected_access."\n".time());
                                }

                                //web
                                if (file_exists("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_dwweb.txt") && (date('Y') > substr($counterc.$inputyear, 2) || (substr($counterc.$inputyear, 2) == date('Y') && substr($counterc.$inputyear, 0, 2) < date('m')))) {
                                    $lines = file("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_dwweb.txt");
                                    $num_results_affected_web = $lines[0];
                                } else {
                                    $queryf_web = "select count(eg_item_download.id) as totalid
                                     from eg_item_download inner join eg_item on eg_item_download.eg_item_id=eg_item.id
                                      where eg_item.38typeid='$typeid' and DATE_FORMAT(STR_TO_DATE(eg_item_download.39logdate, '%a %d/%m/%Y'), '%m/%Y') = '$counterc/$inputyear'";
                                    $resultf_web = mysqli_query($GLOBALS["conn"], $queryf_web);
                                    $myrowf_web = mysqli_fetch_array($resultf_web);
                                    $num_results_affected_web = $myrowf_web["totalid"];
                                    file_put_contents("../".$GLOBALS["system_statcache_directory"]."/acsdwlstat/$typeid/$counterc".$inputyear."_dwweb.txt", $num_results_affected_web."\n".time());
                                }
                            }

                            echo "<tr class=$color_scheme"."Hover>";
                                echo "<td>$counter/$inputyear</td>";
                                echo "<td><a href='adsreport_typesession_more.php?type=$typeid&acstat=/$counterc/$inputyear'>$rowcount_affected_session</a></td>";
                                echo "<td><a href='adsreport_typeaccess_more.php?type=$typeid&acstat=/$counterc/$inputyear'>$num_results_affected_access</a></td>";
                                if ($system_function != "photo") {
                                    echo "<td><a href='adsreport_typedownload_more.php?type=$typeid&acstat=/$counterc/$inputyear&from=web'>$num_results_affected_web</a></td>";
                                }
                            echo "</tr>";
                            $total_t_access = $total_t_access + $num_results_affected_access;
                            $total_t_session = $total_t_session + $rowcount_affected_session;
                            $total_d_web = $total_d_web + $num_results_affected_web;
                        }
                        echo "<tr style='background-color:lightgrey;'>
                            <td style='color:green;'>Total</td>
                            <td style='color:green;'>$total_t_session</td>
                            <td style='color:green;'>$total_t_access</td>";
                            if ($system_function != "photo") {
                                echo "
                                <td style='color:green;'>$total_d_web</td>";
                            }
                        echo "</tr>";
                    echo "</table>";
                }
        ?>

        <br/><br/>
        
        <a class='sButton' href='adsreport.php?toggle=2a'><span class='fas fa-arrow-circle-left'></span> Back to report page</a>
    </div>
    
    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
