<?php
/*
Filename: sw_stats/load_toggle_3.php (Search)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.1601
Last change:
13/12/2024  - some report viewer now will open in new window
            - STR_TO_DATE is introduce in this module to make filtering of date faster
*/
    include_once '../sw_inc/access_isset.php';

    // Memeriksa jika $_REQUEST['hitsDate'] $_REQUEST['yearly'] atau  dihantar
    if (!empty($_REQUEST['hitsDate'])) {
        $dateParts = explode('/', $_REQUEST['hitsDate']);
        if (count($dateParts) === 3) {
            $_SESSION[$ssn.'yearly'] = $dateParts[2];
        }
    } elseif (!empty($_REQUEST['yearly'])) {
        $_SESSION[$ssn.'yearly'] = $_REQUEST['yearly'];
    }
?>
<?php
    function sw_countSearchHitsForMonth($monthStr)
    {
        if (strpos($monthStr, "/00") !== false) {
            return "0";
        } else {
            $t = preg_replace("/\D/", "", $monthStr);

            if (file_exists("../".$GLOBALS["system_statcache_directory"]."/searchstat/$t".".txt") && (date('Y') > substr($t, 2))) {
                $lines = file("../".$GLOBALS["system_statcache_directory"]."/searchstat/$t".".txt");
                $to_return = $lines[0];
            } else {
                $querySTAT = "select count(id) as totalhitSTAT from eg_userlog_det where DATE_FORMAT(STR_TO_DATE(38logdate, '%a %d/%m/%Y %l:%i %p'), '%m/%Y') = '$monthStr'";
                $resultSTAT = mysqli_query($GLOBALS["conn"], $querySTAT);
                $myrowSTAT = mysqli_fetch_array($resultSTAT);
                file_put_contents("../".$GLOBALS["system_statcache_directory"]."/searchstat/$t".".txt", $myrowSTAT["totalhitSTAT"]."\n".time());
                $to_return = $myrowSTAT["totalhitSTAT"];
            }

            return $to_return;
        }
    }

    if (file_exists("../$system_statcache_directory/total_hit_sum.txt") && $report_count_generator == 'daily') {
        $lines = file("../$system_statcache_directory/total_hit_sum.txt");
        $diff = time() - $lines[1];
        $reported_timestamp = $lines[1];
        if ((isset($diff) && $diff < 86400)  && $report_count_generator == 'daily') {
            $numSUM = $lines[0];
        } else {
            $querySUM = "select sum(37freq) as totalhitSUM from eg_userlog";
            $resultSUM = mysqli_query($GLOBALS["conn"], $querySUM);
            $myrowSUM = mysqli_fetch_array($resultSUM);
            $numSUM = $myrowSUM["totalhitSUM"];
            file_put_contents("../$system_statcache_directory/total_hit_sum.txt", $numSUM."\n".time());
            $reported_timestamp = time();
        }
    } else {
        $querySUM = "select sum(37freq) as totalhitSUM from eg_userlog";
        $resultSUM = mysqli_query($GLOBALS["conn"], $querySUM);
        $myrowSUM = mysqli_fetch_array($resultSUM);
        $numSUM = $myrowSUM["totalhitSUM"];
        file_put_contents("../$system_statcache_directory/total_hit_sum.txt", $numSUM."\n".time());

        $lines = file("../$system_statcache_directory/total_hit_sum.txt");
        $reported_timestamp = time();
    }
?>
<table class=whiteHeaderNoCenter>
    <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong>Search Statistic</strong></td></tr>
    <tr style='background-color:#EDF0F6;text-align:center'><td colspan=2>
        <br/>Total search hits (all time):
        <br/><span style='font-size:22px;'><strong><?php echo "$numSUM";?></strong></span>
        <?php if ($report_count_generator == 'daily' && isset($lines[1])) {?><br/><em>Statistic generated date and time: <?php echo date('Y-m-d H:i:s', $reported_timestamp) ?><br/>Statistic is valid for that date and time. New statistic will be generated 24 hours later.</em><?php }?>
        <br/><br/>Top 100: <a onclick='return js_openPopup(this.href,950,580);' href='adsreport_keyworddetails.php'>Search Terms</a> | <a onclick='return js_openPopup(this.href,950,580);' href='adsreport_ipdetails.php'>IP Addresses</a><br/><br/>
    </td></tr>
    
    <tr style='text-align:center'><td colspan=2 class='<?php echo $color_scheme."Back"; ?>'>Choose one of the following report generators:</td></tr>
    
    <tr style='background-color:#EDF0F6;text-align:center'><td colspan=2>
        <form name="getMonthStat" action="adsreport.php?toggle=3" method=post>
            Yearly stats: <input type="text" name="yearly" size="5" <?php if (isset($_SESSION[$ssn.'yearly']) && is_numeric($_SESSION[$ssn.'yearly'])) {echo 'value="'.$_SESSION[$ssn.'yearly'].'"';}?> maxlength="4"/>
        </form><br/>
        <?php
                if (isset($_SESSION[$ssn.'yearly']) && is_numeric($_SESSION[$ssn.'yearly'])) {
                    if ($_SESSION[$ssn.'yearly'] == date('Y')) {
                        $yearly = $_SESSION[$ssn.'yearly']-1;
                        $yearlyB = $_SESSION[$ssn.'yearly']-2;
                        $yearlyA = $_SESSION[$ssn.'yearly'];
                    } else {
                        $yearly = $_SESSION[$ssn.'yearly'];
                        $yearlyB = $_SESSION[$ssn.'yearly']-1;
                        $yearlyA = $_SESSION[$ssn.'yearly']+1;
                    }
                }  else {
                    $yearly = '00';
                    $yearlyB = '00';
                    $yearlyA = '00';
                }

                function sw_create3month_comparetablestatS($leftHead, $rightHead, $year_select)
                {
                    echo "<table style='text-align:center;border:1px solid;display: inline-block;'>";
                    echo "<tr style='background-color:lightgrey;'><td style='text-align:center;border:1px solid;'>$leftHead</td><td style='text-align:center;border:1px solid;'>$rightHead</td></tr>";
                    $total = 0;
                    for ($x = 1; $x <= 12; $x++) {
                        $y = ($x < 10) ? "0$x" : $x;
                        ${"j".$x} = sw_countSearchHitsForMonth("$y/$year_select");
                        echo "<tr style='text-align:center;border:1px solid;'><td>$y/$year_select</td><td>".${"j".$x}."</td></tr>";
                        $total = $total + ${"j".$x};
                    }
                    echo "<tr><td style='text-align:center;border:1px solid;'>TOTAL:</td><td style='text-align:center;border:1px solid;'>$total</td></tr>";
                    echo "</table> ";
                }
                sw_create3month_comparetablestatS('Month', 'Search Hits', $yearlyB);
                sw_create3month_comparetablestatS('Month', 'Search Hits', $yearly);
                sw_create3month_comparetablestatS('Month', 'Search Hits', $yearlyA);
        ?>
    </td></tr>

    <tr style='background-color:#EDF0F6;text-align:left'><td>
        <form name="getMonthStat" action="adsreport.php?toggle=3" method=post>Search hits by month :
        <br/><br/>
        <?php
            $months = [
                '01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr',
                '05' => 'May', '06' => 'June', '07' => 'Jul', '08' => 'Aug',
                '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec'
            ];
        ?>
        <select name='monthly'>
            <option value='' hidden>Choose</option>
            <?php foreach ($months as $value => $name): ?>
                <option value='<?= $value ?>' <?= (isset($_POST['monthly']) && $_POST['monthly'] == $value) ? 'selected' : '' ?>><?= $name ?></option>
            <?php endforeach; ?>
        </select>

        and year :
        <input type="text" name="yearly" size="5" <?php if (isset($_SESSION[$ssn.'yearly']) && is_numeric($_SESSION[$ssn.'yearly'])) {echo 'value="'.$_SESSION[$ssn.'yearly'].'"';}?> maxlength="4"/>
        <br/><br/><input type="submit" value="Submit Query"></form></td>
        <td>
            <?php
                if (isset($_POST['monthly']) && is_numeric($_POST['monthly']) && isset($_SESSION[$ssn.'yearly']) && is_numeric($_SESSION[$ssn.'yearly'])) {
                    $hitsSTRING = $_POST['monthly'].'/'.$_POST['yearly'];
                    $querySTAT = "select count(id) as totalhitSTAT from eg_userlog_det where DATE_FORMAT(STR_TO_DATE(38logdate, '%a %d/%m/%Y %l:%i %p'), '%m/%Y') = '$hitsSTRING'";
                    $resultSTAT = mysqli_query($GLOBALS["conn"], $querySTAT);
                    $myrowSTAT = mysqli_fetch_array($resultSTAT);
                    $numSTAT = $myrowSTAT["totalhitSTAT"];
                    echo "<a onclick='return js_openPopup(this.href,950,580);' href='adsreport_hitsdetails.php?hitsDate=$hitsSTRING'>$numSTAT hits</a>";
                }
            ?>
    </td></tr>

    <tr style='background-color:#EDF0F6;text-align:left'><td>Search hits by date :
        <form name="getTarikh" action="adsreport.php?toggle=3" method="post">
            <script>DateInput('hitsDate', true, 'DD/MM/YYYY' <?php if (isset($_POST["hitsDate"])) {echo ",'".$_POST["hitsDate"]."'"; } ?>)</script>
            <input type="submit" value="Submit Query">
        </form>
    </td>
    <td>
    <?php
        if (isset($_POST['hitsDate'])) {
            $stmt_count = $new_conn->prepare("select count(id) as totalhitSUMselect from eg_userlog_det where DATE_FORMAT(STR_TO_DATE(38logdate, '%a %d/%m/%Y %l:%i %p'), '%d/%m/%Y') = ?");
            $stmt_count->bind_param("s", $_POST['hitsDate']);
            $stmt_count->execute();
            $stmt_count->bind_result($numSUMselect);
            $stmt_count->fetch();$stmt_count->close();
        
            if ($numSUMselect <> 0) {
                echo "<a onclick='return js_openPopup(this.href,950,580);' href='adsreport_hitsdetails.php?hitsDate=".$_POST['hitsDate']."'>$numSUMselect hits</a>";
            } else {
                echo '0 hits.<br/><br/>';
            }
        }
    ?>
    </td></tr>
</table>
