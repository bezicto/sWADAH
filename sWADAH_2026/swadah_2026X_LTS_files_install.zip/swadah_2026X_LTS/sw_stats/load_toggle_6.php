<?php
/*
Filename: sw_stats/load_toggle_6.php (Photo)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change: -
*/

    include_once '../sw_inc/access_isset.php';

    $thisMonthYear = date("m/Y");
    $priorthisMonthYear  = date("m/Y", strtotime("-1 months"));
    $priorpriorthisMonthYear  = date("m/Y", strtotime("-2 months"));
?>
<?php
    
    $querySUM_album = "select count(eg_item.id)as totalalbums from eg_item inner join eg_item_type on eg_item.38typeid = eg_item_type.38typeid";
    $resultSUM_album = mysqli_query($GLOBALS["conn"], $querySUM_album);
    $myrowSUM_album = mysqli_fetch_array($resultSUM_album);
    echo "<span class='fa-regular fa-images' style='margin-top:20px;font-size:35px;'></span><h2>Total albums: ".$myrowSUM_album['totalalbums']."</h2><br/>";
    
    $querySUM_photo = "select sum(52photo_count) as totalphotos from eg_item";
    $resultSUM_photo = mysqli_query($GLOBALS["conn"], $querySUM_photo);
    $myrowSUM_photo = mysqli_fetch_array($resultSUM_photo);
    echo "<span class='fa-regular fa-image' style='margin-top:10px;font-size:35px;'></span><h2>Total photos: ".$myrowSUM_photo['totalphotos']."</h2><br/>";

    echo "<hr/><span style='text-decoration:underline;font-weight:bold;'>Top 10 Most Photos in Album:</span>";
    echo "<table style='border: 0px solid black; width:100%;overflow-x: auto;margin-top:30px;'><tr>";
    $queryPhoto = "select eg_item.id as id, eg_item.38title as title, eg_item.52photo_count as photocount, eg_item.41instimestamp as inserton from eg_item join eg_item_type
    on eg_item.38typeid=eg_item_type.38typeid and eg_item.52photo_count>=1
    order by photocount desc limit 10";
    $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
    while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
        $photo_id = $myrowPhoto['id'];
        $photo_title = $myrowPhoto['title'];
        $photo_count = $myrowPhoto['photocount'];
        $photo_inserton = date('d M Y', $myrowPhoto['inserton']);
        echo "<td style='font-size:8pt;display: inline-block;'><div style='width:200px;height:100px;overflow:hidden;word-wrap:break-word;'>";
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='far fa-folder' style='font-size:20pt;'></span> $photo_count</td></tr>";
            echo "</table>";
            echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a> ($photo_count)<br/><em style='font-size:8pt;color:green;'>Created: $photo_inserton</em>";
        echo "</div></td>";
    }
    echo "</tr></table>";

    echo "<br/><br/><span style='text-decoration:underline;font-weight:bold;'>Top 20 Most Accessed Albums:</span><br/>";
    echo "<table style='border: 0px solid black; width:100%;overflow-x: auto;margin-top:10px;'><tr>";
    $queryPhoto = "select eg_item.id as id, eg_item.38title as title,eg_item.41hits as photohits
     from eg_item join eg_item_type on eg_item.38typeid=eg_item_type.38typeid
      where eg_item.52photo_count>=1
       order by photohits desc limit 20";
    $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
    while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
        $photo_id = $myrowPhoto['id'];
        $photo_title = $myrowPhoto['title'];
        $photo_hits = $myrowPhoto['photohits'];
        echo "<td style='font-size:8pt;display: inline-block;'><div style='width:200px;height:100px;overflow:hidden;word-wrap:break-word;'>";
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-chart-simple' style='font-size:20pt;'></span> $photo_hits</td></tr>";
            echo "</table>";
            echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>Total Access: $photo_hits</em>";
        echo "</div></td>";
    }
    echo "</tr></table>";

    echo "<br/><br/><span style='text-decoration:underline;font-weight:bold;'>Top 10 Last Accessed Albums:</span><br/>";
    echo "<table style='border: 0px solid black; width:100%;overflow-x: auto;margin-top:10px;'><tr>";
        $queryPhoto = "select distinct(eg_item_access.eg_item_id) as id, eg_item.38title as title
        from eg_item inner join eg_item_access on eg_item.id = eg_item_access.eg_item_id
        inner join eg_item_type on eg_item.38typeid = eg_item_type.38typeid
        where eg_item_access.39logdate like '%$thisMonthYear%'
            order by eg_item_access.id desc
            limit 10";
        $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
        echo "<td style='font-size:8pt;display: inline-block;vertical-align:top;'><em>$thisMonthYear</em><br/><br/>";
        if ($resultPhoto->num_rows === 0) {
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-file-excel' style='font-size:20pt;'></span></td></tr>";
            echo "</table>No data.";
        } else {
            while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
                $photo_title = $myrowPhoto['title'];
                $photo_id = $myrowPhoto['id'];
                    echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                        echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-image' style='font-size:20pt;'></span></td></tr>";
                    echo "</table>";
                    $querySubLogDate = "select 39logdate from eg_item_access where eg_item_id=$photo_id order by id desc limit 1";
                    $resultSubLogDate = mysqli_query($GLOBALS["conn"], $querySubLogDate);
                    $myrowSubLogDate = mysqli_fetch_array($resultSubLogDate);
                    $photo_logdate = $myrowSubLogDate['39logdate'];
                    echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>$photo_logdate</em><br/><br/>";
            }
        }
        echo "</td>";

        $queryPhoto = "select distinct(eg_item_access.eg_item_id) as id, eg_item.38title as title
        from eg_item inner join eg_item_access on eg_item.id = eg_item_access.eg_item_id
        inner join eg_item_type on eg_item.38typeid = eg_item_type.38typeid
        where eg_item_access.39logdate like '%$priorthisMonthYear%'
            order by eg_item_access.id desc
            limit 20";
        $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
        echo "<td style='font-size:8pt;display: inline-block;vertical-align:top;'><em>$priorthisMonthYear</em><br/><br/>";
        if ($resultPhoto->num_rows === 0) {
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-file-excel' style='font-size:20pt;'></span></td></tr>";
            echo "</table>No data.";
        } else {
            while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
                $photo_title = $myrowPhoto['title'];
                $photo_id = $myrowPhoto['id'];
                    echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                        echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-image' style='font-size:20pt;'></span></td></tr>";
                    echo "</table>";
                    $querySubLogDate = "select 39logdate from eg_item_access where eg_item_id=$photo_id order by id desc limit 1";
                    $resultSubLogDate = mysqli_query($GLOBALS["conn"], $querySubLogDate);
                    $myrowSubLogDate = mysqli_fetch_array($resultSubLogDate);
                    $photo_logdate = $myrowSubLogDate['39logdate'];
                    echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>$photo_logdate</em><br/><br/>";
            }
        }
        echo "</td>";
       
        $queryPhoto = "select distinct(eg_item_access.eg_item_id) as id, eg_item.38title as title
        from eg_item inner join eg_item_access on eg_item.id = eg_item_access.eg_item_id
        inner join eg_item_type on eg_item.38typeid = eg_item_type.38typeid
        where eg_item_access.39logdate like '%$priorpriorthisMonthYear%'
            order by eg_item_access.id desc
            limit 20";
        $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
        echo "<td style='font-size:8pt;display: inline-block;vertical-align:top;'><em>$priorpriorthisMonthYear</em><br/><br/>";
        if ($resultPhoto->num_rows === 0) {
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-file-excel' style='font-size:20pt;'></span></td></tr>";
            echo "</table>No data.";
        } else {
            while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
                $photo_title = $myrowPhoto['title'];
                $photo_id = $myrowPhoto['id'];
                    echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>";
                        echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-image' style='font-size:20pt;'></span></td></tr>";
                    echo "</table>";
                    $querySubLogDate = "select 39logdate from eg_item_access where eg_item_id=$photo_id order by id desc limit 1";
                    $resultSubLogDate = mysqli_query($GLOBALS["conn"], $querySubLogDate);
                    $myrowSubLogDate = mysqli_fetch_array($resultSubLogDate);
                    $photo_logdate = $myrowSubLogDate['39logdate'];
                    echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>$photo_logdate</em><br/><br/>";
            }
        }
        echo "</td>";
    echo "</tr></table>";

    //----------------------------------------------------
    echo "<br/><br/><span style='text-decoration:underline;font-weight:bold;'>Top 10 Most Accessed Photos:</span><br/>";
    echo "<table style='border: 0px solid black; width:100%;overflow-x: auto;margin-top:10px;'><tr>";
        $queryPhoto = "select eg_photo_access.eg_item_id as id, eg_item.38title as title, eg_photo_access.38filename as filename, count(distinct eg_photo_access.id) as total
            from eg_photo_access inner join eg_item on eg_photo_access.eg_item_id = eg_item.id
            where 38timestamp like '%$thisMonthYear%' group by 38filename order by total desc limit 20";
        $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
        echo "<td style='font-size:8pt;display: inline-block;vertical-align:top;'><em>$thisMonthYear</em><br/><br/>";
        if ($resultPhoto->num_rows === 0) {
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-file-excel' style='font-size:20pt;'></span></td></tr>";
            echo "</table>No data.";
        } else {
            while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
                $photo_id = $myrowPhoto['id'];
                $photo_title = $myrowPhoto['title'];
                $photo_filename = $myrowPhoto['filename'];
                $photo_total = $myrowPhoto['total'];
                    echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>";
                        echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><img src='../$system_albums_directory/$photo_filename' style='width:64px;'> $photo_total</td></tr>";
                    echo "</table>";
                    echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>$photo_filename</em><br/><br/>";
            }
        }
        echo "</td>";

        $queryPhoto = "select eg_photo_access.eg_item_id as id, eg_item.38title as title, eg_photo_access.38filename as filename, count(distinct eg_photo_access.id) as total
            from eg_photo_access inner join eg_item on eg_photo_access.eg_item_id = eg_item.id
            where 38timestamp like '%$priorthisMonthYear%' group by 38filename order by total desc limit 10";
        $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
        echo "<td style='font-size:8pt;display: inline-block;vertical-align:top;'><em>$priorthisMonthYear</em><br/><br/>";
        if ($resultPhoto->num_rows === 0) {
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-file-excel' style='font-size:20pt;'></span></td></tr>";
            echo "</table>No data.";
        } else {
            while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
                $photo_id = $myrowPhoto['id'];
                $photo_title = $myrowPhoto['title'];
                $photo_filename = $myrowPhoto['filename'];
                $photo_total = $myrowPhoto['total'];
                    echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>";
                        echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><img src='../$system_albums_directory/$photo_filename' style='width:64px;'> $photo_total</td></tr>";
                    echo "</table>";
                    echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>$photo_filename</em><br/><br/>";
            }
        }
        echo "</td>";
       
        $queryPhoto = "select eg_photo_access.eg_item_id as id, eg_item.38title as title, eg_photo_access.38filename as filename, count(distinct eg_photo_access.id) as total
        from eg_photo_access inner join eg_item on eg_photo_access.eg_item_id = eg_item.id
        where 38timestamp like '%$priorpriorthisMonthYear%' group by 38filename order by total desc limit 10";
        $resultPhoto = mysqli_query($GLOBALS["conn"], $queryPhoto);
        echo "<td style='font-size:8pt;display: inline-block;vertical-align:top;'><em>$priorpriorthisMonthYear</em><br/><br/>";
        if ($resultPhoto->num_rows === 0) {
            echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;min-width:150px;margin:auto;background-color:#F3F3F3;'>";
                echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><span class='fa-solid fa-file-excel' style='font-size:20pt;'></span></td></tr>";
            echo "</table>No data.";
        } else {
            while ($myrowPhoto = mysqli_fetch_array($resultPhoto)) {
                $photo_id = $myrowPhoto['id'];
                $photo_title = $myrowPhoto['title'];
                $photo_filename = $myrowPhoto['filename'];
                $photo_total = $myrowPhoto['total'];
                    echo "<table style='border: 1px solid white; border-radius: 10px;width:100%;margin:auto;background-color:#F3F3F3;'>";
                        echo "<tr class=$color_scheme"."Hover><td style='text-align:center;'><img src='../$system_albums_directory/$photo_filename' style='width:64px;'> $photo_total</td></tr>";
                    echo "</table>";
                    echo "<a href='../sw_admin/details.php?det=$photo_id'>$photo_title</a><br/><em style='font-size:8pt;color:green;'>$photo_filename</em><br/><br/>";
            }
        }
        echo "</td>";

    echo "</tr></table>";

    echo "<br/><br/><em style='font-size:8pt;'>This module currently on beta mode.</em></div>";
?>
