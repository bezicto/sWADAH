<?php
/*
Filename: sw_stats/load_toggle_2_subload_2.php (Access)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change: -
*/

session_start();

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
ini_set('max_execution_time', 180);

if (!isset($_GET['t'])) {exit;}
$t = mysqli_real_escape_string($GLOBALS["conn"], $_GET['t']); if (!is_numeric($t)) {$t = 0;}

function sw_echoandputcontents_sessions($t, $system_statcache_directory, $lastcount =0, $lastid = 0)
{
    //query last id, $myrow_lastid['lastid'] will be appended in the sessionscount.txt, so that next time, the stat will start from there
    $query_lastid = "select max(id) as lastid from eg_item_access";
    $result_lastid = mysqli_query($GLOBALS["conn"], $query_lastid);
    $myrow_lastid = mysqli_fetch_array($result_lastid);

    //if lastid is include in this function, it will modify the sql statement for query_totalsession to start from the lastid passed to this function
    $sql_lastid = ($lastid == 0) ? "" : "and eg_item_access.id > $lastid";

    //count total session of all item for a type (group by similarly ippaddress and logdate to prevent multiple counting)
    $query_totalsession = "select count(eg_item_access.id) as totalid
    from eg_item_access inner join eg_item on eg_item_access.eg_item_id=eg_item.id
    where eg_item.38typeid='$t' $sql_lastid
    group by eg_item.38typeid, eg_item_access.39ipaddr, SUBSTRING_INDEX(eg_item_access.39logdate,' ', 2)";
    $result_totalsession = mysqli_query($GLOBALS["conn"], $query_totalsession);
   
    echo mysqli_num_rows($result_totalsession) + $lastcount;

    file_put_contents("../$system_statcache_directory/".$t."_sessionscount.txt", mysqli_num_rows($result_totalsession) + $lastcount."\n".time()."\n".$myrow_lastid["lastid"]);
}

if (file_exists("../$system_statcache_directory/".$t."_sessionscount.txt") && $report_count_generator == 'daily') {
    $lines = file("../$system_statcache_directory/".$t."_sessionscount.txt");
    $diff = time() - $lines[1];
    if ($diff < 86400) {
        echo $lines[0];
    }  else {
        sw_echoandputcontents_sessions($t, $system_statcache_directory, $lines[0], $lines[2]);
    }
} else {
    sw_echoandputcontents_sessions($t, $system_statcache_directory);
}
