<?php
/*
Filename: sw_inc/recover_code.php
Usage: If deletion is set to takecover, this will recover the item to be re-shown
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if ($_GET["rec"] <> null && is_numeric($_GET["rec"]) && $_SESSION[$ssn.'editmode'] == 'SUPER') {
    $get_id_rec = $_GET["rec"];
    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_rec);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
    
    $inputdate = $myrow_item["39inputdate"];
    $dir_year = substr("$inputdate", 0, 4);
    $instimestamp = $myrow_item["41instimestamp"];
        
    $del_path = "$dir_year/$get_id_rec"."_"."$instimestamp";

    $get_delfilename = ($num_results_affected >= 1) ? $del_path : "00XXYY";
    $get_delimgname = ($num_results_affected >= 1) ? $del_path : "00XXYY";

    //handling freetype file
    $get_delfreetypefilename = "../$system_isofile_directory/$dir_year/00XXYY.XXX";
    if (is_dir("../$system_isofile_directory/$dir_year")) {
        $files_scanned = scandir("../$system_isofile_directory/$dir_year");
        foreach ($files_scanned as $fileitem) {
            if (preg_match("/$get_id_rec"."_"."$instimestamp/i", $fileitem) == 1) {
                $get_delfreetypefilename = "../$system_isofile_directory/$dir_year/$fileitem";
                break;
            }
        }
    }
    
    mysqli_query($GLOBALS["conn"], "update eg_item set 50item_status='1' where id='$get_id_rec'");//set invisible traces from eg_item

    if (is_file("../$system_docs_directory/".$get_delfilename.".pdf.deleted")) {
        rename("../$system_docs_directory/".$get_delfilename.".pdf.deleted", "../$system_docs_directory/".$get_delfilename.".pdf");
    }
    
    if (is_file("../$system_pdocs_directory/".$get_delfilename.".pdf.deleted")) {
        rename("../$system_pdocs_directory/".$get_delfilename.".pdf.deleted", "../$system_pdocs_directory/".$get_delfilename.".pdf");
    }

    if (is_file("../$system_albums_directory/".$get_delimgname.".jpg.deleted")) {
        rename("../$system_albums_directory/".$get_delimgname.".jpg.deleted", "../$system_albums_directory/".$get_delimgname.".jpg");
    }
        if (is_dir("../$system_albums_directory/".$get_delimgname."_deleted")) {
            rename("../$system_albums_directory/".$get_delimgname."_deleted", "../$system_albums_directory/".$get_delimgname);
        }

    if (is_file("../$system_albums_watermark_directory/".$get_delimgname.".jpg.deleted")) {
        rename("../$system_albums_watermark_directory/".$get_delimgname.".jpg.deleted", "../$system_albums_watermark_directory/".$get_delimgname.".jpg");
    }

    if (is_file("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg.deleted")) {
        rename("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg.deleted", "../$system_albums_thumbnail_directory/".$get_delimgname.".jpg");
    }

    if (is_file("$get_delfreetypefilename")) {
        rename("$get_delfreetypefilename", str_replace(".deleted","","$get_delfreetypefilename"));
    }

    
    sfx_refreshAndClose("Recovery done.");
} elseif ($_GET["rec"] <> null && is_numeric($_GET["rec"]) && $_SESSION[$ssn.'editmode'] == 'STAFF') {
    sfx_echoPopupAlert("Trying doing something illegal arent you ?");
}
