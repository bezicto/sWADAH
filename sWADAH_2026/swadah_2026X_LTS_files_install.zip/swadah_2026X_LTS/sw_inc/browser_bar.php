<?php
/*
Filename: sw_inc/browser_bar.php
Usage: Browser bar for searcher.php and sw_admin/index2.php
Version: 20250101.0801
Last change: -
*/
?>
<?php defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>"); ?>
<table style='width:100%'>
    <tr><td style='height:29;text-align:center;'>Browse by:
        <?php if ($show_subject_browser_bar) {?>
            <img src='<?php echo $appendroot;?>sw_asset/img/bw_subject.png' style='width:16px;' alt='Year_icon'> <a style='margin-right:8px;' href='<?php echo $appendroot;?>sw_brows/subjectbrowser.php'><?php echo $subject_heading_as;?></a>
        <?php }?>

        <?php if ($show_publisher_browser_bar) {?>
            <img src='<?php echo $appendroot;?>sw_asset/img/bw_publisher.png' style='width:16px;' alt='Year_icon'> <a style='margin-right:8px;' href='<?php echo $appendroot;?>sw_brows/publisherbrowser.php'><?php echo $publisher_as;?></a>
        <?php }?>

        <?php if ($show_year_browser_bar) {?>
            <img src='<?php echo $appendroot;?>sw_asset/img/bw_calendar.png' style='width:16px;' alt='Year_icon'> <a style='margin-right:8px;' href='<?php echo $appendroot;?>sw_brows/yearbrowser.php'>Year</a>
        <?php }?>

        <?php if ($show_folder_browser_bar && $enable_folder) {?>
            <?php if (isset($_SESSION[$ssn.'username']) || isset($_SESSION[$ssn.'username_guest'])) {?>
                <img src='<?php echo $appendroot;?>sw_asset/img/bw_folder.png' style='width:16px;' alt='Folder_icon'> <a style='margin-right:8px;' href='<?php echo $appendroot;?>sw_brows/folderbrowser.php'>Folder</a>
            <?php }
        }?>
    </td></tr>
</table>
