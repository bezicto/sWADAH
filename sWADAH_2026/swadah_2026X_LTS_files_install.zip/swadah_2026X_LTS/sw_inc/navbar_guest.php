<?php
  /*
  Filename: sw_inc/navbar_guest.php
  Usage: Navbar for guests
  Version: 20250101.0000
  Last change: -
  */

      defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
      
      if (isset($_SESSION[$ssn.'username_guest'])) {
      ?>
        <script>
          function js_myShowMenuItemGuest() {
              var x = document.getElementById("myTopnav");
              if (x.className === "topnav") {x.className += " responsive";}
              else {x.className = "topnav";}
          }
        </script>

        <div class="topnav <?php echo $color_scheme;?>topnav" id="myTopnav">
          <a href="<?php echo $appendroot;?>dashboard.php" class="active"><img alt='Menu Icon' src='<?php echo $appendroot.$menu_icon;?>' width=20></a>
          <a href="<?php echo $appendroot;?>searcher.php?sc=cl"><span class="fa fa-search"></span> Searcher</a>
          <?php
          if (isset($_SESSION[$ssn.'whichbrowser']) && $_SESSION[$ssn.'whichbrowser'] == 'listgenerator') {
            echo "<a href='".$appendroot."listgen.php'><span class='fa fa-list'></span> Current List</a>";
          }
          ?>
          <a href="<?php echo $appendroot;?>dashboard.php?u=g"><span class="fa fa-book"></span> My Bookmarks</a>
          <div class="dropdownNB">
            <button class="dropbtn"><span class="fa fa-info"></span> Help
              <span class="fa fa-caret-down"></span>
            </button>
            <div class="dropdownNB-content">
              <a href="<?php echo $appendroot;?>nav.php?page=FAQ">FAQ</a>
              <a href="<?php echo $appendroot;?>nav.php?page=About">About</a>
            </div>
          </div>
          <a href="<?php echo $appendroot;?>passch.php?upd=.g"><span class="fa fa-key"></span> Change Password</a>
          <a href="<?php echo $appendroot;?>index.php?log=out" onclick="return confirm('Are you sure?')"><span class="fa fa-user"></span> Logout</a>
          <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="js_myShowMenuItemGuest()">&#9776;</a>
        </div>

        <?php
        if (basename($_SERVER["SCRIPT_FILENAME"], '.php') == 'dashboard' && !isset($_GET['u'])) {
        ?>
          <table class=whiteHeaderNoCenter>
            <tr>
              <td colspan=2>
                <?php echo sfx_getUserInfo($_SESSION[$ssn.'username_guest'], $system_admin_contact_disclaimer);?>
              </td>
            </tr>
          </table>
        <?php
        }
      }  else {
          if (!isset($_SESSION[$ssn.'username'])) {
      ?>
        <table class="<?php echo $color_scheme."banner_guest";?>">
          <tr>
            <td style='height:29;text-align:right;'>
              <strong><div style='color:black;font-size:16px;'>
              <?php
                echo $system_title;
                if ($_SERVER["REMOTE_ADDR"] == $ezproxy_ip) {echo " <input type='button' class='form-grey-button-noshadow' style='font-size:8pt' value='EZPROXY MODE'>";}
                elseif (isset($_SESSION[$ssn.'lls']) && $_SESSION[$ssn.'lls']) {
                  echo " <input type='button' class='form-grey-button-noshadow' style='font-size:8pt' value='LOGINLESS: ".$_SESSION[$ssn.'lls_tokenowner']."'>";
                  if (isset($_SESSION[$ssn.'disableSearch']) && $_SESSION[$ssn.'disableSearch']) {
                    echo " <input type='button' class='form-orange-button-noshadow' style='font-size:8pt' value='WARNING: Search Token Exceeded'>";
                  }
                }
              ?>
              </div></strong>
              <div style='font-size:12px;text-align:right;'>
              <?php
                echo "<i style='color:green;' class=\"fas fa-home\"></i> <a href='".$appendroot."searcher.php?sc=cl' class='nav'>Start</a> | ";
          
                if (isset($_SESSION[$ssn.'listgentoken']) && isset($_SESSION[$ssn.'whichbrowser']) && $_SESSION[$ssn.'whichbrowser'] == 'listgenerator') {
                  echo "<i style='color:green;' class=\"far fa-list-alt\"></i> <a href='".$appendroot."listgen.php' class='nav'>Current List</a> | ";
                }
          
                if ($allow_user_to_login && !isset($_SESSION[$ssn.'lls'])) {
                  echo "<i style='color:green;' class=\"fas fa-sign-in-alt\"></i> <a href='".$appendroot."in.php?t=ma' class='nav'>Login</a> | ";
                }

                echo "<i style='color:green;' class=\"far fa-question-circle\"></i> <a href='$appendroot"."nav.php?page=FAQ' class='nav'>FAQ</a> | ";

                echo "<i style='color:green;' class=\"fas fa-info-circle\"></i> <a href='$appendroot"."nav.php?page=About' class='nav'>About</a>";

                if (isset($_SESSION[$ssn.'lls']) && $_SESSION[$ssn.'lls']) {
                  echo " | <i style='color:indianred;' class=\"fas fa-sign-out-alt\"></i> <a onclick=\"return confirm('Are you sure? This will clear your loginless session.')\" href='".$appendroot."index.php?c=ls' class='nav' style='color:indianred;'>Logout</a>";
                }
              ?>
              </div>
            </td>
            <td style='width:42px;text-align:left;'>
              <img alt='Menu Icon' src='<?php echo $appendroot.$menu_icon;?>' width='20px'>
            </td>
          </tr>
        </table>
      <?php
        }
      }
  ?>
