<?php
    // Security: Escape all output to prevent XSS
    $api_url = htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8');
    
    echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>sWADAH Searcher API Documentation</title>
            <link rel="stylesheet" href="sw_asset/css/searcherapi-ui.css">
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1><img src="sw_asset/img/swadah_icon_www.png" style="width:36px;"> sWADAH Searcher API</h1>
                    <p>Comprehensive API for searching academic resources and publications</p>
                </div>

                    <div class="section">
                    <div class="section-header">
                        <h2><span class="icon">📚</span>Reference Lists</h2>
                    </div>
                    <div class="section-content">
                        <div class="grid">
                            <div class="endpoint">
                                <div class="endpoint-title">📋 List Resource Types</div>
                                <div class="endpoint-url">' . $api_url . '?listype=1</div>
                                <div class="endpoint-description">Get all available resource types and their IDs</div>
                                <a href="' . $api_url . '?listype=1" class="try-btn">View Types</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">🏢 List Publishers</div>
                                <div class="endpoint-url">' . $api_url . '?listpub=1</div>
                                <div class="endpoint-description">Get all publishers with IDs and acronyms</div>
                                <a href="' . $api_url . '?listpub=1" class="try-btn">View Publishers</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">🏷️ List Subject Headings</div>
                                <div class="endpoint-url">' . $api_url . '?listsub=1</div>
                                <div class="endpoint-description">Get all subject headings with acronyms</div>
                                <a href="' . $api_url . '?listsub=1" class="try-btn">View Subjects</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div class="section-header">
                        <h2><span class="icon">📋</span>Available Endpoints</h2>
                    </div>
                    <div class="section-content">
                        <div class="grid">
                            <div class="endpoint">
                                <div class="endpoint-title">🔍 Search Resources</div>
                                <div class="endpoint-url">' . $api_url . '?scstr=TERM&sctype=TYPE</div>
                                <div class="endpoint-description">Search for academic resources by term and type</div>
                                <div class="params">
                                    <div class="param">
                                        <span class="param-name">scstr</span><span class="param-type">string</span><br>
                                        Search term or keywords
                                    </div>
                                    <div class="param">
                                        <span class="param-name">sctype</span><span class="param-type">integer|string</span><br>
                                        Resource type ID or "EveryThing" for all types
                                    </div>
                                </div>
                                <div class="pagination-note">
                                    <strong>💡 Pagination Support:</strong><br/>Add <code>&usepage=1</code> to enable pagination with <code>&page=2&per_page=10</code>
                                </div>
                                <a href="' . $api_url . '?scstr=education&sctype=1" class="try-btn">Try Example</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">🏢 Search by Publisher</div>
                                <div class="endpoint-url">' . $api_url . '?scpub=PUBLISHER_NAME</div>
                                <div class="endpoint-description">Find resources by publisher name</div>
                                <div class="params">
                                    <div class="param">
                                        <span class="param-name">scpub</span><span class="param-type">string</span><br>
                                        Full or partial publisher name
                                    </div>
                                </div>
                                <a href="' . $api_url . '?scpub=Fakulti" class="try-btn">Try Example</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">🆔 Search by Publisher ID</div>
                                <div class="endpoint-url">' . $api_url . '?scpubid=ID</div>
                                <div class="endpoint-description">Find resources by publisher ID</div>
                                <div class="params">
                                    <div class="param">
                                        <span class="param-name">scpubid</span><span class="param-type">integer</span><br>
                                        Publisher ID number
                                    </div>
                                </div>
                                <a href="' . $api_url . '?scpubid=1" class="try-btn">Try Example</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">🏷️ Search by Subject</div>
                                <div class="endpoint-url">' . $api_url . '?scsub=SUBJECT_CODE</div>
                                <div class="endpoint-description">Find resources by subject heading acronym</div>
                                <div class="params">
                                    <div class="param">
                                        <span class="param-name">scsub</span><span class="param-type">string</span><br>
                                        Subject heading acronym
                                    </div>
                                </div>
                                <a href="' . $api_url . '?scsub=A" class="try-btn">Try Example</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">📄 Item Details (Full)</div>
                                <div class="endpoint-url">' . $api_url . '?itemid=ID</div>
                                <div class="endpoint-description">Get complete item details including references and abstract</div>
                                <div class="params">
                                    <div class="param">
                                        <span class="param-name">itemid</span><span class="param-type">integer</span><br>
                                        Item ID from search results
                                    </div>
                                </div>
                                <a href="' . $api_url . '?itemid=10" class="try-btn">Try Example</a>
                            </div>

                            <div class="endpoint">
                                <div class="endpoint-title">📋 Item Details (Minimal)</div>
                                <div class="endpoint-url">' . $api_url . '?mitemid=ID</div>
                                <div class="endpoint-description">Get basic item details without references and abstract</div>
                                <div class="params">
                                    <div class="param">
                                        <span class="param-name">mitemid</span><span class="param-type">integer</span><br>
                                        Item ID from search results
                                    </div>
                                </div>
                                <a href="' . $api_url . '?mitemid=10" class="try-btn">Try Example</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div class="section-header">
                        <h2><span class="icon">💻</span>Example Responses</h2>
                    </div>
                    <div class="section-content">
                        <div class="example">
                            <div class="example-title">Standard Search Response:</div>
                            <pre><code>[
{
    "id": "123",
    "title": "Educational Research Methods",
    "author": "Dr. John Smith",
    "year": "2023",
    "type": "Book",
    "swadah_link": "https://example.com/detailsg.php?det=123"
}
]</code></pre>
                    </div>

                    <div class="example">
                        <div class="example-title">Paginated Response (with usepage=1):</div>
                        <pre><code>{
"data": [...],
"pagination": {
    "current_page": 1,
    "per_page": 20,
    "total_items": 150,
    "total_pages": 8,
    "has_next": true,
    "has_prev": false
}
}</code></pre>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
        ';
