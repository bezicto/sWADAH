<?php
/*
Filename: sw_inc/removefeedback_code.php
Usage: Remove feedback from table
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if (isset($_GET["fid"]) && is_numeric($_GET["fid"])) {
    
    $stmt_update = $new_conn->prepare("delete from eg_item_feedback where id=?");
    $stmt_update->bind_param("i", $_GET["fid"]);
    $stmt_update->execute();$stmt_update->close();
    
    sfx_refreshAndClose("Removing feedback.");
}
