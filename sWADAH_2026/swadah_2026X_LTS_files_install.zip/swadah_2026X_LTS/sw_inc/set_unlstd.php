<?php
/*
Filename: sw_inc/recover_code.php
Usage: If deletion is set to takecover, this will recover the item to be re-shown
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if ($_GET["id"] <> null && is_numeric($_GET["id"]) && ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF')) {
    $get_id = $_GET["id"];
    mysqli_query($GLOBALS["conn"], "update eg_item set 38status='UNLISTED' where id=$get_id");
    sfx_refreshAndClose("Item has been set to Unlisted.","1000");
} else {
    sfx_echoPopupAlert("Trying doing something illegal arent you ?");
}
