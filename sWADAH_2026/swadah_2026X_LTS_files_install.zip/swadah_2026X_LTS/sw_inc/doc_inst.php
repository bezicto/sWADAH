<?php
/*
Filename: sw_inc/doc_inst.php
Usage: Output link to recognizable PDF file path
Version: 20250225.1528
Last change: -
*/

include_once '../core.php';

session_start();
if (!isset($_SESSION['access_from_doc_php']) || $_SESSION['access_from_doc_php'] !== true) {
    http_response_code(403);
    die('Access Denied');
}

unset($_SESSION['access_from_doc_php']);

if (isset($_GET['pdf'])) {
    // Set the correct content type to return plain text
    header('Content-Type: text/plain');

    // Define the PDF file path (can be dynamically fetched)
    $decryption_fpdf_path = openssl_decrypt(base64_decode($_GET['pdf']), "AES-128-CTR", $aes_key, 0, "1234567891011121");

    // Ensure the file exists before outputting the path
    if (file_exists($decryption_fpdf_path)) {
        echo $decryption_fpdf_path;
    } else {
        http_response_code(404);
        echo "Error: File not found";
    }
}
