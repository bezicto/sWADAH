<?php
/*
Filename: sw_inc/ajax_loadpublishercount.php
Usage: AJAX load publisher counts by publisher ID
Version: 20250101.0801
Last change: -
*/

    session_start();
    include_once '../core.php';
    ini_set('max_execution_time', 180);

    if (!isset($_GET['p'])) {
        exit;
    }
    
    if (isset($_GET['pid']) && is_numeric($_GET['pid'])) {
        $pid= mysqli_real_escape_string($GLOBALS["conn"], $_GET['pid']);
    } else {
        exit;
    }

    $param = "%".$_GET['p']."%";
    $stmt_term = $new_conn->prepare("select count(id) as totalSubPub from eg_item2 where 38publication_b like ?");
    $stmt_term->bind_param("s", $param);//s string
    $stmt_term->execute();
    $stmt_term->bind_result($count_SubPub);
    $stmt_term->fetch();
    $stmt_term->free_result();
    $stmt_term->close();

    echo ($count_SubPub >= 1) ? $count_SubPub : 0;

    //new for counting
    $lastcount_timestamp_update = time();
    $stmt_update = $new_conn->prepare("update eg_publisher set 43count=?, 43lastcount_timestamp=? where 43pubid=?");
    $stmt_update->bind_param("isi", $count_SubPub, $lastcount_timestamp_update, $pid);
    $stmt_update->execute();
    $stmt_update->close();
