<?php
/*
Filename: sw_inc/footer.php
Usage: Footer page for every pages
Version: 20250101.0801
Last change: -
*/
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
    
    echo "<div style='font-size:$footer_font_size;text-align:center;'>";
    echo "<strong>Installed and configured by $system_owner</strong>";
        echo "<br/>$system_admin_contact_disclaimer";
        if ($show_build_number_on_footer) {echo "<br/>$system_build";}
    echo "</div>";
