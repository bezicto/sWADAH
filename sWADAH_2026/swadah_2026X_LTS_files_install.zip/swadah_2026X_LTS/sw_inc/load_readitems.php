<?php
/*
Filename: sw_inc/load_readitems.php
Usage: AJAX for filter widget on searcher page
Version: 20250101.0801
Last change: -
*/

header('Content-Type: text/html');
include_once '../core.php';
include_once '../sw_inc/functions.php';

// Semak sama ada kuki 'recent_items' wujud
if (isset($_COOKIE['recent_items'])) {
    // Dapatkan kuki dan ubah menjadi array
    $recent_items = explode(',', $_COOKIE['recent_items']);
    // Ambil hanya 10 item terakhir
    $recent_items = array_slice($recent_items, -10);
    foreach ($recent_items as $item_id) {
        echo "<div style='margin-top:5px;'><i class='fa-regular fa-folder-open'></i> <a href='detailsg.php?det=$item_id'>".sfx_sGetValue('38title', 'eg_item', 'id', $item_id)."</a></div><br/>";
    }
} else {
    echo "No recently access item.";
}
