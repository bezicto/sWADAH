<?php
/*
Filename: sw_inc/popularkeywords.php
Usage: Popular keywords listing/widget
Version: 20250101.0801
Last change: -
*/

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
    
    $datePatternP = date("D d/m/Y");
    //$queryP = "select 37keyword, 37type, 37freq  from eg_userlog where 37lastlog like '$datePatternP%' order by 37freq desc LIMIT 0, 10";
    $queryP = "select 38keyword, 38type from eg_userlog_det where 38logdate like '$datePatternP%' LIMIT 0, 10";
    $resultP = mysqli_query($GLOBALS["conn"], $queryP);
    $num_resultsP = mysqli_num_rows($resultP);
    
    if ($num_resultsP <> 0) {
        $n = 1;
        echo "<div style='overflow-x:auto;width:100%;'>"; // Add responsive wrapper
        echo "<table class='whiteHeader' style='width:100%; table-layout:auto; word-wrap:break-word; background-color:lightyellow;'>";
        echo "<tr><td colspan=5><i class=\"fas fa-star\"></i> ";
        echo "<span style='color:maroon;'><strong><u>Current active searches:</u></strong></span></td></tr>";
        
        while ($myrowP = mysqli_fetch_array($resultP)) {
            echo ($n == 6 || $n == 1) ? "<tr><td>" : "<td>";
        
            $keywordP = $myrowP["38keyword"];
            $typeP = $myrowP["38type"];
        
            $keywordPex = urlencode($keywordP); // encode + sign properly
        
            echo "<a href='searcher.php?sc=cl&scstr=$keywordPex&sctype=$typeP' style='display:inline-block;max-width:100%;word-wrap:break-word;'>";
            echo ($debug_mode == "yes") ? $keywordP : preg_replace('/[^A-Za-z0-9\-]/', " ", $keywordP);
            if ($typeP == 'Author') {
                echo " (Author)";
            }
            echo "</a>";
        
            echo ($n == 5 || $n == 10) ? "</td></tr>" : "</td>";
            $n++;
        }
        
        echo "</table>";
        echo "</div>"; // close responsive wrapper
        
    }
