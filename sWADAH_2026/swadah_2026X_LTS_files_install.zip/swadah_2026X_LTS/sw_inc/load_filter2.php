<?php
/*
Filename: sw_inc/load_filter2.php
Usage: AJAX for filter widget on searcher page
Version: 20250101.0801
Last change: -
*/

header('Content-Type: text/html');
session_start();
include_once '../core.php';
include_once '../sw_inc/functions.php';

if ((isset($_SESSION[$ssn.'sear_scstr']) && $_SESSION[$ssn.'sear_scstr'] != '') && (isset($_GET['nump']) && is_numeric($_GET['nump'])))
{
    $scstr_term = $_SESSION[$ssn.'sear_scstr'];
    $sctype_select = $_GET['scsel'];
    $num_results_affected_paging = $_GET['nump'];
        
    if (isset($scstr_term) && $scstr_term != '' && $num_results_affected_paging >= 1) {
        if (isset($scstr_term) && $scstr_term != '' && $num_results_affected_paging >= 1) {
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=1y&sc=cl'>From Last 1 Year</a> ...</div><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=3y&sc=cl'>From Last 3 Years</a> ...</div><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=5y&sc=cl'>From Last 5 Years</a> ...</div><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=more&sc=cl'>More than 6 Years</a> ...</div><br/>";
        } elseif (isset($scstr_term) && $num_results_affected_paging == 0) {
            echo "<div style='margin-top:10px;'><em>No result. Select from of the following period:</em></div><br/><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=1y&sc=cl'>From Last 1 Year</a> ...</div><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=3y&sc=cl'>From Last 3 Years</a> ...</div><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=5y&sc=cl'>From Last 5 Years</a> ...</div><br/>";
            echo "<div style='margin-top:5px;'><i class='fa-regular fa-calendar'></i> <a href='searcher.php?scstr=$scstr_term&sctype=$sctype_select&p=more&sc=cl'>More than 6 Years</a> ...</div><br/>";
        } else {
            echo "<div style='margin-top:10px;'><em>Please make initial search.</em></div>";
        }
    } else {
        echo "<div style='margin-top:10px;'><em><em>Please make initial search.</em></em></div>";
    }
} else {
    echo "<div style='margin-top:10px;'><em>No result from your search term.</em></div>";
}
