<?php
/*
Filename: sw_inc/assigndelreq_code.php
Usage: Set to update delete request proposal with reasons
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if ($_GET["itemid"] <> null && is_numeric($_GET["itemid"])) {
    $get_id = $_GET["itemid"];
    $get_reason = sfx_stringRemoveScriptTag(mysqli_real_escape_string($GLOBALS["conn"], $_GET["reason"]));

    mysqli_query($GLOBALS["conn"], "update eg_item set 39proposedelete='TRUE', 39proposedeleteby='".$_SESSION[$ssn.'username']."', 39proposedelete_reason='$get_reason' where id=$get_id");

    sfx_refreshAndClose("Delete request has been forwarded to administrator.","1000");
}
