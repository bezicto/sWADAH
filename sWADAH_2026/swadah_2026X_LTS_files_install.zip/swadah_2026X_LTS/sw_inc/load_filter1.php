<?php
/*
Filename: sw_inc/load_filter1.php
Usage: AJAX for filter widget on searcher page
Version: 20250101.0801
Last change: -
*/

header('Content-Type: text/html');
session_start();
include_once '../core.php';
include_once '../sw_inc/functions.php';

if ((isset($_SESSION[$ssn.'sear_scstr']) && $_SESSION[$ssn.'sear_scstr'] != '') && (isset($_GET['nump']) && is_numeric($_GET['nump'])))
{
    $scstr_term = $_SESSION[$ssn.'sear_scstr'];
    $num_results_affected_paging = $_GET['nump'];
        
        if (isset($scstr_term) && $scstr_term != '' && $num_results_affected_paging >= 1) {
            $typelist = "select 38typeid, 38type, 38synonym from eg_item_type";
            $result_typelist = mysqli_query($GLOBALS["conn"], $typelist);
            while ($row_typelist = mysqli_fetch_array($result_typelist)) {
                $append_faster_search = isset($_SESSION[$ssn.'sear_ft']) && $_SESSION[$ssn.'sear_ft'] == 1 ? ", 41pdfattach_fulltext, 50search_cloud" : "";

                $query_filtercount = "select count(id) as totalfiltered from eg_item where id<>0";
                $query_filtercount .= " and 38typeid = '".$row_typelist['38typeid']."' and 50item_status='1' and 38status!='UNLISTED' and match (38title, 41fulltexta, 38author $append_faster_search)";
                $query_filtercount .= " against ('$scstr_term' in boolean mode)";
                $result_filtercount = mysqli_query($GLOBALS["conn"], $query_filtercount);
                $myrow_filtercount = mysqli_fetch_array($result_filtercount);

                $showtotal = "";
                if ($myrow_filtercount['totalfiltered'] >= 1) {
                    $showtotal = "(".$myrow_filtercount['totalfiltered'].")";
                    
                    echo "<div style='margin-top:10px;'>
                    <i style='font-size:16px;margin-top:5px;' class=\"fas fa-file\"></i>
                    <a href='searcher.php?scstr=$scstr_term&sctype=".$row_typelist['38typeid']."&sc=cl'>".$row_typelist['38synonym']."</a> ... $showtotal
                    </div>";
                }
            }

        } elseif (isset($scstr_term) && $scstr_term != '' && $num_results_affected_paging == 0) {
            echo "<div style='margin-top:10px;'><em>No result from your search term.</em></div>";
        }
} else {
    echo "<div style='margin-top:10px;'><em>No result from your search term.</em></div>";
}
