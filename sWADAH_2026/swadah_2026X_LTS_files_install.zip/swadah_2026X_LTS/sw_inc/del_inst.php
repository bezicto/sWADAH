<?php
/*
Filename: sw_inc/del_inst.php
Usage: Handles item deletion the proper way
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if (isset($_GET['defg']) && is_numeric($_GET['defg'])) {
    $get_id_det = $_GET["defg"];

    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
        $inputdate = $myrow_item["39inputdate"];
        $dir_year = substr("$inputdate", 0, 4);
        $instimestamp = $myrow_item["41instimestamp"];
    
    $del_path = "$dir_year/$get_id_det"."_"."$instimestamp";
    $get_delfilename = ($num_results_affected >= 1) ? $del_path : "NODIR";

    if (is_file("../$system_pdocs_directory/".$get_delfilename.".pdf")) {
        unlink("../$system_pdocs_directory/".$get_delfilename.".pdf");
    }

    sfx_refreshAndClose("Item has been deleted.");
    exit();
}

if (isset($_GET['deff']) && is_numeric($_GET['deff'])) {
    $get_id_det = $_GET["deff"];

    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
        $inputdate = $myrow_item["39inputdate"];
        $dir_year = substr("$inputdate", 0, 4);
        $instimestamp = $myrow_item["41instimestamp"];
    
    $del_path = "$dir_year/$get_id_det"."_"."$instimestamp";
    $get_delfilename = ($num_results_affected >= 1) ? $del_path : "NODIR";

    if (is_file("../$system_docs_directory/".$get_delfilename.".pdf")) {
        unlink("../$system_docs_directory/".$get_delfilename.".pdf");
    }

    sfx_refreshAndClose("Item has been deleted.");
    exit();
}

if (isset($_GET['deif']) && is_numeric($_GET['deif'])) {
    $get_id_det = $_GET["deif"];

    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
        $inputdate = $myrow_item["39inputdate"];
        $dir_year = substr("$inputdate", 0, 4);
        $instimestamp = $myrow_item["41instimestamp"];
    
    $del_path = "$dir_year/$get_id_det"."_"."$instimestamp";
    $get_delfilename = ($num_results_affected >= 1) ? $del_path : "NODIR";

    //for handling freetype
    $files_scanned = scandir("../$system_isofile_directory/$dir_year");
    foreach ($files_scanned as $fileitem) {
        if (preg_match("/$get_id_det"."_"."$instimestamp/i", $fileitem) == 1) {
            //file found
            unlink("../$system_isofile_directory/$dir_year/$fileitem");
            break;
        }
    }
    sfx_refreshAndClose("Item has been deleted.");
    exit();
}

if (isset($_GET['defj']) && is_numeric($_GET['defj'])) {
    $get_id_det = $_GET["defj"];

    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
        $inputdate = $myrow_item["39inputdate"];
        $dir_year = substr("$inputdate", 0, 4);
        $instimestamp = $myrow_item["41instimestamp"];
    
    $del_path = "$dir_year/$get_id_det"."_"."$instimestamp";
    $get_delimgname = ($num_results_affected >= 1) ? $del_path : "NODIR";

    if (is_file("../$system_albums_directory/".$get_delimgname.".jpg")) {
        unlink("../$system_albums_directory/".$get_delimgname.".jpg");
    }

    if (is_file("../$system_albums_watermark_directory/".$get_delimgname.".jpg")) {
        unlink("../$system_albums_watermark_directory/".$get_delimgname.".jpg");
    }

    if (is_file("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg")) {
        unlink("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg");
    }

    sfx_refreshAndClose("Item has been deleted.");
    exit();
}

if (isset($_GET['defi']) && isset($_GET['pic']) && is_numeric($_GET['defi']) && is_numeric($_GET['pic'])) {
    $get_id_det = $_GET["defi"];
    $get_id_pic = $_GET["pic"];

    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
        $inputdate = $myrow_item["39inputdate"];
        $dir_year = substr("$inputdate", 0, 4);
        $instimestamp = $myrow_item["41instimestamp"];
    
    $del_path = "$dir_year/$get_id_det"."_"."$instimestamp";
    $get_delimgname = ($num_results_affected >= 1) ? $del_path : "NODIR";

    if (is_file("../$system_albums_directory/".$get_delimgname."/$get_id_pic.jpg")) {
        unlink("../$system_albums_directory/".$get_delimgname."/$get_id_pic.jpg");
    }

    if (is_file("../$system_albums_directory/".$get_delimgname."/$get_id_pic"."_wm.jpg")) {
        unlink("../$system_albums_directory/".$get_delimgname."/$get_id_pic"."_wm.jpg");
    }

    if (is_file("../$system_albums_directory/".$get_delimgname."/$get_id_pic"."_tb.jpg")) {
        unlink("../$system_albums_directory/".$get_delimgname."/$get_id_pic"."_tb.jpg");
    }

    sfx_refreshAndClose("Item has been deleted.");
    exit();
}

//only SUPER user will enable to delete items
if ((isset($_GET["del"]) && $_GET["del"] <> null && is_numeric($_GET["del"])) && $_SESSION[$ssn.'editmode'] == 'SUPER') {
    $get_id_del = $_GET["del"];

    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_del);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
        $inputdate = $myrow_item["39inputdate"];
        $dir_year = substr("$inputdate", 0, 4);
        $instimestamp = $myrow_item["41instimestamp"];
    
    $del_path = "$dir_year/$get_id_del"."_"."$instimestamp";
    $get_delfilename = ($num_results_affected >= 1) ? $del_path : "NODIR";
    $get_delimgname = ($num_results_affected >= 1) ? $del_path : "NODIR";

    //handling freetype file
    $get_delfreetypefilename = "../$system_isofile_directory/$dir_year/NODIR.XXX";
    if (is_dir("../$system_isofile_directory/$dir_year")) {
        $files_scanned = scandir("../$system_isofile_directory/$dir_year");
        foreach ($files_scanned as $fileitem) {
            if (preg_match("/$get_id_del"."_"."$instimestamp/i", $fileitem) == 1) {
                $get_delfreetypefilename = "../$system_isofile_directory/$dir_year/$fileitem";
                break;
            }
        }
    }

    if ($delete_method == 'permanent') {
        mysqli_query($GLOBALS["conn"], "delete from eg_item where id='$get_id_del'");//delete traces from eg_item
        mysqli_query($GLOBALS["conn"], "delete from eg_item2 where eg_item_id='$get_id_del'");//delete traces from eg_item2
        mysqli_query($GLOBALS["conn"], "delete from eg_item2_indicator where eg_item_id='$get_id_del'");//delete traces from eg_item2_indicator
        mysqli_query($GLOBALS["conn"], "delete from eg_item_access where eg_item_id='$get_id_del'");//delete traces from eg_item_access
                
        if (is_file("../$system_docs_directory/".$get_delfilename.".pdf")) {
            unlink("../$system_docs_directory/".$get_delfilename.".pdf");
        }

        if (is_file("../$system_pdocs_directory/".$get_delfilename.".pdf")) {
            unlink("../$system_pdocs_directory/".$get_delfilename.".pdf");
        }
        
        if (is_file("../$system_albums_directory/".$get_delimgname.".jpg")) {
            unlink("../$system_albums_directory/".$get_delimgname.".jpg");
        }
            if (is_dir("../$system_albums_directory/".$get_delimgname)) {
                sfx_deleteDirectory("../$system_albums_directory/".$get_delimgname);
            }
        
        if (is_file("../$system_albums_watermark_directory/".$get_delimgname.".jpg")) {
            unlink("../$system_albums_watermark_directory/".$get_delimgname.".jpg");
        }
        
        if (is_file("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg")) {
            unlink("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg");
        }

        if (is_file("$get_delfreetypefilename")) {
            unlink("$get_delfreetypefilename");
        }
        sfx_refreshAndClose("Item has been deleted.");
    } elseif ($delete_method == 'takecover') {
        mysqli_query($GLOBALS["conn"], "update eg_item set 50item_status='0' where id='$get_id_del'");//set invisible traces from eg_item
        
        if (is_file("../$system_docs_directory/".$get_delfilename.".pdf")) {
            rename("../$system_docs_directory/".$get_delfilename.".pdf", "../$system_docs_directory/".$get_delfilename.".pdf.deleted");
        }
        
        if (is_file("../$system_pdocs_directory/".$get_delfilename.".pdf")) {
            rename("../$system_pdocs_directory/".$get_delfilename.".pdf", "../$system_pdocs_directory/".$get_delfilename.".pdf.deleted");
        }
        
        if (is_file("../$system_albums_directory/".$get_delimgname.".jpg")) {
            rename("../$system_albums_directory/".$get_delimgname.".jpg", "../$system_albums_directory/".$get_delimgname.".jpg.deleted");
        }
            if (is_dir("../$system_albums_directory/".$get_delimgname)) {
                rename("../$system_albums_directory/".$get_delimgname, "../$system_albums_directory/".$get_delimgname."_deleted");
            }
        
        if (is_file("../$system_albums_watermark_directory/".$get_delimgname.".jpg")) {
            rename("../$system_albums_watermark_directory/".$get_delimgname.".jpg", "../$system_albums_watermark_directory/".$get_delimgname.".jpg.deleted");
        }
        
        if (is_file("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg")) {
            rename("../$system_albums_thumbnail_directory/".$get_delimgname.".jpg", "../$system_albums_thumbnail_directory/".$get_delimgname.".jpg.deleted");
        }

        if (is_file("$get_delfreetypefilename")) {
            rename("$get_delfreetypefilename","$get_delfreetypefilename.deleted");
        }
        sfx_refreshAndClose("Item has been deleted.");
    }
} elseif ((isset($_GET["del"]) && $_GET["del"] <> null && is_numeric($_GET["del"])) && $_SESSION[$ssn.'editmode'] == 'STAFF') {
    sfx_echoPopupAlert("Trying doing something illegal arent you ?");
}
