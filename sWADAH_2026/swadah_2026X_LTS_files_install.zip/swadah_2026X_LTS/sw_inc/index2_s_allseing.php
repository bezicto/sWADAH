<?php
    /*
    Filename: sw_inc/index2_s_allseing.php
    Usage: Search engine with SQL statement
    Version: 20250101.0801
    Last change: -
    20260624.1614 - remove common wordlist usage
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
    
    $queryAppend = ($sctype_select != 'EveryThing') ? "and 38typeid = '$sctype_select'" : "";
    $queryPeriod = ($scstr_period >= 1) ? "and STR_TO_DATE(CONCAT(eg_item2.38publication_c, '-01-01'), '%Y-%m-%d') > DATE_SUB(NOW(), INTERVAL $scstr_period YEAR)" : "";

    $scstr_term = mysqli_real_escape_string($GLOBALS["conn"], $scstr_term ?? '');
    if ($scstr_term == '') {
        $query1 = "select SQL_CALC_FOUND_ROWS
            eg_item.id as id, eg_item.38title as 38title, eg_item.38folderid as 38folderid, eg_item.38typeid as 38typeid,
            eg_item.38author as 38author, eg_item.38source as 38source, eg_item.39inputdate as 39inputdate, eg_item.41hits as 41hits,
            eg_item.38link as 38link, eg_item.41fulltexta as 41fulltexta, eg_item.41isabstract as 41isabstract, eg_item.38localcallnum as 38localcallnum,
            eg_item.38publication as 38publication, eg_item.41instimestamp as 41instimestamp,
            eg_item2.38publication_c as 38publication_c
                from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id where eg_item.id<>0";
        $query1 .= " $queryAppend and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' order by eg_item.id desc LIMIT $offset, $rowsPerPage";
    } else {
        $append_faster_search = isset($_SESSION[$ssn.'sear_ft']) && $_SESSION[$ssn.'sear_ft'] == 1 ? ",eg_item.41pdfattach_fulltext , eg_item.50search_cloud" : "";

        $query1 = "select SQL_CALC_FOUND_ROWS eg_item.id as id, eg_item.38title as 38title, eg_item.38folderid as 38folderid, eg_item.38typeid as 38typeid,
            eg_item.38author as 38author, eg_item.38source as 38source, eg_item.39inputdate as 39inputdate, eg_item.41hits as 41hits,
            eg_item.38link as 38link, eg_item.41fulltexta as 41fulltexta, eg_item.41isabstract as 41isabstract, eg_item.38localcallnum as 38localcallnum,
            eg_item.38publication as 38publication, eg_item.41instimestamp as 41instimestamp,
            eg_item2.38publication_c as 38publication_c,
            match (eg_item.38title,eg_item.38author) against ('$scstr_term' in boolean mode) as score
                from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id where eg_item.id<>0";
        $query1 .= " $queryAppend $queryPeriod and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and
            match (eg_item.38title, eg_item.41fulltexta, eg_item.38author $append_faster_search)";
        $query1 .= " against ('$scstr_term' in boolean mode) order by score desc LIMIT $offset, $rowsPerPage";
    }
