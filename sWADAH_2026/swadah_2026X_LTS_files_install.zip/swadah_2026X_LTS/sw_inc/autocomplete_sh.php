<?php
/*
Filename: sw_inc/autocomplete_sh.php
Usage: Auto-complete subject heading as used in sw_asset/js/swadah.js
Version: 20250101.0801
Last change: -
*/

include_once '../core.php';

// Get search term
if (!isset($_GET['term'])) {
        die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
}

$searchTerm = mysqli_real_escape_string($GLOBALS["conn"], $_GET['term']);

//Generate skills data array
$itemData = array();

$param = "%$searchTerm%";
$stmtB = $new_conn->prepare("SELECT 43acronym FROM eg_subjectheading WHERE 43acronym LIKE ? order by 43acronym");
$stmtB->bind_param("s", $param);//s string
$stmtB->execute();
$resultB = $stmtB->get_result();

while ($row = $resultB->fetch_assoc()) {
        array_push($itemData, $row['43acronym']);
}

// Return results as json encoded array
echo json_encode($itemData);
