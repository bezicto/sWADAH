<?php
    /*
    Filename: sw_inc/view_storedSession.php
    Usage: will list out all session variable use for debugging purpose
    Version: 20250301.0000
    Last change: -
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");

    if ($debug_mode == 'yes') {
        
        $unsetVariables = []; // Initialize an array to store the list of unset session variables and their values
        $sessionVariables = $_SESSION; // Get all session variables

        // Loop through each session variable
        foreach ($sessionVariables as $key => $value) {
            // Store the variable name and its value
            $unsetVariables[$key] = $value;
        }

        // Output the list of unset session variables and their values
        if (!empty($unsetVariables)) {
            $print_sessvar = "<span style='color:cyan;'>Alive session variables:</span> ";
            foreach ($unsetVariables as $key => $value) {
                // Convert the value to a readable string and escape HTML characters
                $valueString = htmlspecialchars(print_r($value, true));
                $print_sessvar .= "<strong>$key</strong>: $valueString, ";
            }
        } else {
            $print_sessvar = "<span style='color:cyan;'>No session variables are alive.</span>";
        }
    }
