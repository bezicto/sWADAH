<?php
    /*
    Filename: sw_inc/meta.php
    Usage: Meta widget/links on the start page
    Version: 20250101.0801
    Last change: -
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
?>
<style>
        .meta-button {
            display: inline-block;
            padding: 3px 8px;
            background: linear-gradient(to bottom, #7b96c9, #556b9e);
            color: white;
            text-decoration: none;
            border-radius: 3px;
            font-size: 8pt;
            font-weight: 500;
            margin: 0 4px;
            border: none;
            box-shadow: 0 1px 2px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }

        .meta-button:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
            background: linear-gradient(to bottom, #8ba3d3, #6277ad);
        }
    </style>
<?php
    if ($system_mode != 'maintenance') {
        if ($GLOBALS["enable_oai_pmh"]) {
            sfx_createModalPopupMenu('oai_click', 'OAI PMH v2.0 Status', "OAI PMH v2.0 is enabled for this repository: <a href='$system_path"."oai2.php'>Click Here</a>");
        }
        if ($GLOBALS["enable_searcher_api"]) {
            sfx_createModalPopupMenu('api_click', 'Searcher API Status', "Searcher API is enabled for this repository: <a href='$system_path"."searcherapi.php'>Click Here</a>");
        }
    ?>
        <br/>
        <div style='text-align:center;font-size:8pt;'>
            <?php
                if ($show_admin_login_link || ($GLOBALS["enable_oai_pmh"] && $show_meta_oai_link) || ($GLOBALS["enable_searcher_api"] && $show_meta_searcherapi_link)) {
                    echo "<strong>Meta:</strong> ";
                }
                if ($show_admin_login_link) {echo "<a href='in.php?t=sa' class='meta-button'>Administration</a>";}
                if ($GLOBALS["enable_oai_pmh"] && $show_meta_oai_link && ($system_function == 'full' || $system_function == 'repo')) {echo "<a href='#' id='oai_click' class='meta-button'>OAI</a>";}
                if ($GLOBALS["enable_searcher_api"] && $show_meta_searcherapi_link && ($system_function == 'full' || $system_function == 'repo')) {echo "<a href='#' id='api_click' class='meta-button'>API</a>";}
            ?>
        </div>
    <?php
    }
