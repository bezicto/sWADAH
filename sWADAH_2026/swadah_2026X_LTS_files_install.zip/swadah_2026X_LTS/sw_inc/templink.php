<?php
/*
Filename: sw_inc/templink.php
Usage: Create temporary access link token that valid for 24 hours and 3 clicks
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if (isset($_GET["itemid"]) && is_numeric($_GET["itemid"])) {
    $get_id_det = $_GET["itemid"];
    $timestamp = time();
    $token = uniqid(md5($get_id_det.time()));
    $stmt_insert = $new_conn->prepare("insert into eg_tempaccess values(DEFAULT,?,?,?,DEFAULT)");
    $stmt_insert->bind_param("iss", $get_id_det, $timestamp, $token);
    $stmt_insert->execute();$stmt_insert->close();
    echo "<b>Access link:</b><br/><span style='font-size:10pt'>$system_path"."detailsg.php?det=$get_id_det&at=$token</span>";
    echo "<br/><span style='font-size:10pt;color:grey;'>This link will only valid for a ".($tmpal_access_duration/3600)." hours and with a maximum of $tmpal_access_count clicks.</span>";
    echo "<br/></br>[<a class='sButtonRedSmall' href='javascript:window.close();'><span class='fas fa-window-close'></span> Close</a>]";
    exit;
} elseif (isset($_GET["itemid"]) && !is_numeric($_GET["itemid"])) {
    sfx_echoPopupAlert("Trying doing something illegal arent you ?");
    exit;
}
