<?php
    /*
    Filename: sw_inc/loginless_check.php
    Usage: check if user is using loginless token to access the system. if yes then set the session
    Version: 20250101.0801
    Last change: -
    */
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
    
    if (isset($_GET['lls']) && ctype_alnum($_GET['lls'])) {
        $stmt_login = $new_conn->prepare("select 43desc, 43tokenid, 44totalaccess, 43iprange, 43tokendailylimit, 44redirecturl from eg_loginless where 43token=?");
        $stmt_login->bind_param("s", $_GET['lls']);
        $stmt_login->execute();
        $result_login = $stmt_login->get_result();
        if ($result_login->num_rows>0) {
            $ippassed = false;
            while($row = $result_login->fetch_assoc()) {
                if (sfx_check_ip(sfx_get_ip(), $row['43iprange'])) {
                    $ippassed = true;
                    $newcount = $row['44totalaccess'] + 1;
                    $passedid = $row['43tokenid'];
                    $tokenlimit = $row['43tokendailylimit'];
                }
                $tokenowner = $row['43desc'];
                $redirecturl = $row['44redirecturl'];
            }
            if ($ippassed) {
                //set loginless sessions
                $_SESSION[$ssn.'lls'] = true;
                $_SESSION[$ssn.'lls_id'] = $passedid;
                $_SESSION[$ssn.'lls_token'] = $_GET['lls'];
                $_SESSION[$ssn.'lls_tokenlimit'] = $tokenlimit;
                $_SESSION[$ssn.'lls_tokenowner'] = $tokenowner;
                
                //check current daily usage search token count
                $stmt_fdb = $new_conn->prepare("select 44counts from eg_loginlesslog where 43date='".date('Y-m-d')."' and 43tokenid=".$_SESSION[$ssn.'lls_id']);
                $stmt_fdb->execute();
                $result_fdb = $stmt_fdb->get_result();
                $myrow_fdb = $result_fdb->fetch_assoc();
                if ($myrow_fdb["44counts"] > $_SESSION[$ssn.'lls_tokenlimit']) {
                    $_SESSION[$ssn.'disableSearch'] = true;
                }

                //log access count into database -start
                $stmt_update = $new_conn->prepare("update eg_loginless set 44totalaccess=? where 43tokenid=?");
                $stmt_update->bind_param("is",$newcount,$passedid);
                $stmt_update->execute();$stmt_update->close();
                //log access count into database -end --disabled on 9/5/2025 for seamless access
                //sfx_echoPopupAlert("User has been authenticated.","link","searcher.php");
            } else {
                //unset loginless session
                unset($_SESSION[$ssn.'lls']);
                unset($_SESSION[$ssn.'lls_token']);
                unset($_SESSION[$ssn.'lls_id']);
                unset($_SESSION[$ssn.'lls_tokenlimit']);
                unset($_SESSION[$ssn.'lls_tokenowner']);
                unset($_SESSION[$ssn.'disableSearch']);
                if ($redirecturl != "") {
                    header("Location: $redirecturl");
                    exit;
                } else {
                    sfx_echoPopupAlert("Illegal action detected. This link only to be access on site of $tokenowner.");
                }
            }
        } else {
            unset($_SESSION[$ssn.'lls']);
            unset($_SESSION[$ssn.'lls_token']);
            unset($_SESSION[$ssn.'lls_id']);
            unset($_SESSION[$ssn.'lls_tokenlimit']);
            unset($_SESSION[$ssn.'lls_tokenowner']);
            unset($_SESSION[$ssn.'disableSearch']);
            sfx_echoPopupAlert("Illegal action recorded.","link","searcher.php");
            exit;
        }
    }
