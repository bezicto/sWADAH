<?php
/*
Filename: sw_inc/undodelreq_code.php
Usage: Undo a delete request
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if ($_GET["itemid"] <> null && is_numeric($_GET["itemid"])) {
    $get_id = $_GET["itemid"];
    mysqli_query($GLOBALS["conn"], "update eg_item set 39proposedelete='FALSE', 39proposedeleteby=null, 39proposedelete_reason=null where id=$get_id");

    sfx_refreshAndClose("Delete request has been undone.","1000");
}
