<?php
/*
Filename: sw_inc/upl/upload.php
Usage: Handles uploaded item and rename it
Version: 20250101.0801
Last change: -
*/

defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");

if (!is_dir($affected_directory)) {
    mkdir($affected_directory, 0777, true);
    file_put_contents("$affected_directory/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
    file_put_contents(
                "$affected_directory/.htaccess",
                "<Files \"*.php\">\n".
                "    <IfModule mod_authz_core.c>\n".
                "        Require all denied\n".
                "    </IfModule>\n".
                "    <IfModule !mod_authz_core.c>\n".
                "        deny from all\n".
                "    </IfModule>\n".
                "</Files>\n".
                "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
            );
}

$pathparts = pathinfo($_FILES[$affected_filefield]['name']);
$affected_fileextension = strtolower($pathparts["extension"]);

//check if file extension is allowed
if (strpos($targetted_filetype,$affected_fileextension) !== false) {
    $proceedupload = 'TRUE';
    if ($affected_fileextension == 'jpeg') {
        $affected_fileextension = 'jpg';
    }
} else {
    $proceedupload = 'FALSE';
}

if ($_FILES[$affected_filefield]['size'] > $targetted_filemaxsize) {
    $successupload = 'FALSE SIZE';
} else {
    $successupload = 'TRUE';
    if ($allow_parser_to_parse_internally) {
        if ($_FILES[$affected_filefield]['size'] > $max_allow_parser_to_work) {
            $successbutnotparse = 'TRUENOT';
        } else {
            $successbutnotparse = "NOT";
        }
    }
}

if ($successupload == 'TRUE' && $proceedupload == 'TRUE') {
    if (is_uploaded_file($_FILES[$affected_filefield]['tmp_name'])) {
        //if pdf and isofile //elseif jpg, jpeg --multiple images
        if ($upload_type == "text") {
            move_uploaded_file($_FILES[$affected_filefield]['tmp_name'], $affected_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension);
        } elseif ($upload_type == "isofile") {
            if (!is_dir($affected_directory)) {
                mkdir($affected_directory, 0777, true);
                file_put_contents("$affected_directory/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
                file_put_contents(
                    "$affected_directory/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
            }
            if ($_FILES[$affected_filefield]['size'] < $targetted_filemaxsize && is_uploaded_file($_FILES[$affected_filefield]['tmp_name'])) {
                move_uploaded_file($_FILES[$affected_filefield]['tmp_name'], $affected_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension);
                echo "<span style='color:blue;'>$successful_upload_mesage</span>";
            } else {
                echo "<span style='color:red;'>Error in file upload.</span>";
            }
        } elseif ($upload_type == "multiimage") {
            //upload the original image
            move_uploaded_file($_FILES[$affected_filefield]['tmp_name'], $affected_directory.'/'.$imagenumber.'.'.$affected_fileextension);

            //lets watermarked the image
            $original_File = $affected_directory.'/'.$imagenumber.'.'.$affected_fileextension;
            $watermarked_File = $affected_directory.'/'.$imagenumber.'_wm.'.$affected_fileextension;
            sfx_watermark_image($original_File, "../".$watermark_overlay_file, $watermarked_File);

            //let make thumbnail smaller by 25% - 20240814
            $thumbnailed_target_File = $affected_directory.'/'.$imagenumber.'_tb.'.$affected_fileextension;
            sfx_thumbnail_image025($watermarked_File, $thumbnailed_target_File);

        } elseif ($upload_type == "image") {
            if (!is_dir($affected_watermark_directory)) {
                mkdir($affected_watermark_directory, 0777, true);
                file_put_contents("$affected_watermark_directory/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
                file_put_contents(
                    "$affected_watermark_directory/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
            }
            
            //lets watermarked the image
            $original_File = $affected_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension;
            $watermarked_File = $affected_watermark_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension;
                //if original image successfully uploaded
                if (move_uploaded_file($_FILES[$affected_filefield]['tmp_name'], $original_File)) {
                    //..then watermark the image
                    sfx_watermark_image($original_File, "../".$watermark_overlay_file, $watermarked_File);
                }
            
            //make thumbnail from the watermarked image
            if (!is_dir($affected_thumbnail_directory)) {
                mkdir($affected_thumbnail_directory, 0777, true);
                file_put_contents("$affected_thumbnail_directory/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>");
                file_put_contents(
                    "$affected_thumbnail_directory/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>sWADAH HTTP Response Code</em></div></body></html>\"\n"
                );
            }

            $thumbnailed_target_File = $affected_thumbnail_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension;
            sfx_thumbnail_image($watermarked_File, $thumbnailed_target_File);
        }
        
        if ($parse_txt_file) {
            $text_output = file_get_contents($affected_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension);
            $text_output = addslashes(preg_replace('/[^a-zA-Z0-9_ -]/s', ' ', $text_output));
        }
    }
    echo "<span style='color:blue;'>$successful_upload_mesage</span>";
    
    if ($parse_txt_file) {
        mysqli_query($GLOBALS["conn"], "update eg_item set $targetted_field_to_update='".addslashes($text_output)."' where id=$idUpload");
    }
} elseif ($successupload == 'FALSE SIZE' && $proceedupload == 'TRUE') {
    echo "<span style='color:red;'>$incorrect_filesize_mesage</span>";
} else {
    echo "<span style='color:red;'>$incorrect_filetype_mesage</span>";
}
    
