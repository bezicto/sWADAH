<?php
/*
Filename: listcomposer.php
Usage: Create and manage custom list page based on certain keyword. Also contains API access token and custom page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "List Composer";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
        
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_list where 43listid = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();
            $stmt_del->close();
            sfx_echoPopupAlert("List deleted.","link","listcomposer.php");
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","listcomposer.php");
            exit;
        }
        
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $title1 = sfx_just_clean($_POST["title1"], 'min');
            $type1 = sfx_just_clean($_POST["type1"], 'min');
            $filter1 = sfx_just_clean($_POST["filter1"], 'min');
            if ($_REQUEST["submitted"] == "Insert") {
                $new_token = md5(uniqid($type1, true)).openssl_encrypt($filter1, "AES-128-CTR", time(), 0, "1234567891011121");
                if (strlen($new_token) > 20) {
                    $new_token= substr($new_token, 0, 20); // truncate safely
                }
                if (!empty($type1) && (!empty($filter1))) {
                    $stmt_insert = $new_conn->prepare("insert into eg_list values(DEFAULT,?,?,?,?)");
                    $stmt_insert->bind_param("ssss", $title1, $type1, $filter1,$new_token);
                    $stmt_insert->execute();$stmt_insert->close();
                    sfx_echoPopupAlert("The list has been created.");
                } else {
                    sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];

                if (!empty($type1) && !empty($filter1)) {
                    $stmt_update = $new_conn->prepare("update eg_list set 43title=?, 43type=?, 43filter=? where 43listid=?");
                    $stmt_update->bind_param("sssi", $title1, $type1, $filter1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("The list has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s). The record has been restored to it original state.");
                }
            }
        }
        
        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select 43title, 43listid, 43type, 43filter from eg_list where 43listid = ?");
            $stmt3->bind_param("i", $get_id_upd);//i integer, s string, d double, b blob
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($title3, $id3, $type3, $filter3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","listcomposer.php");
            exit;
        }
    
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Create New List</strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
            <form action="listcomposer.php" method="post" enctype="multipart/form-data">
                <strong>List Title: </strong>
                <br/><input required type="text" name="title1" style="width:35%" maxlength="50" value="<?php if (isset($title3)) {echo $title3;} ?>"/>
            
                <br/><br/><strong>Type: </strong>
                <br/><select style="width:35%" name="type1">
                <?php
                    echo '<option value="EveryThing" '; if (isset($type3) && $type3 == 'EveryThing') {echo 'selected';} echo '>Everything</option>';
                    $query_typelist = "select 38typeid, 38type, 38synonym from eg_item_type";
                    $result_typelist = mysqli_query($GLOBALS["conn"], $query_typelist);
                    while ($row_typelist = mysqli_fetch_array($result_typelist)) {
                        echo '<option value="'.$row_typelist['38typeid'].'"'; if (isset($type3) && $row_typelist['38typeid']==$type3) {echo ' selected';} echo '>'. $row_typelist['38synonym'] . '</option>'."\n";
                    }
                ?>
                </select>
                
                <br/><br/>
                <strong>Filter Term: </strong>
                <br/><input required type="text" name="filter1" style="width:35%" maxlength="50" value="<?php if (isset($filter3)) {echo $filter3;} ?>"/>
                
                <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />

                <br/><br/>
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                <input type="button" value="Cancel" onclick="location.href='listcomposer.php';">
            </form>
        </td>
        </tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>>
            <td colspan=8><strong>List Controls :</strong></td>
        </tr>
        
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'></td>
            <td style='text-align:left;'>Title</td>
            <td style='text-align:left;'>Type</td>
            <td style='width:150;'>Filter Term</td>
            <td style='width:150;'>Link Token</td>
            <td style='width:150;'>Searcher API Link</td>
            <td style='width:150;'>Link</td>
            <td style='width:150;'>Options</td>
        </tr>
        
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select 43listid, 43title, 43type, 43filter, 43token from eg_list order by 43listid");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $listid_fdb = $myrow_fdb["43listid"];
                $title_fdb = $myrow_fdb["43title"];
                $type_fdb = sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_fdb["43type"]) ?? 'Everything';
                $filter_fdb = $myrow_fdb["43filter"];
                $token_fdb = $myrow_fdb["43token"];
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>$title_fdb</td>";
                    echo "<td style='text-align:left;'>$type_fdb</td>";
                    echo "<td>$filter_fdb</td>";
                    echo "<td>$token_fdb</td>";
                    echo "<td><a target='_blank' href='../searcherapi.php?scstr=$filter_fdb&sctype=".$myrow_fdb["43type"]."'>Click</a></td>";
                    echo "<td><a href='../listgen.php?token=$token_fdb'>Click</a></td>";
                    echo "<td>";
                        echo "<a title='Delete this record' href='listcomposer.php?del=$listid_fdb' onclick=\"return confirm('Are you sure ? This is not undoable.');\"><i class=\"fas fa-trash\"></i></a> ";
                        echo "<a title='Update this record' href='listcomposer.php?edt=$listid_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
        ?>
    </table>

    <hr>

    <?php include_once '../sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
