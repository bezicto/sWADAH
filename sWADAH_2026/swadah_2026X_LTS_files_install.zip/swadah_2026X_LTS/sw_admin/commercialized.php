<?php
/*
Filename: sw_admin/commercialized.php
Usage: Listing of items that have been set to be commercialized
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    $thisPageTitle  = "Commercialized Item List";
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
        
    <div style='text-align:center'>
        <?php
                                                                                            
            $query_cmz = "select eg_item_id from eg_commercialize";
            $result_cmz = mysqli_query($GLOBALS["conn"], $query_cmz);
        
            $row_cmz = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
            $num_results_affected = $row_cmz[0];

            echo "<table class=$color_scheme"."Header><tr><td>";
                echo "<strong>Commercialized List</strong> : ";
                echo "$num_results_affected <em>record(s) found.</em>";
            echo "</td></tr></table>";
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'><td width=45></td><td width=60% style='text-align:left;'>Title</td><td>Set Price ($tag_020_c_currency)</td><td>Since</td></tr>";
                                                                                
                $n = 1;
                                        
                while ($myrow_cmz = mysqli_fetch_array($result_cmz)) {
                    $eg_item_id = $myrow_cmz["eg_item_id"];
                    $item_title = sfx_sGetValue("38title", "eg_item", "id", $eg_item_id);
                    $item_terms_of_availability = sfx_sGetValue("38_terms_of_availability", "eg_item2", "eg_item_id", $eg_item_id);
                    $item_since = sfx_sGetValue("since", "eg_commercialize", "eg_item_id", $eg_item_id);

                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td style='text-align:center;'>$n</td>";
                        echo "<td style='text-align:left;vertical-align:top;'>";
                            echo "<a href='details.php?det=$eg_item_id'>$item_title</a><br/>";
                        echo "</td>";
                        echo "<td style='text-align:center;vertical-align:top;'>$item_terms_of_availability</td>";
                        echo "<td style='text-align:center;vertical-align:top;'>".date('d M Y',$item_since)."</td>";
                    echo "</tr>";
                                                                    
                    $n = $n +1 ;
                }
            echo "</table>";
        ?>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
