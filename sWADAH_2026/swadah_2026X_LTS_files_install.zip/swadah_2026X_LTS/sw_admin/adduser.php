<?php
/*
Filename: sw_admin/adduser.php
Usage: Create and manage administrative/patron/staff users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Add User";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    //routing - experimental
    //route check before entering this page
    //route1 index2, route2 chanuser, route3 if route1 and route2 were followed
    if ((isset($_SESSION[$ssn.'route1']) && $_SESSION[$ssn.'route1'] == '1') && (isset($_SESSION[$ssn.'route2']) && $_SESSION[$ssn.'route2'] == '2')) {
        $_SESSION[$ssn.'route3'] = '3';
    } else {
        $_SESSION[$ssn.'route3'] = '0';
    }

    if ($_SESSION[$ssn.'route3'] != '3') {
        //immediately block user from any future usage
        mysqli_query($GLOBALS["conn"], "update eg_auth set num_attempt=$default_num_attempt_login where username='".$_SESSION[$ssn.'username']."'");
        header("Location: ../index.php?log=out");
        exit;
    }
    
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
    
    <?php
    
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $staffid1 = sfx_stringRemoveScriptTag($_POST["staffid1"],false);
            $fullname1 = sfx_stringRemoveScriptTag($_POST["fullname1"]);
            $division1 = sfx_stringRemoveScriptTag($_POST["division1"]);
            $usertype1 = sfx_stringRemoveScriptTag($_POST["usertype1"]);
            $publisheradmin1 = sfx_stringRemoveScriptTag($_POST["publisheradmin1"]);
            if ($_REQUEST["submitted"] == "Insert") {
                $stmt_count = $new_conn->prepare("select count(*) from eg_auth where username = ?");
                $stmt_count->bind_param("s", $staffid1);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected_username);
                $stmt_count->fetch();$stmt_count->close();
                if ($num_results_affected_username == 0) {
                    if (!empty($staffid1) && !empty($fullname1) && !empty($division1) && !empty($usertype1)) {
                        $stmt_insert = $new_conn->prepare("insert into eg_auth values(DEFAULT,?,AES_ENCRYPT('$default_create_password','$aes_key'),?,?,?,?,'','OFF',0,DEFAULT,DEFAULT)");
                        $stmt_insert->bind_param("sssss", $staffid1, $usertype1, $fullname1, $division1, $publisheradmin1);
                        $stmt_insert->execute();
                        $stmt_insert->close();
                        sfx_echoPopupAlert("User $fullname1 has been input into the database. Password has been set to $default_create_password");
                    } else {
                        sfx_echoPopupAlert("Your input has been cancelled. Check if any field(s) left emptied before posting.");
                    }
                } elseif ($num_results_affected_username >= 1) {
                    sfx_echoPopupAlert("Your input has been cancelled. Duplicate field value detected.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];
                if (!empty($fullname1) && !empty($staffid1) && !empty($division1)) {
                    $stmt_update = $new_conn->prepare("update eg_auth set name=?, username=?, division=?, usertype=?, publisheradmin=? where id=?");
                    $stmt_update->bind_param("sssssi", $fullname1, $staffid1, $division1, $usertype1, $publisheradmin1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("The record has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.");
                }
            }
        }

        if (isset($_GET["edt"]) && $_GET["edt"] <> null && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select id,username,usertype,division,name,publisheradmin from eg_auth where id = ?");
            $stmt3->bind_param("i", $get_id_upd);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $username3, $usertype3, $division3, $name3, $publisheradmin3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","chanuser.php");
            exit;
        }
        
    ?>
    
    <?php if (!isset($_REQUEST["submitted"]) || $_REQUEST["submitted"] != "Update") { ?>
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Add new user </strong></td></tr>
            <tr class=greyHeaderCenter><td style='width:370;'><br/>
            <form action="adduser.php" method="post" enctype="multipart/form-data">
                <table style='margin-left:auto;margin-right:auto;'>
                    <tr>
                        <td style='text-align:right;'><strong>User ID </strong></td>
                        <td style='text-align:left;'><input type="text" name="staffid1" size="40" maxlength="255" <?php if (isset($username3)) {echo "readonly=readonly";} ?> value="<?php if (isset($username3)) {echo $username3;} ?>"/></td>
                    </tr>
                
                    <tr>
                        <td style='text-align:right;'><strong>Full Name </strong></td>
                        <td style='text-align:left;'><input type="text" name="fullname1" size="40" maxlength="255" value="<?php if (isset($name3)) {echo $name3;} ?>"/></td>
                    </tr>
                                        
                    <tr>
                        <td style='text-align:right;'><strong>Address </strong></td>
                        <td style='text-align:left;'><textarea name="division1" cols="39" rows="5"><?php if (isset($division3)) {echo $division3;} ?></textarea></td>
                    </tr>

                    <tr>
                        <td style='text-align:right;'><strong>User Level </strong></td>
                        <td style='text-align:left;'>
                            <select name="usertype1">
                            <?php
                                $queryB = "select * from eg_auth_eligibility";
                                $resultB = mysqli_query($GLOBALS["conn"], $queryB);
                            
                                while ($myrowB = mysqli_fetch_array($resultB)) {
                                    $usertypeB = $myrowB["usertype"];
                                    $usertypedescB = $myrowB["usertypedesc"];
                                    echo "<option value='$usertypeB' "; if (isset($usertype3) && $usertypeB == $usertype3) {echo "selected";} echo ">$usertypeB - $usertypedescB</option>";
                                }
                            ?>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td style='text-align:right;'><strong>Publisher (Approver For)</strong></td>
                        <td style='text-align:left;'>
                            <select name="publisheradmin1">
                            <?php
                                $queryB = "select 43acronym,43publisher from eg_publisher";
                                $resultB = mysqli_query($GLOBALS["conn"], $queryB);
                                echo "<option value='ALL' ";
                                    if (isset($publisheradmin3) && $publisheradmin3 == 'ALL') {echo "selected";}
                                echo ">All</option>";
                                while ($myrowB=mysqli_fetch_array($resultB)) {
                                    echo "<option value='".$myrowB["43acronym"]."' ";
                                        if (isset($publisheradmin3) && $publisheradmin3 == $myrowB["43acronym"]) {echo "selected";}
                                    echo ">".$myrowB["43publisher"]."</option>";
                                }
                            ?>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td colspan='2' style='text-align:center;'>
                            <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                            <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>" />
                            <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                            <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                        </td>
                    </tr>
                </table>
            </form>
            </td></tr>
        </table><br/>
    <?php } ?>
    
    <div style='text-align:center;'><a class='sButton' href='../sw_admin/chanuser.php'><span class='fas fa-arrow-circle-left'></span> Back to user account page</a></div>
    
    <hr>

    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
