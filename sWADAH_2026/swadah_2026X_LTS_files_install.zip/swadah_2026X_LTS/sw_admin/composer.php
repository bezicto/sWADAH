<?php
/*
Filename: sw_admin/composer.php
Usage: Tool to edit FAQ and About page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "FAQ and About Composer";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
    
        if (isset($_REQUEST['submitted']) && $proceedAfterToken) {
            $value_form = $_POST["composevalue"];
            $stmt_update = $new_conn->prepare("update eg_composer set 45value=? where id=?");
            $stmt_update->bind_param("si", $value_form, $_POST['aid']);
            $stmt_update->execute();$stmt_update->close();
            sfx_echoPopupAlert("Value saved.");
        }
        
    ?>
    
    <?php
            $query_fdb = "select * from eg_composer";
            $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);
            $n = 1;
            while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                $id_fdb = $myrow_fdb["id"];
                $name_fdb = $myrow_fdb["45name"];
                $value_fdb = $myrow_fdb["45value"];
                echo "<form action='composer.php' method='post' enctype='multipart/form-data'>";
                    echo "<table style='width:100%;'><tr class=$color_scheme"."HeaderCenter><td><strong id='$name_fdb'>$name_fdb</strong></td></tr>";
                    echo "<tr><td style='text-align:center;'>
                                <textarea name='composevalue' style='width:100%;height:450px;'>$value_fdb</textarea>
                                <input type='hidden' name='aid' value='$id_fdb'>
                                <input type='hidden' name='token' value='".$_SESSION[$ssn.'token']."'>
                                <input type='submit' name='submitted' value='Save $name_fdb' />
                            </td></tr></table>";
                echo "</form>";
            }
    ?>
    
    <br/>
    <hr>
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
