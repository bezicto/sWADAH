<?php
/*
Filename: sw_admin/gpt_guide.php
Usage: ChatGPT Guide for OpenAI GPT Builder
Version: 20250301.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "OpenAI GPT Builder";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
    <style>
        .yaml-container, .text-container {
            max-width: 90%;  /* Max width of the container */
            margin: 0 auto;  /* Center the container */
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            white-space: pre-wrap;  /* Ensure text wraps */
            word-wrap: break-word;  /* Prevent horizontal scrolling */
            overflow-wrap: break-word;  /* Break long words if necessary */
            font-size: 16px;  /* Adjust font size for readability */
            color: #333;
            position: relative;
        }
        pre {
            white-space: pre; /* Preserve formatting exactly (no wrapping) */
            overflow-x: auto; /* Enable horizontal scrolling */
            padding: 10px;
            background-color: #f8f8f8;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .text-container pre {
            max-width: 90%;  /* Max width of the container */
            margin: 0 auto;  /* Center the container */
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            white-space: pre-wrap; /* Membolehkan teks dibungkus */
            word-wrap: break-word; /* Memastikan perkataan panjang dibungkus */
            overflow-wrap: break-word; /* Alternatif untuk penyemak imbas moden */
            font-size: 16px;  /* Adjust font size for readability */
            color: #333;
            position: relative;
        }
        .yaml-container h3, .text-container h3 {
            position: absolute;
            top: 10px;
            left: 10px;
            margin: 0;
        }
        .copy-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .copy-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
    require_once '../sw_vendor/autoload.php';

    use Symfony\Component\Yaml\Yaml;
        
    // Path to your YAML file
    $yamlFile = 'chatgpt/template.yaml';
    // Read the YAML file content
    $yamlContent = file_get_contents($yamlFile);
    // Replace the ^^systemname and ^^systemurl with your system name and URL
    $yamlContent = str_replace('^^systemname', $system_title, $yamlContent);
    $yamlContent = str_replace('^^systemurl', rtrim($system_path,'/'), $yamlContent);

    // text instructions
    $txtFile = 'chatgpt/instruction.txt';
    // Read the text file content
    $txtContent = file_get_contents($txtFile);
    // Replace the ^^systemname and ^^systemurl with your system name and URL
    $txtContent = str_replace('^^systemname', $system_title, $txtContent);
    $txtContent = str_replace('^^systemurl', rtrim($system_path,'/'), $txtContent);
        
    ?>

    <div class="text-container">
        <h3>Instructions</h3>
        <button class="copy-button" onclick="js_copyToClipboardtxt()">Copy</button>
        <pre id="txtContent"><?php echo htmlspecialchars($txtContent); ?></pre>
    </div>

    <br/>

    <div class="yaml-container">
        <h3>Actions</h3>
        <button class="copy-button" onclick="js_copyToClipboard()">Copy</button>
        <pre id="yamlContent"><?php echo htmlspecialchars($yamlContent); ?></pre>
    </div>
    
   

    <hr>
    <?php include_once '../sw_inc/footer.php';?>

    <script>
        function js_copyToClipboard() {
            const yamlText = document.getElementById("yamlContent").innerText;
            navigator.clipboard.writeText(yamlText).then(() => {
                alert("YAML copied to clipboard!");
            }).catch(err => {
                console.error("Failed to copy text: ", err);
            });
        }
        function js_copyToClipboardtxt() {
            const yamlText = document.getElementById("txtContent").innerText;
            navigator.clipboard.writeText(yamlText).then(() => {
                alert("Instruction copied to clipboard!");
            }).catch(err => {
                console.error("Failed to copy text: ", err);
            });
        }
    </script>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
