<?php
/*
Filename: sw_splus/templog.php
Usage: Lists temporary access link created to cater user need.
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Temporary Access List";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    $allowed_access_times = 3;

    $_SESSION[$ssn.'previous_url'] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    
    if (isset($_GET['rvk']) && is_numeric($_GET['rvk'])) {
        if ($tmpal_delete_method == 'keep') {
            mysqli_query($GLOBALS["conn"], "update eg_tempaccess set usagecount=$allowed_access_times where id=".$_GET['rvk']);
        } elseif ($tmpal_delete_method == 'delete') {
            mysqli_query($GLOBALS["conn"], "delete from eg_tempaccess where id=".$_GET['rvk']);
        }
        sfx_echoPopupAlert("Access revoke.","link","templog.php");
        exit;
    }
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
        
    <div style='text-align:center'>
        <?php
                                                                                            
            $query_emb = "select * from eg_tempaccess where usagecount < $allowed_access_times order by id desc";
            $result_emb = mysqli_query($GLOBALS["conn"], $query_emb);
        
            $row_emb = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
            $num_results_affected = $row_emb[0];

            echo "<table class=$color_scheme"."Header><tr><td>";
                echo "<strong>Created Temporary Access List</strong> : ";
                echo "$num_results_affected <em>record(s) found.</em>";
            echo "</td></tr></table>";
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;text-align:left;'><td width=45></td><td width=60%>Title</td><td>Since</td><td>Usage Counts</td><td>Options</td></tr>";
                                                                                
                $n = 1;
                                        
                while ($myrow_emb = mysqli_fetch_array($result_emb)) {
                    $id = $myrow_emb["id"];
                    $itemid = $myrow_emb["eg_item_id"];
                    $token = $myrow_emb["token"];
                    $usagecount = $myrow_emb["usagecount"];
                    $since = date("d M Y h:i:s a", $myrow_emb["since"]);

                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td style='text-align:center;'>$n</td>";
                        echo "<td style='text-align:left;vertical-align:top;'><a href='details.php?det=$id'>".sfx_sGetValue("38title", "eg_item", "id", $itemid)."</a>
                                <br/>Link: <u>$system_path"."detailsg.php?det=$itemid&at=$token</u></td>";
                        echo "<td style='text-align:left;vertical-align:top;'>$since</td>";
                        echo "<td style='text-align:left;vertical-align:top;'>$usagecount</td>";
                        echo "<td style='text-align:left;vertical-align:top;'>[<a onclick=\"return confirm('Are you sure ? This action will be finalize.');\" href=templog.php?rvk=$id>Revoke Access</a>]</td>";
                    echo "</tr>";
                                                                    
                    $n = $n +1 ;
                }
            echo "</table>";
        ?>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
