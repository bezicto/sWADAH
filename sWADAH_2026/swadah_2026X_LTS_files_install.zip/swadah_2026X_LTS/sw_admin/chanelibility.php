<?php
/*
Filename: sw_admin/chanelibility.php
Usage: Manage users elibility to bookmark items
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Change Eligibility";
    session_start();define('includeExist', true);
   
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
        
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enforce') {
            if ($_REQUEST['usertype'] != '') {
                $usertype = mysqli_real_escape_string($GLOBALS["conn"], $_POST["usertype"]);
                $usertypedesc = mysqli_real_escape_string($GLOBALS["conn"], $_POST["usertypedesc"]);
                $max_loanitem = mysqli_real_escape_string($GLOBALS["conn"], $_POST["max_loanitem"]);
                $stmt_count = $new_conn->prepare("select id from eg_auth_eligibility where usertype=?");
                $stmt_count->bind_param("s", $usertype);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected);
                $stmt_count->fetch();$stmt_count->close();
                if ($num_results_affected == 0) {
                    $stmt_insert = $new_conn->prepare("insert into eg_auth_eligibility values(DEFAULT,?,?,?)");
                    $stmt_insert->bind_param("ssi", $usertype, $usertypedesc, $max_loanitem);
                    $stmt_insert->execute();$stmt_insert->close();
                    sfx_echoPopupAlert("Record has been inputted into the database.");
                } elseif ($num_results_affected == 1) {
                    sfx_echoPopupAlert("Duplicate user type detected.");
                }
            } else {
                sfx_echoPopupAlert("User type cannot be empty.");
            }
        }
        
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == "Update") {
            if ($_REQUEST['usertype'] != '') {
                $usertype = $_POST["usertype"];
                $usertypedesc = $_POST["usertypedesc"];
                $max_loanitem = $_POST["max_loanitem"];
                $stmt_update = $new_conn->prepare("update eg_auth_eligibility set usertype=?, usertypedesc=?, max_loanitem=? where id=?");
                $stmt_update->bind_param("ssii", $usertype, $usertypedesc, $max_loanitem, $_POST['aid']);
                $stmt_update->execute();$stmt_update->close();
                sfx_echoPopupAlert("User type has been updated.");
            } else {
                sfx_echoPopupAlert("User type cannot be empty.");
            }
        }
        
        if (isset($_GET['aid']) && is_numeric($_GET['aid'])) {
            $stmt3 = $new_conn->prepare("select usertype,usertypedesc,max_loanitem from eg_auth_eligibility where id=?");
            $stmt3->bind_param("i", $_GET['aid']);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($usertypeA, $usertypedescA, $max_loanitemA);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["aid"]) && !is_numeric($_GET["aid"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","chanelibility.php");
            exit;
        }
        
    ?>
    
    <?php if (isset($_GET['aid'])) {?>
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Eligibility status </strong></td></tr>
            <tr class=greyHeaderCenter><td style='width:370;'><br/>
            <form action="chanelibility.php" method="post" enctype="multipart/form-data">
                <table style='margin-left:auto;margin-right:auto;'>
                    <tr>
                        <td><strong>User Type: </strong></td>
                        <td><input type="text" readonly=readonly name="usertype" size="35" maxlength="70" value="<?php if (isset($usertypeA)) {echo $usertypeA;}?>"/></td>
                    </tr>

                    <tr>
                        <td><strong>User Type Description:</strong></td>
                        <td><input type="text" name="usertypedesc" size="35" maxlength="70" value="<?php if (isset($usertypedescA)) {echo $usertypedescA;}?>"/></td>
                    </tr>

                    <tr>
                        <td><strong>Total number of allowed bookmarked items: </strong></td>
                        <td><input type="text" name="max_loanitem" size="35" maxlength="70" value="<?php if (isset($max_loanitemA) && $max_loanitemA != '') {echo $max_loanitemA;} else {echo "0";}?>"/></td>
                    </tr>
                
                    <tr><td colspan='2' style='text-align:center;'><br/>
                        <?php
                        if (!isset($_GET['aid'])) {
                            echo "<input type='submit' name='submitted' value='Enforce' /> ";
                            echo "<input type='button' name='reset' value='Reset' onclick=\"window.location='chanelibility.php';\"/>";
                        } else {
                            echo "<input type='hidden' name='aid' value='".$_GET['aid']."' />";
                            echo "<input type='submit' name='submitted' value='Update' /> ";
                            echo "<input type='button' name='reset' value='Cancel' onclick=\"window.location='chanelibility.php';\"/>";
                        }
                        ?>
                    </td></tr>
                </table>
            </form>
            </td></tr>
        </table><br/><br/>
    <?php }?>

    <table style='width:100%;' class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=6><strong>User Type Listing and Controls :</strong></td></tr>
        <tr class=whiteHeaderCenter style='text-decoration:underline;'>
            <td style='width:25;'></td>
            <td style='width:35%;'>User Type</td>
            <td style='width:20%;'>User Type Description</td>
            <td>Max Bookmarked Item</td>
            <td>Options</td>
        </tr>

        <?php
            $query_fdb = "select * from eg_auth_eligibility where usertype!='FALSE' and usertype!='DEPATRON'";
            $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);
            $n = 1;
            while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                    $id_fdb = $myrow_fdb["id"];
                    $usertype_fdb = $myrow_fdb["usertype"];
                    $usertypedesc_fdb = $myrow_fdb["usertypedesc"];
                    $max_loanitem_fdb = $myrow_fdb["max_loanitem"];
                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td>$n</td>";
                        echo "<td>$usertype_fdb</td>";
                        echo "<td>$usertypedesc_fdb</td>";
                        echo "<td>$max_loanitem_fdb</td>";
                        echo "<td><a title='Edit this eligibility' href='chanelibility.php?aid=$id_fdb'><i class=\"fas fa-edit\"></i></a></td>";
                    echo "</tr>";
                    $n = $n + 1;
                }
        ?>
    </table>
    
    <br/>
    <div style='text-align:center;'><a class='sButton' href='../sw_admin/chanuser.php'><span class='fas fa-arrow-circle-left'></span> Back to user account page</a></div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
