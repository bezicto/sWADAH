<?php
/*
Filename: sw_admin/commercialtoken.php
Usage: Manage token creation and expiry for accessing the commercial API
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Commercial API Loginless Authentication";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
        
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_commercial_token where 43tokenid = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();
            $stmt_del->close();
            sfx_echoPopupAlert("Token deleted.","link","commercialtoken.php");
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","commercialtoken.php");
            exit;
        }
        
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $desc1 = sfx_just_clean($_POST["desc1"], 'min');
            if ($_REQUEST["submitted"] == "Create") {
                $new_token = preg_replace("/[^a-zA-Z0-9]+/", "",md5(uniqid($desc1, true)).openssl_encrypt($aes_key, "AES-128-CTR", time(), 0, "1234567891011121"));
                if (!empty($desc1)) {
                    $stmt_insert = $new_conn->prepare("insert into eg_commercial_token values(DEFAULT,?,?,DEFAULT)");
                    $stmt_insert->bind_param("ss", $desc1, $new_token);
                    $stmt_insert->execute();$stmt_insert->close();
                    sfx_echoPopupAlert("The token has been created.");
                } else {
                    sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];

                if (!empty($desc1)) {
                    $stmt_update = $new_conn->prepare("update eg_commercial_token set 43desc=? where 43tokenid=?");
                    $stmt_update->bind_param("si", $desc1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("The token has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s). The record has been restored to it original state.");
                }
            }
        }
        
        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select 43tokenid, 43desc, 43token from eg_commercial_token where 43tokenid = ?");
            $stmt3->bind_param("i", $get_id_upd);//i integer, s string, d double, b blob
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $desc3, $token);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","commercialtoken.php");
            exit;
        }
    
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Create New Token for Commercial API</strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
            <form action="commercialtoken.php" method="post" enctype="multipart/form-data">
                <strong>Description: </strong>
                <br/><input required type="text" name="desc1" style="width:35%" maxlength="50" value="<?php if (isset($desc3)) {echo $desc3;} ?>"/>
                
                <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Create";}?>" />

                <br/><br/>
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update Token";} else {echo "Create Token";}?>" />
                <input type="button" value="Cancel" onclick="location.href='commercialtoken.php';">
            </form>
        </td>
        </tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>>
            <td colspan=5><strong>Token Controls :</strong></td>
        </tr>
        
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'></td>
            <td style='text-align:left;'>Description</td>
            <td style='text-align:left;'>Token</td>
            <td style='text-align:left;'>Access Count</td>
            <td style='width:150;'>Options</td>
        </tr>
        
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select 43tokenid, 43desc, 43token, 44totalaccess from eg_commercial_token order by 43tokenid");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $tokenid_fdb = $myrow_fdb["43tokenid"];
                $desc_fdb = $myrow_fdb["43desc"];
                $token_fdb = $myrow_fdb["43token"];
                $access_fdb = $myrow_fdb["44totalaccess"];
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>$desc_fdb</td>";
                    echo "<td style='text-align:left;'>$token_fdb [<a target='_blank' href='../sw_cmmsl/api.php?cak=$token_fdb&showlist=commercial'>Test</a>]</td>";
                    echo "<td style='text-align:left;'>$access_fdb</td>";
                    echo "<td>";
                        echo "<a title='Delete this record' href='commercialtoken.php?del=$tokenid_fdb' onclick=\"return confirm('Are you sure ? This is not undoable.');\"><i class=\"fas fa-trash\"></i></a> ";
                        echo "<a title='Update this record' href='commercialtoken.php?edt=$tokenid_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
        ?>
    </table>

    <hr>

    <?php include_once '../sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
