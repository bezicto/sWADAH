<?php
/*
Filename: sw_admin/adduser_bulk.php
Usage: Bulk add new users - patron only
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Bulk Patron User";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    //routing - experimental
    //route check before entering this page
    //route1 index2, route2 chanuser, route3 if route1 and route2 were followed
    if ((isset($_SESSION[$ssn.'route1']) && $_SESSION[$ssn.'route1'] == '1') && (isset($_SESSION[$ssn.'route2']) && $_SESSION[$ssn.'route2'] == '2')) {
        $_SESSION[$ssn.'route3'] = '3';
    } else {
        $_SESSION[$ssn.'route3'] = '0';
    }

    if ($_SESSION[$ssn.'route3'] != '3') {
        //immediately block user from any future usage
        mysqli_query($GLOBALS["conn"], "update eg_auth set num_attempt=$default_num_attempt_login where username='".$_SESSION[$ssn.'username']."'");
        header("Location: ../index.php?log=out");
        exit;
    }
    
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
    
    <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
            // Database connection

            $file = $_FILES['csv_file']['tmp_name'];
            if (!is_uploaded_file($file)) {
                die("Upload failed.");
            }

            $row_number = 1;
            $error_rows = [];

            if (($handle = fopen($file, 'r')) !== false) {
                echo "<h3>Processing uploaded file...</h3>";
                while (($data = fgetcsv($handle, 1000, ',', '"', '\\')) !== false) {
                    $row_number++;

                    if (count($data) < 3) {
                        $error_rows[] = $row_number;
                        continue;
                    }

                    list($username, $name, $division) = $data;

                    // Trim whitespace from all fields
                    $username = trim($username);
                    $name = trim($name);
                    $division = trim($division);

                    // Clean fields by removing invalid characters (keep only alphanumeric and spaces)
                    $original_username = $username;
                    $original_name = $name;
                    $original_division = $division;
                    
                    $username = preg_replace('/[^a-zA-Z0-9]/', '', $username);
                    $name = preg_replace('/[^a-zA-Z0-9\s]/', '', $name);
                    $division = preg_replace('/[^a-zA-Z0-9\s]/', '', $division);
                    
                    // Show what was cleaned if changes were made
                    if ($original_username !== $username) {
                        echo "<p>Row $row_number: Username cleaned from '$original_username' to '$username'</p>";
                    }
                    if ($original_name !== $name) {
                        echo "<p>Row $row_number: Name cleaned from '$original_name' to '$name'</p>";
                    }
                    if ($original_division !== $division) {
                        echo "<p>Row $row_number: Division cleaned from '$original_division' to '$division'</p>";
                    }

                    try {
                        // Check if username already exists
                        $check_stmt = $new_conn->prepare("SELECT COUNT(*) FROM eg_auth WHERE username = ?");
                        $check_stmt->execute([$username]);
                        $result = $check_stmt->get_result();
                        $count = $result->fetch_row()[0];
                        
                        if ($count > 0) {
                            // Username already exists, skip this row
                            echo "<p>Row $row_number: Username '$username' already exists, skipping...</p>";
                            continue;
                        }
                        
                        $stmt = $new_conn->prepare("
                            INSERT INTO eg_auth
                            (username, syspassword, usertype, name, division)
                            VALUES (?, AES_ENCRYPT('$default_create_password', ?), 'PATRON', ?, ?)
                        ");
                        $stmt->execute([$username, $aes_key, $name, $division]);
                    } catch (Exception $e) {
                        $error_rows[] = $row_number;
                    }
                }
                fclose($handle);

                if (!empty($error_rows)) {
                    echo "<p>Import completed with errors on rows: " . implode(", ", $error_rows) . "</p>";
                } else {
                    echo "<p>All rows imported successfully! Default password for all users is $default_create_password</p>";
                }

                echo '<p><a href="' . $_SERVER['PHP_SELF'] . '">Upload another file</a></p>';
            } else {
                echo "Unable to read uploaded file.";
            }

            exit;
        }
        
    ?>
    
    <?php if (!isset($_REQUEST["submitted"]) || $_REQUEST["submitted"] != "Upload and Import") { ?>
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Bulk PATRON uploader. All users will be create with PATRON user type.</strong></td></tr>
            <tr class=greyHeaderCenter><td style='width:370;'><br/>
            <form action="adduser_bulk.php" method="POST" enctype="multipart/form-data">
                <label>Select CSV file (format: username, full name, division)<br/>Maximum 5MB, please do in segments for large files:</label><br/><br/>
                <input type="file" name="csv_file" accept=".csv" required>
                <br><br>
                <input type="hidden" name="submitted" value="Upload and Import">
                <input type="submit" value="Upload and Import">
            </form>
            </td></tr>
        </table><br/>
    <?php } ?>
    
    <div style='text-align:center;'><a class='sButton' href='../sw_admin/chanuser.php'><span class='fas fa-arrow-circle-left'></span> Back to user account page</a></div>
    
    <hr>

    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
