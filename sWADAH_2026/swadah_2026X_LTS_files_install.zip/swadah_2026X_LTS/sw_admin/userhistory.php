<?php
/*
Filename: userhistory.php
Usage: List user bookmark history
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "User Bookmark History";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>

    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <?php if (isset($_REQUEST["pid"]) && is_numeric($_REQUEST["pid"])) {?>
        <table class=whiteHeaderNoCenter>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>>
                <td colspan=3><strong><?php echo sfx_sGetValue("name", "eg_auth", "id", $_REQUEST["pid"], "i");?></strong></td>
            </tr>
            
            <tr class=whiteHeaderCenterUnderline>
                <td style='width:5%;'></td>
                <td>Title</td>
                <td style='width:15%;'>Bookmarked on</td>
            </tr>
            
            <?php
                $n = 1;
                $param_fdb = sfx_sGetValue("username", "eg_auth", "id", $_REQUEST["pid"], "i");
                $stmt_fdb = $new_conn->prepare("select * from eg_item_charge where 39patron=?");
                $stmt_fdb->bind_param("s", $param_fdb);
                $stmt_fdb->execute();
                $result_fdb = $stmt_fdb->get_result();
                while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                    $accessnum_fdb = $myrow_fdb["38accessnum"];
                    $charged_on_fdb = $myrow_fdb["39charged_on"];
                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td style='text-align:center;'>$n</td>";
                        echo "<td>".sfx_sGetValue("38title", "eg_item", "38accessnum", $accessnum_fdb)."<br/><div style='font-size:10px'><em>$accessnum_fdb</em></div></td>";
                        echo "<td>".date('D, Y-m-d h:i:s a', $charged_on_fdb)."</td>";
                    echo "</tr>";
                    $n = $n + 1;
                }
            ?>
        </table><br/>
    <?php } else {echo "<h2 style='text-align:center;'>No history</h2>";}?>
        
    <div style='text-align:center;'><a class='sButton' href='chanuser.php'><span class='fas fa-arrow-circle-left'></span> Back to user account page</a></div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
