<?php
/*
Filename: sw_admin/addfolder_auth.php
Usage: Folder access to users binding module
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Bind folder for access";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
        if (isset($_REQUEST["fid"]) && is_numeric($_REQUEST["fid"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_REQUEST["fid"]);
            $stmt3 = $new_conn->prepare("select 38folderid, 38foldername from eg_item_folder where 38folderid = ?");
            $stmt3->bind_param("i", $get_id_upd);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $name3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["fid"]) && !is_numeric($_GET["fid"])) {
            sfx_echoPopupAlert("Illegal action recorded.", "link", "addfolder.php");
            exit;
        }

        if (isset($_GET["del"]) && is_numeric($_REQUEST["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_item_folder_auth where id=? and eg_item_folder_id=?");
            $stmt_del->bind_param("ii", $get_id_del, $_REQUEST["fid"]);
            $stmt_del->execute();$stmt_del->close();
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.", "link", "addfolder.php");
            exit;
        }
        
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $name1 = sfx_stringRemoveScriptTag($_POST["name1_sc"],false);
            if ($_REQUEST["submitted"] == "Insert") {
                $stmt_count = $new_conn->prepare("select count(*) from eg_item_folder_auth where eg_auth_username=? and eg_item_folder_id=?");
                $stmt_count->bind_param("si", $name1, $_REQUEST["fid"]);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected);
                $stmt_count->fetch();$stmt_count->close();

                $stmt_count = $new_conn->prepare("select count(*) from eg_auth where username=?");
                $stmt_count->bind_param("s", $name1);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected_in_auth);
                $stmt_count->fetch();$stmt_count->close();
                
                if ($num_results_affected == 0 && $num_results_affected_in_auth >= 1) {
                    if (!empty($name1)) {
                        $stmt_insert = $new_conn->prepare("insert into eg_item_folder_auth values(DEFAULT,?,?)");
                        $stmt_insert->bind_param("is", $_REQUEST['fid'], $name1);
                        $stmt_insert->execute();$stmt_insert->close();
                        sfx_echoPopupAlert("User $name1 has been added.");
                    } else {
                        sfx_echoPopupAlert("Your input has been cancelled. Check if any field(s) left emptied before posting.");
                    }
                } else {
                    sfx_echoPopupAlert("Your input has been cancelled. Either user has already added or user not exist.");
                }
            }
        }
                
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong>Add user to access this folder : <span style='color:blue;'><?php echo $name3;?></span></strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
        <form action="addfolder_auth.php" method="post" enctype="multipart/form-data">
                <strong>Username: </strong>
                <br/>
                <input type="text" id="name1_sc" name="name1_sc" style="width:50%;" maxlength="150">
                <br/><br/>
                <input type="hidden" name="fid" value="<?= $id3;?>" />
                <input type="hidden" name="submitted" value="Insert" />
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="Insert" />
                <input type="button" value="Cancel" onclick="location.href='addfolder_auth.php?fid=<?= $id3;?>';">
        </form>
        </td></tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=3><strong>User listing and controls for current folder :</strong></td></tr>
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'>ID</td>
            <td style='text-align:left;'>Users</td>
            <td style='width:150;'>Options</td>
        </tr>
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select * from eg_item_folder_auth where eg_item_folder_id=$id3");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $id_fdb = $myrow_fdb["id"];
                $folderid_fdb = $myrow_fdb["eg_item_folder_id"];
                $user_fdb = $myrow_fdb["eg_auth_username"];
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>".sfx_sGetValue("name", "eg_auth", "username", $user_fdb)." ($user_fdb)</td>";
                    echo "<td><a title='Delete this record' href='addfolder_auth.php?fid=$folderid_fdb&del=$id_fdb' onclick=\"return confirm('Are you sure ?');\"><i class=\"fas fa-trash\"></i></a></td>";
                echo "</tr>";
                $n = $n + 1;
            }
            $stmt_fdb->close();
        ?>
    </table>
            
    <br/>
    <div style='text-align:center;'><a class='sButton' href='addfolder.php'><span class='fas fa-arrow-circle-left'></span> Back to folder list</a></div>
    <br/>
    <hr>

    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
