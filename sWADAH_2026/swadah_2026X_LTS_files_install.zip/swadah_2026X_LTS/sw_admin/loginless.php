<?php
/*
Filename: loginless.php
Usage: Create and manage loginless access token
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Loginless Authentication";
    session_start();define('includeExist', true);
   
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
        
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_loginless where 43tokenid = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();
            $stmt_del->close();
            sfx_echoPopupAlert("Token deleted.","link","loginless.php");
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","loginless.php");
            exit;
        }
        
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $desc1 = sfx_just_clean($_POST["desc1"], 'min');
            $token1 = sfx_just_clean($_POST["token1"], 'min');
            $iprange1 = $_POST["iprange1"];
            $tokendailylimit1 = $_POST["tokendailylimit1"];
            $redirecturl1 = $_POST["redirecturl1"];
            if ($_REQUEST["submitted"] == "Create") {
                $new_token = preg_replace("/[^a-zA-Z0-9]+/", "",md5(uniqid($desc1, true)).openssl_encrypt($desc1, "AES-128-CTR", time(), 0, "1234567891011121"));
                if (!empty($desc1)) {
                    $stmt_insert = $new_conn->prepare("insert into eg_loginless values(DEFAULT,?,?,?,?,DEFAULT,?)");
                    if (!empty($token1) && $token1 != '') {
                        $stmt_insert->bind_param("sssis", $desc1, $iprange1, $token1, $tokendailylimit1,$redirecturl1);
                    } else {
                        $stmt_insert->bind_param("sssis", $desc1, $iprange1, $new_token, $tokendailylimit1,$redirecturl1);
                    }
                    $stmt_insert->execute();$stmt_insert->close();
                    sfx_echoPopupAlert("The token has been created.");
                } else {
                    sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];
                if (!empty($desc1)) {
                    $stmt_update = $new_conn->prepare("update eg_loginless set 43desc=?, 43iprange=?, 43tokendailylimit=?, 44redirecturl=? where 43tokenid=?");
                    $stmt_update->bind_param("ssisi", $desc1, $iprange1, $tokendailylimit1, $redirecturl1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("The token has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s). The record has been restored to it original state.");
                }
            }
        }
        
        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select 43tokenid, 43desc, 43iprange, 43token, 43tokendailylimit, 44redirecturl from eg_loginless where 43tokenid = ?");
            $stmt3->bind_param("i", $get_id_upd);//i integer, s string, d double, b blob
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $desc3, $iprange3, $token3, $tokendailylimit3, $redirecturl3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","loginless.php");
            exit;
        }
    
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Create New Loginless Token</strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
            <form action="loginless.php" method="post" enctype="multipart/form-data">
                <strong>Description: </strong>
                <br/><input required type="text" name="desc1" style="width:35%" maxlength="50" value="<?php if (isset($desc3)) {echo $desc3;} ?>"/>

                <br/><br/><strong>Permitted IP (e.g. 192.168.1.1, 192.168.2.x, 192.168.x.x, 192.x.x.x): </strong>
                <br/><input required type="text" name="iprange1" style="width:35%" maxlength="50" value="<?php if (isset($iprange3)) {echo $iprange3;} ?>"/>

                <br/><br/><strong>Daily Search Token Limit: </strong>
                <br/><input required type="number" name="tokendailylimit1" style="width:35%" maxlength="50" value="<?php if (isset($tokendailylimit3)) {echo $tokendailylimit3;} else {echo "0";} ?>"/>

                <br/><br/><strong>(optional) Token: </strong>
                <br/><input type="text" name="token1" <?php if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {echo "readonly=readonly";}?> style="width:35%" maxlength="50" value="<?php if (isset($token3)) {echo $token3;} ?>"/>
                
                <br/><br/><strong>(optional) Redirect URL If Check Failed: </strong>
                <br/><input type="text" name="redirecturl1" style="width:35%" maxlength="990" value="<?php if (isset($redirecturl3)) {echo $redirecturl3;} ?>"/>
                
                <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Create";}?>" />

                <br/><br/>
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update Loginless Token";} else {echo "Create Loginless Token";}?>" />
                <input type="button" value="Cancel" onclick="location.href='loginless.php';">
            </form>
        </td>
        </tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>>
            <td colspan=8><strong>List Controls :</strong></td>
        </tr>
        
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'></td>
            <td style='text-align:left;'>Description</td>
            <td style='text-align:left;'>IP Range</td>
            <td style='text-align:left;'>Loginless URL</td>
            <td style='text-align:left;'>Daily Search Token Limit</td>
            <td style='text-align:left;'>Access Count</td>
            <td style='text-align:left;'>Redirect URL If Check Failed</td>
            <td style='width:150;'>Options</td>
        </tr>
        
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select 43tokenid, 43iprange, 43desc, 43token, 43tokendailylimit, 44totalaccess, 44redirecturl from eg_loginless order by 43token");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $tokenid_fdb = $myrow_fdb["43tokenid"];
                $desc_fdb = $myrow_fdb["43desc"];
                $iprange_fdb = $myrow_fdb["43iprange"];
                $token_fdb = $myrow_fdb["43token"];
                $tokendailylimit_fdb = $myrow_fdb["43tokendailylimit"];
                $access_fdb = $myrow_fdb["44totalaccess"];
                $redirecturl_fdb = $myrow_fdb["44redirecturl"];
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>$desc_fdb</td>";
                    echo "<td style='text-align:left;'>$iprange_fdb</td>";
                    echo "<td style='text-align:left;'>$system_path"."searcher.php?lls=$token_fdb</td>";
                    echo "<td style='text-align:left;'>$tokendailylimit_fdb</td>";
                    echo "<td style='text-align:left;'>$access_fdb</td>";
                    echo "<td style='text-align:left;'>$redirecturl_fdb</td>";
                    echo "<td>";
                        echo "<a title='Delete this record' href='loginless.php?del=$tokenid_fdb' onclick=\"return confirm('Are you sure ? This is not undoable.');\"><i class=\"fas fa-trash\"></i></a> ";
                        echo "<a title='Update this record' href='loginless.php?edt=$tokenid_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
        ?>
    </table>

    <hr>

    <?php include_once '../sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
