<?php
/*
Filename: delreq.php
Usage: Delete request listing and administration
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Delete Request";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
        
    <div style='text-align:center'>
        <?php
                                                                                            
            $query_del = "select * from eg_item where 39proposedelete = 'TRUE' order by id desc";
            $result_del = mysqli_query($GLOBALS["conn"], $query_del);
            $row_del = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
            $num_results_affected_del = $row_del[0];

            echo "<table class=$color_scheme"."Header><tr><td><strong>Delete Request List</strong>: $num_results_affected_del <em>record(s) found.</em></td></tr></table>";
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'>
                    <td></td>
                    <td>Title</td>
                    <td>Author</td>
                    <td>$type_as</td>
                    <td>Page Count</td>
                    <td>Requestor</td>
                    <td>Reason</td>
                </tr>";
                                                                                
                $n = 1;
                                        
                while ($myrow_del = mysqli_fetch_array($result_del)) {
                    $id = $myrow_del["id"];
                    $titlestatement = $myrow_del["38title"];
                    $typestatement = sfx_sGetValue("38synonym", "eg_item_type", "38typeid",$myrow_del["38typeid"]);
                    $authorname = $myrow_del["38author"] ? $myrow_del["38author"] : "";
                    $proposedeleteby = $myrow_del["39proposedeleteby"];
                    $proposedelete_reason = $myrow_del["39proposedelete_reason"];
                    $page_count = $myrow_del["51_pagecount"];

                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td>$n</td>";
                        echo "<td style='text-align:left;vertical-align:top;'><a href='details.php?det=$id'>$titlestatement</a></td>";
                        echo "<td>$authorname</td>";
                        echo "<td>$typestatement</td>";
                        echo "<td>$page_count</td>";
                        echo "<td>".sfx_sGetValue("name", "eg_auth", "username", $proposedeleteby)."</td>";
                        echo "<td style='text-align:left;vertical-align:top;'>";
                            echo "<font color=red>".strip_tags($proposedelete_reason)."</font>";
                        echo "</td>";
                    echo "</tr>";
                                                                    
                    $n = $n +1 ;
                }
            echo "</table>";
        ?>
        <br/><em>Refresh the page to see the latest updates.</em>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
