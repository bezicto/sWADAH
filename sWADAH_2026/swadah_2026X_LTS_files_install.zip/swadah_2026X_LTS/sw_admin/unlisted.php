<?php
/*
Filename: unlisted.php
Usage: Manage unlisted item
Version: 20250714.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Unlisted List";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
        
    <div style='text-align:center'>
        <?php
                                                                                            
            $query_unlstd = "select * from eg_item where 38status = 'UNLISTED' order by id desc";
            $result_unlstd = mysqli_query($GLOBALS["conn"], $query_unlstd);
        
            $row_unlstd = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
            $num_results_affected = $row_unlstd[0];

            echo "<table class=$color_scheme"."Header><tr><td><strong>Unlisted List</strong>: $num_results_affected <em>record(s) found.</em></td></tr></table>";
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'>
                        <td></td>
                        <td>Title</td>
                        <td>Author</td>
                        <td>Type</td>
                        <td>Page Count</td>
                        <td>Input By</td>
                        <td>Last Update By</td>
                    </tr>";
                                                                                
                $n = 1;
                                        
                while ($myrow_unlstd = mysqli_fetch_array($result_unlstd)) {
                    $id = $myrow_unlstd["id"];
                    $titlestatement = $myrow_unlstd["38title"];
                    $typestatement = sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_unlstd["38typeid"]);
                    $authorname = $myrow_unlstd["38author"] ? $myrow_unlstd["38author"] : "";
                    $page_count = $myrow_unlstd["51_pagecount"];
                    $input_by= sfx_sGetValue("name", "eg_auth", "username",$myrow_unlstd["39inputby"]);
                    $lastupdate_by = sfx_sGetValue("name", "eg_auth", "username",$myrow_unlstd["40lastupdateby"]);

                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td>$n</td>";
                        echo "<td style='text-align:left;vertical-align:top;'><a href='details.php?det=$id'>$titlestatement</a></td>";
                        echo "<td>$authorname</td>";
                        echo "<td>$typestatement</td>";
                        echo "<td>$page_count</td>";
                        echo "<td>$input_by</td>";
                        echo "<td>$lastupdate_by</td>";
                    echo "</tr>";
                                                                    
                    $n = $n +1 ;
                }
            echo "</table>";
        ?>
        <br/><em>Refresh the page to see the latest updates.</em>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
