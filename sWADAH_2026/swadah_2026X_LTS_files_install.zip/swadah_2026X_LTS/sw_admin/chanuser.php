<?php
/*
Filename: sw_admin/chanuser.php
Usage: Manage users interface. Consists many administrative usage to admin users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Change User Account Type";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    //route tracing for future page
    $_SESSION[$ssn.'route2'] = '2';

    if (isset($_GET['scadm'])) {
        $_SESSION[$ssn.'scadm'] = $_GET['scadm'];
    }

    if (isset($_GET['sc']) && $_GET['sc'] == 'cl') {
        unset($_SESSION[$ssn.'scadm']);
    }
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
    <style>
        @media only screen and (max-width: 600px) {
            /* Jadikan setiap baris satu blok */
            table.thisRtable {
                border-collapse: collapse;
            }
            
            tr.thisRrow, td.thisRdata {
            display: block;
            text-align: left;
            width: 100%;
            }

            .thisHrow:nth-of-type(1) {
            display: none;
            }

            /* Paparkan tajuk baris sebelum setiap nilai data */
            td.thisRdata::before {
            content: attr(data-label);
            font-weight: bold;
            color: green; /* Warna hijau untuk data-label */
            text-decoration: underline; /* Garisan bawah untuk data-label */
            display: block;
            text-align: left;
            margin-bottom: 5px; /* Ruang antara label dan nilai */
            }

            /* Tambahkan hr selepas setiap baris */
            tr.thisRrow::after {
            content: "";
            display: block;
            width: 100%;
            border-bottom: 1px solid #000;
            margin: 10px 0; /* Ruang di atas dan di bawah garis */
            }
        }
    </style>
</head>

<body class='<?php echo $color_scheme;?>'>

    <script type="text/javascript">
        window.onclick = function(event) {
            if (event.target.matches('.dropbtn2')) {
                var dropdowns = document.getElementsByClassName('dropbtn2');
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show') && !event.target.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                        }
                }
                event.target.classList.toggle("show");
            }
        }
    </script>

    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php

            //delete
            if (isset($_GET["del"]) && $_GET["del"] <> null && is_numeric($_GET["del"])) {
                $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
                
                $get_usertype = sfx_sGetValue("usertype", "eg_auth", "id", $get_id_del);
                if ($get_usertype == 'PATRON') {
                    $set_to = "DEPATRON";
                } else {
                    $set_to = "FALSE";
                }
                
                $stmt_update = $new_conn->prepare("update eg_auth set usertype=? where id=?");
                $stmt_update->bind_param("si", $set_to, $get_id_del);
                $stmt_update->execute();$stmt_update->close();
            }
            
            //reset
            if (isset($_GET["res"]) && $_GET["res"] <> null && is_numeric($_GET["res"])) {
                $get_id_res = mysqli_real_escape_string($GLOBALS["conn"], $_GET["res"]);
                $stmt_update = $new_conn->prepare("update eg_auth set syspassword=AES_ENCRYPT('$default_password_if_forgotten','$aes_key'), num_attempt=0 where id=?");
                $stmt_update->bind_param("i", $get_id_res);
                $stmt_update->execute();$stmt_update->close();
            }

            //unblock
            if (isset($_GET["reb"]) && $_GET["reb"] <> null && is_numeric($_GET["reb"])) {
                $get_id_reb = mysqli_real_escape_string($GLOBALS["conn"], $_GET["reb"]);
                $stmt_update = $new_conn->prepare("update eg_auth set num_attempt=0, online='OFF' where id=?");
                $stmt_update->bind_param("i", $get_id_reb);
                $stmt_update->execute();$stmt_update->close();
            }
            
            //set offline
            if (isset($_GET["offuser"]) && $_GET["offuser"] <> null && is_numeric($_GET["offuser"])) {
                $get_id_offuser = mysqli_real_escape_string($GLOBALS["conn"], $_GET["offuser"]);
                $stmt_update = $new_conn->prepare("update eg_auth set online='OFF' where id=?");
                $stmt_update->bind_param("i", $get_id_offuser);
                $stmt_update->execute();$stmt_update->close();
            }
            
    ?>

    <?php

        if (isset($_SESSION[$ssn.'scadm']) && $_SESSION[$ssn.'scadm'] != '') {
            $strtosearch = sfx_stringRemoveScriptTag($_SESSION[$ssn.'scadm']);
            $param = "%$strtosearch%";
            $stmt_fdb = $new_conn->prepare("select * from eg_auth where (username like ? or name like ?) order by name");
            $stmt_fdb->bind_param("ss", $param, $param);
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            $num_results_affected_fdb = $result_fdb->num_rows;
        } elseif ((isset($_SESSION[$ssn.'scadm']) && $_SESSION[$ssn.'scadm'] == '') || !isset($_SESSION[$ssn.'scadm'])) {
            $query_fdb = "select * from eg_auth order by name, usertype desc";
            $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);
            $num_results_affected_fdb = mysqli_num_rows($result_fdb);
        }
        
        echo "<table class=$color_scheme"."Header>";
            echo "<tr><td><strong>Total user in the system</strong> : ";
                echo "$num_results_affected_fdb <em>record(s) found.</em>";
                echo "<div style='color:blue;'>To search use CTRL+F (Windows) or CMD+F (macOS).</div><br/>";
                echo "<a class='sButton' href='../sw_admin/chanelibility.php'><span class='fas fa-sticky-note'></span> Users Eligibility</a> ";
                echo "<a class='sButton' href='../sw_admin/adduser.php'><span class='fa fa-user-plus'></span> Add User</a> ";
                echo "<a class='sButton' href='../sw_admin/adduser_bulk.php'><span class='fa fa-upload'></span> Bulk Add Patrons</a> ";
            echo "</td></tr>";
        echo "</table>";

    ?>
      
    <table class=whiteHeaderNoCenter style='width:100%;'>
    <tr style='text-align:center;'>
        <td>
            <form  action="chanuser.php" method="get" enctype="multipart/form-data" style="margin:auto;max-width:100%">
                Search:
                <br/><input type="text" placeholder="Enter ID or Part of Name" name="scadm" style='width:50%;font-size:14px' maxlength="255" value="<?php if (isset($_SESSION[$ssn.'scadm'])) {echo sfx_stringRemoveScriptTag($_SESSION[$ssn.'scadm']);}?>"/>
                <input type="submit" class="form-submit-button" name="s" value="Search" />
                <input type="button" class="form-submit-button" name="r" value="Clear" onclick="window.location.href='chanuser.php?sc=cl';" />
            </form>
        </td>
    </tr>
    </table>

    <?php
        echo "<table class='whiteHeader thisRtable'>";
            echo "<tr class='thisHrow' style='text-decoration:underline;'>";
                echo "<td>#</td>";
                echo "<td width=40% style='text-align:left;'>Full Name</td>";
                echo "<td>User ID @dbID</td>";
                echo "<td>Account Type</td>";
                echo "<td>Publisher (Approver For)</td>";
                echo "<td>Current Failed Attempt</td>";
                echo "<td>Option</td>";
                echo "<td>Status</td>";
            echo "</tr>";
                                                
            $n = 1;
            
            while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                echo "<tr class='$color_scheme"."Hover thisRrow'>";

                    $id_fdb = $myrow_fdb["id"];
                    $username_fdb = $myrow_fdb["username"];
                    $usertype_fdb = $myrow_fdb["usertype"];
                    $name_fdb = $myrow_fdb["name"];
                    $division_fdb = $myrow_fdb["division"];
                    $publisheradmin_fdb = $myrow_fdb["publisheradmin"];
                    $online_fdb = $myrow_fdb["online"];
                    $lastlogin_fdb = $myrow_fdb["lastlogin"];
                    $num_attempt_fdb = $myrow_fdb["num_attempt"];
                    
                    echo "<td class='thisRdata'>$n</td>";

                    echo "<td data-label='Full Name' class='thisRdata' style='text-align:left;'>";
                        echo "<span>$name_fdb ";
                        if ($num_attempt_fdb >= $default_num_attempt_login) {echo "<img src='../sw_asset/img/cu_locked.png' width=12>";}
                        echo "</span>";
                    echo "</td>";

                    echo "<td data-label='User ID @dbID' class='thisRdata'>$username_fdb @$id_fdb</td>";

                    echo "<td data-label='Account Type' class='thisRdata'>$usertype_fdb</td>";
                    
                    echo "<td data-label='Publisher (Approver For)' class='thisRdata'>$publisheradmin_fdb</td>";

                    echo "<td data-label='Current Failed Attempt' class='thisRdata'>$num_attempt_fdb</td>";
                        
                    echo "<td data-label='Option' class='thisRdata'>";
                        echo "<div class='dropdown'><button class='dropbtn2'>Options</button><div id='myDropdown".$n."' class='dropdown-content'>";
                            echo "<a href='adduser.php?edt=$id_fdb' title='Edit User'><img src='../sw_asset/img/cu_edituser.png' width=16>Edit User</a>";
                            if ($username_fdb != 'admin') {
                                echo " <a href='chanuser.php?del=$id_fdb' onclick=\"return confirm('Are you sure to set this user to inactive ? This application will be permanant.');\" title='Deactivate User'><img src='../sw_asset/img/cu_deactivate.png' width=16> Deactivate User</a>";
                                echo " <a href='chanuser.php?res=$id_fdb' onclick=\"return confirm('Are you sure to reset the user $username_fdb\'s password to $default_password_if_forgotten ?');\" title='Reset Password'><img src='../sw_asset/img/cu_resetpass.png' width=16>Reset Password</a>";
                                if ($num_attempt_fdb >= $default_num_attempt_login) {
                                    echo "<a href='chanuser.php?reb=$id_fdb' onclick=\"return confirm('Are you sure to unblock the user $username_fdb\'s ?');\" title='Unblock Account'><img src='../sw_asset/img/cu_ublock.png' width=16>Unblock</a>";
                                }
                            }
                            echo " <a href='userhistory.php?pid=$id_fdb' title='User History'><img src='../sw_asset/img/cu_history.png' width=16us>User History</a>";
                        echo "</div></div>";
                    echo "</td>";
                    
                    echo "<td data-label='Status' class='thisRdata'>";
                        if ($online_fdb == 'ON') {
                            echo "<a class='sButtonRedSmall' href='chanuser.php?offuser=$id_fdb' onclick=\"return confirm('Are you sure to set offline to user $username_fdb ?');\"><span class=\"fas fa-sign-out-alt\"></span> Set Offline</a>";
                            echo "<div style='font-size:6pt;'><strong>Logged:</strong> ".sfx_timetaken($lastlogin_fdb)."</div>";
                        } else {
                            echo "Offline";
                        }
                    echo "</td>";

                echo "</tr>";
                $n = $n +1 ;
            }
        echo "</table>";
    ?>
        
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
