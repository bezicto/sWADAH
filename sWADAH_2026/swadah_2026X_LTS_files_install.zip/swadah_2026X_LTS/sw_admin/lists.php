<?php
/*
Filename: lists.php
Usage: Manage all prepared listed item
Version: 20250714.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Prepared Lists";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
     
    <h2>Available Lists:</h2>
    <div style='text-align:left;font-size:16px;'><ol>
        <?php if ($_SESSION[$ssn.'editmode'] == 'SUPER') { ?>
            <li style='margin-top:15px;'>
                <a href='delreq.php'>Delete Request</a>
                <br/><span style='font-size:12px;'>List of items requested for deletion</span>
            </li>
        <?php }?>
        <li style='margin-top:15px;'>
            <a href='embargoed.php'>Embargoed</a>
            <br/><span style='font-size:12px;'>List of items embargoed for a certain period</span>
        </li>
        <li style='margin-top:15px;'>
            <a href='unlisted.php'>Unlisted</a>
            <br/><span style='font-size:12px;'>List of items not listed in the main catalog</span>
        </li>
    </ol></div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
