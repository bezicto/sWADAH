<?php
/*
Filename: index2.php
Usage: Main page after admin logging-in
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Administration";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    //set this page ref
    $_SESSION[$ssn.'ref'] = 'index2.php';
    
    //route tracing for future page
    $_SESSION[$ssn.'route1'] = '1';

    //clear listgen token
    unset($_SESSION[$ssn.'listgentoken']);

    //get installed date
    if (file_exists("../sw_installed/dateinstalled.txt")) {
        $installed_date = file_get_contents("../sw_installed/dateinstalled.txt");
    }

    $username = $_SESSION[$ssn.'username'];
    $lastlogin = $_SESSION[$ssn.'lastlogin'];
    
    if ($_SESSION[$ssn.'needtochangepwd']) {
        echo "<meta http-equiv=\"refresh\" content=\"0;url=../passch.php?upd=.g\" />"; exit;
    }

    //forward to depoadmin if sWADAH is set to function as self deposit repository
    if ($system_function == "depo") {
        echo "<meta http-equiv=\"refresh\" content=\"0;url=../sw_depos/depoadmin.php?v=entry\" />"; exit;
    }
    
    if ($debug_mode == 'yes') {
        $debug_output = "<span style='color:pink;'>Debugging Mode Running:</span> ".session_id();
    }

    //clear all session variable for searching if sc = cl
    if (isset($_GET['sc']) && $_GET['sc'] == 'cl') {
        unset($_SESSION[$ssn.'sear_scstr']);
        unset($_SESSION[$ssn.'sear_scstr_form']);
        unset($_SESSION[$ssn.'sear_sctype']);
        unset($_SESSION[$ssn.'sear_sclang']);
        unset($_SESSION[$ssn.'sear_page']);
        if ($debug_mode == 'yes') {$debug_output .= " sc = cl | ;</script>";}
    }

    //handling back from other pages -- if user manipulated the query string using url, and alter the scstr value, it will automatically unset the current page the user is in
    if ((isset($_GET['scstr']) && isset($_SESSION[$ssn.'sear_scstr']) && $_GET['scstr'] != $_SESSION[$ssn.'sear_scstr']) || (isset($_GET['sctype']) && isset($_SESSION[$ssn.'sear_sctype']) && $_GET['sctype'] != $_SESSION[$ssn.'sear_sctype'])) {
        unset($_SESSION[$ssn.'sear_page']);
        if ($debug_mode == 'yes') {$debug_output .= "handling back from other pages | ";}
    }

    //session management for search fields
    if (isset($_GET['scstr']) && $_GET['scstr'] != '') {
        //new 20250624 -- to make sure commo words are removed from the search term
        $scstr_term = sfx_filterCommonWords($_GET['scstr']);
        $_SESSION[$ssn.'sear_scstr'] = htmlspecialchars($scstr_term);

        $_SESSION[$ssn.'sear_scstr'] = preg_replace('/\s+/', ' +', "+".sfx_just_clean($_SESSION[$ssn.'sear_scstr']));
        $_SESSION[$ssn.'sear_scstr_form'] = sfx_just_clean($_SESSION[$ssn.'sear_scstr']);
    }
    if (isset($_GET['sctype']) && (is_numeric($_GET['sctype']) || $_GET['sctype'] == 'EveryThing' || $_GET['sctype'] == 'Control Number' || $_GET['sctype'] == 'Author')) {$_SESSION[$ssn.'sear_sctype'] = $_GET['sctype'];}
    if (isset($_GET['sclang']) && (strlen($_GET['sclang']) === 3)) {$_SESSION[$ssn.'sear_sclang'] = $_GET['sclang'];}
    if (isset($_GET['page']) && is_numeric($_GET['page'])) {$_SESSION[$ssn.'sear_page'] = $_GET['page'];}
    

?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php
    
        include_once '../sw_inc/loggedinfo.php';
        include_once '../sw_inc/mainbar.php';
        
    ?>
                                                                
    <hr>
                            
    <div style='text-align:center;background-color:white;padding-top:20px;'>
        <form action="index2.php" method="get" enctype="multipart/form-data">
            
            <input type="text" placeholder="Enter search terms here and press Search" name="scstr" style="width:50%;font-size:14px" maxlength="255" value="<?php if (isset($_SESSION[$ssn.'sear_scstr_form']) && $_SESSION[$ssn.'sear_scstr_form'] <> '') {echo $_SESSION[$ssn.'sear_scstr_form'];}?>"/>
                        
            <select style="width:15%;font-size:14px" id="sctype" name="sctype" style="font-size:11px;">
            <?php
                $sctype_select = isset($_SESSION[$ssn.'sear_sctype']) ? $_SESSION[$ssn.'sear_sctype'] : '';
                echo '<option value="EveryThing" '; if ($sctype_select == 'EveryThing') {echo 'selected';} echo ' >All Types</option> ';
                $query_typelist= "select 38typeid, 38type, 38synonym from eg_item_type";
                $result_typelist = mysqli_query($GLOBALS["conn"], $query_typelist);
                while ($row_typelist = mysqli_fetch_array($result_typelist)) {
                    echo '<option value="'.$row_typelist['38typeid'].'"'; if ($row_typelist['38typeid']==$sctype_select) {echo ' selected';} echo '> '.$type_as.': '. $row_typelist['38synonym'] . '</option>'."\n";
                }
        
                if (isset($_SESSION[$ssn.'username'])) {
                    echo '<option value="Control Number" '; if ($sctype_select == 'Control Number') {echo 'selected';} echo ' >Control Number</option>';
                    echo '<option value="Author" '; if ($sctype_select == 'Author') {echo 'selected';} echo ' >'.$tag_100.'</option> ';
                }
            ?>
            </select>

            <?php
            $sclang_select = isset($_SESSION[$ssn.'sear_sclang']) ? $_SESSION[$ssn.'sear_sclang'] : '';
            $selectable = explode("|", $tag_041_selectable);
            echo "<select name='sclang'>";
            echo '<option value="All" '; if (isset($sclang_select) && $sclang_select == 'Language') {echo 'selected';} echo ' >All Lang.</option> ';
            for ($x = 0; $x < sizeof($selectable); $x++) {
                echo "<option value='".$selectable[$x]."' ";
                    echo (isset($sclang_select) && ($sclang_select == $selectable[$x])) ? "selected" : "";
                echo ">".$selectable[$x]."</option>";
            }
            echo "</select>";
            ?>

            <input type="hidden" name='sc' value='cl'/>
            <button type="submit" style="color:black;"><span class="fa fa-search"></span> Search</button>

        </form><br/>
        <?php
            if ($show_browser_bar_admin) {include_once '../sw_inc/browser_bar.php';}
        ?>
    </div>
                            
    <div style='text-align:center;'>
        <?php
            //start paging 1
            if (isset($_SESSION[$ssn.'sear_page'])) {$currentPage = $_SESSION[$ssn.'sear_page'];}
            include_once '../sw_inc/paging-p1.php';
            
            if (isset($_SESSION[$ssn.'sear_scstr']) || (isset($_SESSION[$ssn.'sear_sctype']) && $_SESSION[$ssn.'sear_sctype'] <> null)) {
                $scstr_term = isset($_SESSION[$ssn.'sear_scstr']) ? $_SESSION[$ssn.'sear_scstr'] : '';
                $latest = "FALSE";
                include_once '../sw_inc/index2_s_boolean.php';
            } else {
                $latest = "TRUE";
                $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item order by id desc LIMIT $offset, $rowsPerPage";
            }
                                    
            $time_start = sfx_getmicrotime();
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
                                                    
            //start paging 2
            include_once '../sw_inc/paging-p2.php';

            $time_end = sfx_getmicrotime();
            $time = round($time_end - $time_start, 5);

            if ($latest == "FALSE") {
                echo "<table class=whiteHeaderNoCenter><tr><td>";
                    echo "<strong>Total records found :</strong> $num_results_affected_paging ";
                    echo "<strong>in</strong> $time seconds <strong>for</strong> ' $scstr_term '";
                echo "</td></tr></table>";
                
                include_once '../sw_inc/index2_sgmtdsrch.php';//segmented search
            } else {
                echo "<table class=whiteHeaderNoCenter><tr><td><strong>Latest addition to the database : </strong></td></tr></table>";
            }
            
            
            
            echo "<table class=whiteHeaderNoCenter>";
                                                                
            $n = $offset + 1;
    
            while ($myrow1 = mysqli_fetch_array($result1)) {
                echo "<tr class=$color_scheme"."Hover>";
                
                    $id2 = $myrow1["id"];
                    $folderid2 = $myrow1["38folderid"];
                    $status2 = $myrow1["38status"];
                    $titlestatement2 = $myrow1["38title"];
                    $typestatement2 = $myrow1["38typeid"];
                    $authorname2 = $myrow1["38author"];
                    $link2 = $myrow1["38link"];
                    $inputdate2 = $myrow1["39inputdate"];
                    $hits2 = $myrow1["41hits"];
                    $inputby2 = $myrow1["39inputby"];
                    $fulltext2 = $myrow1["41fulltexta"];
                    $pdfattach_fulltext2 = $myrow1["41pdfattach_fulltext"];
                    $isabstract2 = $myrow1["41isabstract"];
                    $localcallnum2 = $myrow1["38localcallnum"];
                    $instimestamp2 = $myrow1["41instimestamp"];
                    $accessnum2 = $myrow1["38accessnum"];
                    $item_status2 = $myrow1["50item_status"];
                    $reference2 = $myrow1["41reference"];
                    $dir_year2 = substr("$inputdate2", 0, 4);
                    
                    echo "<td style='text-align:center;vertical-align:top;' width=40>$n</td>";

                    if ($system_function == 'photo') {
                        echo "<td style='text-align:center;vertical-align:top;' width=40>";
                            echo "<img class='centered-and-cropped' src='../sw_inc/image.php?d=$id2&t=t' width=64px height=64px onerror=this.src='../sw_asset/img/no_image.png'>";
                            if ($system_function == 'photo') {
                                $total_photos = sfx_countImageForID($appendroot,$id2);//will take a look this code later to make it more fast
                                echo "<br/><em style='color:green;'>$total_photos photos</em>";
                                mysqli_query($GLOBALS["conn"], "update eg_item set 52photo_count=$total_photos where id=$id2");
                            }
                        echo "</td>";
                    }
                                        
                    echo "<td style='text-align:left;vertical-align:top;'>";
                        if (!$_SESSION[$ssn.'needtochangepwd']) {
                            echo "<a class=myclassOri href='details.php?det=$id2'>";
                                echo !empty($scstr_term) ? sfx_highlight($titlestatement2, $scstr_term) : $titlestatement2;
                                //echo $titlestatement2;
                            echo "</a>";
                        } else {
                            echo $titlestatement2;
                        }
                        
                        if ($authorname2 != '') {echo "<br/><a class=myclass2 href='index2.php?scstr=$authorname2&sctype=Author&sc=cl'>$authorname2</a>";}
                        
                        if ($item_status2 == '1') {
                            echo "<br/>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $typestatement2)."<br/>";

                            if ($fulltext2 != null && $fulltext2 != '<html />') {
                                if ($isabstract2 == 1) {
                                    echo "<img src='../sw_asset/img/ind_abstract_yes.png' width=24 alt='Click to view' title='HTML Abstract.'>";
                                } else {
                                    echo "<img src='../sw_asset/img/ind_html_yes.png' width=24 alt='Click to view' title='HTML Full Text.'>";
                                }
                            }

                            if ($link2 <> null) {
                                $link2 = urldecode($link2);
                                if (substr($link2, 0, 4) != 'http') {
                                    $link2 = 'http://'.$link2;
                                }
                                echo " <a href='$link2' target='_blank'>";
                                if (isset($link2) && strpos($link2, 'youtube.com') !== false && $youtube_detector) {
                                    echo "<img src='../sw_asset/img/ind_youtube.png' width=24 alt='Click to view' title='Quick access to YouTube for this item.'>";
                                } else {
                                    echo "<img src='../sw_asset/img/ind_url_yes.png' width=24 alt='Click to view' title='Quick access to online version of this material.'>";
                                }
                                echo "</a>";
                            }
                                                
                            if (is_file("../$system_docs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf")) {
                                echo " <a href='../$system_docs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf' target='_blank'><img src='../sw_asset/img/ind_pdf_yes.png' width=24 alt='Click to view' title='PDF Available.'></a>";
                            }
         
                            if ($pdfattach_fulltext2 != '') {
                                echo " <img src='../sw_asset/img/ind_pdf_yes_indexed.png' width=24 alt='Click to view' title='PDF contents indexed in the database.'>";
                            }

                            if (is_file("../$system_pdocs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf")) {
                                echo " <img src='../sw_asset/img/ind_pdf_yes_g.png' width=24 alt='Click to view' title='Guest File Available.'>";
                            }

                            if ($reference2 != '') {
                                echo " <img src='../sw_asset/img/ind_reference_yes.png' width=24 alt='Click to view' title='Reference is entered.'>";
                            }

                            if (is_file("$system_albums_directory/$dir_year2/$id2"."_"."$instimestamp2.jpg")) {
                                echo " <img width=24 src='../sw_asset/img/ind_image_yes.png' alt='Click to view' title='Photo Available'>";
                            }

                            //for handling freetype
                            if (is_dir("../$system_isofile_directory/$dir_year2")) {
                                $files_scanned = scandir("../$system_isofile_directory/$dir_year2");
                                foreach ($files_scanned as $fileitem) {
                                    if (preg_match("/$id2"."_"."$instimestamp2/i", $fileitem) == 1) {
                                        echo " <img src='../sw_asset/img/ind_general_file.png' width=24 alt='Click to view' title='$system_isofile_name Available'>";
                                        break;
                                    }
                                }
                            }
                        
                            //show locked icon for item unpermitted for current user
                            if (((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) && $folderid2 != 0) {
                                if (isset($_SESSION[$ssn.'username'])) {
                                    $auth_user = $_SESSION[$ssn.'username'];
                                } elseif (isset($_SESSION[$ssn.'username_guest'])) {
                                    $auth_user = $_SESSION[$ssn.'username_guest'];
                                }
                                
                                $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$folderid2'";
                                $result_user = mysqli_query($GLOBALS["conn"], $query_user);
                                if (mysqli_num_rows($result_user) != 1) {
                                    echo " <img src='../sw_asset/img/cu_locked.png' width=24 alt='Click to view' title='Item locked to you.'>";
                                }
                            }

                            //is commercial
                            if (sfx_sGetValue("count(eg_item_id) as totalid", "eg_commercialize", "eg_item_id", $id2) == 1 && $enable_commercial_api) {
                                echo " <img src='../sw_asset/img/ind_commercial.png' width=24 alt='Click to view' title='This item has been commercialize.'>";
                            }
                        }
                        if ($item_status2 == '0') {echo "<br/><em>Item is undiscoverable.</em>";}
                    echo "</td>";
                                                    
                    echo "<td style='vertical-align:top;font-size:10px;' width=100>";
                        switch ($status2) {
                            case 'AVAILABLE' : $colorStatus = 'green'; break;
                            case 'FINALPROCESSING' : $colorStatus = 'blue'; break;
                            case 'EMBARGO' : $colorStatus = 'red'; break;
                            case 'UNLISTED' : $colorStatus = 'magenta'; break;
                            default: $colorStatus = 'orange'; break;
                        }
                        echo "<span style='color:$colorStatus;'>$status2</span>
                                <br/>
                                <strong><span style='color:black;'>Added by :</span>
                                <br/>
                                </strong>".sfx_sGetValue("name", "eg_auth", "username", $inputby2)."
                                <br/>
                                <strong><span style='color:black;'>Date Added</span> :</strong> $inputdate2 ";
                    echo "</td>";
                
                echo "</tr>";
                $n = $n +1 ;
            }
            echo "</table>";
                                
        //start paging 3
        if ($maxPage > 1) {
            include_once '../sw_inc/paging-p3.php';
        }
    
        ?>
    </div>

    <?php
    if ($debug_mode == 'yes' && $_SESSION[$ssn.'editmode'] == 'SUPER') {
    ?>
        <div class='footer' style='width:100%;text-align:center;'>
        <?php
            echo "<span style='font-size:8pt;'>$debug_output <span style='color:cyan;'>Final query:</span> <span style='color:yellow;'>".$query1."</span></span> ";
            
            include_once '../sw_inc/view_storedSession.php';
            echo $print_sessvar ?? '';
            echo " <strong style='color:cyan;'>URL:</strong> <span style='color:lightgrey;'>".sfx_getCurrentBaseURL()."</span>";
            echo " <strong style='color:cyan;'>Accessed from:</strong>".sfx_get_ip();
        ?>
        </div>
    <?php
    }
    ?>
    
    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
