<?php
/*
Filename: sw_admin/addtype.php
Usage: Create and manage item types
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Add Type";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_item_type where 38typeid = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();$stmt_del->close();
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","addtype.php");
            exit;
        }
        
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $type1 = preg_replace('/\s+/', '', sfx_stringRemoveScriptTag($_POST["type1"]));
            if (isset($_POST["default1"]) && mysqli_real_escape_string($GLOBALS["conn"], $_POST["default1"]) == 'TRUE') {
                $default1 = 'TRUE';
            } else {
                $default1 = 'FALSE';
            }
            $synonym1 = sfx_stringRemoveScriptTag($_POST["synonym1"]);
            $desc1 = sfx_stringRemoveScriptTag($_POST["desc1"]);
            $gview1 = isset($_POST["gview1"]) ? sfx_stringRemoveScriptTag($_POST["gview1"]) : 0;

            if ($_REQUEST["submitted"] == "Insert") {
                $stmt_count = $new_conn->prepare("select count(*) from eg_item_type where 38type = ?");
                $stmt_count->bind_param("s", $type1);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected_type);
                $stmt_count->fetch();$stmt_count->close();
                
                if ($num_results_affected_type == 0) {
                    if (!empty($type1)) {
                        if ($default1 == 'TRUE') {
                                $stmt_update = $new_conn->prepare("update eg_item_type set 38default='FALSE'");
                                $stmt_update->execute();$stmt_update->close();
                            }
                        $stmt_insert = $new_conn->prepare("insert into eg_item_type values(DEFAULT,?,?,null,?,?,?)");
                        $stmt_insert->bind_param("ssssi", $type1, $default1, $synonym1, $desc1, $gview1);
                        $stmt_insert->execute();$stmt_insert->close();
                        sfx_echoPopupAlert("The type $type1 has been inputed into the database.");
                    } else {
                        sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                    }
                } elseif ($num_results_affected_type >= 1) {
                    sfx_echoPopupAlert("Your input has been cancelled. Duplicate $type_as detected.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];
                if (!empty($type1)) {
                    if ($default1 == 'TRUE') {
                        $stmt_update = $new_conn->prepare("update eg_item_type set 38default='FALSE'");
                        $stmt_update->execute();$stmt_update->close();
                    }
                    $stmt_update = $new_conn->prepare("update eg_item_type set 38type=?, 38default=?, 38synonym=?, 38desc=?, 38gview=? where 38typeid=?");
                    $stmt_update->bind_param("ssssii", $type1, $default1, $synonym1, $desc1, $gview1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("The record has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.");
                }
            }
        }

        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select 38typeid, 38type, 38default, 38synonym, 38desc, 38gview from eg_item_type where 38typeid = ?");
            $stmt3->bind_param("i", $get_id_upd);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $type3, $default3, $synonym3, $desc3, $gview3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","addtype.php");
            exit;
        }
        
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong><?php echo $type_as;?> Addition :</strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
        <form action="addtype.php" method="post" enctype="multipart/form-data">
                <strong><?php echo $type_as;?> Name: (spaces will be remove)</strong>
                <br/>
                <input type="text" name="type1" style="width:35%;" maxlength="150" value="<?php if (isset($type3)) {echo $type3;} ?>"/>
                <br/>
                <input type="checkbox" name='default1' value='TRUE' <?php if (isset($default3) && $default3 == 'TRUE') {echo 'checked';}?>> Set as default

                <br/><br/>
                <strong>Synonym (Display name on drop-down list)</strong>
                <br/>
                <input type="text" name="synonym1" style="width:35%;" maxlength="150" value="<?php if (isset($synonym3)) {echo $synonym3;} ?>"/>

                <br/><br/>
                <strong>Description</strong>
                <br/>
                <input type="text" name="desc1" style="width:50%;" maxlength="150" value="<?php if (isset($desc3)) {echo $desc3;} ?>"/>

                <br/><br/>
                <strong>Allow Guests to View File Attachments Without Logging In: </strong>
                <br/>
                <input type="checkbox" name="gview1" value="1" <?php if (isset($gview3) && $gview3=='1') {echo "checked";} ?>><label for="1">Viewable</label><br>
                                
                <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                
                <br/><br/>
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                <input type="button" value="Cancel" onclick="location.href='addtype.php';">
        </form>
        </td></tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=6><strong><?php echo $type_as;?> Listing and Controls :</strong></td></tr>
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'>ID</td>
            <td style='text-align:left;'>Name</td>
            <td style='text-align:left;'>Synonym</td>
            <td style='text-align:left;'>Description</td>
            <td style='text-align:left;'>Guest View</td>
            <td style='width:150;'>Options</td>
        </tr>
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select 38typeid, 38type, 38default, 38synonym, 38desc, 38gview from eg_item_type");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $type_fdb = $myrow_fdb["38type"];
                $typeid_fdb = $myrow_fdb["38typeid"];
                $default_fdb = $myrow_fdb["38default"];
                $synonym_fdb = $myrow_fdb["38synonym"];
                $desc_fdb = $myrow_fdb["38desc"];
                $gview_fdb = $myrow_fdb["38gview"];
                
                /*$defaultmarker = "";
                if ($default_fdb == 'TRUE') {
                    $defaultmarker = "<sup style='color:green;'>DEFAULT</sup>";
                }*/
                $defaultmarker = ($default_fdb == 'TRUE') ? "<sup style='color:green;'>DEFAULT</sup>" : "";
                
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>$type_fdb $defaultmarker</td>";
                    echo "<td style='text-align:left;'>$synonym_fdb</td>";
                    echo "<td style='text-align:left;'>$desc_fdb</td>";
                    echo "<td style='text-align:left;'>".sfx_checkBooleanValue($gview_fdb)."</td>";
                    echo "<td>";
                        echo "<a title='Delete this record' href='addtype.php?del=$typeid_fdb' onclick=\"return confirm('Are you sure ? You are advisable to change all items based on this type to the other type before proceeding.');\"><i class=\"fas fa-trash\"></i></a> ";
                        echo "<a title='Update this record' href='addtype.php?edt=$typeid_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
            $stmt_fdb->close();
        ?>
    </table>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
