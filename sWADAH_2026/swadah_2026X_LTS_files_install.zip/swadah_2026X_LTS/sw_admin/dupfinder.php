<?php
/*
Filename: dupfinder.php
Usage: Manage duplicate found by the module internal engine
Version: 20250417.1408
Last change:
    20250417.1408 - add last checked column and tracking functionality
    20250415.0854 - improve string replacements in line 79-84
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Duplicate Finder";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    // Handle timestamp updates via AJAX
    if(isset($_POST['update_timestamp']) && isset($_POST['item_id'])) {
        $item_id = intval($_POST['item_id']);
        $timestamp = date('Y-m-d H:i:s');
        
        // Check if entry exists
        $check_query = "SELECT * FROM eg_item_lastchecked WHERE item_id = $item_id";
        $check_result = mysqli_query($GLOBALS["conn"], $check_query);
        
        if(mysqli_num_rows($check_result) > 0) {
            // Update existing timestamp
            $update_query = "UPDATE eg_item_lastchecked SET last_checked = '$timestamp' WHERE item_id = $item_id";
            mysqli_query($GLOBALS["conn"], $update_query);
        } else {
            // Insert new timestamp
            $insert_query = "INSERT INTO eg_item_lastchecked (item_id, last_checked) VALUES ($item_id, '$timestamp')";
            mysqli_query($GLOBALS["conn"], $insert_query);
        }
        
        echo $timestamp;
        exit;
    }
    
    // Check if eg_item_lastchecked table exists, create if not
    $table_check = mysqli_query($GLOBALS["conn"], "SHOW TABLES LIKE 'eg_item_lastchecked'");
    if(mysqli_num_rows($table_check) == 0) {
        $create_table = "CREATE TABLE eg_item_lastchecked (
            id INT(11) NOT NULL AUTO_INCREMENT,
            item_id INT(11) NOT NULL,
            last_checked DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY (item_id)
        )";
        mysqli_query($GLOBALS["conn"], $create_table);
    }
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
    <script>
    function updateLastChecked(itemId, linkElement) {
        // Get the original destination URL
        const href = linkElement.getAttribute('href');
        
        // Create XMLHttpRequest
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'dupfinder.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        xhr.onreadystatechange = function() {
            if(xhr.readyState === 4 && xhr.status === 200) {
                // Update the last checked timestamp in the DOM
                const row = linkElement.closest('tr');
                const lastCheckedCell = row.querySelector('.last-checked-cell');
                if(lastCheckedCell) {
                    lastCheckedCell.textContent = xhr.responseText;
                }
                
                // Navigate to the original URL
                window.location.href = href;
            }
        };
        
        // Send the request
        xhr.send('update_timestamp=1&item_id=' + itemId);
        
        // Prevent the default link behavior
        return false;
    }
    </script>
</head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
            
    <div style='text-align:center'>
        <?php
                
            $query_dup = "SELECT count(*) as num, i.id, i.38title, i.38typeid, lc.last_checked
                         FROM eg_item i
                         LEFT JOIN eg_item_lastchecked lc ON lc.item_id = i.id ";
            if (isset($_GET['typeref']) && is_numeric($_GET['typeref']) && ($_GET['typeref'] != 'All')) {
                $query_dup .= "WHERE i.38typeid=".mysqli_real_escape_string($GLOBALS["conn"], $_GET['typeref'])." ";
            }
            $query_dup .= "GROUP BY i.38title HAVING count(*) > 1 ORDER BY i.38typeid, i.38title";
            $result_dup = mysqli_query($GLOBALS["conn"], $query_dup);

        ?>
                <table class=whiteHeader><tr class=<?php echo $color_scheme."HeaderCenter";?>><td>
                    <strong>Detected Duplicates </strong>
                    <br/><br/>
                    <form action="dupfinder.php" method="get" enctype="multipart/form-data">
                        <em>Filter by :</em>
                        <select name="typeref">
                            <option value='All'>All</option>
                            <?php
                                $query_type = "select 38typeid, 38type from eg_item_type";
                                $result_type = mysqli_query($GLOBALS["conn"], $query_type);
                                while ($myrow_type=mysqli_fetch_array($result_type)) {
                                    $type=$myrow_type["38type"];
                                    $typeid=$myrow_type["38typeid"];
                                    echo "<option value='$typeid'" . (isset($_GET['typeref']) && $_GET['typeref'] == $typeid ? " selected" : "") . ">$type</option>";
                                }
                            ?>
                        </select>
                        <input type="submit" name="do" value="Filter" />
                    </form>
                </td></tr></table>

        <?php
                echo "<table class=whiteHeader>";
                    echo "<tr style='text-decoration:underline;'>";
                        echo "<td></td>";
                        echo "<td style='text-align:left;'>Title</td>";
                        echo "<td width=150>$type_as</td>";
                        echo "<td width=65>Duplicate</td>";
                        echo "<td width=150>Last Checked</td>";
                    echo "</tr>";
                                                                                    
                    $n = 1;
                    while ($myrow_dup = mysqli_fetch_array($result_dup)) {
                        echo "<tr class=$color_scheme"."Hover>";
                            $num2 = $myrow_dup["num"];
                            $titlestatement2 = $myrow_dup["38title"];
                            $type2 = $myrow_dup["38typeid"];
                            $item_id = $myrow_dup["id"];
                            $last_checked = $myrow_dup["last_checked"];

                            $replacements = [
                                '\"' => '&#34;',
                                '\'s' => '',
                                '\'' => ''
                            ];
                            $titlestatement2converted = strtr($titlestatement2, $replacements);
                            $searchurl = 'index2.php?scstr='.$titlestatement2converted.'&sctype=EveryThing&onlytitle=yes&mf=9999';

                            echo "<td width=50 style='text-align:center;'>$n</td>";
                            echo "<td style='text-align:left;'><a href=\"$searchurl\" onclick=\"return updateLastChecked($item_id, this)\">$titlestatement2</a></td>";
                            echo "<td>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $type2)."</td>";
                            echo "<td>$num2</td>";
                            echo "<td class='last-checked-cell'>".($last_checked ? $last_checked : "Never")."</td>";
                        echo "</tr>";
                        $n = $n + 1;
                    }
                echo "</table>";
        ?>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
