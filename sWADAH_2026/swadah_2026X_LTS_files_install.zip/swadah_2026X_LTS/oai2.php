<?php
/*
Filename: oai2.php
Usage: OAI-PMH 2.0 connector for MySQL/MariaDB database for sWADAH
Version: 20250410.1424 Beta
Author: Khairul Asyrani Sulaiman | asyrani@upsi.edu.my
Metadata Supported: OAI_DC, UKETD_DC
*/

//get database connection
include_once 'core.php';

//function declaration
function oaifx_validateDate($date)
{
  return preg_match("/^\d{4}-\d{2}-\d{2}$/", $date) ? true : false;
}

function oaifx_compareDate($from, $until)
{
  return new DateTime($from) > new DateTime($until);
}

function oaifx_checkStringDuplicate($text)
{
  return substr_count($text, 'metadataPrefix');
}

function oaifx_tomorrow()
{
  return (new DateTime('tomorrow + 12hours'))->format('Y-m-d\TH:i:s\Z');
}

function oaifx_strip_to_bare_text($stringtobare)
{
  $replace_pairs = [
    '&nbsp;' => '',
    '&ndash;' => '-',
    '&' => '&amp;',
    '< ' => '&lt;',
    '> ' => '&gt;'
  ];
  $str1 = str_replace(array_keys($replace_pairs), array_values($replace_pairs), strip_tags($stringtobare));
  return preg_replace('/[[:^print:]]/', "", $str1);
}

$installed_date = file_exists("sw_installed/dateinstalled.txt") ? file_get_contents("sw_installed/dateinstalled.txt") : '1972-01-01';
?>
<?php






//if enable oai_pmh is not set, then exit and if exist, then proceed
//the main code begins here
if (!$enable_oai_pmh) {
  echo "OAI PMH is not enabled on this server.";exit;
} else {
  header('Content-Type: text/xml');
  session_start();

  //user permittable configuration
  $oai_resultPerPage = 100;
  
  //system default - WARNING ! Do not alter this
  $illegalGET_Argument = false;
  $illegalSET_isset = false;
  $isnumericToken = true;
  $dateInFormat = true;
  $metadataPrefixIsOn = false;
  $fromBiggerThanUntil = false;
  $metadataPrefixCount = 1;
  $lateThanInstalledDate = false;
  $earlyThanInstalledDate = false;
  $legitIdentifier = false;//default to false because of line 162
  $overblownIdentifier = false;

  //get verb forwarded by either clicking one of the links or automated harvester inquiry
  $get_verb = isset($_REQUEST["verb"]) ? strtoupper($_REQUEST["verb"]) : null;

  //get first record
  $queryFirst = "select id from eg_item order by id limit 1";
    $resultFirst = mysqli_query($GLOBALS["conn"], $queryFirst);
    $myrowFirst = mysqli_fetch_array($resultFirst);
    $firstID_of_record = $myrowFirst["id"];

  echo "<?xml version='1.0' encoding='UTF-8' ?>\n";
  echo "<?xml-stylesheet type='text/xsl' href='sw_asset/css/oai2.xsl' ?>\n";
  echo "<OAI-PMH xmlns='http://www.openarchives.org/OAI/2.0/' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xsi:schemaLocation='http://www.openarchives.org/OAI/2.0/ http://www.openarchives.org/OAI/2.0/OAI-PMH.xsd'>\n";
  echo "  <responseDate>".gmdate("Y-m-d\TH:i:s\Z")."</responseDate>\n";

  $fullURL = isset($_SERVER['HTTP_HOST'], $_SERVER['REQUEST_URI']) ? $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] : null;
  if (isset(explode("Identify&", $fullURL)[1]) && strlen(explode("Identify&", $fullURL)[1]) >= 1) {
    $illegalGET_Argument = true;
  }

  if (isset($_REQUEST["resumptionToken"])) {
    if (is_numeric($_REQUEST["resumptionToken"])) {
      $isnumericToken = true;
    } else {
        //to handle resumptionToken criteria with %26 (&) and %3D (=)
        if (strpos($_REQUEST["resumptionToken"], "&metadataPrefix=oai_dc") !== false) {
          $_REQUEST["metadataPrefix"] = "oai_dc";
        } elseif (strpos($_REQUEST["resumptionToken"], "&metadataPrefix=uketd_dc") !== false) {
          $_REQUEST["metadataPrefix"] = "uketd_dc";
        }
        
        $hold_resumptionTokenValue = $_REQUEST["resumptionToken"];

        $_REQUEST["resumptionToken"] = strtok($hold_resumptionTokenValue, "&metadataPrefix");
        
        if (strpos($hold_resumptionTokenValue, "&set=") !== false) {
          $_REQUEST["set"] = substr($hold_resumptionTokenValue, strpos($hold_resumptionTokenValue, "&set=") + 5);
        }

        $isnumericToken = is_numeric(strtok($hold_resumptionTokenValue, "&"));
    }
  }
  
  if (isset($_REQUEST["set"]) && isset($_REQUEST["metadataPrefix"]) && isset($_REQUEST["from"]) && isset($_REQUEST["until"])) {
    $illegalSET_isset = true;
  }
  if (isset($_REQUEST['from'])) {
    $dateInFormat = oaifx_validateDate($_REQUEST['from']);
  }
  if (isset($_REQUEST['until'])) {
    $dateInFormat = oaifx_validateDate($_REQUEST['until']);
  }
  if (isset($_REQUEST['metadataPrefix'])) {
    $metadataPrefixIsOn = in_array($_REQUEST['metadataPrefix'], ['oai_dc', 'uketd_dc']);
  }
  if ((isset($_REQUEST['from']) && oaifx_validateDate($_REQUEST['from'])) && (isset($_REQUEST['until']) && oaifx_validateDate($_REQUEST['until']))) {
    $fromBiggerThanUntil = oaifx_compareDate($_REQUEST['from'], $_REQUEST['until']);
  }
  if (oaifx_checkStringDuplicate("$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]") >= 2) {
    $metadataPrefixCount = oaifx_checkStringDuplicate("$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
  }
  if (isset($_REQUEST['until']) && (oaifx_validateDate($_REQUEST['from']) && oaifx_validateDate($_REQUEST['until'])) && oaifx_compareDate($installed_date, $_REQUEST['until'])) {
    $lateThanInstalledDate = true;
  }
  if (isset($_REQUEST['until']) && oaifx_validateDate($_REQUEST['until']) && oaifx_compareDate($installed_date, $_REQUEST['until'])) {
    $earlyThanInstalledDate = true;
  }
  if (isset($_REQUEST['identifier']) && strpos($_REQUEST['identifier'], "oai:") !== false) {
    $legitIdentifier = true;
  }
  if ((isset($_REQUEST['verb']) && $_REQUEST['verb'] == 'ListIdentifiers') && isset($_REQUEST['resumptionToken']) && isset($_REQUEST['metadataPrefix'])) {
    $overblownIdentifier = true;
  }
  
  //handling from until for LISTRECORDS and LISTIDENTIFIERS
  if (isset($_REQUEST['from']) && isset($_REQUEST['until'])) {
    $_SESSION[$ssn.'appendFromUntil'] = "and STR_TO_DATE(eg_item.39inputdate, '%Y-%m-%d') BETWEEN '".$_REQUEST['from']."' AND '".$_REQUEST['until']."'";
  } elseif (isset($_REQUEST['from'])) {
    $_SESSION[$ssn.'appendFromUntil'] = "and STR_TO_DATE(eg_item.39inputdate, '%Y-%m-%d') >= '".$_REQUEST['from']."'";
  } elseif (isset($_REQUEST['until'])) {
    $_SESSION[$ssn.'appendFromUntil'] = "and STR_TO_DATE(eg_item.39inputdate, '%Y-%m-%d') <= '".$_REQUEST['until']."'";
  }  elseif (!isset($_REQUEST['resumptionToken'])) {
    $_SESSION[$ssn.'appendFromUntil'] = '';
  }

  //handling set
  if (isset($_REQUEST['set']) && is_numeric($_REQUEST['set'])) {
    $_SESSION[$ssn.'appendSet'] = "and eg_item.38typeid='".$_REQUEST['set']."'";
    $setSpec = $_REQUEST['set'];
  } else {
    $_SESSION[$ssn.'appendSet']='';
    $setSpec = null;
  }

  //handling metadataPrefix
  if (isset($_REQUEST['metadataPrefix']) && $_REQUEST['metadataPrefix'] == 'uketd_dc') {
    $_SESSION[$ssn.'metaDataSelected'] = 'uketd_dc';
  } elseif (isset($_REQUEST['metadataPrefix']) && $_REQUEST['metadataPrefix'] == 'oai_dc') {
    $_SESSION[$ssn.'metaDataSelected'] = 'oai_dc';
  }
  
?>
<?php






if ($get_verb == 'IDENTIFY' && !$illegalGET_Argument) {
?>
  <request verb='Identify'><?= $system_path;?>oai2.php</request>
  <Identify>
    <repositoryName><?= $system_title;?></repositoryName>
    <baseURL><?= $system_path."oai2.php";?></baseURL>
    <protocolVersion>2.0</protocolVersion>
    <adminEmail><?= $system_admin_email;?></adminEmail>
    <earliestDatestamp><?= $installed_date;?></earliestDatestamp>
    <deletedRecord>no</deletedRecord>
    <granularity>YYYY-MM-DD</granularity>
    <description>
      <oai-identifier xmlns="http://www.openarchives.org/OAI/2.0/oai-identifier" xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/oai-identifier http://www.openarchives.org/OAI/2.0/oai-identifier.xsd">
        <scheme>oai</scheme>
        <repositoryIdentifier><?= $system_identifier;?></repositoryIdentifier>
        <delimiter>:</delimiter>
        <sampleIdentifier>oai:<?= $system_identifier;?>:<?= $firstID_of_record;?></sampleIdentifier>
      </oai-identifier>
    </description>
  </Identify>
<?php
}//if identify






elseif (($get_verb == 'LISTMETADATAFORMATS' && !isset($_REQUEST['identifier']) && !$overblownIdentifier) || ($get_verb == 'LISTMETADATAFORMATS' && $legitIdentifier && !$overblownIdentifier)) {
?>
  <request verb="ListMetadataFormats" identifier="oai:<?= $system_identifier;?>:<?= $firstID_of_record;?>"><?= $system_path."oai2.php";?></request>
  <ListMetadataFormats>
    <metadataFormat>
      <metadataPrefix>oai_dc</metadataPrefix>
      <schema>http://www.openarchives.org/OAI/2.0/oai_dc.xsd</schema>
      <metadataNamespace>http://www.openarchives.org/OAI/2.0/oai_dc/</metadataNamespace>
    </metadataFormat>
    <metadataFormat>
      <metadataPrefix>uketd_dc</metadataPrefix>
      <schema>http://naca.central.cranfield.ac.uk/ethos-oai/2.0/uketd_dc.xsd</schema>
      <metadataNamespace>http://naca.central.cranfield.ac.uk/ethos-oai/2.0/</metadataNamespace>
    </metadataFormat>
  </ListMetadataFormats>
<?php
}//elseif listmetadataformats






elseif ($get_verb == 'LISTRECORDS' && $isnumericToken && $dateInFormat && !$lateThanInstalledDate && !$earlyThanInstalledDate && (isset($_REQUEST["resumptionToken"]) || $metadataPrefixIsOn)) {
?>
<?php
  $fromAppend = isset($_REQUEST['from']) ? "from=\"".$_REQUEST['from']."\"" : null;
  $untilAppend = isset($_REQUEST['until']) ? "until=\"".$_REQUEST['until']."\"" : null;
?>
  <request verb="ListRecords"<?php if ($fromAppend <> '') {echo " $fromAppend";} if ($untilAppend <> '') {echo " $untilAppend";}?> metadataPrefix="<?= $_SESSION[$ssn.'metaDataSelected'];?>"><?= $system_path;?>oai2.php</request>
<?php
    $pageNum = isset($_REQUEST["resumptionToken"]) ? $_REQUEST["resumptionToken"] : 1;
    
    $offset = ($pageNum - 1) * $oai_resultPerPage;
    $pageNum = $pageNum + 1;
    
    $query1 = "select
    eg_item.id as id,
    eg_item.38langcode as langcode,
    eg_item.38title as title,
    eg_item.38typeid as typeid,
    eg_item.38publication as publication,
    eg_item.38location as location,
    eg_item.38author as author,
    eg_item.38source as source,
    eg_item.39inputdate as inputdate,
    eg_item.41instimestamp as instimestamp,
    eg_item.41subjectheading as subjectheading,
    eg_item.41fulltexta as abstract_text,
    eg_item.41reference as reference_text,
    eg_item2.38publication_c as yearpublish,
    eg_item2.38publication_b as frompublisher,
    eg_item2.38dissertation_note_b as qualificationlevel,
    eg_item2.38geographic_coverage_note_a as dc_rights,
    eg_item2.38original_version_note_t as dc_source,
    eg_item2.38terms_governing_use_a as dc_relation,
    eg_item_type.38type as typename
      from eg_item left join eg_item2
       on eg_item.id = eg_item2.eg_item_id left join eg_item_type
        on eg_item.38typeid = eg_item_type.38typeid
         where 38status='AVAILABLE' and
          50item_status='1' ".$_SESSION[$ssn.'appendFromUntil']." ".$_SESSION[$ssn.'appendSet']."
           order by eg_item.id limit $offset, $oai_resultPerPage";
      $result1 = mysqli_query($GLOBALS["conn"], $query1);
      $num_results_affected1 = mysqli_num_rows($result1);
    
    $query1complete = "select count(id) as completelist from eg_item where 38status='AVAILABLE' and 50item_status='1' ".$_SESSION[$ssn.'appendFromUntil']." ".$_SESSION[$ssn.'appendSet'];
      $result1complete = mysqli_query($GLOBALS["conn"], $query1complete);
      $myrow1complete = mysqli_fetch_array($result1complete);
      $oai_completeListSize = $myrow1complete["completelist"];
    
    if ($num_results_affected1 < 1) {
      echo "<error code=\"noRecordsMatch\">No items match. None. None at all. Not even deleted ones.</error>";
    } else {
?>
  <ListRecords>
<?php
    while ($myrow=mysqli_fetch_array($result1)) {
      $id5=$myrow["id"];

      $title5 = $myrow["title"];
      $exploded_removed_words = explode(',', $remove_word_from_title);
      foreach ($exploded_removed_words as $value) {
        $title5 = str_replace($value, "", $title5);
      }
      $title5 = oaifx_strip_to_bare_text($title5);

      $typeid5 = oaifx_strip_to_bare_text($myrow["typeid"]);
      $typename5 = !empty($myrow["typename"]) ? oaifx_strip_to_bare_text($myrow["typename"]) : "N/A";
      $location5 = $myrow["location"] !== '' ? oaifx_strip_to_bare_text($myrow["location"]) : "N/A";

      $author5 = oaifx_strip_to_bare_text($myrow["author"]);
      if ($author5 == '') {
        $author5 = $myrow["source"] != '' ? oaifx_strip_to_bare_text($myrow["source"]) : "N/A";
      }

      $source5 = $myrow["source"] != '' ? oaifx_strip_to_bare_text($myrow["source"]) : "N/A";
      $inputdate5 = $myrow["inputdate"] != '' ? date('Y-m-d', strtotime(str_replace('/', '-', $myrow["inputdate"]))) : "N/A";
      $instimestamp5 =$myrow["instimestamp"];
      $yearpublish5 = $myrow["yearpublish"] != '' ? $myrow["yearpublish"] : "N/A";
      $publication5 = $myrow["publication"] != '' ? oaifx_strip_to_bare_text($myrow["publication"]) : "N/A";
      $langcode5 = $myrow["langcode"];

      $dc_relation5 = $myrow["dc_relation"] != '' ? oaifx_strip_to_bare_text($myrow["dc_relation"]) : "N/A";
      if ($dc_relation5 == 'N/A') {
        $frompublisher5 = $myrow["frompublisher"] != '' ? oaifx_strip_to_bare_text($myrow["frompublisher"]) : "N/A";
        $dc_relation5 = $frompublisher5;
      }
            
      $dc_source5 = $myrow["dc_source"] != '' ? oaifx_strip_to_bare_text($myrow["dc_source"]) : "N/A";

      $dc_rights5 = $myrow["dc_rights"] != '' ? oaifx_strip_to_bare_text($myrow["dc_rights"]) : "N/A";
      if ($dc_rights5 == 'N/A') {
        $dc_rights5 = $oai_rights;
      }

      $qualificationlevel5 = $myrow["qualificationlevel"] != '' ? $myrow["qualificationlevel"] : "N/A";
      $abstract5 = $myrow["abstract_text"] != '' ? oaifx_strip_to_bare_text($myrow["abstract_text"]) : "N/A";
      $reference5 = $myrow["reference_text"] != '' ? oaifx_strip_to_bare_text($myrow["reference_text"]) : "N/A";
      
      $subjectheading5 =$myrow["subjectheading"];
      $returnSH = "N/A";
      if ($subjectheading5 != '') {
        $returnSH = "";
        $subjectheadings = explode("|", $subjectheading5);
        $totalsubjectheadings = count($subjectheadings) - 1;
        $i = 1;
        foreach ($subjectheadings as $subjectheading) {
          $subjectheading = trim($subjectheading);
          $queryTx = "select 43subject from eg_subjectheading where 43acronym = '$subjectheading'";
          $resultTx = mysqli_query($GLOBALS["conn"], $queryTx);
          $myrowTy=mysqli_fetch_array($resultTx);
          if ($subject_heading_selectable == "multi") {
              $returnSH .= preg_replace('/&(?!#?[a-z0-9]+;)/', '&amp;', $myrowTy["43subject"]);
              if ($i < $totalsubjectheadings) {$returnSH .= ", ";}
              $i=$i+1;
          } else {
            $returnSH = preg_replace('/&(?!#?[a-z0-9]+;)/', '&amp;', $myrowTy["43subject"])."";
            break;//just show the first subject heading found. disable this to show all in one liner
          }
        }//foreach
      }//if subjectheading5
?>
    <record>
    <header>
      <identifier>oai:<?= $system_identifier;?>:<?= $id5;?></identifier>
      <datestamp><?= $inputdate5;?></datestamp>
      <setSpec><?= $typeid5;?></setSpec>
    </header>
<?php
    if ($_SESSION[$ssn.'metaDataSelected'] == "uketd_dc") {
    //uketd_dc view
?>
    <metadata>
      <uketd_dc:uketddc xmlns:uketd_dc="http://naca.central.cranfield.ac.uk/ethos-oai/2.0/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:uketdterms="http://naca.central.cranfield.ac.uk/ethos-oai/terms/" xsi:schemaLocation="http://naca.central.cranfield.ac.uk/ethos-oai/2.0/ http://naca.central.cranfield.ac.uk/ethos-oai/2.0/uketd_dc.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <dc:title><?= htmlspecialchars($title5);?></dc:title>
        <dc:date><?= $yearpublish5;?></dc:date>
        <dc:creator><?= htmlspecialchars($author5);?></dc:creator>
        <dc:subject><?= $returnSH;?></dc:subject>
        <dcterms:abstract><?= $abstract5;?></dcterms:abstract>
        <dcterms:issued><?= $yearpublish5;?></dcterms:issued>
        <dc:type><?= $typename5;?></dc:type>
        <dcterms:isReferencedBy><?= $system_path."detailsg.php?det=$id5";?></dcterms:isReferencedBy>
        <dc:identifier xsi:type="dcterms:URI"><?= $system_path."detailsg.php?det=$id5";?></dc:identifier>
        <dc:format><?= $oai_main_format;?></dc:format>
        <dc:language><?= $langcode5;?></dc:language>
        <dc:source><?= $dc_source5;?></dc:source>
        <dcterms:accessRights><?= $dc_rights5;?></dcterms:accessRights>
        <uketdterms:qualificationname></uketdterms:qualificationname>
        <uketdterms:qualificationlevel><?= $qualificationlevel5;?></uketdterms:qualificationlevel>
        <uketdterms:institution><?= $source5;?></uketdterms:institution>
        <uketdterms:department><?= $dc_relation5;?></uketdterms:department>
        <dcterms:references><?= $reference5;?></dcterms:references>
      </uketd_dc:uketddc>
    </metadata>
<?php
    } else {
      //dc view
?>
    <metadata>
      <oai_dc:dc xmlns:oai_dc="http://www.openarchives.org/OAI/2.0/oai_dc/" xmlns:dc="http://purl.org/dc/elements/1.1/" xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/oai_dc/ http://www.openarchives.org/OAI/2.0/oai_dc.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <dc:relation><?= $system_path."detailsg.php?det=$id5";?></dc:relation>
        <dc:title><?= htmlspecialchars($title5);?></dc:title>
        <dc:creator><?= htmlspecialchars($author5);?></dc:creator>
        <dc:subject><?= $returnSH;?></dc:subject>
        <dc:publisher><?= htmlspecialchars($publication5);?></dc:publisher>
        <dc:relation><?= $dc_relation5;?></dc:relation>
        <dc:date><?= $yearpublish5;?></dc:date>
        <dc:type><?= $typename5;?></dc:type>
        <dc:format><?= $oai_main_format;?></dc:format>
        <dc:language><?= $langcode5;?></dc:language>
        <dc:source><?= $dc_source5;?></dc:source>
        <dc:identifier><?= $system_path."detailsg.php?det=$id5";?></dc:identifier>
        <dc:rights><?= $dc_rights5;?></dc:rights>
        <dc:description><?= htmlspecialchars($title5)." by ".htmlspecialchars($author5);?></dc:description>
      </oai_dc:dc>
    </metadata>
<?php
  }
?>
    </record>
<?php
    }//while
    if (($num_results_affected1 == $oai_resultPerPage) && ($oai_completeListSize != $oai_resultPerPage)) {
      echo "<resumptionToken completeListSize=\"".$oai_completeListSize."\" expirationDate=\"".oaifx_tomorrow()."\">$pageNum";
        if ($_SESSION[$ssn.'metaDataSelected'] != '') {
          echo "&amp;metadataPrefix=".$_SESSION[$ssn.'metaDataSelected'];
        }
        if ($setSpec != '') {
          echo "&amp;set=$setSpec";
        }
      echo "</resumptionToken>";
    }
?>
  </ListRecords>
<?php
    }//else $num_results_affected1 >= 1
}//elseif listrecords






elseif ($get_verb == 'LISTIDENTIFIERS' && !$illegalSET_isset && $isnumericToken && $dateInFormat && !$fromBiggerThanUntil && (isset($_REQUEST["resumptionToken"]) || ($metadataPrefixIsOn && $metadataPrefixCount == 1))) {
  $fromAppend = isset($_REQUEST['from']) ? "from=\"".$_REQUEST['from']."\"" : '';
  $untilAppend = isset($_REQUEST['until']) ? "until=\"".$_REQUEST['until']."\"" : '';
?>
  <request verb="ListIdentifiers"<?php if ($fromAppend <> '') {echo " $fromAppend";} if ($untilAppend <> '') {echo " $untilAppend";}?> metadataPrefix="<?= $_SESSION[$ssn.'metaDataSelected'];?>"><?= $system_path;?>oai2.php</request>
<?php
    $pageNum = $_REQUEST["resumptionToken"] ?? 1;
    
    $offset = ($pageNum - 1) * $oai_resultPerPage;
    $pageNum = $pageNum + 1;

    $query1 = "select * from eg_item where 38status='AVAILABLE' and 50item_status='1' ".$_SESSION[$ssn.'appendFromUntil']." ".$_SESSION[$ssn.'appendSet']." order by id limit $offset, $oai_resultPerPage";
      $result1 = mysqli_query($GLOBALS["conn"], $query1);
      $num_results_affected1 = mysqli_num_rows($result1);

    $query1complete = "select count(id) as completelist from eg_item where 38status='AVAILABLE' and 50item_status='1' ".$_SESSION[$ssn.'appendFromUntil']." ".$_SESSION[$ssn.'appendSet'];
      $result1complete = mysqli_query($GLOBALS["conn"], $query1complete);
      $myrow1complete = mysqli_fetch_array($result1complete);
      $oai_completeListSize = $myrow1complete["completelist"];

    if ($num_results_affected1 < 1) {
      echo "  <error code=\"noRecordsMatch\">No items match. None. None at all. Not even deleted ones.</error>";
    } else {
?>
  <ListIdentifiers>
<?php
    while ($myrow=mysqli_fetch_array($result1)) {
      $id5=$myrow["id"];
      $inputdate5 = date('Y-m-d', strtotime(str_replace('/', '-', $myrow["39inputdate"])));
?>
    <header>
      <identifier><?= $overblownIdentifier;?> oai:<?= $system_identifier;?>:<?= $id5;?></identifier>
      <datestamp><?= $inputdate5;?></datestamp>
    </header>
<?php
    }
    if (($num_results_affected1 == $oai_resultPerPage) && ($oai_completeListSize != $oai_resultPerPage)) {
      echo "<resumptionToken completeListSize=\"".$oai_completeListSize."\" expirationDate=\"".oaifx_tomorrow()."\">$pageNum";
        if ($_SESSION[$ssn.'metaDataSelected'] != '') {
          echo "&amp;metadataPrefix=".$_SESSION[$ssn.'metaDataSelected'];
        }
        if ($setSpec != '') {
          echo "&amp;set=$setSpec";
        }
      echo "</resumptionToken>";
    }
  ?>
  </ListIdentifiers>
<?php
    }//else $num_results_affected1 >= 1
}//elseif LISTIDENTIFIERS






elseif ($get_verb == 'LISTSETS') {
?>
  <request verb="ListSets"><?= $system_path;?>oai2.php</request>
  <ListSets>
<?php
  $query1 = "select * from eg_item_type";
  $result1 = mysqli_query($GLOBALS["conn"], $query1);
  while ($myrow=mysqli_fetch_array($result1)) {
?>
    <set>
      <setSpec><?= $myrow['38typeid'];?></setSpec>
      <setName><?= $myrow['38type'];?></setName>
    </set>
<?php
  }
?>
  </ListSets>
<?php
} //elseif listsets






elseif ($get_verb == 'GETRECORD' && $metadataPrefixIsOn) {
  unset($_SESSION[$ssn.'appendSet']);
  $get_identifier = substr($_REQUEST['identifier'], strrpos($_REQUEST['identifier'], ':') + 1);
  if ($get_identifier == '' || !$legitIdentifier || $overblownIdentifier) {
    $get_identifier = 0;
  }
?>
  <request verb="GetRecord" identifier='oai:<?= "$system_identifier:$get_identifier";?>' metadataPrefix="<?= $_SESSION[$ssn.'metaDataSelected'];?>"><?= $system_path;?>oai2.php</request>
<?php
    $query1 = "select
    eg_item.id as id,
    eg_item.38typeid as typeid,
    eg_item.38langcode as langcode,
    eg_item.38title as title,
    eg_item.38publication as publication,
    eg_item.38location as location,
    eg_item.38author as author,
    eg_item.38source as source,
    eg_item.39inputdate as inputdate,
    eg_item.41instimestamp as instimestamp,
    eg_item.41subjectheading as subjectheading,
    eg_item2.38publication_c as yearpublish,
    eg_item.41fulltexta as abstract_text,
    eg_item.41reference as reference_text,
    eg_item2.38publication_c as yearpublish,
    eg_item2.38publication_b as frompublisher,
    eg_item2.38dissertation_note_b as qualificationlevel,
    eg_item2.38geographic_coverage_note_a as dc_rights,
    eg_item2.38original_version_note_t as dc_source,
    eg_item2.38terms_governing_use_a as dc_relation,
    eg_item_type.38type as typename
      from eg_item left join eg_item2
       on eg_item.id = eg_item2.eg_item_id left join eg_item_type
        on eg_item.38typeid = eg_item_type.38typeid
         where eg_item.id=$get_identifier limit 1";
      $result1 = mysqli_query($GLOBALS["conn"], $query1);
      $num_results_affected1 = mysqli_num_rows($result1);

    if ($num_results_affected1 < 1) {
      echo " <error code=\"idDoesNotExist\">'oai:$system_identifier:$get_identifier' is not a valid item in this repository</error>";
      echo " <error code=\"badArgument\">Illegal Parameter Detected</error>";
    } else {
?>
  <GetRecord>
<?php
    $myrow=mysqli_fetch_array($result1);
    
    $id5=$myrow["id"];

    $title5 = $myrow["title"];
    $exploded_removed_words = explode(',', $remove_word_from_title);
    foreach ($exploded_removed_words as $value) {
      $title5 = str_replace($value, "", $title5);
    }
    $title5 = oaifx_strip_to_bare_text($title5);

    $typeid5 = oaifx_strip_to_bare_text($myrow["typeid"]);
    $typename5 = $myrow["typename"] != '' ? oaifx_strip_to_bare_text($myrow["typename"]) : "N/A";
    $location5 = $myrow["location"] != '' ? oaifx_strip_to_bare_text($myrow["location"]) : "N/A";

    $author5 = oaifx_strip_to_bare_text($myrow["author"]);
    if ($author5 == '') {
      $author5 = $myrow["source"] != '' ? oaifx_strip_to_bare_text($myrow["source"]) : "N/A";
    }

    $source5 = $myrow["source"] != '' ? oaifx_strip_to_bare_text($myrow["source"]) : "N/A";
    $inputdate5 = $myrow["inputdate"] != '' ? date('Y-m-d', strtotime(str_replace('/', '-', $myrow["inputdate"]))) : "N/A";
    $instimestamp5 =$myrow["instimestamp"];
    $yearpublish5 = $myrow["yearpublish"] != '' ? $myrow["yearpublish"] : "N/A";
    $publication5 = $myrow["publication"] != '' ? oaifx_strip_to_bare_text($myrow["publication"]) : "N/A";
    $langcode5 = $myrow["langcode"];

    $dc_relation5 = $myrow["dc_relation"] != '' ? oaifx_strip_to_bare_text($myrow["dc_relation"]) : "N/A";
    if ($dc_relation5 == 'N/A') {
      $frompublisher5 = $myrow["frompublisher"] != '' ? oaifx_strip_to_bare_text($myrow["frompublisher"]) : "N/A";
      $dc_relation5 = $frompublisher5;
    }
    
    $dc_source5 = $myrow["dc_source"] != '' ? oaifx_strip_to_bare_text($myrow["dc_source"]) : "N/A";
    
    $dc_rights5 = $myrow["dc_rights"] != '' ? oaifx_strip_to_bare_text($myrow["dc_rights"]) : "N/A";
      if ($dc_rights5 == 'N/A') {
        $dc_rights5 = $oai_rights;
      }

    $qualificationlevel5 = $myrow["qualificationlevel"] != '' ? $myrow["qualificationlevel"] : "N/A";
    $abstract5 = $myrow["abstract_text"] != '' ? oaifx_strip_to_bare_text($myrow["abstract_text"]) : "N/A";
    $reference5 = $myrow["reference_text"] != '' ? oaifx_strip_to_bare_text($myrow["reference_text"]) : "N/A";

    $subjectheading5 =$myrow["subjectheading"];
    $returnSH = "N/A";
    if ($subjectheading5 != '') {
      $returnSH = "";
      $subjectheadings = explode("|", $subjectheading5);
      $totalsubjectheadings = count($subjectheadings) - 1;
      $i = 1;
      foreach ($subjectheadings as $subjectheading) {
        $subjectheading = trim($subjectheading);
        $queryTx = "select 43subject from eg_subjectheading where 43acronym = '$subjectheading'";
        $resultTx = mysqli_query($GLOBALS["conn"], $queryTx);
        $myrowTy=mysqli_fetch_array($resultTx);
        if ($subject_heading_selectable == "multi") {
          $returnSH .= preg_replace('/&(?!#?[a-z0-9]+;)/', '&amp;', $myrowTy["43subject"]);
          if ($i < $totalsubjectheadings) {
            $returnSH .= ", ";
          }
          $i=$i+1;
        } else {
          $returnSH = preg_replace('/&(?!#?[a-z0-9]+;)/', '&amp;', $myrowTy["43subject"])."";
          break;//just show the first subject heading found. disable this to show all in one liner
        }
      }
    }
?>
    <record>
    <header>
      <identifier>oai:<?= $system_identifier.":".$id5;?></identifier>
      <datestamp><?= $inputdate5;?></datestamp>
      <setSpec><?= $typeid5;?></setSpec>
    </header>
<?php
    if ($_SESSION[$ssn.'metaDataSelected'] == "uketd_dc") {
?>
    <metadata>
      <uketd_dc:uketddc xmlns:uketd_dc="http://naca.central.cranfield.ac.uk/ethos-oai/2.0/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:uketdterms="http://naca.central.cranfield.ac.uk/ethos-oai/terms/" xsi:schemaLocation="http://naca.central.cranfield.ac.uk/ethos-oai/2.0/ http://naca.central.cranfield.ac.uk/ethos-oai/2.0/uketd_dc.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <dc:title><?= htmlspecialchars($title5);?></dc:title>
        <dc:date><?= $yearpublish5;?></dc:date>
        <dc:creator><?= htmlspecialchars($author5);?></dc:creator>
        <dc:subject><?= $returnSH;?></dc:subject>
        <dcterms:abstract><?= $abstract5;?></dcterms:abstract>
        <dcterms:issued><?= $yearpublish5;?></dcterms:issued>
        <dc:type><?= $typename5;?></dc:type>
        <dcterms:isReferencedBy><?= $system_path."detailsg.php?det=$id5";?></dcterms:isReferencedBy>
        <dc:identifier xsi:type="dcterms:URI"><?= $system_path."detailsg.php?det=$id5";?></dc:identifier>
        <dc:format><?= $oai_main_format;?></dc:format>
        <dc:language><?= $langcode5;?></dc:language>
        <dc:source><?= $dc_source5;?></dc:source>
        <dcterms:accessRights><?= $dc_rights5;?></dcterms:accessRights>
        <uketdterms:qualificationname></uketdterms:qualificationname>
        <uketdterms:qualificationlevel><?= $qualificationlevel5;?></uketdterms:qualificationlevel>
        <uketdterms:institution><?= $source5;?></uketdterms:institution>
        <uketdterms:department><?= $dc_relation5;?></uketdterms:department>
        <dcterms:references><?= $reference5;?></dcterms:references>
      </uketd_dc:uketddc>
    </metadata>
<?php
    } else {
?>
    <metadata>
      <oai_dc:dc xmlns:oai_dc="http://www.openarchives.org/OAI/2.0/oai_dc/" xmlns:dc="http://purl.org/dc/elements/1.1/" xsi:schemaLocation="http://www.openarchives.org/OAI/2.0/oai_dc/ http://www.openarchives.org/OAI/2.0/oai_dc.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <dc:relation><?= $system_path."detailsg.php?det=$id5";?></dc:relation>
        <dc:title><?= htmlspecialchars($title5);?></dc:title>
        <dc:creator><?= htmlspecialchars($author5);?></dc:creator>
        <dc:subject><?= $returnSH;?></dc:subject>
        <dc:publisher><?= htmlspecialchars($publication5);?></dc:publisher>
        <dc:relation><?= $dc_relation5;?></dc:relation>
        <dc:date><?= $yearpublish5;?></dc:date>
        <dc:type><?= $typename5;?></dc:type>
        <dc:format><?= $oai_main_format;?></dc:format>
        <dc:language><?= $langcode5;?></dc:language>
        <dc:source><?= $dc_source5;?></dc:source>
        <dc:identifier><?= $system_path."detailsg.php?det=$id5";?></dc:identifier>
        <dc:rights><?= $dc_rights5;?></dc:rights>
        <dc:description><?= htmlspecialchars($title5)." by ".htmlspecialchars($author5);?></dc:description>
      </oai_dc:dc>
    </metadata>
<?php
    }
?>
    </record>
  </GetRecord>
<?php
    }
} //elseif GETRECORD






else {
  if ($get_verb!='IDENTIFY' && $get_verb!='LISTIDENTIFIERS' && $get_verb!='LISTMETADATAFORMATS' && $get_verb!='LISTRECORDS' && $get_verb!='LISTSETS' && $get_verb!='GETRECORD') {
?>
  <request><?= $system_path;?>oai2.php</request>
  <error code="badVerb">Requires verb argument</error>
<?php
  } else {
    if ($illegalGET_Argument || !$metadataPrefixIsOn || !$dateInFormat || $fromBiggerThanUntil || $metadataPrefixCount >= 2 || $lateThanInstalledDate) {
?>
  <request><?= $system_path;?>oai2.php</request>
  <error code="badArgument">Illegal Parameter Detected</error>
<?php
    }
    if (!$isnumericToken || $overblownIdentifier) {
?>
  <request><?= $system_path;?>oai2.php</request>
  <error code="badResumptionToken">Bad Resumption Token Detected</error>
<?php
    }
    if ($fromBiggerThanUntil || $earlyThanInstalledDate) {
?>
  <request><?= $system_path;?>oai2.php</request>
  <error code="noRecordsMatch">No records found.</error>
<?php
    }
  }
}//else
?>
</OAI-PMH><?php }//else OAI-PMH enable = true?>
