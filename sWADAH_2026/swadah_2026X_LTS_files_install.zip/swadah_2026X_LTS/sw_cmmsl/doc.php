<?php
/*
    Filename: sw_cmmsl/doc.php
    Usage: sWadah Commercial List Item Viewer
    Version: 1.0.20240619.1223 Alpha
    ------
    Notes:
    If you can read this, you are probably want to change something in this puddle of codes.

    call structure e.g.: http://localhost:834/swadah/sw_cmmsl/doc.php?v=
    where v is passed as encrypted value from api
*/

session_start();
include_once '../core.php';

if (!isset($_GET['v'])) {
    echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Resource time out.</h2><em>sWADAH Response Code</em></div>";
    mysqli_close($GLOBALS["conn"]); exit;
}

//decrypt the v
$decryption_f = openssl_decrypt(base64_decode($_GET['v']), "AES-128-CTR", $aes_key, 0, "1234567891011121");

$contentdisposition = "inline";
$contenttransferencoding = "binary";
$mm_type="application/pdf";
$file = $decryption_f;
$filename = time()."F.pdf";

function dfx_getValueBetween($string) {
    $pattern = "/\/([^\/]*)_/";
    preg_match($pattern, $string, $matches);
    return $matches[1] ?? null;
}
$idgot = dfx_getValueBetween($file);

function dfx_getStringAfterSecondLastSlash($input) {
    // Cari kedudukan simbol "/" kedua terakhir
    $lastSlashPos = strrpos($input, '/');
    $secondLastSlashPos = strrpos($input, '/', $lastSlashPos - strlen($input) - 1);

    // Dapatkan substring selepas simbol "/" kedua terakhir
    if ($secondLastSlashPos !== false) {
        return substr($input, $secondLastSlashPos + 1);
    } else {
        return $input; // Jika tiada dua simbol "/", kembalikan string asal
    }
}
$commercialfilelocation = dfx_getStringAfterSecondLastSlash($file);

//store access to this file into statistic
mysqli_query($GLOBALS["conn"], "insert into eg_item_download values(DEFAULT,$idgot,'".date("D d/m/Y")."','".$_SERVER["REMOTE_ADDR"]."','cml')");

ob_start();
    header("Cache-Control: public, must-revalidate");
    header("Pragma: no-cache");
    header("Content-Type: " . $mm_type);
    header("Content-Length: " .(string)(filesize($file)));
    header("Content-Disposition: $contentdisposition; filename=$filename");//can be set to attachment or inline
    header("Content-Transfer-Encoding: binary\n");
ob_end_clean();
readfile($file);
