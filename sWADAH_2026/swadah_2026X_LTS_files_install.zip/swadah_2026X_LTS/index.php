<?php
/*
Filename: index.php
Usage: Front page
Qualification: access point page
Version: 20250101.0801
Last change: -
*/
?>
<?php
    $thisPageTitle  = "Main Page";
    session_start();define('includeExist', true);

    //load core
    include_once 'core.php';

    //unset previous_url session set on various non admin pages
    unset($_SESSION[$ssn.'previous_url']);
    unset($_SESSION[$ssn.'t']);
    
    //firstrun only dateinstalled and ssn check
    include_once 'sw_inc/firstrun_ssncheck.php';
    //firstrun only aes key check
    include_once 'sw_inc/firstrun_aescheck.php';
    //firstrun only admin user check
    include_once 'sw_inc/firstrun_admincheck.php';

    //loading functions
    include_once 'sw_inc/functions.php';
    //creating directories
    include_once 'sw_inc/function_createdir.php';
    
    //log out active patron whenever they arrived at this page
    //but if they still have session, redirect them to dashboard
    if (isset($_SESSION[$ssn.'username_guest']) && (isset($_GET['log']) && $_GET['log'] == 'out')) {
        mysqli_query($GLOBALS["conn"], "update eg_auth set online='OFF' where username='{$_SESSION[$ssn.'username_guest']}'");
        session_destroy();$_SESSION = [];//destroy sessions
    } elseif (isset($_SESSION[$ssn.'username_guest'])) {
        header("Location: dashboard.php");
        die();
    }
    
    //if username / admin is set and log is defined
    if (isset($_SESSION[$ssn.'username']) && isset($_GET['log'])) {
        if ($_GET['log'] == 'out') {
            mysqli_query($GLOBALS["conn"], "update eg_auth set online='OFF' where username='{$_SESSION[$ssn.'username']}'");
        }
        session_destroy();$_SESSION = [];//destroy sessions
    } elseif (isset($_SESSION[$ssn.'username'])) {
        header("Location: sw_admin/index2.php");
        die();
    }

    //clear loginless token sessions
    if (isset($_GET['c']) && $_GET['c'] == 'ls') {
        unset($_SESSION[$ssn.'lls']);
        unset($_SESSION[$ssn.'lls_token']);
        unset($_SESSION[$ssn.'lls_id']);
        unset($_SESSION[$ssn.'lls_tokenlimit']);
        unset($_SESSION[$ssn.'lls_tokenowner']);
        unset($_SESSION[$ssn.'disableSearch']);
    }

    $_SESSION[$ssn.'sear_period'] = 0;
    
?>
<!DOCTYPE HTML>
<html lang='en'>

<head>
    <?php include_once 'sw_inc/header.php'; ?>
    <link rel="stylesheet" type="text/css" href="sw_asset/css/topmenu.css<?= "$refresh_component";?>"/>
</head>

<body class='<?= $color_scheme;?>'>    <div class="top-menu">
        <ul>
            <?php
                if ($system_mode != 'maintenance' && $allow_user_to_login) {
                ?>
                    <li><span class="fa-regular fa-address-card"></span> <a href="in.php?t=ma">My Account</a></li>
                <?php
                }
                if ($system_mode != 'maintenance' && ($system_function == 'depo' || $system_function == 'full')) {
                ?>
                    <li><span class="fa-solid fa-upload"></span> <a href="sw_depos/depologin.php">Self Deposit</a></li>
                <?php
                }
            ?>
        </ul>
    </div>

    <main>
    <table style="padding-top:30px;" class=transparentCenter100percent>
        <tr>
            <td>
                <img alt='Main Logo' style='min-width:350px;max-width:550px;margin-bottom:30px;' width=<?= $main_logo_width;?> src="<?= $main_logo;?>">
                <br/><?= $intro_words;?>
                <br/><br/>
                <?php
                if ($searcher_type_bar_visibility && $system_mode != 'maintenance' && ($system_function == 'full' || $system_function == 'repo' || $system_function == 'photo')) {
                ?>
                    <form  action="searcher.php" method="get" enctype="multipart/form-data" style="margin:auto;max-width:100%;margin-top:20px;">
                        <input class="roundInputText" type="text" placeholder="&#x1F50D; Enter terms and press enter" name="scstr" style='font-size:14px' maxlength="255" autofocus/>
                        <input type="hidden" name="sctype" value="EveryThing" />
                    </form>
                    <br/><?php if ($show_browser_bar_guest) {include_once 'sw_inc/browser_bar.php';} ?>
                    <br/>
                <?php
                } elseif ($system_mode == 'maintenance') {
                    echo "<h2 style='color:red;'>System is currently under maintenance. Will be right back !</h2>";
                }
                ?>
            </td>
        </tr>
    </table>

    <br/>
    
    <?php
        include_once 'sw_inc/footer.php';
        include_once 'sw_inc/meta.php';
    ?>

    <div style='width:100%;text-align:center;'>
        <?php
            echo "<br/><br/>";
            echo sfx_checkPHPExtension('gd');
            echo sfx_checkPHPExtension('exif');
            echo sfx_checkPHPExtension('mbstring');
            echo sfx_checkPHPExtension('bz2');
            //echo sfx_checkPHPExtension('curl');
            echo sfx_checkPHPExtension('fileinfo');
            echo sfx_checkPHPExtension('gettext');
        ?>
    </div>
    </main>
    
    <?php
    if ($debug_mode == 'yes') {
    ?>
        <div class='footer' style='width:100%;text-align:center;'>
        <?php
            include_once 'sw_inc/view_storedSession.php';
            echo ($print_sessvar ?? '') . "<strong style='color:cyan;'>URL:</strong> <span style='color:lightgrey;'>" . sfx_getCurrentBaseURL() . "</span> <strong style='color:cyan;'>Accessed from: </strong>" . sfx_get_ip();
        ?>
        </div>
    <?php
    }
    ?>
    
</body>

</html>
<?php
    mysqli_close($GLOBALS["conn"]); exit();
?>
