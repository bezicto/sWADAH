<?php
/*
Filename: searcherapi.php
Usage: sWADAH SEARCHER API
Version: 2.3.20250624.1600 Beta
*/

    define('includeExist', true);
    
    include_once 'core.php';
    include_once 'sw_inc/functions.php';

    sfx_check_is_blocked("$recorded_incidents_directory/", "");

    if (isset($_GET['sctype']) && (!is_numeric($_GET['sctype']) && $_GET['sctype'] != 'EveryThing')) {
        sfx_record_block("$recorded_incidents_directory/");
    }

    $append_search_limit = (isset($_GET['agpt']) && is_numeric($_GET['agpt']) && $_GET['agpt'] == '1') ? "limit 20" : "";

    $sctype_select = (isset($_GET['sctype']) && is_numeric($_GET['sctype'])) ? $_GET['sctype'] : 'EveryThing';
    $scstr_term = isset($_GET['scstr']) ? sfx_just_clean($_GET['scstr']) : '';
    $scstr_term = preg_replace('/\s+/', ' +', "+".$scstr_term);//add '+' in front of every word

    if (isset($_GET['sctype'])) {
        if ($scstr_term == '' && $sctype_select == 'EveryThing') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 and 50item_status='1' and 38status!='UNLISTED' and 38folderid=0 order by id desc $append_search_limit";
            $stmt = $new_conn->prepare($query1);
        } elseif ($scstr_term == '' && is_numeric($sctype_select)) {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 and 38typeid = ? and 50item_status='1' and 38status!='UNLISTED' and 38folderid=0 order by id desc $append_search_limit";
            $stmt = $new_conn->prepare($query1);
            $stmt->bind_param("s", $sctype_select);
        } elseif ($scstr_term != '' && $sctype_select == 'EveryThing') {
            $scstr_term = sfx_filterCommonWords($scstr_term);
            $query1 = "
            select SQL_CALC_FOUND_ROWS *, match (38title,38author) against (? in boolean mode) as score
             from eg_item where id<>0 and 50item_status='1' and 38status!='UNLISTED' and 38folderid=0
             and match (38title,38author,41fulltexta) against (? in boolean mode)
              order by score desc $append_search_limit";//41pdfattach_fulltext,50search_cloud
            $stmt = $new_conn->prepare($query1);
            $stmt->bind_param("ss", $scstr_term, $scstr_term);
        } elseif ($scstr_term != '' && is_numeric($sctype_select)) {
            $scstr_term = sfx_filterCommonWords($scstr_term);
            $query1 = "
            select SQL_CALC_FOUND_ROWS *, match (38title,38author) against (? in boolean mode) as score
             from eg_item where id<>0 and 38typeid = ? and 50item_status='1' and 38status!='UNLISTED' and 38folderid=0
             and match (38title,38author,41fulltexta) against (? in boolean mode)
              order by score desc $append_search_limit";//41pdfattach_fulltext,50search_cloud
            $stmt = $new_conn->prepare($query1);
            $stmt->bind_param("sss", $scstr_term, $sctype_select, $scstr_term);
        }

        $stmt->execute();
        $result_term = $stmt->get_result();

        $posts = array();
        while ($myrow_term = $result_term->fetch_assoc()) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'year'=>sfx_sGetValue("38publication_c", "eg_item2", "eg_item_id", $myrow_term["id"]),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'swadah_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }

        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } elseif (isset($_GET['scpub'])) {
        $scpub2 = htmlspecialchars($_GET['scpub']);
        
        $param = "%".$scpub2."%";
        $stmt_term = $new_conn->prepare("
        select
        eg_item.id as id, eg_item.38title as 38title, eg_item.38author as 38author, eg_item.38typeid as 38typeid,
        eg_item2.38publication_b as 38publication_b, eg_item2.38publication_c as 38publication_c, eg_item2.38dissertation_note_b as 38dissertation_note_b
        from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id
         where eg_item2.38publication_b like ? and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0
        ");
        $stmt_term->bind_param("s", $param);//s string
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();
        
        $posts = array();

        while ($myrow_term = $result_term->fetch_assoc()) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'publication'=>htmlspecialchars($myrow_term["38publication_b"]),
                'year_of_publication'=>htmlspecialchars($myrow_term["38publication_c"]),
                'degree_type'=>htmlspecialchars($myrow_term["38dissertation_note_b"]),
                'swadah_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);







    } elseif (isset($_GET['scpubid']) && is_numeric($_GET['scpubid'])) {
        $scpub2 = sfx_sGetValue("43publisher", "eg_publisher", "43pubid", $_GET['scpubid']);
        
        $param = "%".$scpub2."%";
        $stmt_term = $new_conn->prepare("
        select
        eg_item.id as id, eg_item.38title as 38title, eg_item.38author as 38author, eg_item.38typeid as 38typeid,
        eg_item2.38publication_b as 38publication_b, eg_item2.38publication_c as 38publication_c, eg_item2.38dissertation_note_b as 38dissertation_note_b
        from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id
         where eg_item2.38publication_b like ? and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0
        ");
        $stmt_term->bind_param("s", $param);//s string
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();
        
        $posts = array();

        while ($myrow_term = $result_term->fetch_assoc()) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'publication'=>htmlspecialchars($myrow_term["38publication_b"]),
                'year_of_publication'=>htmlspecialchars($myrow_term["38publication_c"]),
                'degree_type'=>htmlspecialchars($myrow_term["38dissertation_note_b"]),
                'swadah_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } elseif (isset($_GET['scsub'])) {
        $scsub2 = sfx_just_clean($_GET['scsub']);

        $param = "%".$scsub2."%";
        $stmt_term = $new_conn->prepare("select id, 38title, 38author, 38typeid, 41subjectheading from eg_item
         where 41subjectheading like ? and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0");
        $stmt_term->bind_param("s", $param);//s string
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();

        $posts = array();
        while ($myrow_term = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'subject'=>htmlspecialchars($myrow_term["41subjectheading"]),
                'swadah_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);





    } elseif (isset($_GET['listype']) && is_numeric($_GET['listype']) && $_GET['listype'] == '1') {
        $stmt_term = $new_conn->prepare("select 38typeid, 38type from eg_item_type");
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();

        $posts = array();
        while ($row_typelist = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$row_typelist['38typeid'],
                'type'=>$row_typelist['38type']
            );
        }
        array_push($posts, array(
            'id'=>'EveryThing',
            'type'=>'This will list everything'));
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } elseif (isset($_GET['listpub']) && is_numeric($_GET['listpub']) && $_GET['listpub'] == '1') {
        $stmt_term = $new_conn->prepare("select 43pubid, 43acronym, 43publisher from eg_publisher");
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();
        
        $posts = array();
        while ($row_publist = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$row_publist['43pubid'],
                'acronym'=>$row_publist['43acronym'],
                'publisher'=>$row_publist['43publisher']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);







    } elseif (isset($_GET['listsub']) && is_numeric($_GET['listsub']) && $_GET['listsub'] == '1') {
        $stmt_term = $new_conn->prepare("select 43subjectid, 43acronym, 43subject from eg_subjectheading");
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();

        $posts = array();
        while ($row_sublist = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$row_sublist['43subjectid'],
                'acronym'=>$row_sublist['43acronym'],
                'subject'=>$row_sublist['43subject']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);







    } elseif ((isset($_GET['itemid']) && is_numeric($_GET['itemid'])) || (isset($_GET['mitemid']) && is_numeric($_GET['mitemid']))) {
        $iid = $_GET['itemid'] ?? $_GET['mitemid'] ?? 0;

        $stmt_detail = $new_conn->prepare("select * from eg_item where id=?");
        $stmt_detail->bind_param("i", $iid);//i integer
        $stmt_detail->execute();
        $result_detail = $stmt_detail->get_result();
        $row_detail = $result_detail->fetch_assoc();
        
        $fulltext = (isset($row_detail["41isabstract"]) && $row_detail["41isabstract"] == 1) ? 'abstract' : 'fulltext';

        //generate downloadkey -start
        if (empty($_SERVER['REQUEST_URI'])) {$_SERVER['REQUEST_URI'] = $_SERVER['SCRIPT_NAME'];}
        $url = preg_replace('/\?.*$/', '', $_SERVER['REQUEST_URI']);
        $folderpath = $system_path;
        $time = date('U');
        $ip_address = $_SERVER["REMOTE_ADDR"];
        //generate downloadkey -end

        $guest_file = "sw_admin/temp/no_permission.pdf";
        $pdocs_file = "sw_admin/temp/no_permission.pdf";
        $docs_file = "sw_admin/temp/no_permission.pdf";
        $image_file = "sw_admin/temp/no_permission.pdf";
        $albums_file = "sw_admin/temp/no_permission.pdf";
        $isos_file = "sw_admin/temp/no_permission.pdf";

        $inputdate_fdb = $row_detail["39inputdate"] ?? '00';
        $id_fdb = $row_detail['id'] ?? 0;
        $instimestamp_fdb = $row_detail['41instimestamp'] ?? 0;

        //create database entry for permission and granted access to the downloadkey
        $registerid = mysqli_query($GLOBALS["conn"], "INSERT INTO eg_downloadkey (id,eg_item_id,ip_address,timestamped,downloads) VALUES(DEFAULT,'".$id_fdb."','$ip_address','$time',DEFAULT)");
        $registeredid_justnow = $registerid ? mysqli_insert_id($GLOBALS["conn"]) : 0;

        if (is_file("$system_pdocs_directory/".substr($inputdate_fdb, 0, 4)."/".$id_fdb.""."_".$instimestamp_fdb.".pdf")) {
            
            $guest_file = "$system_path"."sw_inc/doc.php?t=p&did=$id_fdb&id=$registeredid_justnow";
        }
        
        if (is_file("$system_albums_directory/".substr($inputdate_fdb, 0, 4)."/".$id_fdb.""."_".$instimestamp_fdb.".jpg")) {
            
            $image_file = "$system_path"."sw_inc/doc.php?t=a&did=$id_fdb&id=$registeredid_justnow";
        }

        $posts = array(
            'id' => $row_detail['id'] ?? 0,
            'title' => sfx_filterHexadecimal($row_detail["38title"]) ?? 'N/A',
            'author' => sfx_filterHexadecimal($row_detail["38author"]) ?? 'N/A',
            'type' => sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $row_detail['38typeid'] ?? 0),
            'publication' => $row_detail["38publication"] ?? 'N/A',
            'source' => $row_detail["38source"] ?? 'N/A',
            'weblink' => urldecode($row_detail["38link"] ?? 'N/A'),
            'guest_file' => $guest_file,
            'image_file' => $image_file,
            'swadah_link' => $system_path . "detailsg.php?det=" . $id_fdb,
        );
        
        if (isset($_GET['itemid'])) {
            $posts['fulltext'] = htmlspecialchars(strip_tags($row_detail["41fulltexta"] ?? ''));
            $posts['reference'] = htmlspecialchars(strip_tags($row_detail["41reference"] ?? ''));
        }
        
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } else {
        echo "<h2>Welcome to sWADAH Searcher API.</h2><strong>Please provide parameters to the API.</strong><br/>";
        
        echo "<br/><em><strong>Listing: types, publishers and subject headings.</strong></em>";
        echo "<br/>For list of type, <a href='searcherapi.php?listype=1'>searcherapi.php?listype=1</a>";
        echo "<br/>For list of publisher, <a href='searcherapi.php?listpub=1'>searcherapi.php?listpub=1</a>";
        echo "<br/>For list of subject headings, <a href='searcherapi.php?listsub=1'>searcherapi.php?listsub=1</a>";

        echo "<br/><br/><em><strong>Search parameter:</strong></em>";
        echo "<br/>Search paramater: <strong>scstr</strong> (search string), <strong>sctype</strong> (type as integer-ID, refer to json output of searcherapi.php?listype=1) ";
        echo "<ul><li>E.g. <a href='searcherapi.php?scstr=education&sctype=1'>searcherapi.php?scstr=education&sctype=1</a></li>";
        echo "<li>E.g. <a href='searcherapi.php?scstr=education&sctype=2'>searcherapi.php?scstr=education&sctype=2</a></li>";
        echo "<li>E.g. <a href='searcherapi.php?scstr=education&sctype=EveryThing'>searcherapi.php?scstr=education&sctype=EveryThing</a> (<em>EveryThing will search all regardless the types</em>)</li>";
        echo "<li>E.g. <a href='searcherapi.php?sctype=EveryThing'>searcherapi.php?sctype=EveryThing</a> or <a href='searcherapi.php?sctype=1'>searcherapi.php?sctype=1</a> (<em>You may also use empty scstr to search for ALL or any available types.</em>)</li></ul>";

        echo "<br/><em><strong>List item by publisher / subject heading:</strong></em>";
        echo "<ul>";
            echo "<li>List item by publisher: <strong>scpubid</strong> (publisher ID, refer to list of publisher above)";
            echo " E.g. <a href='searcherapi.php?scpubid=1'>searcherapi.php?scpubid=1</a></li>";

            echo "<li>List item by subject heading: <strong>scsub</strong> (subject heading <code>acronym</code>)";
            echo " E.g. <a href='searcherapi.php?scsub=A'>searcherapi.php?scsub=A</a></li>";
        echo "</ul>";
        
        echo "<br/><em><strong>Item detailing:</strong></em>";
        echo "<ul><li>Details parameter (full including references, abstract): <strong>itemid</strong> (item <code>id</code> returned from search parameter) E.g. <a href='searcherapi.php?itemid=10'>searcherapi.php?itemid=10</a></li>";
        echo "<li>Min. Details parameter (minimum excluding references, abstract): <strong>mitemid</strong> (item <code>id</code> returned from search parameter) E.g. <a href='searcherapi.php?mitemid=10'>searcherapi.php?mitemid=10</a></li></ul>";
    }
    
    mysqli_close($GLOBALS["conn"]); exit();
