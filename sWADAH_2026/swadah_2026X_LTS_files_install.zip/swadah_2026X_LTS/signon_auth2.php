<?php
/*
Filename: signon_auth2.php
Usage: single sign on silent authentication module for sWADAH
Qualification: access point page
Version: 1.3.20250201.0000 Alpha
Only for sWADAH 2026 LTS and above
*/

    //user configurable values -----------------------------
    $sys_key = "SDF4DSFAUR45DF";//must be the same with registered in SCENSO
    $handshake_url = "http://localhost:88/signon/dl.php?at=";//http address of dl.php access at SCENSO
    $redirected_page = "sw_admin/index2.php";//where to redirect after completion

    //do not change anything below this line ---------------

    /*
    //older version 2025B
    //get ssn created during first swadah installation on this server
    if (file_exists(stream_resolve_include_path("sw_installed/ssn.txt"))) {
        $ssn = file_get_contents(stream_resolve_include_path("sw_installed/ssn.txt"));
    }
    include_once "config.php";
    if (file_exists(stream_resolve_include_path("userfiles/dev.config.db.php"))) {include_once "userfiles/dev.config.db.php";}
    */

    //new version 2025C
    //get ssn created during first swadah installation on this server
    if (file_exists("sw_installed/ssn.txt")) {
        $ssn = file_get_contents("sw_installed/ssn.txt");
    }
    include_once "config.php";
    if (file_exists("userfiles/dev.config.db.php")) {include_once "userfiles/dev.config.db.php";}

    try {
        $new_conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);$new_conn->set_charset("utf8mb4");
    } catch (mysqli_sql_exception $e) {
        exit("Unable to connect to database. Check your configuration file.");
    }
    
    header("access-control-allow-origin: *");
    session_start();
    session_regenerate_id();

    if (isset($_REQUEST['post_token']) && isset($_REQUEST['post_iden']) && isset($_REQUEST['access_token'])) {
        $decrypted_username = openssl_decrypt($_REQUEST['post_iden'], "AES-128-CTR", $sys_key, 0, "1234567890123456");
        $decrypted_sys_token = openssl_decrypt($_REQUEST['post_token'], "AES-256-CTR", date('Ymd').$sys_key, 0, "1234567891011121");

        //for sysaccess.php only
        if (isset($_REQUEST['u']) && $_REQUEST['u'] == 'getID') {
            //check if a user existed or not
            $stmt_loginask = $new_conn->prepare("select count(id) as existed from eg_auth where username=? and usertype!='FALSE' and usertype!='PATRON'");
            $stmt_loginask->bind_param("s", $decrypted_username);
            $stmt_loginask->execute();$stmt_loginask->store_result();
            $stmt_loginask->bind_result($existed);
            $stmt_loginask->fetch();
            
            header('Content-disposition: inline; filename=output.txt');
            header('Content-type: text/plain');
            echo $existed >= 1 ? "1" : "0";
            exit;
        }
        
        //handshake process start
        if (file_get_contents($handshake_url.$_REQUEST['access_token']) != '1') {
            exit("<head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Error Code: 403a</strong></span><h2>Forbidden: Access prohibited</h2></div></body>");
        }
        //handshake process end
    
        if (isset($_REQUEST['post_iden']) && $decrypted_username == $decrypted_sys_token) {
            $username = $decrypted_username ?: null;
        } else {
            exit("<head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Error Code: 403b</strong></span><h2>Forbidden: Access prohibited</h2></div></body>");
        }
    } else {
        exit("<head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Error Code: 403c</strong></span><h2>Forbidden: Access prohibited</h2></div></body>");
    }

    $stmt_login = $new_conn->prepare("select id, usertype, lastlogin, publisheradmin from eg_auth where username=? and usertype!='FALSE' and usertype!='PATRON'");
    $stmt_login->bind_param("s", $username);
    $stmt_login->execute();$stmt_login->store_result();
    $stmt_login->bind_result($id2, $usertype2, $lastlogin2,$publisheradmin2);
    $stmt_login->fetch();

    if ($stmt_login->num_rows <> 0) {
        $_SESSION[$ssn.'username'] = $username;
        $_SESSION[$ssn.'editmode'] = $usertype2;
        $_SESSION[$ssn.'lastlogin'] = $lastlogin2;
        $_SESSION[$ssn.'publisheradmin'] = $publisheradmin2;
        $_SESSION[$ssn.'needtochangepwd'] = false;
        $_SESSION[$ssn.'validSession'] = session_id();
        $datelog = date("D d/m/Y h:i a");
        
        $stmt_fieldexist_updatets = $new_conn->query("SHOW COLUMNS FROM eg_auth LIKE 'num_attempt'");
        $exists_updatets = mysqli_num_rows($stmt_fieldexist_updatets);
        
        $sql = $exists_updatets == 0
        ? "UPDATE eg_auth SET lastlogin=?, online='ON' WHERE id=?"
        : "UPDATE eg_auth SET lastlogin=?, online='ON', num_attempt=0 WHERE id=?";

        $stmt_update = $new_conn->prepare($sql);
        $stmt_update->bind_param("si", $datelog, $id2);
        $stmt_update->execute();$stmt_update->close();
        $stmt_login->close();
        
        echo "<script>document.location.href='$redirected_page'</script>";
    } else {
        echo "<head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Error Code: 403d</strong></span><h2>Forbidden: Access prohibited</h2></div></body>";
    }

    exit;
