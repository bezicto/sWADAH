<?php
/*
Filename: core.php
Usage: sWADAH core configuration loader
Version: 1.3.20250201.0000
Last change:
20250201.0000 - replace stream_resolve_include_path to base_path solution which is more faster
20250620.0900 - now requires PHP 8.0 or later

Do not change any of this system settings
*/

    //overwrite PHP setting for error_reporting
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ALL);//e.g. (E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT); display all errors except notice and deprecated and strict
    
    //version information
    $system_build = "20250801.0900 (2026X)";
    
    //newer implementation: 2025C - faster retrival of all required files
    define('BASE_PATH', __DIR__);

    //swadah special serial number
    if (file_exists(BASE_PATH . "/sw_installed/ssn.txt")) {
        $ssn = file_get_contents(BASE_PATH . "/sw_installed/ssn.txt");
    }

    //load configuration
    if (file_exists(BASE_PATH . '/config.php')) {
        include_once BASE_PATH . '/config.php';
    } else {
        exit("Missing configuration file.");
    }

    //developer only: overwriting configuration (use with caution) for database connection
    if (file_exists(BASE_PATH . "/userfiles/dev.config.db.php")) {
        include_once BASE_PATH . "/userfiles/dev.config.db.php";
    }

    //for mysqli database connection engine
    try {
        $conn = @mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die("Unable to connect to $dbname at $dbhost.");
        @mysqli_query($conn, "SET CHARACTER SET 'utf8'");
        @mysqli_query($conn, "SET SESSION collation_connection ='utf8_swedish_ci'");
    } catch (mysqli_sql_exception $e) {
        exit("Unable to connect to database. Check your configuration file.");
    }
    //new database connection for in use with prepared statement
    try {
        $new_conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
        $new_conn->set_charset("utf8mb4");
    } catch (mysqli_sql_exception $e) {
        exit("Unable to connect to database. Check your configuration file.");
    }
    $new_conn->set_charset("utf8mb4");

    //load config_user, either load from init.php (faster) or load from database (slower, only for first time installation)
    if (file_exists(BASE_PATH . '/init.php')) {
        include_once BASE_PATH . '/init.php';
    } else {
        $config_table = "config_user";
        ${"query_$config_table"} = "select * from $config_table";
        ${"result_$config_table"} = mysqli_query($GLOBALS["conn"], ${"query_$config_table"});
        while (${"row_$config_table"} = mysqli_fetch_array(${"result_$config_table"})) {
            if (${"row_$config_table"}['cvalue'] == 'true') {
                ${${"row_$config_table"}['cname']} =  true;
            } elseif (${"row_$config_table"}['cvalue'] == 'false') {
                ${${"row_$config_table"}['cname']} = false;
            } else {
                ${${"row_$config_table"}['cname']} = ${"row_$config_table"}['cvalue'];
            }
        }
    }

    //developer only: overwriting configuration (use with caution)
    if (file_exists(BASE_PATH . '/userfiles/dev.config.sys.php')) {
        include_once BASE_PATH . '/userfiles/dev.config.sys.php';
    }

    //load maintenance page if set by the admin
    if ($system_mode == 'maintenance' && basename($_SERVER["SCRIPT_FILENAME"], '.php') != 'in' && !isset($_SESSION[$ssn.'username'])) {
        exit("<html lang='en'><body style='text-align:center;'><h1>$system_title</h1><h2 style='color:red;'>System is currently under maintenance. Will be right back !</h2></body></html>");
    }

    //header policy
    $hd_Strict_Transport_Security = "max-age=31536000";
    $hd_X_Frame_Options = "SAMEORIGIN";
    $hd_Referrer_Policy = "same-origin";
    $hd_Content_Security_Policy = "default-src $system_path $system_ip $ezproxy_appended_domain localhost ajax.googleapis.com 'unsafe-inline' 'unsafe-eval' img-src * data:; frame-ancestors default-src $system_path $system_ip $ezproxy_appended_domain localhost ajax.googleapis.com 'unsafe-inline' 'unsafe-eval' img-src * data:;";
    $hd_X_Content_Type_Options = "nosniff";
    $hd_Permissions_Policy = "accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()";
    
    putenv("TZ=$date_default_timezone_set");
    date_default_timezone_set("$date_default_timezone_set");
