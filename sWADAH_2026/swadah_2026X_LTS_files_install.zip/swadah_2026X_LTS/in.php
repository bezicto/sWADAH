<?php
/*
Filename: in.php
Usage: Login page for admins and registered users
Qualification: access point page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Login Page";
    session_start();define('includeExist', true);
    
    include_once 'core.php';
    include_once 'sw_inc/functions.php';
    
    //clear search sessions
    unset($_SESSION[$ssn.'sear_scstr']);
    unset($_SESSION[$ssn.'sear_ft']);
    unset($_SESSION[$ssn.'sear_scstr_form']);
    unset($_SESSION[$ssn.'sear_sctype']);
    unset($_SESSION[$ssn.'sear_sclang']);
    unset($_SESSION[$ssn.'sear_page']);
    unset($_SESSION[$ssn.'whichbrowser']);
    $_SESSION[$ssn.'sear_period'] = 0;

    //unset previous_url session set on various non admin pages
    unset($_SESSION[$ssn.'previous_url']);

    //if user click on any of provided login link whether for admin or normal user
    if (isset($_GET['t']) && $_GET['t'] == 'ma') {
        $_SESSION[$ssn.'t'] = "User";
    } elseif (isset($_GET['t']) && $_GET['t'] == 'sa') {
        include_once 'sw_inc/access_allowed_adminip.php';
        $_SESSION[$ssn.'t'] = "Admin";
    }

    //if user access directly via 'in'
    if (!isset($_SESSION[$ssn.'t'])) {
        include_once 'sw_inc/access_allowed_adminip.php';
        $_SESSION[$ssn.'t'] = "Admin";
    }

    //redirect if user is my account user and not allowed to login
    if ($_SESSION[$ssn.'t'] == 'User' && !$allow_user_to_login) {
        unset($_SESSION[$ssn.'t']);
        header("Location: index.php");
        die();
    }

    //redirect is user already logged in
    if (isset($_SESSION[$ssn.'username'])) {
        unset($_SESSION[$ssn.'t']);
        header("Location: sw_admin/index2.php");
        die();
    } elseif (isset($_SESSION[$ssn.'username_guest'])) {
        unset($_SESSION[$ssn.'t']);
        header("Location: dashboard.php");
        die();
    }

    //unset all loginless session token variable
    if (isset($_SESSION[$ssn.'lls']) && isset($_SESSION[$ssn.'lls_token'])) {
        unset($_SESSION[$ssn.'lls']);
        unset($_SESSION[$ssn.'lls_token']);
        unset($_SESSION[$ssn.'lls_id']);
        unset($_SESSION[$ssn.'lls_tokenlimit']);
        unset($_SESSION[$ssn.'lls_tokenowner']);
        unset($_SESSION[$ssn.'disableSearch']);
    }

    $datelog = date("D d/m/Y h:i a");

    include_once 'sw_inc/token_validate.php';
?>

<html lang='en'>

<head>
    <?php include_once 'sw_inc/header.php'; ?>
</head>

<body class='<?= $color_scheme;?>' <?php if ($show_main_body_background_image) {?>style='background-image:url("<?= $main_body_background_image;?>");' <?php }?>>

    <?php
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE' && $proceedAfterToken) {
                $stmt_login = $new_conn->prepare("
                                select id, username, aes_decrypt(syspassword,'$aes_key') as syspassword, usertype, publisheradmin, lastlogin, online, num_attempt
                                from eg_auth where username=?");
                $stmt_login->bind_param("s", $_POST['username']);
                $stmt_login->execute();$stmt_login->store_result();
                $num_results_affected_login = $stmt_login->num_rows;
                $stmt_login->bind_result($id2, $username2, $password2, $usertype2, $publisheradmin2, $date2, $online2, $num_attempt2);
                $stmt_login->fetch();$stmt_login->close();
                
                $login_label = "<div style='text-align:center;font-size:12px;'><strong>Status:</strong> ";
                
                if ($_SESSION[$ssn.'t'] == 'Admin') {
                    if ($num_results_affected_login <> 0) {
                        $allowed3 = ($usertype2 == 'STAFF' || $usertype2 == 'SUPER' || $usertype2 == 'LINKP') ? 'STAFF' : 'FALSE';
                        
                        if ($_POST['username'] == $username2 && $_POST['password'] == $password2 && $allowed3 == 'STAFF' && $num_attempt2 < 5) {
                            if ($online2 == 'OFF' || $usertype2 == 'SUPER') {
                                $login_label .= "<label style='color:blue;'>Authentication complete. You will be directed in no time.</label>";
                                
                                $_SESSION[$ssn.'username'] = $_POST['username'];
                                $_SESSION[$ssn.'editmode'] = $usertype2;
                                $_SESSION[$ssn.'lastlogin'] = $date2;
                                $_SESSION[$ssn.'publisheradmin'] = $publisheradmin2;

                                session_regenerate_id();
                                $_SESSION[$ssn.'validSession'] = session_id();

                                $_SESSION[$ssn.'needtochangepwd'] = ($password2 == $default_create_password || $password2 == $default_password_if_forgotten);
                                
                                //for admin, default password is also a no go
                                if ($_SESSION[$ssn.'username'] == 'admin' && $password2 == 'pustaka') {
                                    $_SESSION[$ssn.'needtochangepwd'] = true;
                                }

                                $stmt_update = $new_conn->prepare("update eg_auth set lastlogin=?, online='ON', num_attempt=0 where id=?");
                                $stmt_update->bind_param("si", $datelog, $id2);
                                $stmt_update->execute();$stmt_update->close();
                                
                                unset($_SESSION[$ssn.'t']);
                                echo "<script>document.location.href='sw_admin/index2.php'</script>";exit;
                            } else {
                                $login_label .= "<label style='color:red;'>Improper log-out session detected. Contact your administrator.</label>";
                            }
                        } elseif ($_POST['username'] == $username2 && $_POST['password'] == $password2 && $allowed3 == 'FALSE') {
                            $login_label .= "<label style='color:red;'>Inactive or invalid account detected! You're not permitted to enter the system.</label>";
                        } else {
                            if ($num_attempt2 == 5) {
                                $login_label .= "<label style='color:red;'>Your account has been blocked. Contact us for more info.</label>";
                            } else {
                                $login_label .= "<label style='color:red;'>Incorrect authentication information detected !</label>";
                                $num_attempt2 = $num_attempt2+1;

                                //record all invalid access attempt
                                $stmt_update = $new_conn->prepare("update eg_auth set num_attempt=? where id=?");
                                $stmt_update->bind_param("ii", $num_attempt2, $id2);
                                $stmt_update->execute();$stmt_update->close();
                            }
                        }
                    } else {
                        $login_label .= "<label style='color:red;'>Cannot find username !</label>";
                    }
                } elseif ($_SESSION[$ssn.'t'] == 'User') {
                    if ($num_results_affected_login <> 0) {
                        if (sfx_stringRemoveScriptTag($_POST['username'],false) == $username2 && $_POST['password'] == $password2) {
                            $login_label .= "<label style='color:blue;'>Authentication complete. You will be directed in no time.</label>";
                            $_SESSION[$ssn.'username_guest'] = sfx_stringRemoveScriptTag($_POST['username'],false);
                            $_SESSION[$ssn.'lastlogin'] = $date2;
        
                            $stmt_update = $new_conn->prepare("update eg_auth set lastlogin=?, online='ON' where id=?");
                            $stmt_update->bind_param("si", $datelog, $id2);
                            $stmt_update->execute();$stmt_update->close();

                            unset($_SESSION[$ssn.'t']);
                            echo "<script>document.location.href='dashboard.php'</script>";exit;
                        } else {
                            $login_label .= "<label style='color:red;'>Incorrect authentication information detected !</label>";
                        }
                    } else {
                        $login_label .= "<label style='color:red;'>Cannot find username !</label>";
                    }
                }
            $login_label .= "</div><br/>";
        }
    ?>

    <table style="padding-top:30px;" class=transparentCenter100percent>
    <tr>
        <td>
        <div id="adminlogin">
            <img alt='Main Logo' style='min-width:350px;max-width:550px;margin-bottom:30px;' width=<?= $main_logo_width;?> src="<?= $main_logo;?>"><br/><br/>
            <form action="in.php" method="post">
                <br/><strong><?= $_SESSION[$ssn.'t'];?> Name: </strong><br/><input autocomplete="off" class="roundInputTextMin" type="text" name="username" size="25" maxlength="25" required autofocus/>
                <br/><br/><strong>Password: </strong><br/><input autocomplete="off" class="roundInputTextMin" type="password" name="password" size="25" maxlength="25" required/>
                
                <input type="hidden" name="submitted" value="TRUE" />
                <input type="hidden" name="token" value="<?= $_SESSION[$ssn.'token'] ?? '' ?>">

                <?php
                if ($show_admin_login_link && (isset($_GET['t']) && $_GET['t'] != 'sa')) {
                    echo "<br/><br/><br/><i class=\"fas fa-sign-in-alt\"></i> <a href='in.php?t=sa'>Login as admin</a>";
                }
                ?>

                <br/><br/><br/>
                <button type="submit" class="googleButtonGreen" name="submit_button" value="Login">Login</button> <button type="button" class="googleButtonGrey" name="Cancel" value="Login" onclick="window.location='index.php'";>Go to Search</button>
            </form>
        </div>
        </td>
    </tr>
    </table>

    <?php echo $login_label ?? '';?>
    
    <br/><br/>
    
    <?php include_once 'sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
