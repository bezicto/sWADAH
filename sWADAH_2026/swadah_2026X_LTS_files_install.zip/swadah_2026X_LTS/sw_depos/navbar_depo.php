<?php
/*
Filename: sw_depos/navbar_depo.php
Usage: Navigation bar for self submission users
Version: 20250101.0000
Last change: -
*/

defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");

if (isset($_SESSION[$ssn.'useridentity'])) {
  $query_countuseridentity = "select count(id) as totaluserdeposit from eg_item_depo where inputby='".$_SESSION[$ssn.'useridentity']."'";
  $result_countuseridentity = mysqli_query($GLOBALS["conn"], $query_countuseridentity);
  $myrow_countuseridentity= mysqli_fetch_array($result_countuseridentity);
  $totaluserdeposit = $myrow_countuseridentity["totaluserdeposit"];

  $query_totalpost = "select totalpost from eg_auth_depo where useridentity='".$_SESSION[$ssn.'useridentity']."'";
  $result_totalpost = mysqli_query($GLOBALS["conn"], $query_totalpost);
  $myrow_totalpost= mysqli_fetch_array($result_totalpost);
  $totalpost= $myrow_totalpost["totalpost"];
?>
  <script type="text/javascript">
      function js_myShowMenuItem() {
          var x = document.getElementById("myTopnav");
          if (x.className === "topnav") {
              x.className += " responsive";
          } else {
              x.className = "topnav";
          }
      }
  </script>
  <div class="topnav <?php echo $color_scheme;?>topnav" id="myTopnav">
    <a href="depositor.php" class="active"><img alt='Menu Icon' src='../<?php echo $menu_icon;?>' width=20></a>
    <a href="depositor.php"><span class="fa fa-home"></span> Start</a>
    <?php if ($totaluserdeposit < $totalpost) {?><a href="deporeg.php"><span class="fa fa-plus"></span> Insert Deposit</a><?php }?>
    <a href="depopchange.php?upd=g"><span class="fa fa-key"></span> Change Password</a>
    <a href="depologin.php?log=out" onclick="return confirm('Are you sure?')"><span class="fa fa-user"></span> Logout</a>
    <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="js_myShowMenuItem()">&#9776;</a>
  </div>
  <?php
}
