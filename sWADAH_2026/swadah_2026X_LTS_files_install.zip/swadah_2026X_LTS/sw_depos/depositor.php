<?php
/*
Filename: sw_depos/depositor.php
Usage: Main page after login for all self submission users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Depositor Account";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset_depo.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>'>

    <?php include_once 'navbar_depo.php';?>

    <hr>

    <?php
        $query_Name = "select fullname,emailaddress,phonenum,totalpost from eg_auth_depo where useridentity='".$_SESSION[$ssn.'useridentity']."'";
        $result_Name = mysqli_query($GLOBALS["conn"], $query_Name);
        $myrow_Name = mysqli_fetch_array($result_Name);

        echo "<table style='width:100%;'>";
            echo "<tr style='text-align:left;vertical-align:top;'>";
                echo "<td class='$color_scheme"."Back'>
                Welcome back, <strong>".$myrow_Name["fullname"]."</strong>
                <br/><span style='color:green;'>Contact Methods: ".$myrow_Name["emailaddress"]." / ".$myrow_Name["phonenum"]."
                <br/>Upload Quotas: ".$myrow_Name["totalpost"]."</span>
                </td>";
            echo "</tr>";
        echo "</table>";
    ?>

    <?php

        if (isset($_GET['del']) && is_numeric($_GET['del'])) {
            $stmt_del = $new_conn->prepare("select id,year,timestamp from eg_item_depo where id=? and inputby='".$_SESSION[$ssn.'useridentity']."' and itemstatus not like 'A%'");
            $stmt_del->bind_param("i", $_GET['del']);
            $stmt_del->execute();
            $result_del = $stmt_del->get_result();
            $myrow_del= $result_del->fetch_assoc();
            mysqli_query($GLOBALS["conn"], "delete from eg_item_depo where id='".$myrow_del["id"]."' and inputby='".$_SESSION[$ssn.'useridentity']."' and itemstatus not like 'A%'");

            if (file_exists("../$system_dfile_directory/".$myrow_del["year"]."/".$myrow_del["id"].""."_".$myrow_del["timestamp"].".pdf")) {
                unlink("../$system_dfile_directory/".$myrow_del["year"]."/".$myrow_del["id"].""."_".$myrow_del["timestamp"].".pdf");
            }
            if (file_exists("../$system_pfile_directory/".$myrow_del["year"]."/".$myrow_del["id"].""."_".$myrow_del["timestamp"].".pdf")) {
                unlink("../$system_pfile_directory/".$myrow_del["year"]."/".$myrow_del["id"].""."_".$myrow_del["timestamp"].".pdf");
            }

            echo "<script>location.replace('depositor.php');</script>";
        }

    ?>

    <?php
        $query_fdb = "select SQL_CALC_FOUND_ROWS * from eg_item_depo where inputby='".$_SESSION[$ssn.'useridentity']."' order by id";
        $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);

        echo "<table class=whiteHeaderNoCenter>";
            echo "<tr style='text-align:center;vertical-align:top;background-color:lightgrey;'>";
                echo "<td colspan=2>Author</td>";
                echo "<td>Publisher</td>";
                if ($allow_declaration_submission) {
                    echo "<td width=15%>Submission Declaration</td>";
                }
                echo "<td width=15%>Full Text</td>";
                echo "<td>Current Status</td>";
                echo "<td>Options</td>";
            echo "</tr>";
                                                                        
            $n = 1;
            while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                $id = $myrow_fdb["id"];
                $authorname = stripslashes($myrow_fdb["29authorname"]);
                $publisher = stripslashes($myrow_fdb["29publication_b"]);
                $titlestatement = stripslashes($myrow_fdb["29titlestatement"]);
                $dissertation_note_b = $myrow_fdb["29dissertation_note_b"];
                $lastupdated = date('d M Y H:i:s', $myrow_fdb["29lastupdated"]);
                $year = $myrow_fdb["year"];
                $timestamp = $myrow_fdb["timestamp"];
                $itemstatus = $myrow_fdb["itemstatus"];

                if ($myrow_fdb['29dfile'] == 'YES' && file_exists("../$system_dfile_directory/$year/$id"."_".$timestamp.".pdf")) {
                    $dfilelink = "<a target='blank' href='depodoc.php?t=d&docid=$id'>Click</a>";
                } else {
                    $dfilelink = "N/A";
                }

                if ($myrow_fdb['29pfile'] == 'YES' && file_exists("../$system_pfile_directory/$year/$id"."_".$timestamp.".pdf")) {
                    $pfilelink = "<a target='blank' href='depodoc.php?t=p&docid=$id'>Click</a>";
                } else {
                    $pfilelink = "N/A";
                }
                    
                echo "<tr class=$color_scheme"."Hover style='text-align:center;'>";
                    echo "<td style='vertical-align:top;'>$n</td>";

                    echo "<td style='text-align:left;vertical-align:top;'>$titlestatement<br/><font color=green>$dissertation_note_b</font><br/><font size=1>Last updated: <em>$lastupdated</em></font></td>";

                    $paramsOrAnd = [
                        'fieldtoget' => '43publisher',
                        'tablename' => 'eg_publisher',
                        'wherefield1' => '43acronym',
                        'wherefield2' => '43pubid',
                        'wherevalue1' => $publisher,
                        'wherevalue2' => $publisher,
                        'wherevaluetype' => 'si',
                        'operator' => 'OR'
                    ];
                    echo "<td style='text-align:center;'>".sfx_sGetValueOrAnd($paramsOrAnd)."</td>";

                    if ($itemstatus == 'ACCEPTED') {
                        if ($allow_declaration_submission) {
                            echo "<td>$dfilelink</td>";
                        }

                        echo "<td>$pfilelink</td>";
                    } elseif ($itemstatus == 'ARCHIVEDP' || $itemstatus == 'ARCHIVEDPM') {
                        echo "<td><em>Declaration archived</em></td>";
                        echo "<td><em>Full text archived</em></td>";
                    } else {
                        echo "<td>$dfilelink</td>";
                        echo "<td>$pfilelink</td>";
                    }

                    echo "<td>";
                        echo sfx_getDepoStatus($itemstatus);
                        if (substr($itemstatus, 0, 1) == 'A') {
                            echo "<br><a href='depoacceptance.php?id=$id' target='_blank'>View/print acceptance letter</a>";
                        }
                    echo "</td>";
                            
                    echo "<td>";
                        if (substr($itemstatus, 0, 1) != 'A' && substr($itemstatus, 0, 1) != 'G' ) {
                            echo "<a href='deporeg.php?upd=$id'>Edit</a> | <a href='depositor.php?del=$id' onclick=\"return confirm('Are you sure want to delete this entry?')\">Delete</a>";
                        } else {
                            echo "<i style='color:green;' class=\"fas fa-check-circle fa-2xl\"></i>";
                        }
                    echo "</td>";
                echo "</tr>";
                $n=$n+1;
            }
        echo "</table>";
    ?>
    
    <hr>
            
    <?php include_once '../sw_inc/footer.php';?>
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
