<?php
/*
Filename: sw_depos/depodet.php
Usage: Detail page for all submitted submission. Admin may set approval or rejection here
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Manage User Deposit";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/functions.php';
    
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    include_once '../sw_inc/token_validate.php';

    $detid = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id'])) ? $_REQUEST['id'] : 0;
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<?php

    if (isset($_REQUEST['s']) && $_REQUEST['s'] == 'Set' && isset($_REQUEST['id']) && is_numeric($_REQUEST['id']) && $proceedAfterToken) {
        $queryInfo = "select fullname,emailaddress from eg_auth_depo where useridentity='".$_REQUEST['authorid']."'";
        $resultInfo = mysqli_query($GLOBALS["conn"], $queryInfo);
        $myrowInfo = mysqli_fetch_array($resultInfo);

        $queryInfoDepo = "select 29titlestatement from eg_item_depo where id=".$_REQUEST['id'];
        $resultInfoDepo = mysqli_query($GLOBALS["conn"], $queryInfoDepo);
        $myrowInfoDepo = mysqli_fetch_array($resultInfoDepo);
        
        $cstatus = sfx_getDepoStatus($_REQUEST['itemstatus']);
        $grade_assigned = $_REQUEST['grade'];
        
        mysqli_query($GLOBALS["conn"], "update eg_item_depo set itemstatus='".$_REQUEST['itemstatus']."', grade='".$_REQUEST['grade']."' where id=".$_REQUEST['id']);
        
        if (isset($myrowInfo["fullname"]) && $useEmailNotification) {
            $mel_subject = "Current status for : ".$myrowInfoDepo['29titlestatement'];
            $mel_body = "Hi, ".$myrowInfo["fullname"]."<br/><br/>Item: <strong><em>".$myrowInfoDepo['29titlestatement']."</em></strong> current status is : <strong>$cstatus</strong>. <br/><br/>Remarks by admin: ".$_REQUEST['remarks'];
                if ($_REQUEST['itemstatus'] == "ACCEPTED") {
                    $mel_body .= "<br/><br/>Please login into your account to view/print acceptance letter. [<a href='$system_path"."sw_depos/depologin.php'>Click here to login</a>]";
                }
                $mel_body .= "<br/><br/>$emailFooter";
            $mel_address = $myrowInfo["emailaddress"];
            $mel_failed = "";
            $mel_success = "";
            sfx_sendEmail("..", $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed);
        }

        if (isset($_REQUEST['remarks']) || isset($_REQUEST['grade'])) {
            mysqli_query($GLOBALS["conn"], "insert into eg_item_depo_remarks values(DEFAULT,".$_REQUEST['id'].",'Set status to: <em>$cstatus ($grade_assigned)</em>. Remarks:".sfx_stringRemoveScriptTag($_REQUEST['remarks'])."','".time()."')");
        }

        sfx_echoPopupAlert("Status has been updated.");
    }

    $pub_to_search = ($_SESSION[$ssn.'publisheradmin'] != 'ALL') ? " and 29publication_b='" . $_SESSION[$ssn.'publisheradmin'] . "'" : "";


    $stmt_depodet = $new_conn->prepare("select * from eg_item_depo where id=? $pub_to_search");
    $stmt_depodet->bind_param("i", $detid);
    $stmt_depodet->execute();
    $result_depodet = $stmt_depodet->get_result();
    $num_results_affected = $result_depodet->num_rows;
    $myrow_depodet = $result_depodet->fetch_assoc();

    if ($num_results_affected >= 1) {
        $id = $myrow_depodet["id"];
        $eg_item_id = $myrow_depodet["eg_item_id"];
        $authorname = $myrow_depodet["29authorname"];
        $titlestatement = $myrow_depodet["29titlestatement"];
        $dissertation_note_b = $myrow_depodet["29dissertation_note_b"];
        $publication_b = $myrow_depodet["29publication_b"];
            $publication_b_text = sfx_sGetValue("43publisher", "eg_publisher", "43acronym", $myrow_depodet["29publication_b"]);
        $pname1 = $myrow_depodet["29pname1"];
        $pname2 = $myrow_depodet["29pname2"];
        $pname3 = $myrow_depodet["29pname3"];
        $pname4 = $myrow_depodet["29pname4"];
        $pname5 = $myrow_depodet["29pname5"];
        $pname6 = $myrow_depodet["29pname6"];
        $pname7 = $myrow_depodet["29pname7"];
        $pname8 = $myrow_depodet["29pname8"];
        $pname9 = $myrow_depodet["29pname9"];
        $pname10 = $myrow_depodet["29pname10"];
        $abstract = $myrow_depodet["29abstract"];
        $accesscategory = $myrow_depodet["29accesscategory"];
        $year = $myrow_depodet["year"];
        $timestamp = $myrow_depodet["timestamp"];
        $lastupdated = $myrow_depodet["29lastupdated"];
        $itemstatus = $myrow_depodet["itemstatus"];
        $inputby = $myrow_depodet["inputby"];
        $grade = $myrow_depodet["grade"];
        $inputbyName = sfx_sGetValue("fullname", "eg_auth_depo", "useridentity", $myrow_depodet["inputby"]);
        $contactdetails = sfx_getEmailPhoneFromUserIdentity($myrow_depodet["inputby"]);

        if ($myrow_depodet['29dfile'] == 'YES' && file_exists("../$system_dfile_directory/$year/$id"."_".$timestamp.".pdf")) {
            $dfilelink = "<a target='blank' href='../$system_dfile_directory/$year/$id"."_".$timestamp.".pdf'>$system_dfile_directory/$year/$id"."_".$timestamp.".pdf</a>";
        } else {
            $dfilelink = "N/A";
        }

        if ($myrow_depodet['29pfile'] == 'YES' && file_exists("../$system_pfile_directory/$year/$id"."_".$timestamp.".pdf")) {
            $pfilelink = "<a target='blank' href='../$system_pfile_directory/$year/$id"."_".$timestamp.".pdf'>$system_pfile_directory/$year/$id"."_".$timestamp.".pdf</a>";
        } else {
            $pfilelink = "N/A";
        }
    }
    
    //transferring to reg.php for further updating
    if (isset($_REQUEST['s']) && $_REQUEST['s'] == 'Set' && isset($_REQUEST['id']) && is_numeric($_REQUEST['id']) && $proceedAfterToken && $system_function == 'full' && $_REQUEST['itemstatus'] == 'ARCHIVEDPM') {
            $instimestamp = time();
            $accessionnum = sfx_millitime();

            mysqli_query(
               $GLOBALS["conn"], "insert into eg_item values (
               DEFAULT,
               '0',
               '$accessionnum',
               '',
               'FINALPROCESSING',
               '','','zms','','$inputbyName','$titlestatement','','','','',
               '','','','','','".date("Y-m-d")."','".$_SESSION[$ssn.'username']."','FALSE','','',
               '',DEFAULT,'$instimestamp',
               0,0,
               '','','','',0,
               '$inputbyName $titlestatement',
               1,0,'0',0
               )"
            );

            $queryN = "select id from eg_item where 41instimestamp='$instimestamp' and 39inputby='".$_SESSION[$ssn.'username']."'";
            $resultN = mysqli_query($GLOBALS["conn"], $queryN);
            $myrowN = mysqli_fetch_array($resultN);
            $idN = $myrowN["id"];

            //if moved to repository then update eg_item_id in eg_item_depo
            mysqli_query($GLOBALS["conn"], "update eg_item_depo set eg_item_id=$idN where id=".$_REQUEST['id']);

            mysqli_query($GLOBALS["conn"], "insert into eg_item2 values(
            DEFAULT,
            $idN,DEFAULT,
            '','','','','','','','','','','$publication_b_text',
            '','','','','','$dissertation_note_b',
            '','','','','','','','','','',
            '','','','','','','','','','',
            '','','','','','','','','','',
            '','','','','','',''
            )"
            );
            
            mysqli_query($GLOBALS["conn"], "insert into eg_item2_indicator values(
            DEFAULT,$idN,
            '','','','','','','','','','',
            '','','','','','','','','','',
            '','','','','','','','','','',
            '','','','',''
            )"
            );

            if ($pfilelink != 'N/A') {
                if (!is_dir("../$system_docs_directory/".date("Y"))) {
                    mkdir("../$system_docs_directory/".date("Y"), 0777, true);
                }
                //move to mainline upload directory that serves all digital items
                copy("../$system_pfile_directory/$year/$id"."_".$timestamp.".pdf", "../$system_docs_directory/".date("Y")."/$idN"."_".$instimestamp.".pdf");
            }
            echo "<script>window.location.replace('../sw_admin/details.php?det=$idN');</script>";
    }
?>

<body class='<?php echo $color_scheme;?>'>
    <?php include_once '../sw_inc/navbar.php';?>

    <hr>
    <div style="width:100%;text-align:center;">
    <?php
        if ($num_results_affected >= 1) {
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=$color_scheme"."HeaderCenter>";
                    echo "<td colspan=2>Details</td>";
                echo "</tr>";
                            
                echo "<tr><td width=200 bgcolor=lightgrey>Submission</td><td style='text-align:left;vertical-align:top;'><font color=blue>$inputbyName ($inputby)</font> <em>$contactdetails</em><br/>$titlestatement</td></tr>";
                
                $paramsOrAnd = [
                    'fieldtoget' => '43publisher',
                    'tablename' => 'eg_publisher',
                    'wherefield1' => '43acronym',
                    'wherefield2' => '43pubid',
                    'wherevalue1' => $publication_b,
                    'wherevalue2' => $publication_b,
                    'wherevaluetype' => 'si',
                    'operator' => 'OR'
                ];
                echo "<tr><td bgcolor=lightgrey>Publisher and $tag_502</td><td style='text-align:left;vertical-align:top;'>".sfx_sGetValueOrAnd($paramsOrAnd)."<br/><font color=green>$dissertation_note_b</font></td></tr>";
                
                if ($allow_declaration_submission) {
                    echo "<tr><td bgcolor=lightgrey>Submission Declaration Form</td><td style='text-align:left;vertical-align:top;'>$dfilelink</td></tr>";
                }
                
                echo "<tr><td bgcolor=lightgrey>Full Text</td><td style='text-align:left;vertical-align:top;'>$pfilelink</td></tr>";
                
                if (!$hide_additional_authors_entry) {
                    echo "<tr><td bgcolor=lightgrey>$tag_700</td><td style='text-align:left;vertical-align:top;'>";
                        if ($pname1 != '') {echo "$pname1";}
                        if ($pname2 != '') {echo ", $pname2";}
                        if ($pname3 != '') {echo ", $pname3";}
                        if ($pname4 != '') {echo ", $pname4";}
                        if ($pname5 != '') {echo ", $pname5";}
                        if ($pname6 != '') {echo ", $pname6";}
                        if ($pname7 != '') {echo ", $pname7";}
                        if ($pname8 != '') {echo ", $pname8";}
                        if ($pname9 != '') {echo ", $pname9";}
                        if ($pname10 != '') {echo ", $pname10";}
                }
                echo "</td></tr>";

                echo "<tr><td bgcolor=lightgrey>Abstract</td><td style='text-align:left;vertical-align:top;'>$abstract</td></tr>";
                
                echo "<tr><td bgcolor=lightgrey>$tag_506</td><td style='text-align:left;vertical-align:top;'>$accesscategory</td></tr>";
                
                echo "<tr><td bgcolor=lightgrey>Inserted On</td><td style='text-align:left;vertical-align:top;'>".date('Y-m-d H:i:s', $timestamp)."</td></tr>";
                
                echo "<tr><td bgcolor=lightgrey>Last Updated</td><td style='text-align:left;vertical-align:top;'>".date('Y-m-d H:i:s', $lastupdated)."</td></tr>";
                
                echo "<tr><td bgcolor=lightgrey>Current Status</td>";
                    echo "<td style='text-align:left;vertical-align:top;'>";
                    
                        $entry = ''; $accepted = ''; $archivedp = ''; $archivedl = ''; $r_incomplete = ''; $r_duplicate = ''; $r_contact = '';
                        if ($itemstatus == "ENTRY") {
                            $entry = "selected";
                        } elseif ($itemstatus == "ACCEPTED") {
                            $accepted = "selected";
                        } elseif ($itemstatus == "GRADED") {
                            $graded = "selected";
                        } elseif ($itemstatus == "ARCHIVEDP") {
                            $archivedp = "selected";
                        } elseif ($itemstatus == "ARCHIVEDPM") {
                            $archivedp = "selected";
                        } elseif ($itemstatus == "ARCHIVEDL") {
                            $archivedl =  "selected";
                        } elseif ($itemstatus == "ARCHIVEEX") {
                            $archiveex =  "selected";
                        } elseif ($itemstatus == "R_INCOMPLETE") {
                            $r_incomplete = "selected";
                        } elseif ($itemstatus == "R_DUPLICATE") {
                            $r_duplicate = "selected";
                        } elseif ($itemstatus == "R_CONTACT") {
                            $r_contact = "selected";
                        }

                        echo "<form name='itemstatusform' action='depodet.php' method='post'>";
                        echo "<input type='hidden' name='token' value='".$_SESSION[$ssn.'token']."'>";
                        echo "<input type='hidden' name='id' value='$id'>";
                        echo "<span style='color:blue;'>Email remarks:</span><br/><input type='text' style='width:80%;' name='remarks'><br/><br/>";
                        echo "<span style='color:blue;'>Status:</span><br/><select name='itemstatus'>";
                            echo "<option $entry value='ENTRY'>Pending Approval</option>";
                            echo "<option $accepted value='ACCEPTED'>Accepted</option>";
                            echo "<option $graded value='GRADED'>Graded</option>";
                            echo ($system_function == 'full') ? "<option $archivedp value='ARCHIVEDPM'>Move to Repository</option>" : "<option $archivedp value='ARCHIVEDP'>Live in Repository</option>";
                            echo "<option $archivedl value='ARCHIVEDL'>Archived for Limited Access</option>";
                            echo "<option $archiveex value='ARCHIVEEX'>Archived Externally</option>";
                            echo "<option $r_incomplete value='R_INCOMPLETE'>Rejected: Incomplete</option>";
                            echo "<option $r_duplicate value='R_DUPLICATE'>Rejected: Duplicate Entry</option>";
                            echo "<option $r_contact value='R_CONTACT'>Rejected: Contact Admin</option>";
                        echo "</select>";
                        echo "<br/><br/><span style='color:blue;'>Grade (if applicable):</span><br/>";
                        echo "<select name='grade'>";
                            echo "<option value='-'>-</option>";
                            $selectable_grades = explode(",", $depo_grades);
                            for ($x = 0; $x < sizeof($selectable_grades); $x++) {
                                echo "<option value='".$selectable_grades[$x]."' ";
                                if ($grade == $selectable_grades[$x]) {echo "selected";}
                                echo ">".$selectable_grades[$x]."</option>";
                            }
                        echo "</select>";
                        echo " <input type='hidden' name='authorid' value='$inputby'>";
                        echo " <br/><br/><input type='submit' name='s' value='Set'/>";
                        echo "</form>";

                    echo "</td>";
                echo "</tr>";
                
                if ($eg_item_id != '0') {
                    echo "<tr><td bgcolor=lightgrey>Item Available in Repository:</td><td style='text-align:left;vertical-align:top;'>[<a href='../sw_admin/details.php?det=$eg_item_id'>Click to view item</a>]</td></tr>";
                }

            echo "</table>";

            echo "<br/><table class=whiteHeaderNoCenter>";
                $query_log = "select * from eg_item_depo_remarks where eg_item_depo_id=$id order by id desc";
                $result_log = mysqli_query($GLOBALS["conn"], $query_log);
                
                echo "<tr style='background-color:lightgrey;'>";
                    echo "<td width=30%>Date recorded (# days since submission)</td>";
                    echo "<td width=70%>Email Remarks</td>";
                echo "</tr>";

                while ($myrow_log = mysqli_fetch_array($result_log)) {
                    $remarks = $myrow_log["39remarks"];
                    $timestamp_log = $myrow_log["timestamp"];
                    $datediff = round(($timestamp_log - $timestamp) / (60*60*24));
                    echo "<tr style='text-align:center;'>";
                        echo "<td>".date('Y-m-d H:i:s', $timestamp_log)." ($datediff days)</td>";
                        echo "<td>$remarks</td>";
                    echo "</tr>";
                }
            echo "</table>";

        } else {
            echo "<br/>Item is not available.<br/>";
        }
    ?>
    
    <br/>
    </div>

    <div style="width:100%;text-align:center;">
        <a class='sButton' href='depoadmin.php'><span class='fas fa-arrow-circle-left'></span> Back to Manage User Deposit</a>
    </div>

    <hr>
    <?php include_once '../sw_inc/footer.php';?>
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
