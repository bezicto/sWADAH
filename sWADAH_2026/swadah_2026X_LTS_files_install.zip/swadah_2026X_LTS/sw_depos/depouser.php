<?php
/*
Filename: sw_depos/depouser.php
Usage: Manage and administer all self deposit users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Deposit User List";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>

    <script type="text/javascript">
        window.onclick = function(event) {
            if (event.target.matches('.dropbtn2')) {
                var dropdowns = document.getElementsByClassName('dropbtn2');
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show') && !event.target.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                        }
                }
                event.target.classList.toggle("show");
            }
        }
    </script>

    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <table class=whiteHeaderNoCenter style='width:100%;'>
    <tr style='text-align:center;'>
        <td>
            <form  action="depouser.php" method="get" enctype="multipart/form-data" style="margin:auto;max-width:100%">
                Search:
                <br/><input type="text" placeholder="Enter ID or Email Address or Part of Name" name="scstr" style='width:50%;font-size:14px' maxlength="255" value="<?php if (isset($_GET['scstr'])) {echo sfx_stringRemoveScriptTag($_GET['scstr']);}?>"/>
                <input type="submit" class="form-submit-button" name="s" value="Search" />
            </form>
        </td>
    </tr>
    </table>

    <br/>
    
    <?php
            // if reset password
            if (isset($_GET["rep"]) && $_GET["rep"] <> null && is_numeric($_GET["rep"])) {
                $get_id_rep = $_GET["rep"];
                $stmt_update = $new_conn->prepare("update eg_auth_depo set userpass=AES_ENCRYPT('$default_password_if_forgotten','$aes_key') where id=?");
                $stmt_update->bind_param("i", $get_id_rep);
                $stmt_update->execute();$stmt_update->close();
            }

            // if reject and delete
            if (isset($_GET["del"]) && $_GET["del"] <> null && is_numeric($_GET["del"])) {
                $get_id_del = $_GET["del"];
                $stmt_fdba = $new_conn->prepare("select emailaddress from eg_auth_depo where id=?");
                $stmt_fdba->bind_param("i", $get_id_del);
                $stmt_fdba->execute();
                $result_fdba = $stmt_fdba->get_result();
                $myrow_fdba = $result_fdba->fetch_assoc();
                $stmt_del = $new_conn->prepare("delete from eg_auth_depo where id=?");
                $stmt_del->bind_param("i", $get_id_del);
                $stmt_del->execute();$stmt_del->close();

                if ($useEmailNotification) {
                    $mel_subject = "$system_title : Registration Rejected/Deleted";
                    $mel_body = "Hi. your $system_title account has been rejected/deleted. <br/><br/>Kindly contact us at 05-4506797/6454 for more information or try register again with a valid input. Kindly rechecking all important fields before submitting.<br/><br/>$emailFooter";
                    $mel_address = $myrow_fdba["emailaddress"];
                    $mel_failed = "<script>alert('Error in sending email.'); </script>";
                    $mel_success = "<script>alert('Rejection/deletion email has been sent.');</script>";
                    sfx_sendEmail("..", $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed);
                    if ($emailDebuggerEnable == 0) {echo "<script>window.location.replace('depouser.php');</script>";}
                }
            }

            // if unblock
            if (isset($_GET["reb"]) && $_GET["reb"] <> null && is_numeric($_GET["reb"])) {
                $get_id_reb = $_GET["reb"];
                $stmt_update = $new_conn->prepare("update eg_auth_depo set num_attempt=0 where id=?");
                $stmt_update->bind_param("i", $get_id_reb);
                $stmt_update->execute();$stmt_update->close();
                echo "<script>window.location.replace('depouser.php');</script>";
            }

            //new 20240917
            if (isset($_GET["sac"]) && $_GET["sac"] <> null && isset($_GET["em"]) && $_GET["em"] <> null && $enable_self_activation) {
                $mel_subject = "$system_title : Self activation link";
                $mel_body = "Greetings, please click on this link to activate your account: <a href='$system_path"."sw_depos/depoactivate.php?k=".$_GET["sac"]."'>click here</a>.<br/>$emailFooter";
                $mel_address = $_GET["em"];
                $mel_failed = "<script>alert('Error in sending email. We might have a problem with the mailing subsystem. We have to manually activate your account. Contact us for more info.');</script>";
                $mel_success = "";
                sfx_sendEmail("..", $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed);
    
                echo "<script>alert('The user has been registered and activation link has been sent.');</script>";
                echo "<script>window.location.replace('depouser.php');</script>";
            }
            
            // if activation
            if (isset($_GET["act"]) && $_GET["act"] <> null && is_numeric($_GET["act"])) {
                $get_id_act = $_GET["act"];
                $stmt_act = $new_conn->prepare("select id,useridentity, activation, emailaddress from eg_auth_depo where id=?");
                $stmt_act->bind_param("i", $get_id_act);
                $stmt_act->execute();
                $result_act = $stmt_act->get_result();
                $myrow_act = $result_act->fetch_assoc();
                if ($myrow_act['activation'] == 'ACTIVE') {
                    mysqli_query($GLOBALS["conn"], "update eg_auth_depo set activation='NOTACTIVE' where id='".$myrow_act['id']."'");
                    $prompt = 'Deactivation';
                    $prompt_a = 'deactivated';
                } elseif ($myrow_act['activation'] == 'NOTACTIVE') {
                    mysqli_query($GLOBALS["conn"], "update eg_auth_depo set activation='ACTIVE' where id='".$myrow_act['id']."'");
                    $prompt = 'Activation';
                    $prompt_a = 'activated';
                }
                
                if ($useEmailNotification) {
                    $mel_subject = "$system_title : ".$myrow_act['useridentity']." has been $prompt_a.";
                    $mel_body = "Hi. your $system_title Account has been $prompt_a. <br/><br/>Kindly contact us at 05-4506797/6454 if you require more information.<br/><br/>$emailFooter";
                    $mel_address = $myrow_act["emailaddress"];
                    $mel_failed = "<script>alert('Error in sending email.'); </script>";
                    $mel_success = "<script>alert('$prompt email has been sent.');</script>";
                    sfx_sendEmail("..", $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed);
                    if ($emailDebuggerEnable == 0) {
                        echo "<script>window.location.replace('depouser.php');</script>";
                    }
                }
            }
            
            
    ?>

    <?php

        if (isset($_GET['scstr']) && $_GET['scstr'] != '') {
            $strtosearch = sfx_stringRemoveScriptTag($_GET['scstr']);
            $param = "%$strtosearch%";
            $stmt_fdb = $new_conn->prepare("select * from eg_auth_depo where (useridentity like ? or emailaddress like ? or fullname like ?) order by activation desc,fullname");
            $stmt_fdb->bind_param("sss", $param, $param, $param);
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            $num_results_affected_fdb = $result_fdb->num_rows;
        } else {
            if (!isset($_SESSION[$ssn.'appendurl'])) {
                $_SESSION[$ssn.'appendurl'] = "where activation='NOTACTIVE'";
            }
            
            if (isset($_GET['show']) &&  $_GET['show'] == 'ACTIVE') {
                $_SESSION[$ssn.'appendurl'] = "where activation='ACTIVE'";
            } elseif (isset($_GET['show']) &&  $_GET['show'] == 'NOTACTIVE') {
                $_SESSION[$ssn.'appendurl'] = "where activation='NOTACTIVE'";
            }
            
            $query_fdb = "select * from eg_auth_depo ".$_SESSION[$ssn.'appendurl']." order by activation desc,fullname";
            $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);
            $num_results_affected_fdb = mysqli_num_rows($result_fdb);
        }

        echo "<table class=$color_scheme"."Header>";
            echo "<tr><td><strong>Total deposit user in the system</strong> : ";
                echo "$num_results_affected_fdb <em>record(s) found.</em>";
                echo "<div style='color:blue;'>To search use CTRL+F (Windows) or CMD+F (macOS).</div>";
                echo "<br/>Select : [<a href='depouser.php?show=ACTIVE'>Show activated account</a>]
                 [<a href='depouser.php?show=NOTACTIVE'>Show unactivated account only</a>]
                  [<a style='text-decoration: underline;cursor: pointer;' onclick=\"return js_openPopup('deporegister.php?fr=int',900,580);\">+Create New Depositer Account</a>]";
                    echo "<br/><br/>
                    <span class='fas fa-check-circle' style='color:blue;'></span> Accepted
                    <span class='fas fa-times-circle' style='color:red;'></span> Rejected
                    <span class='fas fa-folder-plus' style='color:green;'></span> Archived
                    <span class='fas fa-file-alt' style='color:grey;'></span> Unprocessed
                    <span class='fas fa-check-double' style='color:purple;'></span> Graded
                    <span class='fas fa-exclamation-triangle' style='color:orange;'></span> No submission";
            echo "</td></tr>";
        echo "</table>";
                                                        
        echo "<table class=whiteHeader>";
            echo "<tr style='text-decoration:underline;'>";
                echo "<td width=10% colspan=2>#</td>";
                echo "<td width=20% style='text-align:left;'>Full Name</td>";
                echo "<td class=specialTD>User Identity</td>";
                echo "<td width=10%>Email</td>";
                echo "<td width=10%>Phone</td>";
                echo "<td width=10%>Option</td>";
                echo "<td width=10%>Activation</td>";
                echo "<td width=10%>Total Allowed Post</td>";
                echo "<td>Registered on</td>";
            echo "</tr>";
                                                
            $n = 1;
            while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                
                $id_fdb = $myrow_fdb["id"];
                $useridentity_fdb = $myrow_fdb["useridentity"];
                $fullname_fdb = $myrow_fdb["fullname"];
                $emailaddress_fdb = $myrow_fdb["emailaddress"];
                $phonenum_fdb = $myrow_fdb["phonenum"];
                $num_attempt_fdb = $myrow_fdb["num_attempt"];
                $activation_fdb = $myrow_fdb["activation"];
                $totalpost_fdb = $myrow_fdb["totalpost"];
                $styleColor = ($activation_fdb == 'ACTIVE') ? 'blue' : 'red';
                $regts_fdb = date('Y-m-d H:i:s', $myrow_fdb["regtimestamp"]);
                $rkey_fdb = $myrow_fdb["registerkey"];//new 20240917
                            
                $query_deposit = "select id,itemstatus,inputby from eg_item_depo where inputby='$useridentity_fdb' limit 1";
                $result_deposit = mysqli_query($GLOBALS["conn"], $query_deposit);
                $myrow_deposit = mysqli_fetch_array($result_deposit);

                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";

                    echo "<td>";
                        if (isset($myrow_deposit["id"])) {
                            echo "<a onclick=\"return confirm('Are you sure ? This will leave this module and jump to the user deposit module.');\" href='depodet.php?id=".$myrow_deposit["id"]."'>";
                            $icons = [
                                'AC' => ['fa-check-circle', 'blue'],
                                'R_' => ['fa-times-circle', 'red'],
                                'AR' => ['fa-folder-plus', 'green'],
                                'UP' => ['fa-file-alt', 'grey'],
                                'EN' => ['fa-file-alt', 'grey'],
                                'GR' => ['fa-check-double', 'purple']
                            ];
                            $status = substr($myrow_deposit["itemstatus"], 0, 2);
                            if (isset($icons[$status])) {
                                echo " <span class='fas {$icons[$status][0]}' style='color:{$icons[$status][1]};'></span>";
                            }
                            echo "</a>";
                        } else {
                            echo " <span class='fas fa-exclamation-triangle' style='color:orange;'></span>";
                        }
                    echo "</td>";

                    echo "<td style='text-align:left;text-transform: uppercase;'>";
                        echo $fullname_fdb;
                        echo ($num_attempt_fdb >= $default_num_attempt_login) ? "<img src='../sw_asset/img/cu_locked.png' width=12>" : '';
                    echo "</td>";

                    echo "<td class=specialTD>$useridentity_fdb</td>";

                    echo "<td>$emailaddress_fdb</td>";

                    echo "<td>$phonenum_fdb</td>";

                    echo "<td>";
                        echo "<div class='dropdown'><button class='dropbtn2'>Options</button><div id='myDropdown".$n."' class='dropdown-content'>";
                        if ($useridentity_fdb != 'admin') {
                            echo "<a href='depouser.php?rep=$id_fdb' onclick=\"return confirm('Are you sure to reset the user $useridentity_fdb\'s password to $default_password_if_forgotten ?');\" title='Reset Password'><img src='../sw_asset/img/cu_resetpass.png' width=16>Reset Password</a> ";
                            
                            if ($num_attempt_fdb >= $default_num_attempt_login) {
                                echo "<a href='depouser.php?reb=$id_fdb' onclick=\"return confirm('Are you sure to unblock the user $useridentity_fdb\'s ?');\" title='Unblock Account'><img src='../sw_asset/img/cu_ublock.png' width=16>Unblock</a>";
                            }
                            
                            echo "<a href='depouser_edit.php?edt=$id_fdb' title='Edit Account'><img src='../sw_asset/img/cu_edituser.png' width=16>Edit</a>";
                            echo "<a href='depouser.php?del=$id_fdb' onclick=\"return confirm('Are you sure to delete the user $useridentity_fdb ?');\" title='Delete User'><img src='../sw_asset/img/cu_deactivate.png' width=16>Delete</a>";
                            
                            //new 20240917
                            if ($rkey_fdb != '' && $activation_fdb == 'NOTACTIVE') {
                                echo "<a href='depouser.php?sac=$rkey_fdb&em=$emailaddress_fdb' onclick=\"return confirm('Resend activation link to user $useridentity_fdb ?');\" title='Resend Activation Link to Email'><img src='../sw_asset/img/cu_sendaemail.png' width=16>Resend Activation</a>";
                            }
                        }
                        echo "</div></div>";
                    echo "</td>";
                    
                    echo "<td><a style='color:$styleColor;' href='depouser.php?act=$id_fdb'>$activation_fdb</a></td>";
                    echo "<td>$totalpost_fdb</td>";
                    echo "<td>$regts_fdb</td>";
                echo "</tr>";
                $n = $n +1 ;
            }
        echo "</table>";
    ?>
        
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
