<?php
/*
Filename: sw_depos/depofpwd.php
Usage: Forgot password page for self deposit users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Depositor Forgot Password";
    session_start();define('includeExist', true);
    include_once '../core.php';
    if (isset($_SESSION[$ssn.'useridentity'])) {unset($_SESSION[$ssn.'useridentity']);}
    
    include_once '../sw_inc/functions.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head>
    <?php
        if ($system_function != 'full' && $system_function != 'depo') {
            header("Location: ../index.php");
            die();
        }
    ?>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>'>

    <?php
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE' && $proceedAfterToken) {
            $stmt_login = $new_conn->prepare("select emailaddress, aes_decrypt(userpass,'$aes_key') as userpass from eg_auth_depo where emailaddress=? and activation='ACTIVE' and num_attempt < $default_num_attempt_login");
            $stmt_login->bind_param("s", $_POST['emailaddress']);
            $stmt_login->execute();$stmt_login->store_result();
            $num_results_affected_login = $stmt_login->num_rows;
            $stmt_login->bind_result($emailaddress, $userpass);
            $stmt_login->fetch();$stmt_login->close();
            
            if ($num_results_affected_login <> 0) {
                $ip = sfx_get_ip();
                
                mysqli_query(
                    $GLOBALS["conn"],
                    "insert into eg_forgotpassword_depo values
                    (DEFAULT,'$emailaddress','$ip',".time().")"
                );
                
                if ($useEmailNotification) {
                    $mel_subject = "$system_title : Password retrieval";
                    $mel_body = "Greetings, your password is $userpass. You will be required to change this as soon as possible.<br/>$emailFooter";
                    $mel_address = $emailaddress;
                    $mel_failed = "<script>alert('Error in sending email. We might have a problem with the mailing subsystem. Try again later or contact us for help.');</script>";
                    $mel_success = "";
                    sfx_sendEmail("..", $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed);
                }
                
                echo "<div style='text-align:center;'>
                        <img src='../$main_logo' width=250><h2>Your password has been emailed to you.</h2>
                        <input type=\"button\" name=\"Cancel\" class=\"form-grey-button\" value=\"Go to Front Page\" onclick=\"window.location='../index.php'\";>
                      </div><br/><br/>";
            } else {
                sfx_echoPopupAlert("Email not registered in the system, account has not been activated or your account has been blocked. Contact our staff for more info.","link","depologin.php");
            }
        }
    ?>

    <div style='text-align:center;'>
    <br/><img alt='System Logo' src='../<?php echo $main_logo;?>' width=250>
    <?php if (!isset($_REQUEST["submitted"])) {
        if ($depo_enable_forget_password) {
        ?>

            <h2>Enter your registered email address for password retrieval. Your password will be emailed back to you.<br/>If however, you have entered a wrong email address during registration, you will not receive any email from us. Contact us at pustakasys@upsi.edu.my for assistance.<br/><br/></h2>
            <form action="depofpwd.php" method="post" enctype="multipart/form-data">

                <table style='width:80%;margin-left:auto;margin-right:auto;'>
                    <tr>
                        <td colspan=2><input autocomplete="off" required type="email" name="emailaddress" style='width:350px;' maxlength="100" autofocus/></td>
                    </tr>
                    <tr><td colspan='2' style='text-align:center;'><br/>
                        <input type="hidden" name="submitted" value="TRUE" />
                        <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                        
                        <button type="submit" class="googleButton" name="submit_button" value="Submit">Submit</button> <button type="button" class="googleButtonGrey" name="Cancel" value="Login" onclick="window.location='depologin.php'";>Back to Login</button>
                    </td></tr>
                </table>
            </form>
        
    <?php } else {
        echo "
        <br/><br/><h2>$depo_forget_password_wording_if_subsystem_disable</h2><br/><br/>
        <div style='text-align:center;margin-top:5px;'><a class='sButton' href='depologin.php'><span class='fas fa-arrow-circle-left'></span> Back to front page</a></div>
        ";
    }
    }?>
    </div>

    <br/><br/>
    

    <br/><br/>
    <?php include_once '../sw_inc/footer.php';?>
    
</body>
    
</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
