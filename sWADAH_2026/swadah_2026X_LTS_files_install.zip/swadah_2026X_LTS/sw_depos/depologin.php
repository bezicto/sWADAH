<?php
/*
Filename: sw_depos/depologin.php
Usage: Login page for depositor. Also contains self registration link
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Depositor Login Page";
    session_start();define('includeExist', true);
    include_once '../core.php';
    include_once '../sw_inc/functions.php';
    
    if (isset($_SESSION[$ssn.'useridentity']) && (isset($_GET['log']) && $_GET['log'] == 'out')) {
        unset($_SESSION[$ssn.'useridentity']);
    } elseif (isset($_SESSION[$ssn.'useridentity'])) {
        header("Location: depositor.php");
        die();
    }

    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head>
    <?php
        if ($system_function != 'full' && $system_function != 'depo') {
            header("Location: ../index.php");
            die();
        }
    ?>
    <?php include_once '../sw_inc/header.php'; ?>
    <link rel="stylesheet" type="text/css" href="../sw_asset/css/topmenu.css<?php echo "$refresh_component";?>"/>
</head>

<body class='<?php echo $color_scheme;?>' <?php if ($show_main_body_background_image) {?>style='background-image:url("<?php echo "../".$main_body_background_image;?>");' <?php }?>>
    
    <div class="top-menu">
        <ul>
            <?php
                    if ($system_function == 'full' || $system_function == 'depo') {
                        ?>
                        <li><span class="fa-regular fa-address-card"></span> <a href='deporegister.php'>Register</a></li>
                        <li><span class="fas fa-asterisk"></span> <a href='depofpwd.php'>Forgot Password</a></li>
                    <?php
                    }
                    if ($system_mode != 'maintenance' && $enable_tutorial_button) {
                    ?>
                        <li><span class="fas fa-book-reader"></span> <a href='<?php echo $tutorial_link;?>' target='_blank'>Tutorial</a></li>
                    <?php
                    }
            ?>
        </ul>
    </div>

    <main>
    <?php
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE' && $proceedAfterToken) {
            
            $stmt_login = $new_conn->prepare("select id, useridentity, aes_decrypt(userpass,'$aes_key') as userpass, activation, num_attempt from eg_auth_depo where useridentity=?");
            $stmt_login->bind_param("s", $_POST['fname']);
            $stmt_login->execute();$stmt_login->store_result();
            $num_results_affected_login = $stmt_login->num_rows;
            $stmt_login->bind_result($id2, $useridentity2, $userpass2, $activation2, $num_attempt2);
            $stmt_login->fetch();$stmt_login->close();

            $login_label = "<div style='text-align:center;font-size:12px;'><strong>Status:</strong> ";
            
            if ($num_results_affected_login <> 0) {
                if (sfx_stringRemoveScriptTag($_POST['fname'],false) == $useridentity2 && $_POST['fpass'] == $userpass2 && $num_attempt2 < 5) {
                    if ($activation2 == 'ACTIVE') {
                        $login_label .= "<label style='color:blue;'>Authentication complete. You will be directed in no time.</label>";
                        $_SESSION[$ssn.'useridentity']=$useridentity2;
                        $stmt_update = $new_conn->prepare("update eg_auth_depo set num_attempt=0 where id=?");
                        $stmt_update->bind_param("i", $id2);
                        $stmt_update->execute();$stmt_update->close();
                        echo "<script>document.location.href='depositor.php'</script>";
                    } else {
                        $login_label .= "<label style='color:red;'>Account is not activated. If you have further questions, contact us at $system_admin_email</label>";
                    }
                } else {
                    if ($num_attempt2 == 5) {
                        $login_label .= "<label style='color:red;'>You account has been blocked. Contact us at $system_admin_email for more info.</label>";
                    } else {
                        $login_label .= "<label style='color:red;'>Incorrect authentication information detected !</label>";
                        $num_attempt2 = $num_attempt2+1;
                        $stmt_update = $new_conn->prepare("update eg_auth_depo set num_attempt=? where id=?");
                        $stmt_update->bind_param("ii", $num_attempt2, $id2);
                        $stmt_update->execute();$stmt_update->close();
                    }
                }
            } else {
                $login_label .= "<label style='color:red;'>Cannot find username !</label>";
            }
            $login_label .= "</div><br/>";
        }
    ?>

    <table class=transparentCenter100percent>
        <tr>
            <td colspan=2 style='text-align:center;'>
            <br/><img alt='Main Logo' style='min-width:350px;max-width:550px;' src='../<?php echo $main_logo;?>' width=<?php echo $main_logo_width;?>>
            <h1>Depositor Portal</h1>
                <form action="depologin.php" method="post">
                    <br/>
                    <strong><?php echo $depo_txt_identification;?> : </strong><br/><input autocomplete="off" class="roundInputTextMin" type="text" name="fname" size="25" maxlength="25" required autofocus/>
                    <br/><br/>
                    <strong>Password : </strong><br/><input autocomplete="off" class="roundInputTextMin" type="password" name="fpass" size="25" maxlength="25" required />
    
                    <input type="hidden" name="submitted" value="TRUE" />
                    <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                    
                    <br/><br/><br/>
                    <button type="submit" class="googleButton" name="submit_button" value="Login">Login</button> <button type="button" class="googleButtonGrey" name="Cancel" value="Login" onclick="window.location='../index.php'";>Go to Front Page</button>
                    
                    <br/><br/>
                    <?php echo $login_label ?? '';?>
                </form>
            </td>
        </tr>
    </table>

    <br/><br/>
    <?php include_once '../sw_inc/footer.php';?>
    </main>
</body>
    
</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
