<?php
/*
Filename: sw_depos/deporegister.php
Usage: Self registration page for self submission user
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Depositor Login Page";
    session_start();define('includeExist', true);
    include_once '../core.php';
    if (isset($_SESSION[$ssn.'useridentity'])) {unset($_SESSION[$ssn.'useridentity']);}
    include_once '../sw_inc/functions.php';

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head>
    <?php
        if ($system_function != 'full' && $system_function != 'depo') {
            header("Location: ../index.php");
            die();
        }
    ?>
    <?php include_once '../sw_inc/header.php'; ?>
    <script type="text/javascript">
        $(function () {
            $("#submit_button").click(function () {
                var password = $("#fpass").val();
                var confirmPassword = $("#fpass2").val();
                if (password != confirmPassword) {
                    alert("Passwords do not match.");
                    return false;
                }
                return true;
            });
        });
    </script>
    <style>
        /* body structure just for this page */
        body {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            padding-top: 40px;
            margin: 0;
        }
    </style>
</head>

<body class='<?php echo $color_scheme;?>'>

    <?php
        if (isset($_REQUEST['submitted']) && $_REQUEST["submitted"] == 'TRUE' && $proceedAfterToken) {
            $useridentity1 = sfx_stringRemoveScriptTag($_POST["fname"],false);
            $userpass1 = sfx_stringRemoveScriptTag($_POST["fpass"],false);
            $userpass2 = sfx_stringRemoveScriptTag($_POST["fpass2"],false);
            $fullname1 = sfx_stringRemoveScriptTag($_POST["fullname"]);
            $emailaddress1 = sfx_stringRemoveScriptTag($_POST["emailaddress"]);
            $phonenum1 = sfx_stringRemoveScriptTag($_POST["phonenum"]);
            $key = md5(microtime().rand().$emailaddress1);

            echo "<div class=\"swadahsent-container\">";
            
            if ($userpass1 == $userpass2) {
                //check if user the identity existed
                $stmt_count = $new_conn->prepare("select useridentity from eg_auth_depo where useridentity=?");
                $stmt_count->bind_param("s", $useridentity1);
                $stmt_count->execute();$stmt_count->store_result();
                $num_results_affected_username = $stmt_count->num_rows;
                $stmt_count->close();
                
                if ($num_results_affected_username == 0) {
                        if (!empty($useridentity1) && !empty($fullname1) && !empty($emailaddress1) && !empty($phonenum1)) {
                            $stmt_insert = $new_conn->prepare("insert into eg_auth_depo values(DEFAULT,?,AES_ENCRYPT(?,'$aes_key'),?,?,?,".time().",'NOTACTIVE',0,?,?)");
                            $stmt_insert->bind_param("ssssssi", $useridentity1, $userpass1, $fullname1, $emailaddress1, $phonenum1, $key, $depo_max_deposit);
                            $stmt_insert->execute();$stmt_insert->close();
                            
                            if (isset($_SESSION[$ssn.'username'])) {
                                echo "<i class=\"fas fa-check-square fa-2xl\"></i><br/><br/><div style='text-align:center;color:blue;'>User <strong>$fullname1</strong> has been registered.
                                <br/><br/><button type='button' class='googleButtonRed' name='Cancel' value='Close' onclick=\"window.opener.location.reload(true);window.close();setTimeout('self.close()', 500);\";>Close</button>";
                            } else {
                                if ($enable_self_activation) {
                                    $mel_subject = "$system_title : Self activation link";
                                    $mel_body = "Greetings, please click on this link to activate your account: <a href='$system_path"."sw_depos/depoactivate.php?k=$key'>click here</a>.<br/>$emailFooter";
                                    $mel_address = $emailaddress1;
                                    $mel_failed = "<script>alert('Error in sending email. We might have a problem with the mailing subsystem. We have to manually activate your account. Contact us for more info.');</script>";
                                    $mel_success = "";
                                    sfx_sendEmail("..", $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed);
                        
                                    echo "<i class=\"fas fa-check-square fa-2xl\"></i><br/><br/><div style='text-align:center;color:blue;'>User <strong>$fullname1</strong> has been registered and activation link has been sent.<br/>If you have further question kindly contact $system_admin_email</div><br/><a href='depologin.php'>Click here to continue</a><br/><br/>";
                                } else {
                                    echo "<i class=\"fas fa-check-square fa-2xl\"></i><br/><br/><div style='text-align:center;color:blue;'>User <strong>$fullname1</strong> has been registered. Activation and verification will take 24-48 hours on working days only.<br/>If you have further question kindly contact $system_admin_email</div><br/><a href='depologin.php'>Click here to continue</a><br/><br/>";
                                }
                            }
                        } else {
                            echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><div style='text-align:center;color:red;'>Your input has been cancelled. Check if any field(s) left emptied before posting.</div><br/><a href='deporegister.php'>Click here to retry</a><br/><br/>";
                        }
                } elseif ($num_results_affected_username >= 1) {
                    echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><div style='text-align:center;color:red;'>Your input has been cancelled. Duplicate identification detected. <br/>If you have further question kindly contact $system_admin_email</div><br/><a href='deporegister.php'>Click here to retry</a><br/><br/>";
                }
            } else {
                echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><div style='text-align:center;color:red;'>Passwords not matching with one another. Please retry.</div><br/><a href='deporegister.php'>Click here to retry</a><br/><br/>";
            }
            
            echo "</div>";
        }
    ?>

    <?php if (!isset($_REQUEST["submitted"])) {?>
        <div class="swadahneo-logo-container">
            <img alt='Main Logo' src='../<?php echo $main_logo;?>'>
        </div>
        <div class="swadahneo-header-text">
            <?php
            if (isset($_GET['fr']) && $_GET['fr'] == 'int') {
                echo "<h2>New depositor registration window.<br/>Manual activation is required on the Depositor Account page: <em>Options > Resend Activation</em>.</h2>";
            } else  {
                echo "<h2>Register new account. Activation will take 24-48 hours on working days only.<br/>Plan your deposit timeframe before proceeding.</h2>";
            }
            ?>
        </div>
        <div class="swadahneo-container">
            <form action="deporegister.php" method="post">
                <div class="swadahneo-group">
                    <label><?=$depo_txt_identification;?></label>
                    <input autocomplete="off" required type="text" name="fname" maxlength="25">
                </div>
                <div class="swadahneo-group">
                    <label>Password</label>
                    <input autocomplete="off" required type="password" name="fpass" maxlength="25">
                </div>
                <div class="swadahneo-group">
                    <label>Password (Enter again)</label>
                    <input autocomplete="off" required type="password" name="fpass2" maxlength="25">
                </div>
                <div class="swadahneo-group">
                    <label>Full Name</label>
                    <input autocomplete="off" required type="text" name="fullname" maxlength="80">
                </div>
                <div class="swadahneo-group">
                    <label>Email Address</label>
                    <input autocomplete="off" required type="email" name="emailaddress" maxlength="100">
                </div>
                <div class="swadahneo-group">
                    <label>Phone Number</label>
                    <input autocomplete="off" required type="tel" name="phonenum" maxlength="20">
                </div>
                <input type="hidden" name="submitted" value="TRUE">
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <div class="swadahneo-btn-group">
                    <button type="submit" class="swadahneo-submit-btn">Submit</button>
                    <?php if (isset($_SESSION[$ssn.'username'])): ?>
                        <button type="button" class="swadahneo-cancel-btn" onclick="window.opener.location.reload(true);window.close();">Close</button>
                    <?php else: ?>
                        <button type="button" class="swadahneo-cancel-btn" onclick="window.location='depologin.php'">Back to Login</button>
                    <?php endif; ?>
                </div>
            </form>
            <br/><br/><?php include_once '../sw_inc/footer.php';?>
        </div><br/><br/>
    <?php }?>
    
    
    
</body>
    
</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
