<?php
/*
Filename: sw_depos/depoadmin.php
Usage: Page for admins to manage user deposit
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Manage User Deposit";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';

    unset($_SESSION[$ssn.'appendurl']);//unset appendurl session from depouser
   
    if (isset($_GET['scstr']) && $_GET['scstr'] != '') {
        $_SESSION[$ssn.'sqlappend'] = 'nil';
        unset($_SESSION[$ssn.'pubappend']);
        unset($_SESSION[$ssn.'pubidappend']);
        unset($_SESSION[$ssn.'cubappend']);
        unset($_SESSION[$ssn.'typeaddpend']);
    } else {
        $statuses = [
            'accepted' => 'accepted',
            'graded' => 'graded',
            'repod' => 'repod',
            'repex' => 'repex',
            'rejected' => 'rejected',
            'entry' => 'entry',
            'all' => 'all'
        ];
        if (isset($_GET['v']) && isset($statuses[$_GET['v']])) {
            $_SESSION[$ssn.'sqlappend'] = $statuses[$_GET['v']];
        }

        if (isset($_GET['pub']) && ctype_alnum($_GET['pub'])) {
            $_SESSION[$ssn.'pubappend'] = $_GET['pub'];
        }

        if (isset($_GET['pubid']) && is_numeric($_GET['pubid'])) {
            $_SESSION[$ssn.'pubidappend'] = $_GET['pubid'];
        }

        if (isset($_SESSION[$ssn.'pubappend']) && $_SESSION[$ssn.'pubappend'] == 'all') {
            unset($_SESSION[$ssn.'pubidappend']);
        }

        if (isset($_GET['cub'])) {
            $_SESSION[$ssn.'cubappend'] = $_GET['cub'];
        }

        if (isset($_GET['g'])) {
            $_SESSION[$ssn.'typeaddpend'] = $_GET['g'];
        }
    }

?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>' <?php if (isset($_GET['print'])) {echo "style='background-color:white;'";}?>>
    
    <?php
        if (!isset($_GET['print'])) {
            include_once '../sw_inc/navbar.php';
        }

        if (isset($_GET["del"]) && $_GET["del"] <> null && is_numeric($_GET["del"])) {
            $get_id_del = $_GET["del"];
            $stmt_del = $new_conn->prepare("delete from eg_item_depo where id=?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();$stmt_del->close();
        }
    ?>
    
    <?php
        if ($system_function == 'depo') {
            include_once '../sw_inc/mainbar.php';
        }
    ?>

    <?php if (!isset($_GET['print'])) {?>
        <hr>
        <table class=whiteHeaderNoCenter style='width:100%;'>
        <tr style='text-align:center;'>
            <td>
                <form  action="depoadmin.php" method="get" enctype="multipart/form-data" style="margin:auto;max-width:100%">
                    Search:
                    <br/>
                    <input type="text" placeholder="Enter ID" name="scstr" style='width:50%;font-size:14px' maxlength="255" value="<?php if (isset($_GET['scstr'])) {echo strip_tags(mysqli_real_escape_string($GLOBALS["conn"], $_GET['scstr']));}?>"/>
                    <input type="submit" class="form-submit-button" name="s" value="Search" />
                </form>
            </td>
        </tr>
        </table>
        <br/>
    <?php }?>

    <table class=whiteHeaderNoCenter style='width:100%;'>
        <?php if (!isset($_GET['print'])) {?>
        <tr style='text-align:center;background-color:lightgrey;'>
            <td><br/>
                Filter:
                <select name='v' onchange="if (this.value) window.location.href=this.value;">
                    <?php
                        $options = [
                            'all' => 'All',
                            'accepted' => 'Accepted',
                            'graded' => 'Graded',
                            'repod' => 'Live',
                            'repex' => 'Archived Externally',
                            'rejected' => 'Rejected',
                            'entry' => 'Entry'
                        ];

                        foreach ($options as $value => $text) {
                            $selected = (isset($_SESSION[$ssn.'sqlappend']) && $_SESSION[$ssn.'sqlappend'] == $value) ? 'selected' : '';
                            echo "<option value='depoadmin.php?v=$value' $selected>$text</option>";
                        }
                    ?>
                </select>
                <?php
                    echo "<select name='g' onchange=\"if (this.value) window.location.href=this.value;\">";
                        echo "<option value='depoadmin.php?g=all'>All</option>";
                        $selectable_grades = explode(",", $depo_grades);
                        for ($x = 0; $x < sizeof($selectable_grades); $x++) {
                            echo "<option value='depoadmin.php?g=".urlencode($selectable_grades[$x])."' ";
                            if (isset($_SESSION[$ssn.'typeaddpend']) &&  $_SESSION[$ssn.'typeaddpend'] == $selectable_grades[$x]) {echo "selected";}
                            echo ">".$selectable_grades[$x]."</option>";
                        }
                    echo "</select>";
                ?>
                <?php if ($_SESSION[$ssn.'publisheradmin'] == 'ALL') { ?>
                    <select name="publication1_b" onchange="if (this.value) window.location.href=this.value;">
                                <?php
                                    $queryB = "select * from eg_publisher order by 43sstatus desc";
                                    $resultB = mysqli_query($GLOBALS["conn"], $queryB);
                                    echo "<option value='depoadmin.php?pub=all'>All</option>";
                                    while ($myrowB = mysqli_fetch_array($resultB)) {
                                        echo "<option value='depoadmin.php?pub=".$myrowB["43acronym"]."&pubid=".$myrowB["43pubid"]."' ";
                                        if ((isset($_SESSION[$ssn.'pubappend']) && $_SESSION[$ssn.'pubappend'] == $myrowB["43acronym"]) || (isset($_SESSION[$ssn.'pubidappend']) && $_SESSION[$ssn.'pubidappend'] == $myrowB["43pubid"])) {echo "selected";}
                                        echo ">".$myrowB["43publisher"];
                                        if ($myrowB["43sstatus"] == 0) {
                                            echo " (Not-selectable)";
                                        }
                                        echo "</option>";
                                    }
                                ?>
                    </select>

                    <?php
                        $selectable_502_b = explode("|", $tag_502_b_selectable);
                        echo "<select name='ctype' onchange='if (this.value) window.location.href=this.value';>";
                        echo "<option value='depoadmin.php?cub=all'>All</option>";
                        for ($x = 0; $x < sizeof($selectable_502_b); $x++) {
                            echo "<option value='depoadmin.php?cub=".$selectable_502_b[$x]."' ";
                            if (isset($_SESSION[$ssn.'cubappend']) && $_SESSION[$ssn.'cubappend'] == $selectable_502_b[$x]) {
                                echo "selected";
                            }
                            echo ">".$selectable_502_b[$x]."</option>";
                        }
                        echo "</select>";
                    ?>
                    <br/><br/>
                <?php }?>
            </td>
        </tr>
        <?php }?>

        <tr style='text-align:center;'>
            <td <?php if (isset ($_GET['print'])) {echo "style='border:1px solid;'";}?>>
                <?php
                    echo "Showing status: <span style='color:blue;'>";
                        $statuses = [
                            'accepted' => 'Accepted',
                            'graded' => 'Graded',
                            'repod' => 'Live in Repository',
                            'repex' => 'Archived Externally',
                            'rejected' => 'Rejected',
                            'entry' => 'Entry',
                            'all' => 'All'
                        ];
                        if (isset($_SESSION[$ssn.'sqlappend']) && isset($statuses[$_SESSION[$ssn.'sqlappend']])) {
                            echo $statuses[$_SESSION[$ssn.'sqlappend']];
                        } else {
                            echo 'All';
                        }
                    echo "</span>";

                    if (isset($_SESSION[$ssn.'typeaddpend'])) {
                        echo ", Grade: <span style='color:blue;'>".$_SESSION[$ssn.'typeaddpend']."</span>";
                    }

                    if (isset($_SESSION[$ssn.'pubappend'])) {
                        echo ", Publisher: <span style='color:blue;'>".$_SESSION[$ssn.'pubappend']."</span>";
                    }

                    if (isset($_SESSION[$ssn.'cubappend'])) {
                        echo ", Degree Type: <span style='color:blue;'>".$_SESSION[$ssn.'cubappend']."</span>";
                    }

                    if ($_SESSION[$ssn.'publisheradmin'] == 'ALL' && isset($_SESSION[$ssn.'sqlappend']) && $_SESSION[$ssn.'sqlappend'] == 'repod' && !isset($_GET['print'])) {
                        echo " [<a target='_blank' href='depoliveclear.php'>Clear storage for this status</a>]";
                    }

                    if (!isset($_GET['print'])) {
                        echo " <a style='float:right;' href='depoadmin.php?print=u'><i class=\"fas fa-print\"></i> Printer Mode</a>";
                    }
                ?>
            </td>
        </tr>
    </table>

    <?php
        echo "<table class=whiteHeaderNoCenter>";

            $sqlappend = "where itemstatus != ''";
            $conditions = [
                'accepted' => "where itemstatus like 'AC%'",
                'repex' => "where itemstatus like 'ARCHIVEEX'",
                'repod' => "where itemstatus like 'AR%' and itemstatus not like 'ARCHIVEEX'",
                'rejected' => "where itemstatus like 'R_%'",
                'entry' => "where (itemstatus like 'E%' or itemstatus like 'UPD%')",
                'graded' => "where (itemstatus like 'G%' or itemstatus like 'GRADED%')"
            ];
            if (isset($_SESSION[$ssn.'sqlappend']) && isset($conditions[$_SESSION[$ssn.'sqlappend']])) {
                $sqlappend = $conditions[$_SESSION[$ssn.'sqlappend']];
            }

            $gradeappend = "";
            if (isset($_SESSION[$ssn.'typeaddpend']) && $_SESSION[$ssn.'typeaddpend'] != '-' && $_SESSION[$ssn.'typeaddpend'] != 'all') {
                $gradeappend = "and grade='".$_SESSION[$ssn.'typeaddpend']."'";
            }

            $pubappend = "and 29publication_b != ''";
            if ($_SESSION[$ssn.'publisheradmin'] == 'ALL' && isset($_SESSION[$ssn.'pubappend']) && $_SESSION[$ssn.'pubappend'] != 'all') {
                $pubappend = "and (29publication_b='".$_SESSION[$ssn.'pubappend']."'";
                if (isset($_SESSION[$ssn.'pubidappend']) && is_numeric($_SESSION[$ssn.'pubidappend'])) {
                    $pubappend .= "or 29publication_b='".$_SESSION[$ssn.'pubidappend']."'";
                }
                $pubappend .= ")";
            }

            $cubappend = "and 29dissertation_note_b != ''";
            if (isset($_SESSION[$ssn.'cubappend']) && $_SESSION[$ssn.'cubappend'] != 'all') {
                $cubappend = "and 29dissertation_note_b='".$_SESSION[$ssn.'cubappend']."'";
            }

            $sqlappend_tosearch = "";
            if (isset($_GET['scstr'])) {
                $sqlappend_tosearch = " and inputby='".strip_tags(mysqli_real_escape_string($GLOBALS["conn"], $_GET['scstr']))."'";
            }

            $pub_to_search = "";
            if ($_SESSION[$ssn.'publisheradmin'] != 'ALL') {
                $pub_to_search = " and 29publication_b='".$_SESSION[$ssn.'publisheradmin']."'";
            }

            $query_deposit = "select SQL_CALC_FOUND_ROWS * from eg_item_depo $sqlappend $pubappend $cubappend $gradeappend $sqlappend_tosearch $pub_to_search order by id desc";
            $result_deposit = mysqli_query($GLOBALS["conn"], $query_deposit);
            
            if (!isset($_GET['print'])) {
                echo "<tr class=$color_scheme"."HeaderCenter>";
                    echo "<td width=40% colspan=2>Submission</td>";
                    echo "<td width=10%>Type</td>";
                    echo "<td width=10%>Publisher</td>";
                    echo "<td width=10%>User submitted date</td>";
                    echo "<td width=10%>User last updated</td>";
                    echo "<td width=10%>Current Status</td>";
                    echo "<td width=10%>Storage Usage</td>";
                echo "</tr>";
                $n = 1;
                while ($myrow_deposit = mysqli_fetch_array($result_deposit)) {
                    $id = $myrow_deposit["id"];
                    $authorname = $myrow_deposit["29authorname"];
                    $titlestatement = $myrow_deposit["29titlestatement"];
                    $dissertation_note_b = $myrow_deposit["29dissertation_note_b"];
                    $publication_b = $myrow_deposit["29publication_b"];
                    $lastupdated = $myrow_deposit["29lastupdated"];
                    $depositornot = $myrow_deposit['29pfile'];
                    $year = $myrow_deposit["year"];
                    $timestamp = $myrow_deposit["timestamp"];
                    $itemstatus = $myrow_deposit["itemstatus"];
                    $inputby = $myrow_deposit["inputby"];
                    $grade = $myrow_deposit["grade"];
                    $inputbyName = sfx_sGetValue("fullname", "eg_auth_depo", "useridentity", $myrow_deposit["inputby"]);

                    $append_grade_to_Graded = (isset($grade) && $grade != '') ? "(<span style='color:blue;'>$grade</span>)" : '';
                
                    echo "<tr class=$color_scheme"."Hover style='text-align:center;'>";
                        echo "<td style='vertical-align:top;'>$n</td>";
                        echo "<td style='text-align:left;vertical-align:top;'>";
                                echo "<font color=blue>$inputbyName ($inputby) <sup>[<a href='depouser.php?scstr=$inputby&s=Search'>Edit User Detail</a>]</sup></font>
                                <br/>$titlestatement
                                <br/>[<a href='depodet.php?id=$id'>View Detail and Set Status</a>]";
                                if (isset($_GET['v']) && $_GET['v'] == 'rejected' && $inputbyName == '') {
                                    echo " [<a href='depoadmin.php?v=rejected&del=$id' onclick=\"return confirm('Are you sure to delete the item: $titlestatement ?');\">Delete</a>]";
                                }
                        echo "</td>";
                        echo "<td>$dissertation_note_b</td>";
                        
                        $paramsOrAnd = [
                            'fieldtoget' => '43publisher',
                            'tablename' => 'eg_publisher',
                            'wherefield1' => '43acronym',
                            'wherefield2' => '43pubid',
                            'wherevalue1' => $publication_b,
                            'wherevalue2' => $publication_b,
                            'wherevaluetype' => 'si',
                            'operator' => 'OR'
                        ];
                        echo "<td>".sfx_sGetValueOrAnd($paramsOrAnd)."</td>";

                        echo "<td>".date('Y-m-d H:i', $timestamp)."</td>";
                        echo "<td>".date('Y-m-d H:i', $lastupdated)."</td>";
                        echo "<td>".sfx_getDepoStatus($itemstatus)." $append_grade_to_Graded</td>";
                        echo "<td>";
                        echo ($depositornot == 'YES' && file_exists("../$system_pfile_directory/$year/$id" . "_" . $timestamp . ".pdf")) ? sfx_formatBytes(filesize("../$system_pfile_directory/$year/$id" . "_" . $timestamp . ".pdf")) : "-";
                    
                        echo "</td>";
                    echo "</tr>";
                    $n=$n+1;
                }
            } else {
                echo "<tr class=whiteHeaderCenter><td colspan=8 style='text-align:center;border:1px solid;'>List of submission</td></tr>";
                echo "<tr class=whiteHeaderCenter>";
                    echo "<td style='border:1px solid;'colspan=2><u>Name</u></td>";
                    echo "<td style='border:1px solid;'><u>User ID</u></td>";
                    echo "<td style='border:1px solid;'><u>Title</u></td>";
                    echo "<td style='border:1px solid;'><u>Publisher</u></td>";
                    echo "<td style='border:1px solid;'><u>Type</u></td>";
                    echo "<td style='border:1px solid;'><u>Submit Date</u></td>";
                    echo "<td style='border:1px solid;'><u>Grade</u></td>";
                echo "</tr>";
                $n = 1;
                while ($myrow_deposit = mysqli_fetch_array($result_deposit)) {
                    $id = $myrow_deposit["id"];
                    $authorname = $myrow_deposit["29authorname"];
                    $titlestatement = $myrow_deposit["29titlestatement"];
                    $dissertation_note_b = $myrow_deposit["29dissertation_note_b"];
                    $publication_b = $myrow_deposit["29publication_b"];
                    $lastupdated = $myrow_deposit["29lastupdated"];
                    $depositornot = $myrow_deposit['29pfile'];
                    $year = $myrow_deposit["year"];
                    $timestamp = $myrow_deposit["timestamp"];
                    $itemstatus = $myrow_deposit["itemstatus"];
                    $inputby = $myrow_deposit["inputby"];
                    $inputbyName = sfx_sGetValue("fullname", "eg_auth_depo", "useridentity", $myrow_deposit["inputby"]);
                
                    echo "<tr style='text-align:center;border:1px solid;'>";
                        echo "<td style='vertical-align:top;border:1px solid;'>$n</td>";
                        echo "<td style='vertical-align:top;text-align:left;border:1px solid;'>$inputbyName</td>";
                        echo "<td style='vertical-align:top;border:1px solid;'>$inputby</td>";
                        echo "<td style='vertical-align:top;text-align:left;border:1px solid;'>$titlestatement</td>";
                        
                        $paramsOrAnd = [
                            'fieldtoget' => '43publisher',
                            'tablename' => 'eg_publisher',
                            'wherefield1' => '43acronym',
                            'wherefield2' => '43pubid',
                            'wherevalue1' => $publication_b,
                            'wherevalue2' => $publication_b,
                            'wherevaluetype' => 'si',
                            'operator' => 'OR'
                        ];
                        echo "<td style='vertical-align:top;border:1px solid;'>".sfx_sGetValueOrAnd($paramsOrAnd)."</td>";
                        
                        echo "<td style='vertical-align:top;border:1px solid;'>$dissertation_note_b</td>";
                        echo "<td style='vertical-align:top;border:1px solid;'>".date('Y-m-d H:i', $timestamp)."</td>";
                        echo "<td style='vertical-align:top;border:1px solid;'></td>";
                    echo "</tr>";
                    $n=$n+1;
                }
            }
        echo "</table>";
    ?>

    <?php
        if (!isset($_GET['print'])) {
            echo "<hr>";
            include_once '../sw_inc/footer.php';
        } else {
            echo "<div style='font-size:12px;margin-top:30px;width:100%;text-align:center;'>[ <a href='depoadmin.php'>Close</a> ]</div>";
        }
    ?>

<?php
    if ($debug_mode == 'yes') {
    ?>
        <div class='footer' style='width:100%;text-align:center;'>
        <?php
            echo "<span style='color:cyan;'>Final query:</span> <span style='color:yellow;'>".$query_deposit."</span> ";
            include_once '../sw_inc/view_storedSession.php';
            echo $print_sessvar ?? '';
        ?>
        </div>
    <?php
    }
    ?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
