<?php
/*
Filename: sw_depos/depopchange.php
Usage: Change password page for self deposit users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Depositor Change Password";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset_depo.php';
    include_once '../sw_inc/functions.php';
    
    $username3 = $_SESSION[$ssn.'useridentity'];
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once 'navbar_depo.php'; ?>
    
    <hr>
                
    <?php
        if (isset($_GET["upd"]) && $_GET['upd'] == 'g') {
    ?>
            <table class=<?php echo $color_scheme."Header";?>>
                <tr class=<?php echo $color_scheme."HeaderCenter";?>><td>
                    <strong>Please input your new password alongside with it confirmation :</strong>
                </td></tr>
            </table>
                        
            <form action="depopchange.php" method="post">
                <table class=greyBody>
                    <tr style='text-align:center;'><td>
                        <strong>Old Password:</strong><br/><input class="roundInputTextMin" required autocomplete="off" type="password" name="password3o" size="25" maxlength="25"/>
                        <br/><br/>
                        <strong>New Password:</strong><br/><input class="roundInputTextMin" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" autocomplete="off" type="password" name="password3" size="25" maxlength="25"/>
                        <br/><br/>
                        <strong>New Password (Again):</strong><br/><input class="roundInputTextMin" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" autocomplete="off" type="password" name="password3a" size="25" maxlength="25"/>
                        <br/><br/>
                        <input type="hidden" name="submitted" value="TRUE" />
                        <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                        <input type="submit" class="googleButton" name="submit_button" value="Update"/>
                    </td></tr>
                </table>
            </form>
    <?php
        }
                
        if (isset($_POST["submitted"]) && $proceedAfterToken) {
            $stmt_getoldpwd = $new_conn->prepare("select AES_DECRYPT(userpass,'$aes_key') as syspassword from eg_auth_depo where useridentity=?");
            $stmt_getoldpwd->bind_param("s", $username3);
            $stmt_getoldpwd->execute();
            $stmt_getoldpwd->bind_result($password_old);
            $stmt_getoldpwd->fetch();$stmt_getoldpwd->close();
            
            $password4o = $_POST["password3o"];
            $password4 = $_POST["password3"];
            $password4a = $_POST["password3a"];
            
            echo "<table class=whiteHeader><tr><td>";
            
            if ($password4o == $password_old) {
                if (!empty($password4)) {
                    if ($password4 == $password4a) {
                        $stmt_update = $new_conn->prepare("update eg_auth_depo set userpass=AES_ENCRYPT(?,'$aes_key') where useridentity=?");
                        $stmt_update->bind_param("ss", $password4, $username3);
                        $stmt_update->execute();$stmt_update->close();
                        echo "<i class=\"fas fa-check-square fa-2xl\"></i><br/><br/>Your password has been updated. Click <A HREF='depositor.php'>here</A> to continue.";
                    } else {
                        echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><span style='color:red;'>Confirmation failed. Click <A HREF='javascript:history.go(-1)'>here</A> to reinput the password.</span>";
                    }
                } else {
                    echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><span style='color:red;'>Please insert any empty field ! Click <A HREF='javascript:history.go(-1)'>here</A> to retry.</span>";
                }
            } else {
                echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><span style='color:red;'>Please verify your old password ! Click <A HREF='javascript:history.go(-1)'>here</A> to retry.</span>";
            }
            
            echo "</td></tr></table>";
        }
    ?>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
