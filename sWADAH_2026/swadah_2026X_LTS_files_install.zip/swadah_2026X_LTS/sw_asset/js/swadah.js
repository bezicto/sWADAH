tinymce.init({
    selector: '#wadahComposer',
    menubar: false,
    branding: false,
});

tinymce.init({
    selector: '#referenceComposer',
    menubar: false,
    branding: false,
});

$(function() {
    $("#subjectheading1").autocomplete({
        source: "../sw_inc/autocomplete_sh.php"
    });
});

$(function() {
    $("#publication1_b").autocomplete({
        source: "../sw_inc/autocomplete_pub.php"
    });
});

$(function() {
    $("#name1_sc").autocomplete({
        source: "../sw_inc/autocomplete_un.php"
    });
});

function js_openPopup(url,winWidth,winHeight) {
    window.open(url, "popup_id", "scrollbars=yes,resizable=no,width="+winWidth+",height="+winHeight);
    return false;
}

function js_showList() 
{
    window.open("../sw_inc/shselector.php", "list", "scrollbars=yes,resizable=no,width=400,height=450");
}

function js_showPublisher() 
{
    window.open("../sw_inc/pubselector.php", "list", "scrollbars=yes,resizable=no,width=400,height=450");
}

function js_showFolder() 
{
    window.open("../sw_inc/folderselector.php", "list", "scrollbars=yes,resizable=no,width=400,height=450");
}

function remLink() 
{
    if (window.sList?.open && !window.sList?.closed)
    {
        window.sList.opener = null;
    }
}
