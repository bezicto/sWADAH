<?php
/*
Filename: sw_splus/keymaker.php
Usage: Generate key for sWADAH and SCENSO randomly
Version: 20250101.0801
Last change: -
*/

    $thisPageTitle = "Random KeyMaker";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    
    function kmfx_generateRandomStringAes($length = 64) {
        $characters = 'ABCDE0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    function kmfx_generateRandomStringScenso($length = 14) {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    if (isset($_GET['generate'])) {
        header('Content-Type: text/plain');
        echo kmfx_generateRandomStringAes();
        exit;
    }

    if (isset($_GET['generate2'])) {
        header('Content-Type: text/plain');
        echo kmfx_generateRandomStringScenso();
        exit;
    }
    
?>
<!DOCTYPE HTML>
<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>' style='font-size:12pt;'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <div style='width:100%;text-align:center;'>
        <button onclick="js_generateRandomString()">Generate Random String (AES Key)</button>
        <p id="result"></p>
        <script>
            function js_generateRandomString() {
                fetch('?generate=true')
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('result').textContent = data;
                    });
            }
        </script>

        <button onclick="js_generateRandomString2()">Generate Random String (SCENSO Key)</button>
        <p id="result2"></p>
        <script>
            function js_generateRandomString2() {
                fetch('?generate2=true')
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('result2').textContent = data;
                    });
            }
        </script>
    </div>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
