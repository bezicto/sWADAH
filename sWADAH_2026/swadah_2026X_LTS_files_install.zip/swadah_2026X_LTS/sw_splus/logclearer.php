<?php
/*
Filename: sw_splus/logclearer.php
Usage: Clear unused data from columns inside of many log tables
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Database Log Clearer and Exporter";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>' style='font-size:12pt;'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <?php
    
        echo "<strong>This tool will export the search and download log in the database. Should you choose, you can also clear the log inside the database.</strong>";
        echo "<br/>The deleted/cleared logs will not come back. Use this tool with cautions.<br/><br/><br/>";

        $find_tablesize= "select ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024) AS 'downloadkeysize' from information_schema.tables where table_schema = '$dbname' and table_name='eg_downloadkey'";
        $result_find_tablesize = mysqli_query($GLOBALS["conn"], $find_tablesize);
        $row_find_tablesize = mysqli_fetch_array($result_find_tablesize);

        $find_tablesize2= "select ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024) AS 'accesslogsize' from information_schema.tables where table_schema = '$dbname' and table_name='eg_item_access'";
        $result_find_tablesize2 = mysqli_query($GLOBALS["conn"], $find_tablesize2);
        $row_find_tablesize2 = mysqli_fetch_array($result_find_tablesize2);

        $find_tablesize3= "select ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024) AS 'downloadlogsize' from information_schema.tables where table_schema = '$dbname' and table_name='eg_item_download'";
        $result_find_tablesize3 = mysqli_query($GLOBALS["conn"], $find_tablesize3);
        $row_find_tablesize3 = mysqli_fetch_array($result_find_tablesize3);

        echo "<strong>Current Download Key Size in MB:</strong> <br/>".$row_find_tablesize['downloadkeysize']."MB<br/><br/>";
        echo "<strong>Current Access Log Size in MB:</strong> <br/>".$row_find_tablesize2['accesslogsize']."MB<br/><br/>";
        echo "<strong>Current Download Log Size in MB:</strong> <br/>".$row_find_tablesize3['downloadlogsize']."MB<br/><br/>";
    ?>

    <hr>

    <form action="logclearer.php" method="POST">
        <label for="date1">Date 1:</label>
        <input type="date" id="date1" name="date1" required>
        <br><br>
        <label for="date2">Date 2:</label>
        <input type="date" id="date2" name="date2" required>
        <br><br>
        <button type="submit" name="submit" value="purge" onclick="return confirm('Are you sure?')">Purge Unimportant Data</button> <button type="submit" name="submit" value="clear" onclick="return confirm('Are you sure?')">Clear Records</button>
    </form>
    
    <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['date1']) && isset($_POST['date2']) && $_POST['submit'] == 'purge') {

            echo "<br/><u>Output from:</u> <strong>".$_POST['date1']." to ".$_POST['date2']."</strong><br/>";
            sfx_echoPopupAlert("Nothing done. This function has been deprecated", 'link', 'logclearer.php');
            
        } elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['date1']) && isset($_POST['date2']) && $_POST['submit'] == 'clear') {
            
            $date1 = $_POST['date1']." 00:00:00";
            $date2 = $_POST['date2']." 23:59:59";
            // Convert dates to timestamps
            $timestamp1 = strtotime($date1);
            $timestamp2 = strtotime($date2);

            //code to clear logs
            $stmt_del = $new_conn->prepare("delete from eg_downloadkey where timestamped>=? and timestamped<=?");
            $stmt_del->bind_param("ss", $timestamp1, $timestamp2);
            $stmt_del->execute();$stmt_del->close();

            $stmt_del = $new_conn->prepare("delete from eg_item_access where STR_TO_DATE(39logdate, '%a %d/%m/%Y %h:%i %p') between ? and ?");
            $stmt_del->bind_param("ss", $date1, $date2);
            $stmt_del->execute();$stmt_del->close();

            $stmt_del = $new_conn->prepare("delete from eg_item_download where STR_TO_DATE(39logdate, '%a %d/%m/%Y') between ? and ?");
            $stmt_del->bind_param("ss", $date1, $date2);
            $stmt_del->execute();$stmt_del->close();

            sfx_echoPopupAlert("Logs cleared from $date1 ($timestamp1) and $date2 ($timestamp2).", 'link', 'logclearer.php');
        }
    ?>

    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
