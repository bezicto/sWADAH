<?php
/*
Filename: sw_splus/convertkey.php
Usage: Convert AES key to new one. Must follow directions provided by this page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "AES Key Convert Tool";
    session_start();define('includeExist', true);
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
        
    <?php
    
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken && $_REQUEST["submitted"] == "Update") {
                if (!empty($_REQUEST["old1"]) && !empty($_REQUEST["new1"])) {
                    //for eg_auth
                    $query_fdb = "select id, AES_DECRYPT(syspassword,'".$_REQUEST["old1"]."') as syspassword from eg_auth";
                    $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);
                    while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                        $id_fdb = $myrow_fdb["id"];
                        $password_fdb = $myrow_fdb["syspassword"];
                        //will only update the password when the old aeskey can provide the decrypted passcode
                        if ($password_fdb != '') {
                            $stmt_update = $new_conn->prepare("update eg_auth set syspassword=AES_ENCRYPT(?,'".$_REQUEST["new1"]."') where id=?");
                            $stmt_update->bind_param("si", $password_fdb, $id_fdb);
                            $stmt_update->execute();$stmt_update->close();
                        }
                    }
                    
                    //for eg_auth_depo
                    $query_gdb = "select id, AES_DECRYPT(userpass,'".$_REQUEST["old1"]."') as syspassword from eg_auth_depo";
                    $result_gdb = mysqli_query($GLOBALS["conn"], $query_gdb);
                    while ($myrow_gdb = mysqli_fetch_array($result_gdb)) {
                        $id_gdb = $myrow_gdb["id"];
                        $password_gdb = $myrow_gdb["syspassword"];
                        //will only update the password when the old aeskey can provide the decrypted passcode
                        if ($password_gdb != '') {
                            $stmt_update = $new_conn->prepare("update eg_auth_depo set userpass=AES_ENCRYPT(?,'".$_REQUEST["new1"]."') where id=?");
                            $stmt_update->bind_param("si", $password_gdb, $id_gdb);
                            $stmt_update->execute();$stmt_update->close();
                        }
                    }
                    sfx_echoPopupAlert("AES Key update success. Please logout and login again.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s). The record has been restored to it original state.");
            }
        }
    
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>
            AES Converter Tool. This tool will convert existing password that uses current AES Key to a new AES Key. <br/>
            Current AES Key is set to: <span style='color:green;'><?php echo $aes_key;?></span><br/><br/>
            <span style='color:red;'>
            <i class="fas fa-exclamation-triangle fa-2xl"></i><br/><br/>
            CAUTION ! CAUTION ! CAUTION !<br/>
            It is important to always write down somewhere safe all AES Key that have been assigned to this system.<br/>
            And always a best practice to backup the entire database before using this tool as precautions.<br/><br/>
            After changing to the new AES Key using this tool, please logout, then change the value inside <u>config.php</u>. After that, please login again.
            </span>
        </strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
            <form action="convertkey.php" method="post" enctype="multipart/form-data">
                
                <input type="checkbox" id="confirm1" name="confirm1" required>
                <label for="confirm1"> I understand the risks of this operation and I really need to use this conversion tool.</label><br/><br/><br/>

                <strong>Current AES Key: </strong>
                <br/>
                <input type="text" name="old1" style="width:50%" required maxlength="250" value=""/>
                
                <br/><br/>
                <strong>New AES Key: </strong>
                <br/>
                <input type="text" name="new1" style="width:50%" required maxlength="250" value=""/>

                <br/><br/><br/>
                <input type="hidden" name="submitted" value="Update" />
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="Update" />
                <input type="button" value="Cancel" onclick="location.href='convertkey.php';">
            </form>
        </td>
        </tr>
    </table>
    
    <hr>

    <?php include_once '../sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
