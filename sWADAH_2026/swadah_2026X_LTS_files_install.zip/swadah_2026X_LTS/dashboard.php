<?php
/*
Filename: dashboard.php
Usage: Patron main user page after logging-in
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "My Account";
    session_start();define('includeExist', true);
    
    include_once 'core.php';
    include_once 'sw_inc/access_isset_guest.php';
    include_once 'sw_inc/functions.php';

    $_SESSION[$ssn.'previous_url'] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    if (isset($_GET['rb']) && is_numeric($_GET['rb'])) {
        $stmt_chargeid = $new_conn->prepare("select id from eg_item_charge where 39patron=? and 38accessnum=? and 40dc='NO'");
            $stmt_chargeid->bind_param("si", $_SESSION[$ssn.'username_guest'], $_GET['rb']);
            $stmt_chargeid->execute();$stmt_chargeid->store_result();
            $stmt_chargeid->bind_result($id_charge);
            $stmt_chargeid->fetch();$stmt_chargeid->close();

        if ($id_charge != '') {
            $stmt_update = $new_conn->prepare("update eg_item_charge set 40dc='DC', 40dc_on='".time()."', 40dc_by=? where 39patron=? and 38accessnum=? and 40dc != 'DC'");
                $stmt_update->bind_param("ssi", $_SESSION[$ssn.'username_guest'], $_SESSION[$ssn.'username_guest'], $_GET['rb']);
                $stmt_update->execute();$stmt_update->close();
        }
    }
?>

<html lang='en'>

<head>
    <?php include_once 'sw_inc/header.php'; ?>
</head>

<body class='<?= $color_scheme;?>'>
    
    <?php
        include_once 'sw_inc/navbar_guest.php';
        $append_g = (isset($_GET['u']) && $_GET['u'] == 'g') ? "&u=g" : '';
    ?>
            
    <br/>
    
    <table class=whiteHeader>
        <tr class=<?= $color_scheme."HeaderCenter";?>>
            <td>Bookmarked items history
                <?php
                    echo isset($_GET['s']) && $_GET['s'] == 'all'
                    ? "[<a href='dashboard.php?s=no$append_g'>Show current bookmarks</a>]"
                    : "[<a href='dashboard.php?s=all$append_g'>Show all</a>]";
                ?>
            </td>

        </tr>
        <tr>
            <td>
                <table class=whiteHeader>
                <tr class=whiteHeaderCenter>
                    <td colspan=2 style='text-align:left;'>Title</td>
                    <td>Last Bookmarked</td>
                    <td>Option</td>
                </tr>
                <?php
                    $query_itemcharged = "select * from eg_item_charge where 39patron='".$_SESSION[$ssn.'username_guest']."'";
                    $query_itemcharged .= isset($_GET['s']) && $_GET['s'] == 'all' ? " order by 39charged_on desc" : " and 40dc='NO' order by 39charged_on desc";
                        $result_itemcharged = mysqli_query($GLOBALS["conn"], $query_itemcharged);
                    
                    $n = 1;
                    $totalunpaid = 0.00;
                    while ($myrow_itemcharged = mysqli_fetch_array($result_itemcharged)) {
                        $id = $myrow_itemcharged["id"];
                        $patron = $myrow_itemcharged["39patron"];
                        $accessnum = $myrow_itemcharged["38accessnum"];
                        $charged_on = $myrow_itemcharged["39charged_on"];
                        $duedate_mp = $myrow_itemcharged["39duedate"];
                        $dc_on = $myrow_itemcharged["40dc_on"];
                        $dc = $myrow_itemcharged["40dc"];
                                                        
                        echo "<tr class=$color_scheme"."Hover>
                                <td>$n</td>
                                <td style='text-align:left;'>";
                                    if (sfx_sGetValue("id", "eg_item", "38accessnum", $accessnum) != '') {
                                        echo "<a href='detailsg.php?det=".sfx_sGetValue("id", "eg_item", "38accessnum", $accessnum)."&bk=1'>".stripslashes(sfx_sGetValue("38title", "eg_item", "38accessnum", $accessnum))."</a>";
                                    } else {
                                        echo "<em>Item has been deleted.</em>";
                                    }
                            echo "</td>
                                <td>".date('D, Y-m-d h:i:s a', $charged_on)."</td>
                                <td>";
                                    if (sfx_getDischargeStatus($_SESSION[$ssn.'username_guest'], $accessnum) == 'NO') {
                                        echo "[<a href='dashboard.php?rb=$accessnum"."$append_g' onclick=\"return confirm('Are you sure to remove this bookmark?')\">Remove Bookmark</a>]";
                                    } else {
                                        echo "Unbookmarked on ".date('D, Y-m-d h:i:s a', $dc_on);
                                    }
                            echo "</td>
                        </tr>";
                        $n = $n + 1;
                    }
                ?>
                </table>
            </td>
        </tr>
    </table>

    <br/>
    
    <?php include_once 'sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
