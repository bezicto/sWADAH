-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 21, 2025 at 04:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ercdb_2026x_install`
--

-- --------------------------------------------------------

--
-- Table structure for table `config_user`
--

CREATE TABLE `config_user` (
  `id` int(11) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `cdesc` varchar(2000) NOT NULL,
  `cvalue` varchar(4000) NOT NULL,
  `cvalue_default` varchar(4000) NOT NULL,
  `ctype` varchar(15) NOT NULL,
  `possible_values` varchar(255) NOT NULL,
  `important` varchar(5) NOT NULL DEFAULT 'false',
  `dc_element` varchar(70) NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `config_user`
--

INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES
(1, 'debug_mode', 'debugging mode yes|no', 'no', 'no', 'system', 'yes|no', 'false', 'false'),
(3, 'date_default_timezone_set', 'set php time zone reference: https://www.php.net/manual/en/timezones.php', 'Asia/Kuala_Lumpur', 'Asia/Kuala_Lumpur', 'system', '', 'false', 'false'),
(4, 'system_path', 'repository url (mention the subdirectory, if applicable) must begin with http:// or https:// and end with / eg. https://myir.myuni.edu/myrepo/ (if subdirectory) or https://myir.myuni.edu/ (if no subdirectory)', 'https://mydomain.institution.edu/myrepo/', 'https://mydomain.institution.edu/myrepo/', 'system', '', 'true', 'false'),
(5, 'system_identifier', 'system identifier (preferaby a domain without leading http or https) -- for in use at oai-pmh module', 'mydomain.institution.edu', 'mydomain.institution.edu', 'system', '', 'true', 'false'),
(6, 'system_policy_url', 'repository policy url', 'https://mydomain.institution.edu/policy.pdf', 'https://mydomain.institution.edu/policy.pdf', 'system', '', 'false', 'false'),
(7, 'system_function', 'repo : repository only | depo : self deposit mode only | full : self deposit and repository | photo : photo repository', 'repo', 'repo', 'system', 'repo|depo|full|photo', 'true', 'false'),
(8, 'system_mode', 'system running mode live|demo|maintenance in \'demo\' mode: password changing, user management module will be disabled. in \'maintenance\' mode: the searcher and user portion of this system will be disabled.', 'live', 'live', 'system', 'live|demo|maintenance', 'false', 'false'),
(9, 'system_title', 'system title - give a title to your sWADAH installation', 'sWADAH', 'sWADAH', 'system', '', 'true', 'false'),
(10, 'system_ip', 'this server ip address (internal network ip only)', '10.10.1.11', '10.10.1.11', 'system', '', 'true', 'false'),
(11, 'system_admin_contact_disclaimer', 'admin contact disclaimer. html5 enabled. you may use html tag on it to control size etc.', 'If you have enquiries, kindly contact us at contactus@swadah.com or 01-2345678', 'If you have enquiries, kindly contact us at contactus@swadah.com or 01-2345678', 'system', '', 'false', 'false'),
(12, 'system_owner', 'registered owner', 'sWADAH Support Unit', 'sWADAH Support Unit', 'system', '', 'true', 'false'),
(13, 'ezproxy_ip', 'set your ezproxy ip server here (if you have no ezproxy server, just type in your server ip address here). if sWADAH detected user access from ezproxy, the sWADAH automagically will enable full text access (if permittable)', '10.10.1.12', '10.10.1.12', 'system', '', 'false', 'false'),
(14, 'ezproxy_appended_domain', 'url that appended by ezproxy for this repository. it might look something like this sample url. http or https will not be required.', 'mydomain_institution_edu.ezproxy.institution.edu', 'mydomain_institution_edu.ezproxy.institution.edu', 'system', '', 'false', 'false'),
(15, 'main_logo', 'location of main logo to be displayed at front page and various oither pages. default is sw_asset/img/swadah_logo.png', 'sw_asset/img/swadah_logo.png', 'sw_asset/img/swadah_logo.png', 'gui', '', 'true', 'false'),
(16, 'main_logo_width', 'can be px or %', '50%', '50%', 'gui', '', 'false', 'false'),
(17, 'intro_words', 'intro words below the main logo. html5 enabled. you may use html tag on it to control size etc.', 'Welcome to sWADAH Digital Repository. This is developed by Tuanku Bainun Library for all libraries in the world. Welcome.', 'Welcome to sWADAH Digital Repository. This is developed by Tuanku Bainun Library for all libraries in the world. Welcome.', 'gui', '', 'true', 'false'),
(18, 'show_main_body_background_image', 'show background image for the main page true|false', 'false', 'false', 'gui', 'true|false', 'false', 'false'),
(19, 'main_body_background_image', 'the location of the background if enabled', 'sw_asset/img/bodybackground.jpg', 'sw_asset/img/bodybackground.jpg', 'gui', '', 'false', 'false'),
(20, 'browser_icon', 'browser mini icon on the title bar', 'sw_asset/img/swadah_icon_www.png', 'sw_asset/img/swadah_icon_www.png', 'gui', '', 'false', 'false'),
(21, 'menu_icon', 'menu icon for the navigation menu bar', 'sw_asset/img/swadah_big_icon.png', 'sw_asset/img/swadah_big_icon.png', 'gui', '', 'false', 'false'),
(22, 'footer_font_size', 'control footer font size. in px.', '8px', '8px', 'gui', '', 'false', 'false'),
(23, 'show_build_number_on_footer', 'show build number on footer', 'false', 'false', 'gui', 'true|false', 'false', 'false'),
(24, 'show_admin_login_link', 'show admin login link on meta. if you set this to false, to access is by calling in.php', 'false', 'false', 'gui', 'true|false', 'false', 'false'),
(26, 'show_browser_bar_guest', 'allow or not guest to access browser bar', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(27, 'show_browser_bar_admin', 'allow or not admin to access browser bar', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(28, 'show_subject_browser_bar', 'allow or not subject browser to be shown', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(29, 'show_publisher_browser_bar', 'allow or not publisher browser to be shown', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(30, 'show_year_browser_bar', 'allow or not year browser to be shown', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(31, 'show_folder_browser_bar', 'allow or not folder browser to be shown', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(32, 'allow_user_to_login', 'allow user to login to their page, enable the My Account button and Login link', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(33, 'enable_feedback_function', 'enable or disable registered user feedback for items if user are allowed to login', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(34, 'searcher_type_bar_visibility', 'search input bar on index page', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(36, 'system_wide_resultPerPage', 'for paging purposes, how many number per page per resultset', '20', '20', 'gui', '', 'false', 'false'),
(37, 'searcher_title_font_size', 'title font size in pixel', '16px', '16px', 'gui', '', 'false', 'false'),
(38, 'searcher_author_font_size', 'author font size in pixel', '14px', '14px', 'gui', '', 'false', 'false'),
(39, 'searcher_hits_font_size', 'hits count font size in pixel', '10px', '10px', 'gui', '', 'false', 'false'),
(40, 'searcher_show_icon_indicator', 'show (true) or hide (false) indicators on guest search page for results (below the title description)', 'false', 'false', 'gui', 'true|false', 'false', 'false'),
(41, 'ip_fence_enabled', 'searcher access only for permitted IP addresses/range input using Administration > Allowed IP configuration. default is false to allow all', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(42, 'remove_word_from_title', 'if title has any of these pattern, it will be unseen. items must be comma separated. affected only the search result.', '(IR),(SCOPUS)', '(IR),(SCOPUS)', 'system', '', 'false', 'false'),
(43, 'show_qr_code_for_item', 'show_qr_code_for_item : show or hide qr code on item detail page', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(44, 'copyright_info', 'disclaimer or copyright info for detail page. html5 enabled. you may use html tag on it to control size etc.', 'This material may be protected under Copyright Act which governs the making of photocopies or reproductions of copyrighted materials.<br/>You may use the digitized material for private study, scholarship, or research.', 'This material may be protected under Copyright Act which governs the making of photocopies or reproductions of copyrighted materials.<br/>You may use the digitized material for private study, scholarship, or research.', 'system', '', 'false', 'false'),
(45, 'embargoed_duration', 'default embargoed duration. if item is set it status to embargo, how long it would take to automatically set it back to available. in days.', '365', '365', 'system', '', 'false', 'false'),
(46, 'default_password_if_forgotten', 'set the default password to reset whenever reset password tool is used by admin for a user', '1', '1', 'system', '', 'false', 'false'),
(47, 'default_create_password', 'default creation password when creating new user', '1', '1', 'system', '', 'false', 'false'),
(48, 'default_num_attempt_login', 'num of login attempt before blocking mechanism start', '5', '5', 'system', '', 'false', 'false'),
(49, 'system_statcache_directory', 'cache directory for statistic generator', 'files/statcache', 'files/statcache', 'dirloca', '', 'false', 'false'),
(50, 'invalid_access_detection', 'system intruder detection mode for all guest enabled page such as searcher.php and all title listers: subject heading, year, publisher browsers. \'strict\' =user input will be sanitize AND will automatically block access to all related pages within even one try of invalid access/query. \'precaution\' =user input will be sanitize AND will automatically block access to all related pages within 5 invalid accesses/queries. \'guard\' =default, user input will be sanitize and will not be block until reached a hard limit of 99 invalid queries. should he/she cross that line, the access will be blocked. redirection to default page will be enforced. all above incidents are stored in files/blocked/ all bans will only valid for one day. will be automatically cleared the next day.', 'precaution', 'precaution', 'system', 'strict|precaution|guard', 'false', 'false'),
(51, 'recorded_incidents_directory', 'incidents are stored in this location', 'files/blocked', 'files/blocked', 'dirloca', '', 'false', 'false'),
(52, 'enable_folder', 'secure folder function', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(53, 'usePdfInfo', 'pdfinfo will show number of page on detail page. true | false.', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(54, 'max_page_toshow_red_color', 'what minimum page number when the total page number will be shown with red color when usePdfInfo is set to true', '30', '30', 'system', '', 'false', 'false'),
(55, 'max_download_allowed', 'the number of count digital document will be available before it is expired (per user session)', '3', '3', 'system', '', 'false', 'false'),
(56, 'max_time_link_availability', 'duration in seconds on which the digital document will be available before it is expired.', '86400', '86400', 'system', '', 'false', 'false'),
(57, 'enable_oai_pmh', 'oai-pmh enabler. true = enabled OAI-PMH request, false = disable', 'false', 'false', 'oai', 'true|false', 'false', 'false'),
(58, 'oai_rights', 'openAccess | restrictedAccess | closedAccess | embargoedAccess', 'openAccess', 'openAccess', 'oai', 'openAccess|restrictedAccess|closedAccess|embargoedAccess', 'false', 'false'),
(59, 'oai_main_language', 'must be in ISO 639-3 format', 'eng', 'eng', 'oai', '', 'false', 'false'),
(60, 'oai_main_format', 'oai-pmh format for display', 'text', 'text', 'oai', '', 'false', 'false'),
(61, 'enable_searcher_api', 'enable or disable access to SEARCHER API', 'false', 'false', 'api', 'true|false', 'false', 'false'),
(62, 'delete_method', 'item delete method : \'permanent\': item and all its detailing will be deleted entirely from the system. \'takecover\' : item will be set to undiscoverable, a hide button will appear instead of delete button. resources will be renamed to <filename>.<extension>.deleted', 'permanent', 'permanent', 'system', 'permanent|takecover', 'false', 'false'),
(63, 'default_view_input', 'marc | simple', 'simple', 'simple', 'system', '', 'true', 'false'),
(64, 'show_accession_number', 'accession number visibility on item detail page', 'false', 'false', 'gui', 'true|false', 'false', 'false'),
(65, 'show_control_number', 'control number visibility on item detail page', 'false', 'false', 'gui', 'true|false', 'false', 'false'),
(66, 'type_as', 'rebrand or reuse item type as', 'Type', 'Type', 'metadata', '', 'false', 'false'),
(67, 'enable_subject_entry', 'enable subject heading selection in input and update page', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(68, 'subject_heading_as', 'rebrand subject heading as -  this will utilize/repurpose subject heading for a different means', 'Subject', 'Subject', 'metadata', '', 'false', 'false'),
(69, 'subject_heading_delimiter', 'if multiple subject heading can be selected, this will be the delimiter', ',', ',', 'metadata', '', 'false', 'false'),
(70, 'subject_heading_selectable', 'selectable subject heading : \'single\' will only able to select one | \'multi\' will be able to select multiple subject headings', 'multi', 'multi', 'metadata', 'single|multi', 'false', 'false'),
(71, 'init_status_visibility', 'hide|show initial status on add new item page. if hide, default will always be Available-Public', 'show', 'show', 'system', 'show|hide', 'false', 'false'),
(72, 'default_is_abstract', 'full text input field will be abstract', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(73, 'enable_fulltext_abstract_composer', 'enable full text/abstract composer in add new / update', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(74, 'fulltext_abstract_composer_type', 'simpletext | richtext', 'richtext', 'richtext', 'system', 'simpletext|richtext', 'false', 'false'),
(75, 'enable_reference_composer', 'enabled reference composer in add new / update', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(76, 'reference_composer_type', 'simpletext | richtext', 'richtext', 'richtext', 'system', 'simpletext|richtext', 'false', 'false'),
(77, 'system_docs_directory', 'full text document for uploading new item directory location', 'files/docs', 'files/docs', 'dirloca', '', 'false', 'false'),
(78, 'system_allow_document_extension', 'full text document extensions', 'pdf', 'pdf', 'dir', '', 'false', 'false'),
(79, 'system_allow_document_maxsize', 'full text document max file size in MB', '100', '100', 'dir', '', 'false', 'false'),
(81, 'index_pdf', 'allow indexing to the uploaded full text document', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(82, 'system_pdocs_directory', 'guest document for uploading new item directory location', 'files/pdocs', 'files/pdocs', 'dirloca', '', 'false', 'false'),
(83, 'system_allow_pdocument_extension', 'guest document extensions', 'pdf', 'pdf', 'dir', '', 'false', 'false'),
(84, 'system_allow_pdocument_maxsize', 'guest document max file size in MB', '20', '20', 'dir', '', 'false', 'false'),
(85, 'allow_guestpdf_insert_by_admin', 'allow guest file input to be inserted for an item', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(87, 'system_txts_directory', 'text file for uploading new item directory location', 'files/txts', 'files/txts', 'dirloca', '', 'false', 'false'),
(88, 'system_allow_txt_extension', 'text file extensions', 'txt', 'txt', 'dir', '', 'false', 'false'),
(89, 'system_allow_txt_maxsize', 'text file max file size in MB', '5', '5', 'dir', '', 'false', 'false'),
(90, 'allow_txt_insert_by_admin', 'allow text file input to be inserted', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(91, 'system_isofile_directory', 'misc file type for uploading new item directory location', 'files/isofile', 'files/isofile', 'dirloca', '', 'false', 'false'),
(92, 'system_isofile_name', 'misc file name', 'FreeType', 'FreeType', 'dir', '', 'false', 'false'),
(93, 'system_allow_isofile_extension', 'allowed file extensions', 'iso,zip,xlsx,pptx', 'iso,zip,xlsx,pptx', 'dir', '', 'false', 'false'),
(94, 'system_allow_isofile_maxsize', 'allowed max filesize for misc file in MB', '10', '10', 'dir', '', 'false', 'false'),
(95, 'allow_isofile_insert_by_admin', 'allow misc file input to be inserted', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(97, 'system_albums_directory', 'image attachment directory location for uploading new item', 'files/albums', 'files/albums', 'dirloca', '', 'false', 'false'),
(98, 'watermark_overlay_file', 'in use for image upload, will be automatically watermarked, must be transparent and png', 'sw_asset/img/watermark.png', 'sw_asset/img/watermark.png', 'system', '', 'false', 'false'),
(99, 'system_albums_thumbnail_directory', 'location of thumbnail directory', 'files/albums_thumbnailed', 'files/albums_thumbnailed', 'dirloca', '', 'false', 'false'),
(100, 'system_albums_watermark_directory', 'location of watermarked image directory', 'files/albums_watermarked', 'files/albums_watermarked', 'dirloca', '', 'false', 'false'),
(101, 'system_allow_imageatt_extension', 'allowed extensions for image attachments', 'jpg,jpeg', 'jpg,jpeg', 'dir', '', 'false', 'false'),
(102, 'system_allow_imageatt_maxsize', 'allowed max size for a single image attachment', '10', '10', 'dir', '', 'false', 'false'),
(103, 'maximum_num_imageatt_allowed', 'maximum number of additional image attachment allowed', '20', '20', 'system', '', 'false', 'false'),
(104, 'allow_image_insert_by_admin', 'allow image attachment function for item input', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(106, 'allow_confidential_setup', 'allow self deposit user to set item confidentiality', 'true', 'true', 'sdepo', 'true|false', 'false', 'false'),
(107, 'enable_self_activation', 'allow self deposit user to self activate themselves via email links', 'false', 'false', 'sdepo', 'true|false', 'false', 'false'),
(108, 'enable_tutorial_button', 'enable tutorial button for self deposit', 'false', 'false', 'sdepo', 'true|false', 'false', 'false'),
(109, 'tutorial_link', 'link must for self submission. complete URL with http:// or https:// if tutorial button is set to true', 'https://mydomain.institution.edu/tutorial.pdf', 'https://mydomain.institution.edu/tutorial.pdf', 'sdepo', '', 'false', 'false'),
(110, 'system_dfile_directory', 'declaration file upload directory for self submission', 'files/depos/d', 'files/depos/d', 'dirloca', '', 'false', 'false'),
(111, 'system_allow_dfile_extension', 'allowed file extension for declaration file for self submission', 'pdf', 'pdf', 'dir', '', 'false', 'false'),
(112, 'system_allow_dfile_maxsize', 'declaration file for self submission max filesize in MB', '10', '10', 'dir', '', 'false', 'false'),
(113, 'system_pfile_directory', 'full text file for self submission upload directory', 'files/depos/p', 'files/depos/p', 'dirloca', '', 'false', 'false'),
(114, 'system_allow_pfile_extension', 'allowed extension for full text file for self submission', 'pdf', 'pdf', 'dir', '', 'false', 'false'),
(115, 'system_allow_pfile_maxsize', 'fulltext file for self submission max filesize in MB', '100', '100', 'dir', '', 'false', 'false'),
(116, 'hide_main_author', 'hide main author input in user deposit page', 'true', 'true', 'sdepo', 'true|false', 'false', 'false'),
(117, 'hide_additional_authors_entry', 'hide additional authors input in user deposit page', 'true', 'true', 'sdepo', 'true|false', 'false', 'false'),
(118, 'allow_declaration_submission', 'allow submission of item declaration in user deposit page', 'true', 'true', 'sdepo', 'true|false', 'false', 'false'),
(119, 'allow_abstract_submission', 'allow abstract submission in user deposit page', 'true', 'true', 'sdepo', 'true|false', 'false', 'false'),
(120, 'show_dateof_publication', 'show (true) or hide (false) date of publication input in user deposit page', 'false', 'false', 'sdepo', 'true|false', 'false', 'false'),
(121, 'depo_grades', 'grades selection separated by commas', 'A,A-,B+,B,B-,C+,C,C-,D+,D,E,F', 'A,A-,B+,B,B-,C+,C,C-,D+,D,E,F', 'sdepo', '', 'false', 'false'),
(122, 'depo_enable_forget_password', 'enable forget password subsystem for depositor', 'false', 'false', 'sdepo', 'true|false', 'false', 'false'),
(123, 'depo_forget_password_wording_if_subsystem_disable', 'if depo_enable_forget_password is set to false, this line will appear for reset password link', 'Please contact us via our support line for password reset.', 'Please contact us via our support line for password reset.', 'sdepo', '', 'false', 'false'),
(124, 'useEmailNotification', 'use email notification for certain feature ? true or false.', 'false', 'false', 'email', 'true|false', 'false', 'false'),
(125, 'emailDebuggerEnable', '0 disable , 1 enable (when enable, redirection will turn off for email sending pages and allow you to see debugging messages)', '0', '0', 'email', '', 'false', 'false'),
(126, 'emailMode', 'ssl|tls|false', 'ssl', 'ssl', 'email', 'ssl|tls|false', 'false', 'false'),
(127, 'emailAuthentication', 'true|false', 'true', 'true', 'email', 'true|false', 'false', 'false'),
(128, 'emailAutoTLS', 'auto tls setting', 'true', 'true', 'email', 'true|false', 'false', 'false'),
(129, 'emailHost', 'email smtp', 'smtp.gmail.com', 'smtp.gmail.com', 'email', '', 'false', 'false'),
(130, 'emailPort', 'email port for smtp', '465', '465', 'email', '', 'false', 'false'),
(131, 'emailUserName', 'username for email', 'actual_sending_user@gmail.com', 'actual_sending_user@gmail.com', 'email', '', 'false', 'false'),
(132, 'emailPassword', 'email password', 'mypassword', 'mypassword', 'email', '', 'false', 'false'),
(133, 'emailSetFrom', 'hide the real sender of email', 'noreply_hide_real_user@gmail.com', 'noreply_hide_real_user@gmail.com', 'email', '', 'false', 'false'),
(134, 'emailSetFromName', 'hide the name of real sender of email', 'sWADAH Mailer', 'sWADAH Mailer', 'email', '', 'false', 'false'),
(135, 'emailFooter', 'footer of the composed email content', '<hr>This is an automated email. Please do not reply to this email. If you have any question regarding your submission, contact us at user@gmail.com', '<hr>This is an automated email. Please do not reply to this email. If you have any question regarding your submission, contact us at user@gmail.com', 'email', '', 'false', 'false'),
(136, 'system_admin_email', 'Administrator Email', 'admin@swadah.com', 'admin@swadah.com', 'system', '', 'false', 'false'),
(138, 'tag_020', 'display text for tag 020 with description', 'ISBN', 'ISBN', 'metadata', '', 'false', 'false'),
(139, 'tag_020_show', 'show tag 020 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(141, 'tag_020_c', 'display text for tag 020|c with description', 'Term of Availability', 'Term of Availability', 'metadata', '', 'false', 'false'),
(142, 'tag_020_c_currency', 'Currency value acronym. See https://www.bws.net/toolbox/currency for more info', 'MYR', 'MYR', 'metadata', '', 'false', 'false'),
(143, 'tag_020_c_show', 'show tag 020|c in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(145, 'tag_022', 'display text for tag 022 with description', 'ISSN', 'ISSN', 'metadata', '', 'false', 'false'),
(146, 'tag_022_show', 'show tag 022 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(148, 'tag_041', 'display text for tag 041 with description', 'Language Code', 'Language Code', 'metadata', '', 'false', 'dc.language'),
(149, 'tag_041_inputtype', 'select|keyin', 'select', 'select', 'metadata', 'select|keyin', 'false', 'false'),
(150, 'tag_041_selectable', 'selectable values. separated with |', 'zsm|eng|chi|tam|ara', 'zsm|eng|chi|tam|ara', 'metadata', '', 'false', 'false'),
(151, 'tag_041_selectable_default', 'default value for tag_041_selectable', 'zsm', 'zsm', 'metadata', '', 'false', 'false'),
(152, 'tag_041_show', 'show tag 041 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(154, 'tag_090', 'display text for tag 090 with description', 'Call Number', 'Call Number', 'metadata', '', 'false', 'false'),
(155, 'tag_090_show', 'show tag 090 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(157, 'tag_100', 'display text for tag 100 with description', 'Main Author', 'Main Author', 'metadata', '', 'false', 'dc.creator'),
(160, 'tag_245', 'display text for tag 245 with description', 'Title', 'Title', 'metadata', '', 'false', 'dc.title'),
(163, 'tag_246', 'display text for tag 246 with description', 'Varying Form of Title', 'Varying Form of Title', 'metadata', '', 'false', 'false'),
(164, 'tag_246_show', 'show tag 246 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(167, 'tag_250', 'display text for tag 250 with description', 'Edition', 'Edition', 'metadata', '', 'false', 'false'),
(168, 'tag_250_show', 'show tag 250 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(170, 'tag_264', 'display text for tag 264 with description', 'Publication', 'Publication', 'metadata', '', 'false', 'dc.publisher'),
(171, 'tag_264_show', 'show tag 264 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(172, 'tag_264_a_default', 'default indicator for tag 246|a', 'Tanjong Malim', 'Tanjong Malim', 'metadata', '', 'false', 'false'),
(174, 'publisher_as', 'Rebrand publisher as something else', 'Publisher', 'Publisher', 'metadata', '', 'false', 'false'),
(175, 'publisher_place_of_production', 'Rebrand publisher place of production', 'Place of Production', 'Place of Production', 'metadata', '', 'false', 'false'),
(176, 'publisher_year_of_publication', 'Rebrand year of publication', 'Year of Publication', 'Year of Publication', 'metadata', '', 'false', 'dc.date'),
(178, 'tag_300', 'display text for tag 300 with description', 'Physical Description', 'Physical Description', 'metadata', '', 'false', 'dc.format'),
(179, 'tag_300_show', 'show tag 300 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(200, 'tag_490', 'display text for tag 490 with description', 'Series', 'Series', 'metadata', '', 'false', 'false'),
(201, 'tag_490_show', 'show tag 490 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(203, 'tag_500', 'display text for tag 500 with description', 'Notes', 'Notes', 'metadata', '', 'false', 'dc.description'),
(204, 'tag_500_hint', 'hint for tag 500 to ease value insert', '', '', 'metadata', '', 'false', 'false'),
(205, 'tag_500_show', 'show tag 500 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(208, 'tag_502', 'display text for tag 502 with description', 'Dissertation Note', 'Dissertation Note', 'metadata', '', 'false', 'false'),
(209, 'tag_502_show', 'show tag 502 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(210, 'tag_502_inputtype', 'keyin|select', 'select', 'select', 'metadata', 'keyin|select', 'false', 'false'),
(211, 'tag_502_b_selectable', 'values must be separated by |', 'Doctoral|Masters|Degree|Diploma|Others', 'Doctoral|Masters|Degree|Diploma|Others', 'metadata', '', 'false', 'false'),
(212, 'tag_502_b_selectable_default', 'values must one from tag_502_b_selectable', 'Degree', 'Degree', 'metadata', '', 'false', 'false'),
(214, 'tag_506', 'display text for tag 506 with description', 'Access Category', 'Access Category', 'metadata', '', 'false', 'false'),
(215, 'tag_506_hint', 'hint for tag 506 to ease value insert', '', '', 'metadata', '', 'false', 'false'),
(216, 'tag_506_show', 'show tag 506 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(218, 'tag_520', 'display text for tag 520 with description', 'Summary', 'Summary', 'metadata', '', 'false', 'false'),
(219, 'tag_520_show', 'show tag 520 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(222, 'tag_600', 'display text for tag 600 with description', 'Subject Added Entry - Personal Name', 'Subject Added Entry - Personal Name', 'metadata', '', 'false', 'false'),
(223, 'tag_600_show', 'show tag 600 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(226, 'tag_650', 'display text for tag 650 with description', 'Subject Entry - Topical Term', 'Subject Entry - Topical Term', 'metadata', '', 'false', 'dc.subject'),
(227, 'tag_650_show', 'show tag 650 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(229, 'tag_700', 'display text for tag 700 with description', 'Additional Authors', 'Additional Authors', 'metadata', '', 'false', 'dc.contributor'),
(230, 'tag_700_show', 'show tag 700 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(233, 'tag_710', 'display text for tag 710 with description', 'Corporate Name', 'Corporate Name', 'metadata', '', 'false', 'false'),
(234, 'tag_710_show', 'show tag 710 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(235, 'tag_710_a_default', 'default indicator for tag 710|a', 'Perpustakaan Tuanku Bainun', 'Perpustakaan Tuanku Bainun', 'metadata', '', 'false', 'false'),
(236, 'tag_710_b_default', 'default indicator for tag 710|b', 'Universiti Pendidikan Sultan Idris', 'Universiti Pendidikan Sultan Idris', 'metadata', '', 'false', 'false'),
(237, 'tag_710_e_default', 'default indicator for tag 710|e', 'Issuing body', 'Issuing body', 'metadata', '', 'false', 'false'),
(240, 'tag_852', 'display text for tag 852 with description', 'Location', 'Location', 'metadata', '', 'false', 'false'),
(241, 'tag_852_show', 'show tag 852 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(243, 'tag_856', 'display text for tag 856 with description', 'HTTP Link', 'HTTP Link', 'metadata', '', 'false', 'false'),
(244, 'tag_856_show', 'show tag 856 in input field true|false', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(245, 'depo_txt_identification', 'Depositor identification ID', 'Matrix Number', 'Matrix Number', 'depo', '', 'false', 'false'),
(246, 'depo_txt_slip_title', 'Title of the generated slip', 'DIGITAL DOCUMENT RECEIVING SLIP', 'DIGITAL DOCUMENT RECEIVING SLIP', 'depo', '', 'false', 'false'),
(247, 'depo_txt_institution', 'Name of institution', 'MY DIGITAL LIBRARY', 'MY DIGITAL LIBRARY', 'depo', '', 'false', 'false'),
(248, 'depo_txt_notvalidslip', 'Invalid slip ID prompt', 'INVALID SLIP ID', 'INVALID SLIP ID', 'depo', '', 'false', 'false'),
(249, 'depo_txt_declaration_to_library', 'Declaration of submission document. (HTML capable)', 'Declaration of submission PDF', 'Declaration of submission PDF', 'depo', '', 'false', 'false'),
(250, 'depo_txt_mandatory_fields', 'Mandatory field wording. (HTML capable)', 'Mandatory fields.<br/><span style=\'color:lightgrey;\'><em>Medan mandatori.</em></span>', 'Mandatory fields.<br/><span style=\'color:lightgrey;\'><em>Medan mandatori.</em></span>', 'depo', '', 'false', 'false'),
(251, 'depo_txt_optional_fields', 'Optional wording. (HTML capable)', 'Optional. Might be required on for certain degree type. Kindly refer to your uploading criteria.<br/><span style=\'color:lightgrey;\'><em>Medan pilihan. Mungkin diperlukan oleh beberapa jenis tahap pengajian. Sila rujuk kembali panduan memuatnaik bagi tahap pengajian anda.</em></span>', 'Optional. Might be required on for certain degree type. Kindly refer to your uploading criteria.<br/><span style=\'color:lightgrey;\'><em>Medan pilihan. Mungkin diperlukan oleh beberapa jenis tahap pengajian. Sila rujuk kembali panduan memuatnaik bagi tahap pengajian anda.</em></span>', 'depo', '', 'false', 'false'),
(252, 'depo_acknowledgement', 'Acknowledgement wording. (HTML capable)', 'Acknowlegdement.<br/><span style=\'color:lightgrey;\'><em>Pengesahan.</em></span>', 'Acknowlegdement.<br/><span style=\'color:lightgrey;\'><em>Pengesahan.</em></span>', 'depo', '', 'false', 'false'),
(253, 'depo_image_institution', 'Location of where logo to be displayed on the slip to be stored.', 'sw_asset/img/swadah_big_icon.png', 'sw_asset/img/swadah_big_icon.png', 'depo', '', 'false', 'false'),
(254, 'depo_para_acceptance_words', 'Words of acceptance. (HTML capable) ^^is fixed value that must be there. ^^name for the depositor name, ^^titlestatement for uploaded item title, ^^useridentity for the depositor ID.', 'Please be informed that your digital document with the title <br/><u><strong>^^titlestatement</strong></u> by <br/><u><strong>^^name</strong></u> with identification ID of <u><strong>^^useridentity</strong></u><br/>has been accepted by us on <u><strong>^^approvedOn</strong></u>.', 'Please be informed that your digital document with the title <br/><u><strong>^^titlestatement</strong></u> by <br/><u><strong>^^name</strong></u> with identification ID of <u><strong>^^useridentity</strong></u><br/>has been accepted by us on <u><strong>^^approvedOn</strong></u>.', 'depo', '', 'false', 'false'),
(255, 'depo_validation', 'Wording for validation of QR code. (HTML capable)', '<br/><div style=\'font-size:x-small;\'>For validation purposes, scan this QR code:</div><br/>', '<br/><div style=\'font-size:x-small;\'>For validation purposes, scan this QR code:</div><br/>', 'depo', '', 'false', 'false'),
(256, 'depo_para_autoremarks', 'This slip is automactically generated wording. (HTML capable)', 'THIS SLIP IS AUTOMATICALLY GENERATED. <br/>NO SIGNATURE IS REQUIRED.', 'THIS SLIP IS AUTOMATICALLY GENERATED. <br/>NO SIGNATURE IS REQUIRED.', 'depo', '', 'false', 'false'),
(257, 'depo_confidentiality_remarks', 'Uploaded confidential remarks and wording. (HTML capable)', '<br/>If the thesis is CONFIDENTIAL or RESTRICTED, please scan and attach with the letter from the organization with period and reasons for confidentiality or restriction.', '<br/>If the thesis is CONFIDENTIAL or RESTRICTED, please scan and attach with the letter from the organization with period and reasons for confidentiality or restriction.', 'depo', '', 'false', 'false'),
(258, 'depo_para_acknowledgement', 'Acknowledgement remarks and wording. (HTML capable)', '<h3 style=\'color:blue;\'>Acknowledgement:</h3>I hereby acknowledged that MY DIGITAL LIBRARY reserves the right as follows:-</em><br/><br/>\r\n<ol>\r\n<li>The thesis is the property of MY DIGITAL LIBRARY.</li><br/>\r\n<li>The Library has the right to make copies for the purpose of reference and research.</li><br/>\r\n<li>The Library has the right to make copies of the thesis for academic exchange.</li><br/>\r\n</ol>', '<h3 style=\'color:blue;\'>Acknowledgement:</h3>I hereby acknowledged that MY DIGITAL LIBRARY reserves the right as follows:-</em><br/><br/>\r\n<ol>\r\n<li>The thesis is the property of MY DIGITAL LIBRARY.</li><br/>\r\n<li>The Library has the right to make copies for the purpose of reference and research.</li><br/>\r\n<li>The Library has the right to make copies of the thesis for academic exchange.</li><br/>\r\n</ol>', 'depo', '', 'false', 'false'),
(259, 'max_allow_parser_to_work', 'pdf file in MB where a parser engine will parse the pdf, anything bigger pdf will not be indexed.', '20', '20', 'system', '', 'false', 'false'),
(260, 'strip_tags_fulltext_abstract_composer', 'strip all html tags on full text/abstract composer value', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(261, 'strip_tags_reference_composer', 'strip all html tags on reference composer value', 'true', 'true', 'system', 'true|false', 'false', 'false'),
(262, 'item_count_generator', 'browser count generator. for subject, publisher and year browser : daily | live (live will be slower). daily will generate after 24 hours later.', 'daily', 'daily', 'system', 'daily|live', 'false', 'false'),
(263, 'report_count_generator', 'report statistic generator count : daily | live (live will be slower). daily will generate after 24 hours later.', 'daily', 'daily', 'system', 'daily|live', 'false', 'false'),
(268, 'enable_commercial_api', 'Enable items to be commercialized. Will enable Commercial Token Management and API Access.', 'false', 'false', 'api', 'true|false', 'false', 'false'),
(270, 'enable_related_files_upload', 'This will enable or disable related files field when viewing details of an item.', 'false', 'false', 'system', 'true|false', 'false', 'false'),
(271, 'tmpal_delete_method', 'Temporary Access Link Delete Method. delete: will delete after expiry | keep: will keep log in the database', 'delete', 'delete', 'system', 'delete|keep', 'false', 'false'),
(273, 'tag_522_show', 'show tag 522 on item insert/update page', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(274, 'tag_534_show', 'show tag 534 on item insert/update page', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(275, 'tag_540_show', 'show tag 540 on item insert/update page', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(276, 'tag_787_show', 'show tag 787 on item insert/update page', 'true', 'true', 'metadata', 'true|false', 'false', 'false'),
(277, 'tag_522', 'full description of tag 522', 'Geographic Coverage Note', 'Geographic Coverage Note', 'metadata', '', 'false', 'dc.coverage'),
(278, 'tag_534', 'full description of tag 534', 'Original Version Note', 'Original Version Note', 'metadata', '', 'false', 'dc.source'),
(279, 'tag_540', 'full description of tag 540', 'Terms of Governing Use', 'Terms of Governing Use', 'metadata', '', 'false', 'dc.rights'),
(280, 'tag_787', 'full description of tag 787', 'Other Relationship Entry', 'Other Relationship Entry', 'metadata', '', 'false', 'dc.relation'),
(285, 'tag_700_e', 'simple text for tag 700 |e', 'Role', 'Role', 'metadata', '', 'false', 'false'),
(287, 'color_scheme', 'control color scheme of certain element on sWADAH. bluish is more towards blue and yellow is subtle yellowish color scheme', 'bluish', 'bluish', 'gui', 'bluish | yellow', 'false', 'false'),
(288, 'tag_502_b', 'display text for tav 502 |b', 'Degree Type', 'Degree Type', 'metadata', '', 'false', 'false'),
(289, 'youtube_detector', 'if HTTP link (tag 856) is sourced from youtube, it will show embedded player on top of detail page.', 'true', 'true', 'gui', 'true|false', 'false', 'false'),
(290, 'system_docs_login_warning', 'full text document access warning when not login', 'Login required to access this item.', 'Login required to access this item.', 'dir', '', 'false', 'false'),
(291, 'show_meta_oai_link', 'show oai link on index page', 'false', 'false', 'oai', 'true|false', 'false', 'false'),
(292, 'show_meta_searcherapi_link', 'show searcher api link on index page', 'false', 'false', 'api', 'true|false', 'false', 'false'),
(293, 'depo_max_deposit', 'max deposit for item submitted through self deposit', '1', '1', 'sdepo', 'any integer value', 'false', 'false'),
(294, 'tmpal_access_duration', 'access duration in second for the temporary access link for item', '86400', '86400', 'system', 'any integer value, it will represent seconds', 'false', 'false'),
(295, 'tmpal_access_count', 'access counts permitted for the temporary access link for item', '3', '3', 'system', 'number of refresh/access for temporary access link detail page', 'false', 'false'),
(296, 'system_pdf_viewer', 'default pdf viewer for sWADAH. pdfjs will use pdfjs as viewer, direct will output pdf directly to browser', 'pdfjs', 'pdfjs', 'system', 'pdfjs|direct', 'false', 'false'),
(297, 'searcher_active_popular_keyword', 'show popular keyword of the day at the top of searcher page', 'false', 'false', 'gui', 'true|false', 'false', 'false');

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth`
--

CREATE TABLE `eg_auth` (
  `id` int(5) NOT NULL,
  `username` varchar(15) NOT NULL,
  `syspassword` longtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usertype` varchar(255) NOT NULL DEFAULT 'FALSE',
  `name` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `publisheradmin` varchar(255) NOT NULL DEFAULT 'ALL',
  `lastlogin` varchar(25) DEFAULT NULL,
  `online` varchar(3) NOT NULL DEFAULT 'OFF',
  `num_attempt` int(5) NOT NULL DEFAULT 0,
  `input_count` int(11) NOT NULL DEFAULT 0,
  `timestamp_count` varchar(25) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_depo`
--

CREATE TABLE `eg_auth_depo` (
  `id` int(5) NOT NULL,
  `useridentity` varchar(25) NOT NULL,
  `userpass` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `emailaddress` varchar(255) DEFAULT NULL,
  `phonenum` varchar(255) NOT NULL DEFAULT 'OFF',
  `regtimestamp` varchar(255) NOT NULL,
  `activation` varchar(25) NOT NULL DEFAULT 'NOTACTIVE',
  `num_attempt` int(5) NOT NULL DEFAULT 0,
  `registerkey` varchar(500) NOT NULL,
  `totalpost` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_eligibility`
--

CREATE TABLE `eg_auth_eligibility` (
  `id` int(11) NOT NULL,
  `usertype` varchar(255) NOT NULL,
  `usertypedesc` varchar(255) NOT NULL,
  `max_loanitem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `eg_auth_eligibility`
--

INSERT INTO `eg_auth_eligibility` (`id`, `usertype`, `usertypedesc`, `max_loanitem`) VALUES
(1, 'SUPER', 'Administrator', 999),
(2, 'STAFF', 'Basic Administrative Account', 999),
(3, 'FALSE', 'Deactivated Account', 0),
(4, 'PATRON', 'Patron Account', 999),
(5, 'LINKP', 'Link Provider', 1),
(6, 'DEPATRON', 'Deactivated Patron (only for Patron)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_ip`
--

CREATE TABLE `eg_auth_ip` (
  `id` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_commercialize`
--

CREATE TABLE `eg_commercialize` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `since` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_commercial_token`
--

CREATE TABLE `eg_commercial_token` (
  `43tokenid` int(11) NOT NULL,
  `43desc` varchar(255) NOT NULL,
  `43token` varchar(255) NOT NULL,
  `44totalaccess` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_composer`
--

CREATE TABLE `eg_composer` (
  `id` int(11) NOT NULL,
  `45name` varchar(255) NOT NULL,
  `45desc` varchar(255) NOT NULL,
  `45value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eg_composer`
--

INSERT INTO `eg_composer` (`id`, `45name`, `45desc`, `45value`) VALUES
(1, 'FAQ', 'Frequently Asked Questions', '<table style=\'background-color:white;\'>			\r\n<tr>\r\n<td colspan=2 style=\'font-size:16px;\'>\r\n<br/><br/><a href=\'#1\' style=\'text-decoration:none\'>1. The result list only shows up to 10 items but the result is more than that. How can I navigate to the next page ?</a>\r\n<br/><br/><a href=\'#2\' style=\'text-decoration:none\'>2. What is <em>exploded search term</em> ?</a>\r\n<br/><br/><a href=\'#3\' style=\'text-decoration:none\'>3. Is there any time-out when using the search function ?</a>\r\n<br/><br/><a href=\'#4\' style=\'text-decoration:none\'>4. Why some of words in my search terms did not being included in the search results ?</a>\r\n</td>\r\n</tr>\r\n<tr class=greyHeaderCenter><td colspan=2><div style=\'text-align:center;font-size:14px;\'><strong>Questions and Answers</strong></div></td></tr>\r\n<tr>\r\n<td colspan=2>\r\n<br/><a id=\'1\'>1. The result list only shows up to 10 items but the result is more than that. How can I navigate to the next page ?</a>\r\n<br/><span style=\'color:green;\'>At the bottom of the results list, you may see the navigation toolbar to browse to the next page of the resultset. Use \'Next\' to navigate further or \'Previous\' for prior pages.</span><br/><br/><a id=\'2\'>2. What is <em>exploded search term</em> ?</a>\r\n<br/><span style=\'color:green;\'>Whenever you typed multiple value in the search box, the \'Exploded Search Term\' function will be activated and separate those multiple value into segmented search entries. Click on any of those segmented search term will redo the search function using the new search term.</span><br/><br/><a id=\'3\'>3. Is there any time-out when using the search function ?</a>\r\n<br/><span style=\'color:green;\'>No. Normal user will be automatically be logged in as Guest. Guest mode do not have any specific access duration per session.</span><br/><br/><a id=\'4\'>4. Why some of words in my search terms did not being included in the search results ?</a><br/><span style=\'color:green;\'>Please take note that common words (often called \'noise terms\') will be filtered and not to be included in the final search result. This is to ensure that you will get hold of accurate result with given search terms.</span><br/>\r\n</td>		\r\n</tr>	\r\n</table>'),
(2, 'About', 'About This Repository', '<table style=\'background-color:white;\'> \r\n<tr>\r\n<td style=\'text-align:center;\'>\r\n<img alt=\'Main Logo\' width=\'250px\' src=\'sw_asset/img/swadah_logo.png\'><br/>\r\nsWADAH is developed by Perpustakaan Tuanku Bainun, Universiti Pendidikan Sultan Idris and it\'s targetted as an alternative digital repository for institutions. It features an easy to deploy system, easy to manage web based file repository system, following Google Scholar inclusion guideline, support OAI-PMH and also with fast, reliable and user-friendly interface.\r\n</td>\r\n</tr>\r\n</table>');

-- --------------------------------------------------------

--
-- Table structure for table `eg_downloadkey`
--

CREATE TABLE `eg_downloadkey` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `ip_address` text NOT NULL,
  `timestamped` varchar(255) NOT NULL DEFAULT '',
  `downloads` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_forgotpassword_depo`
--

CREATE TABLE `eg_forgotpassword_depo` (
  `id` int(11) NOT NULL,
  `emailaddress` varchar(350) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `timestamp` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item`
--

CREATE TABLE `eg_item` (
  `id` int(11) NOT NULL,
  `38folderid` int(11) NOT NULL DEFAULT 0,
  `38accessnum` varchar(150) NOT NULL,
  `38typeid` varchar(10) NOT NULL,
  `38status` varchar(50) NOT NULL,
  `38isbn` varchar(60) NOT NULL COMMENT 'tag 020 |a',
  `38issn` varchar(60) NOT NULL COMMENT 'tag 022 |a',
  `38langcode` varchar(5) NOT NULL DEFAULT 'zsm' COMMENT 'tag 041 a|',
  `38localcallnum` varchar(70) NOT NULL COMMENT 'tag 090 |a',
  `38author` varchar(350) NOT NULL COMMENT 'tag 100 |a',
  `38title` varchar(450) NOT NULL COMMENT 'tag 245 |a',
  `38edition` varchar(255) NOT NULL COMMENT 'tag 250 |a',
  `38publication` varchar(255) NOT NULL COMMENT 'tag 264 |a',
  `38physicaldesc` varchar(255) NOT NULL COMMENT 'tag 300 |a',
  `38series` varchar(150) NOT NULL COMMENT 'tag 490 |a',
  `38notes` text NOT NULL COMMENT 'tag 500 |a',
  `38dissertation_note` varchar(255) NOT NULL COMMENT 'tag 502 |a',
  `38source` varchar(255) NOT NULL COMMENT 'tag 710 |a',
  `38location` varchar(50) NOT NULL COMMENT 'tag 852 |a',
  `38link` varchar(255) DEFAULT NULL COMMENT 'tag 856 |u',
  `39inputdate` varchar(25) NOT NULL,
  `39inputby` varchar(50) NOT NULL,
  `39proposedelete` varchar(5) NOT NULL DEFAULT 'FALSE',
  `39proposedeleteby` varchar(50) DEFAULT NULL,
  `39proposedelete_reason` varchar(255) DEFAULT NULL,
  `40lastupdateby` varchar(50) DEFAULT NULL,
  `40lastupdatetimestamp` varchar(255) NOT NULL DEFAULT '0',
  `41instimestamp` varchar(12) DEFAULT NULL,
  `41hits` int(11) DEFAULT 0,
  `41downloads` int(11) NOT NULL DEFAULT 0,
  `41fulltexta` longtext DEFAULT NULL,
  `41reference` longtext DEFAULT NULL,
  `41pdfattach_fulltext` longtext NOT NULL,
  `41subjectheading` varchar(150) DEFAULT NULL,
  `41isabstract` int(1) NOT NULL DEFAULT 0,
  `50search_cloud` mediumtext NOT NULL,
  `50item_status` varchar(1) NOT NULL DEFAULT '1',
  `51_pagecount` int(11) NOT NULL DEFAULT 0,
  `51_embargo_timestamp` varchar(255) NOT NULL DEFAULT '0',
  `52photo_count` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item2`
--

CREATE TABLE `eg_item2` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `38_terms_of_availability` varchar(25) NOT NULL DEFAULT '0.00' COMMENT 'tag 020 |c',
  `38localcallnum_b` varchar(255) NOT NULL COMMENT 'tag 090 |b',
  `38author_c` varchar(255) NOT NULL COMMENT 'tag 100 |c',
  `38author_d` varchar(255) NOT NULL COMMENT 'tag 100 |d',
  `38author_e` varchar(255) NOT NULL COMMENT 'tag 100 |e',
  `38author_q` varchar(255) NOT NULL COMMENT 'tag 100 |q',
  `38title_b` varchar(255) NOT NULL COMMENT 'tag 245 |b',
  `38title_c` varchar(255) NOT NULL COMMENT 'tag 245 |c',
  `38vtitle_a` varchar(255) NOT NULL COMMENT 'tag 246_a',
  `38vtitle_b` varchar(255) NOT NULL COMMENT 'tag 246_b',
  `38vtitle_g` varchar(255) NOT NULL COMMENT 'tag 246_g',
  `38publication_b` varchar(255) NOT NULL COMMENT 'tag 264 |b',
  `38publication_c` varchar(255) NOT NULL COMMENT 'tag 264 |c',
  `38physicaldesc_b` varchar(255) NOT NULL COMMENT 'tag 300 |b',
  `38physicaldesc_c` varchar(255) NOT NULL COMMENT 'tag 300 |c',
  `38physicaldesc_e` varchar(255) NOT NULL COMMENT 'tag 300 |e',
  `38series_v` varchar(255) NOT NULL COMMENT 'tag 490 |v',
  `38dissertation_note_b` varchar(255) NOT NULL COMMENT 'tag 502 |b',
  `38dissertation_note_c` varchar(255) NOT NULL COMMENT 'tag 502 |c',
  `38dissertation_note_d` varchar(255) NOT NULL COMMENT 'tag 502 |d',
  `38summary_a` text NOT NULL COMMENT 'tag 520_a',
  `38geographic_coverage_note_a` varchar(255) NOT NULL DEFAULT '' COMMENT 'tag 522 |a',
  `38original_version_note_t` varchar(255) NOT NULL DEFAULT '' COMMENT 'tag 534 |t',
  `38terms_governing_use_a` varchar(255) NOT NULL DEFAULT '' COMMENT 'tag 540 |a',
  `38se_pname_a` varchar(255) NOT NULL COMMENT 'tag 600_a',
  `38se_pname_x` varchar(255) NOT NULL COMMENT 'tag 600_x',
  `38se_pname_y` varchar(255) NOT NULL COMMENT 'tag 600_y',
  `38subject_entry1` varchar(255) NOT NULL COMMENT 'tag 650 |a',
  `38subject_entry2` varchar(255) NOT NULL COMMENT 'tag 650 |a',
  `38subject_entry3` varchar(255) NOT NULL COMMENT 'tag 650 |a',
  `38pname1` varchar(255) NOT NULL COMMENT 'tag 700-1 a|',
  `38pname1_s` varchar(255) NOT NULL COMMENT 'tag 700-1 |e',
  `38pname2` varchar(255) NOT NULL COMMENT 'tag 700-2 a|',
  `38pname2_s` varchar(255) NOT NULL COMMENT 'tag 700-2 |e',
  `38pname3` varchar(255) NOT NULL COMMENT 'tag 700-3 a|',
  `38pname3_s` varchar(255) NOT NULL COMMENT 'tag 700-3 |e',
  `38pname4` varchar(255) NOT NULL COMMENT 'tag 700-4 a|',
  `38pname4_s` varchar(255) NOT NULL COMMENT 'tag 700-4 |e',
  `38pname5` varchar(255) NOT NULL COMMENT 'tag 700-5 a|',
  `38pname5_s` varchar(255) NOT NULL COMMENT 'tag 700-5 |e',
  `38pname6` varchar(255) NOT NULL COMMENT 'tag 700-6 a|',
  `38pname6_s` varchar(255) NOT NULL COMMENT 'tag 700-6 |e',
  `38pname7` varchar(255) NOT NULL COMMENT 'tag 700-7 a|',
  `38pname7_s` varchar(255) NOT NULL COMMENT 'tag 700-7 |e',
  `38pname8` varchar(255) NOT NULL COMMENT 'tag 700-8 a|',
  `38pname8_s` varchar(255) NOT NULL COMMENT 'tag 700-8 |e',
  `38pname9` varchar(255) NOT NULL COMMENT 'tag 700-9 a|',
  `38pname9_s` varchar(255) NOT NULL COMMENT 'tag 700-9 |e',
  `38pname10` varchar(255) NOT NULL COMMENT 'tag 700-10 a|',
  `38pname10_s` varchar(255) NOT NULL COMMENT 'tag 700-10 |e',
  `38source_b` varchar(255) NOT NULL COMMENT 'tag 710 |b',
  `38source_e` varchar(255) NOT NULL COMMENT 'tag 710 |e',
  `38other_relationship_entry_n` varchar(255) NOT NULL DEFAULT '' COMMENT 'tag 787 |n',
  `38location_b` varchar(255) NOT NULL COMMENT 'tag 852 |b',
  `38location_c` varchar(255) NOT NULL COMMENT 'tag 852 |c'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item2_indicator`
--

CREATE TABLE `eg_item2_indicator` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `i_020` varchar(3) NOT NULL,
  `i_022` varchar(3) NOT NULL,
  `i_041` varchar(3) NOT NULL,
  `i_090` varchar(3) NOT NULL,
  `i_100` varchar(3) NOT NULL,
  `i_245` varchar(3) NOT NULL,
  `i_246` varchar(3) NOT NULL,
  `i_250` varchar(3) NOT NULL,
  `i_264` varchar(3) NOT NULL,
  `i_300` varchar(3) NOT NULL,
  `i_490` varchar(3) NOT NULL,
  `i_500` varchar(3) NOT NULL,
  `i_502` varchar(3) NOT NULL,
  `i_520` varchar(3) NOT NULL,
  `i_522` varchar(3) NOT NULL,
  `i_534` varchar(3) NOT NULL,
  `i_540` varchar(3) NOT NULL,
  `i_600` varchar(3) NOT NULL,
  `i_650_1` varchar(3) NOT NULL,
  `i_650_2` varchar(3) NOT NULL,
  `i_650_3` varchar(3) NOT NULL,
  `i_700` varchar(3) NOT NULL,
  `i_700_2` varchar(3) NOT NULL,
  `i_700_3` varchar(3) NOT NULL,
  `i_700_4` varchar(3) NOT NULL,
  `i_700_5` varchar(3) NOT NULL,
  `i_700_6` varchar(3) NOT NULL,
  `i_700_7` varchar(3) NOT NULL,
  `i_700_8` varchar(3) NOT NULL,
  `i_700_9` varchar(3) NOT NULL,
  `i_700_10` varchar(3) NOT NULL,
  `i_710` varchar(3) NOT NULL,
  `i_787` varchar(3) NOT NULL,
  `i_852` varchar(3) NOT NULL,
  `i_856` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_access`
--

CREATE TABLE `eg_item_access` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `eg_loginless_id` int(11) NOT NULL DEFAULT 0,
  `39logdate` varchar(25) NOT NULL,
  `39ipaddr` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_charge`
--

CREATE TABLE `eg_item_charge` (
  `id` int(11) NOT NULL,
  `38accessnum` varchar(150) NOT NULL,
  `39patron` varchar(150) NOT NULL,
  `39charged_on` varchar(150) NOT NULL,
  `39charged_by` varchar(150) NOT NULL,
  `39duedate` int(11) DEFAULT 0,
  `40dc` varchar(2) NOT NULL,
  `40dc_on` varchar(150) NOT NULL,
  `40dc_by` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_depo`
--

CREATE TABLE `eg_item_depo` (
  `id` int(11) NOT NULL,
  `29authorname` varchar(255) NOT NULL,
  `29titlestatement` text NOT NULL,
  `29publication_b` varchar(255) NOT NULL,
  `29publication_c` varchar(255) NOT NULL,
  `29dissertation_note_b` varchar(255) NOT NULL,
  `29pname1` text NOT NULL,
  `29pname2` text NOT NULL,
  `29pname3` text NOT NULL,
  `29pname4` text NOT NULL,
  `29pname5` text NOT NULL,
  `29pname6` text NOT NULL,
  `29pname7` text NOT NULL,
  `29pname8` text NOT NULL,
  `29pname9` text NOT NULL,
  `29pname10` text NOT NULL,
  `29dfile` varchar(255) NOT NULL DEFAULT 'NO',
  `29pfile` varchar(255) NOT NULL DEFAULT 'NO',
  `29abstract` mediumtext NOT NULL,
  `29accesscategory` varchar(255) NOT NULL DEFAULT 'openaccess',
  `29lastupdated` varchar(255) NOT NULL,
  `year` int(4) NOT NULL,
  `inputby` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  `itemstatus` varchar(25) NOT NULL DEFAULT 'ENTRY',
  `grade` varchar(10) NOT NULL DEFAULT '-',
  `eg_item_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_depo_remarks`
--

CREATE TABLE `eg_item_depo_remarks` (
  `id` int(11) NOT NULL,
  `eg_item_depo_id` int(11) NOT NULL,
  `39remarks` text NOT NULL,
  `timestamp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_download`
--

CREATE TABLE `eg_item_download` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `39logdate` varchar(25) NOT NULL,
  `39ipaddr` varchar(15) NOT NULL,
  `39from` varchar(10) NOT NULL DEFAULT 'web'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_feedback`
--

CREATE TABLE `eg_item_feedback` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `eg_auth_username` varchar(255) NOT NULL,
  `38feedback` text NOT NULL,
  `38timestamp` varchar(25) NOT NULL,
  `38upvote` int(11) NOT NULL,
  `38downvote` int(11) NOT NULL,
  `38votebys` text NOT NULL,
  `39moderated_status` varchar(25) NOT NULL,
  `39moderated_by` varchar(255) NOT NULL,
  `39moderated_timestamp` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_folder`
--

CREATE TABLE `eg_item_folder` (
  `38folderid` int(4) NOT NULL,
  `38foldername` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_folder_auth`
--

CREATE TABLE `eg_item_folder_auth` (
  `id` int(11) NOT NULL,
  `eg_item_folder_id` int(11) NOT NULL,
  `eg_auth_username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_lastchecked`
--

CREATE TABLE `eg_item_lastchecked` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `last_checked` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_type`
--

CREATE TABLE `eg_item_type` (
  `38typeid` int(4) NOT NULL,
  `38type` varchar(50) NOT NULL,
  `38default` varchar(5) DEFAULT 'FALSE',
  `38defaultlocation` varchar(150) DEFAULT NULL,
  `38synonym` varchar(255) DEFAULT NULL,
  `38desc` varchar(255) DEFAULT NULL,
  `38gview` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `eg_item_type`
--

INSERT INTO `eg_item_type` (`38typeid`, `38type`, `38default`, `38defaultlocation`, `38synonym`, `38desc`, `38gview`) VALUES
(1, 'thesis', 'TRUE', NULL, 'Thesis', 'Masters and phD', 0),
(2, 'article', 'FALSE', NULL, 'Article', '', 0),
(3, 'book', 'FALSE', NULL, 'Book', '', 0),
(4, 'book_section', 'FALSE', NULL, 'Book Section', '', 0),
(5, 'conference_item', 'FALSE', NULL, 'Conference Item', '', 0),
(6, 'monograph', 'FALSE', NULL, 'Monograph', '', 0),
(7, 'photo', 'FALSE', NULL, 'Photo', '', 0),
(8, 'cd_image', 'FALSE', NULL, 'CD/DVD Image', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `eg_list`
--

CREATE TABLE `eg_list` (
  `43listid` int(11) NOT NULL,
  `43title` varchar(255) NOT NULL,
  `43type` varchar(15) NOT NULL,
  `43filter` varchar(255) NOT NULL,
  `43token` varchar(25) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_loginless`
--

CREATE TABLE `eg_loginless` (
  `43tokenid` int(11) NOT NULL,
  `43desc` varchar(255) NOT NULL,
  `43iprange` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `43token` varchar(255) NOT NULL,
  `43tokendailylimit` int(11) NOT NULL DEFAULT 999999,
  `44totalaccess` int(11) NOT NULL DEFAULT 0,
  `44redirecturl` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_loginlesslog`
--

CREATE TABLE `eg_loginlesslog` (
  `id` int(11) NOT NULL,
  `43tokenid` int(11) NOT NULL,
  `43date` date NOT NULL,
  `44counts` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_photo_access`
--

CREATE TABLE `eg_photo_access` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `38filename` text NOT NULL,
  `38timestamp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_publisher`
--

CREATE TABLE `eg_publisher` (
  `43pubid` int(11) NOT NULL,
  `43acronym` varchar(255) NOT NULL,
  `43publisher` varchar(255) NOT NULL,
  `43sstatus` int(1) NOT NULL DEFAULT 1,
  `43count` int(11) NOT NULL DEFAULT 0,
  `43lastcount_timestamp` varchar(25) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_relatedfiles`
--

CREATE TABLE `eg_relatedfiles` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `38filename` varchar(255) NOT NULL,
  `38desc` varchar(255) NOT NULL,
  `38accesstype` varchar(10) NOT NULL DEFAULT 'openaccess'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_stat_year`
--

CREATE TABLE `eg_stat_year` (
  `id` int(5) NOT NULL,
  `43count` int(11) NOT NULL DEFAULT 0,
  `43lastcount_timestamp` varchar(25) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_subjectheading`
--

CREATE TABLE `eg_subjectheading` (
  `43subjectid` int(11) NOT NULL,
  `43acronym` varchar(255) NOT NULL,
  `43subject` varchar(255) NOT NULL,
  `43count` int(11) NOT NULL DEFAULT 0,
  `43lastcount_timestamp` varchar(25) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data for table `eg_subjectheading`
--

INSERT INTO `eg_subjectheading` (`43subjectid`, `43acronym`, `43subject`, `43count`, `43lastcount_timestamp`) VALUES
(1, 'A', 'General Works', 22, '1744675295'),
(2, 'B', 'Philosophy. Psychology. Religion', 5, '1744675295'),
(3, 'C', 'Auxiliary Sciences of History', 1, '1744675295'),
(4, 'D', 'History General and Old World', 2, '1744675295'),
(5, 'E', 'History America', 3, '1744675295'),
(6, 'F', 'History United States, Canada, Latin America', 1, '1744675295'),
(7, 'G', 'Geography. Anthropology. Recreation', 0, '1744675295'),
(8, 'H', 'Social Sciences', 0, '1744675295'),
(9, 'J', 'Political Science', 1, '1744675295'),
(10, 'K', 'Law', 1, '1744675295'),
(11, 'L', 'Education', 0, '1744675295'),
(12, 'M', 'Music and Books on Music', 1, '1744675295'),
(13, 'N', 'Fine Arts', 1, '1744675295'),
(14, 'P', 'Language and Literature', 1, '1744675295'),
(15, 'Q', 'Science', 0, '1744675295'),
(16, 'R', 'Medicine', 1, '1744675295'),
(17, 'S', 'Agriculture', 1, '1744675295'),
(18, 'T', 'Technology', 2, '1744675295'),
(19, 'U', 'Military Science', 0, '1744675295'),
(20, 'V', 'Naval Science', 0, '1744675295'),
(21, 'Z', 'Bibliography. Library Science. Information Resources', 0, '1744675295');

-- --------------------------------------------------------

--
-- Table structure for table `eg_tempaccess`
--

CREATE TABLE `eg_tempaccess` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `since` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `usagecount` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog`
--

CREATE TABLE `eg_userlog` (
  `id` int(11) NOT NULL,
  `37keyword` varchar(255) NOT NULL,
  `37type` varchar(20) NOT NULL DEFAULT 'All Type',
  `37freq` int(11) NOT NULL,
  `37lastlog` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog_det`
--

CREATE TABLE `eg_userlog_det` (
  `id` int(11) NOT NULL,
  `38keyword` varchar(255) NOT NULL,
  `38logdate` varchar(25) NOT NULL,
  `38ipaddr` varchar(15) DEFAULT NULL,
  `38type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config_user`
--
ALTER TABLE `config_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_auth`
--
ALTER TABLE `eg_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_auth_depo`
--
ALTER TABLE `eg_auth_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_auth_eligibility`
--
ALTER TABLE `eg_auth_eligibility`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_id` (`usertype`);

--
-- Indexes for table `eg_auth_ip`
--
ALTER TABLE `eg_auth_ip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_commercialize`
--
ALTER TABLE `eg_commercialize`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_commercial_token`
--
ALTER TABLE `eg_commercial_token`
  ADD PRIMARY KEY (`43tokenid`);

--
-- Indexes for table `eg_composer`
--
ALTER TABLE `eg_composer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_downloadkey`
--
ALTER TABLE `eg_downloadkey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_forgotpassword_depo`
--
ALTER TABLE `eg_forgotpassword_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item`
--
ALTER TABLE `eg_item`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `40lastupdateby` (`40lastupdateby`),
  ADD KEY `39inputby` (`39inputby`),
  ADD KEY `38subjectheading` (`41subjectheading`),
  ADD KEY `38typeid` (`38typeid`,`41instimestamp`),
  ADD KEY `id_2` (`id`,`38typeid`),
  ADD KEY `38typeid_2` (`38typeid`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38title` (`38title`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38fulltext` (`41fulltexta`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38author` (`38author`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38pdfattach_fulltext` (`41pdfattach_fulltext`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `50search_cloud` (`50search_cloud`);

--
-- Indexes for table `eg_item2`
--
ALTER TABLE `eg_item2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item2_indicator`
--
ALTER TABLE `eg_item2_indicator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_access`
--
ALTER TABLE `eg_item_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eg_item_id` (`eg_item_id`),
  ADD KEY `39logdate` (`39logdate`,`39ipaddr`);

--
-- Indexes for table `eg_item_charge`
--
ALTER TABLE `eg_item_charge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_depo`
--
ALTER TABLE `eg_item_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_depo_remarks`
--
ALTER TABLE `eg_item_depo_remarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_download`
--
ALTER TABLE `eg_item_download`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eg_item_id` (`eg_item_id`),
  ADD KEY `39logdate` (`39logdate`,`39ipaddr`),
  ADD KEY `39logdate_2` (`39logdate`),
  ADD KEY `39from` (`39from`),
  ADD KEY `eg_item_id_2` (`eg_item_id`,`39logdate`,`39from`);

--
-- Indexes for table `eg_item_feedback`
--
ALTER TABLE `eg_item_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_folder`
--
ALTER TABLE `eg_item_folder`
  ADD PRIMARY KEY (`38folderid`),
  ADD KEY `38typeid` (`38folderid`);

--
-- Indexes for table `eg_item_folder_auth`
--
ALTER TABLE `eg_item_folder_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_lastchecked`
--
ALTER TABLE `eg_item_lastchecked`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_id` (`item_id`);

--
-- Indexes for table `eg_item_type`
--
ALTER TABLE `eg_item_type`
  ADD PRIMARY KEY (`38typeid`),
  ADD KEY `38typeid` (`38typeid`);

--
-- Indexes for table `eg_list`
--
ALTER TABLE `eg_list`
  ADD PRIMARY KEY (`43listid`);

--
-- Indexes for table `eg_loginless`
--
ALTER TABLE `eg_loginless`
  ADD PRIMARY KEY (`43tokenid`);

--
-- Indexes for table `eg_loginlesslog`
--
ALTER TABLE `eg_loginlesslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_photo_access`
--
ALTER TABLE `eg_photo_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eg_item_id` (`eg_item_id`),
  ADD KEY `eg_item_id_2` (`eg_item_id`,`38timestamp`);

--
-- Indexes for table `eg_publisher`
--
ALTER TABLE `eg_publisher`
  ADD PRIMARY KEY (`43pubid`);

--
-- Indexes for table `eg_relatedfiles`
--
ALTER TABLE `eg_relatedfiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_stat_year`
--
ALTER TABLE `eg_stat_year`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_subjectheading`
--
ALTER TABLE `eg_subjectheading`
  ADD PRIMARY KEY (`43subjectid`);

--
-- Indexes for table `eg_tempaccess`
--
ALTER TABLE `eg_tempaccess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `37lastlog` (`37lastlog`);
ALTER TABLE `eg_userlog` ADD FULLTEXT KEY `37keyword` (`37keyword`);

--
-- Indexes for table `eg_userlog_det`
--
ALTER TABLE `eg_userlog_det`
  ADD PRIMARY KEY (`id`),
  ADD KEY `38logdate` (`38logdate`);
ALTER TABLE `eg_userlog_det` ADD FULLTEXT KEY `38keyword` (`38keyword`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config_user`
--
ALTER TABLE `config_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `eg_auth`
--
ALTER TABLE `eg_auth`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_auth_depo`
--
ALTER TABLE `eg_auth_depo`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_auth_eligibility`
--
ALTER TABLE `eg_auth_eligibility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `eg_auth_ip`
--
ALTER TABLE `eg_auth_ip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `eg_commercialize`
--
ALTER TABLE `eg_commercialize`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_commercial_token`
--
ALTER TABLE `eg_commercial_token`
  MODIFY `43tokenid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_composer`
--
ALTER TABLE `eg_composer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `eg_downloadkey`
--
ALTER TABLE `eg_downloadkey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_forgotpassword_depo`
--
ALTER TABLE `eg_forgotpassword_depo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item`
--
ALTER TABLE `eg_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item2`
--
ALTER TABLE `eg_item2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item2_indicator`
--
ALTER TABLE `eg_item2_indicator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_access`
--
ALTER TABLE `eg_item_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_charge`
--
ALTER TABLE `eg_item_charge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_depo`
--
ALTER TABLE `eg_item_depo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_depo_remarks`
--
ALTER TABLE `eg_item_depo_remarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_download`
--
ALTER TABLE `eg_item_download`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_feedback`
--
ALTER TABLE `eg_item_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_folder`
--
ALTER TABLE `eg_item_folder`
  MODIFY `38folderid` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_folder_auth`
--
ALTER TABLE `eg_item_folder_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_lastchecked`
--
ALTER TABLE `eg_item_lastchecked`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_type`
--
ALTER TABLE `eg_item_type`
  MODIFY `38typeid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `eg_list`
--
ALTER TABLE `eg_list`
  MODIFY `43listid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_loginless`
--
ALTER TABLE `eg_loginless`
  MODIFY `43tokenid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_loginlesslog`
--
ALTER TABLE `eg_loginlesslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_photo_access`
--
ALTER TABLE `eg_photo_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_publisher`
--
ALTER TABLE `eg_publisher`
  MODIFY `43pubid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_relatedfiles`
--
ALTER TABLE `eg_relatedfiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_subjectheading`
--
ALTER TABLE `eg_subjectheading`
  MODIFY `43subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `eg_tempaccess`
--
ALTER TABLE `eg_tempaccess`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_userlog_det`
--
ALTER TABLE `eg_userlog_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
