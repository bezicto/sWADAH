<?php
    /*
    Filename: sw_cmmsl/api.php
    Usage: Commercial List API
    Version: 1.0.20240705.0926 Alpha
    ------
    Notes:
    Welcome to Commercial List API.
    If you can read this, you are probably want to change something in this lake of codes.

    call structure
    1. get all listing e.g.: /sw_cmmsl/api.php?cak=<clientaccesskey>&showlist=commercial
    2. get specific item e.g.: /sw_cmmsl/api.php?cak=<clientaccesskey>&getid=<id>
    3. search title listing based on a string e.g.: /sw_cmmsl/api.php?cak=<clientaccesskey>&scr=<title_search_string>
    */

    session_start();
    define('includeExist', true);
    include_once '../core.php';
    include_once '../sw_inc/functions.php';

    if (!$enable_commercial_api) {
        $posts[] = array(
            'id'=>'API Disabled',
            'title'=>'Request Error',
            'author'=>'Perpustakaan Tuanku Bainun, Universiti Pendidikan Sultan Idris',
        );
    } else {
        //validation of token
        if (isset($_GET['cak']) && ctype_alnum($_GET['cak'])) {
            $stmt_findtoken = $new_conn->prepare("select 43tokenid, 43token, 44totalaccess from eg_commercial_token where 43token=? limit 1");
            $stmt_findtoken->bind_param("s", $_GET['cak']);
            $stmt_findtoken->execute();
            $result_findtoken = $stmt_findtoken->get_result();
            $num_results_affected_findtoken = $result_findtoken->num_rows;
            $myrow_findtoken = $result_findtoken->fetch_assoc();
            if ($num_results_affected_findtoken == 1) {
                $_SESSION[$ssn.'cak'] = 'valid';
                //log access count into database -start
                $newcount = $myrow_findtoken['44totalaccess'] + 1;
                $stmt_update = $new_conn->prepare("update eg_commercial_token set 44totalaccess=? where 43tokenid=?");
                $stmt_update->bind_param("is",$newcount,$myrow_findtoken['43tokenid']);
                $stmt_update->execute();$stmt_update->close();
                //log access count into database -end
            } else {
                unset($_SESSION[$ssn.'cak']);
            }
        }

        if (isset($_SESSION[$ssn.'cak']) && $_SESSION[$ssn.'cak'] == 'valid') {
            if (isset($_GET['showlist']) && $_GET['showlist'] == 'commercial') {
                $append_sts = (isset($_GET['sts']) && is_numeric($_GET['sts'])) ? "and (eg_item.41instimestamp >= ".$_GET['sts']." or 40lastupdatetimestamp >= ".$_GET['sts'].")" : "";

                $query_term = "select eg_item.id as id,
                eg_item.38title as 38title,
                eg_item.38author as 38author,
                eg_item_type.38type as 38type,
                eg_item.39inputdate as 39inputdate,
                eg_item.41instimestamp as 41instimestamp,
                eg_item.40lastupdatetimestamp as 40lastupdatetimestamp,
                    eg_item2.38_terms_of_availability as price,
                    eg_item2.38publication_c as 38publication_c
                from eg_item inner join eg_commercialize inner join eg_item2 inner join eg_item_type
                on eg_item.id=eg_commercialize.eg_item_id and eg_item.id=eg_item2.eg_item_id and eg_item.38typeid=eg_item_type.38typeid
                where eg_item.id<>0 and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0 $append_sts
                    order by id desc";
                
                $stmt_term = $new_conn->prepare($query_term);
                $stmt_term->execute();
                $result_term = $stmt_term->get_result();

                $posts = array();
                while ($myrow_term = $result_term->fetch_assoc()) {
                    
                    $pdocs_file = "";$encryption_pfile="";
                    $docs_file = "";$encryption_dfile="";
                    if (is_file("../$system_pdocs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf") &&
                        is_file("../$system_docs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf")
                    ) {
                        $pdocs_file = $system_path."$system_pdocs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf";
                        $docs_file = $system_path."$system_docs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf";
                        
                        $encryption_pfile = base64_encode(openssl_encrypt($pdocs_file, "AES-128-CTR", $aes_key, 0, "1234567891011121"));
                        $encryption_dfile = base64_encode(openssl_encrypt($docs_file, "AES-128-CTR", $aes_key, 0, "1234567891011121"));

                        $posts[] = array(
                            'id'=>$myrow_term["id"]."",
                            'title'=>htmlspecialchars($myrow_term["38title"]),
                            'author'=>htmlspecialchars($myrow_term["38author"]),
                            'type'=>$myrow_term["38type"],
                            'year'=>$myrow_term["38publication_c"],
                            'price'=>$myrow_term["price"],
                            'sampleddl'=>$encryption_pfile,
                            'fullddl'=>$encryption_dfile,
                            'lastupdate'=>$myrow_term["40lastupdatetimestamp"]
                        );
                    } else {
                        $posts[] = array(
                            'id'=>$myrow_term["id"]."",
                            'title'=>htmlspecialchars($myrow_term["38title"]),
                            'author'=>htmlspecialchars($myrow_term["38author"]),
                            'type'=>$myrow_term["38type"],
                            'year'=>$myrow_term["38publication_c"],
                            'price'=>$myrow_term["price"],
                            'lastupdate'=>$myrow_term["40lastupdatetimestamp"]
                        );
                    }
                }
            } elseif (isset($_GET['getid']) && is_numeric($_GET['getid'])) {
                $query_term = "select eg_item.id as id,
                eg_item.38title as 38title,
                eg_item.38author as 38author,
                eg_item_type.38type as 38type,
                eg_item.39inputdate as 39inputdate,
                eg_item.41instimestamp as 41instimestamp,
                eg_item.40lastupdatetimestamp as 40lastupdatetimestamp,
                    eg_item2.38_terms_of_availability as price,
                    eg_item2.38publication_c as 38publication_c
                from eg_item inner join eg_commercialize inner join eg_item2 inner join eg_item_type
                on eg_item.id=eg_commercialize.eg_item_id and eg_item.id=eg_item2.eg_item_id and eg_item.38typeid=eg_item_type.38typeid
                where eg_item.id<>0 and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0 and eg_item.id=".$_GET['getid']."
                    order by id desc";
                
                $stmt_term = $new_conn->prepare($query_term);
                $stmt_term->execute();
                $result_term = $stmt_term->get_result();

                $posts = array();
                while ($myrow_term = $result_term->fetch_assoc()) {
                    
                    $pdocs_file = "";$encryption_pfile="";
                    $docs_file = "";$encryption_dfile="";
                    if (is_file("../$system_pdocs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf") &&
                        is_file("../$system_docs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf")
                    ) {
                        $pdocs_file = $system_path."$system_pdocs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf";
                        $docs_file = $system_path."$system_docs_directory/".substr($myrow_term["39inputdate"], 0, 4)."/".$myrow_term["id"].""."_".$myrow_term['41instimestamp'].".pdf";
                        
                        $encryption_pfile = base64_encode(openssl_encrypt($pdocs_file, "AES-128-CTR", $aes_key, 0, "1234567891011121"));
                        $encryption_dfile = base64_encode(openssl_encrypt($docs_file, "AES-128-CTR", $aes_key, 0, "1234567891011121"));

                        $posts[] = array(
                            'id'=>$myrow_term["id"]."",
                            'title'=>htmlspecialchars($myrow_term["38title"]),
                            'author'=>htmlspecialchars($myrow_term["38author"]),
                            'type'=>$myrow_term["38type"],
                            'year'=>$myrow_term["38publication_c"],
                            'price'=>$myrow_term["price"],
                            'sampleddl'=>$encryption_pfile,
                            'fullddl'=>$encryption_dfile,
                            'lastupdate'=>$myrow_term["40lastupdatetimestamp"]
                        );
                    } else {
                        $posts[] = array(
                            'id'=>$myrow_term["id"]."",
                            'title'=>htmlspecialchars($myrow_term["38title"]),
                            'author'=>htmlspecialchars($myrow_term["38author"]),
                            'type'=>$myrow_term["38type"],
                            'year'=>$myrow_term["38publication_c"],
                            'price'=>$myrow_term["price"],
                            'lastupdate'=>$myrow_term["40lastupdatetimestamp"]
                        );
                    }
                }
            } elseif (isset($_GET['scr']) && $_GET['scr'] != '') {
                $query_term = "select eg_item.id as id,
                eg_item.38title as 38title,
                eg_item.38author as 38author,
                eg_item_type.38type as 38type,
                    eg_item2.38_terms_of_availability as price,
                    eg_item2.38publication_c as 38publication_c,
                    match (eg_item.38title,eg_item.38author) against ('".$_GET['scr']."' in boolean mode) as score
                from eg_item inner join eg_commercialize inner join eg_item2 inner join eg_item_type
                on eg_item.id=eg_commercialize.eg_item_id and eg_item.id=eg_item2.eg_item_id and eg_item.38typeid=eg_item_type.38typeid
                where eg_item.id<>0 and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and
                match (eg_item.38title, eg_item.38author, eg_item.50search_cloud) against ('".$_GET['scr']."' in boolean mode)
                    order by score desc";
                
                $stmt_term = $new_conn->prepare($query_term);
                $stmt_term->execute();
                $result_term = $stmt_term->get_result();

                $posts = array();
                while ($myrow_term = $result_term->fetch_assoc()) {
                    $posts[] = array(
                        'id'=>$myrow_term["id"]."",
                        'title'=>htmlspecialchars($myrow_term["38title"]),
                        'author'=>htmlspecialchars($myrow_term["38author"]),
                        'type'=>$myrow_term["38type"],
                        'year'=>$myrow_term["38publication_c"],
                        'price'=>$myrow_term["price"],
                        //'detail'=>sfx_getCurrentUrlWithoutQuery()."?getid=".$myrow_term["id"]
                    );
                }
            } else {
                $posts[] = array(
                    'header'=>"Welcome to $system_title Commercial List API",
                    'version'=>'Version 1.0.20240805 Alpha',
                    'authorized'=>'Perpustakaan Tuanku Bainun, Universiti Pendidikan Sultan Idris',
                );
            }
        } else {
            $posts[] = array(
                'header'=>'Invalid Request',
                'details'=>"$system_title Request Error",
            );
        }
    }

header('Content-type:application/json;charset=utf-8');
echo stripslashes(json_encode($posts, JSON_UNESCAPED_UNICODE));
mysqli_close($GLOBALS["conn"]);
exit;
