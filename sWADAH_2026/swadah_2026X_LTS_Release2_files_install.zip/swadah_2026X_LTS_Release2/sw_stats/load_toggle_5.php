<?php
/*
Filename: sw_stats/load_toggle_5.php (Deposit)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change: -
*/

    include_once '../sw_inc/access_isset.php';
    
    // Memeriksa jika $_REQUEST['hitsDate'] $_REQUEST['yearly'] atau  dihantar
    if (!empty($_REQUEST['hitsDate'])) {
        $dateParts = explode('/', $_REQUEST['hitsDate']);
        if (count($dateParts) === 3) {
            $_SESSION[$ssn.'dlyearly'] = $dateParts[2];
        }
    } elseif (!empty($_REQUEST['dlyearly'])) {
        $_SESSION[$ssn.'dlyearly'] = $_REQUEST['dlyearly'];
    }
?>
<?php
    function sw_countDepoHitsForMonth($monthStr, $additionalQL = '')
    {
        $appendSQL = ($additionalQL != '') ? "and itemstatus like '$additionalQL%'" : "";

        if (strpos($monthStr, "/00") !== false) {
            return "0";
        } else {
            $t = preg_replace("/\D/", "", $monthStr);

            if (file_exists("../".$GLOBALS["system_statcache_directory"]."/depositstat/$t"."_$additionalQL.txt") && (substr($t, 2) < date('Y'))) {
                $lines = file("../".$GLOBALS["system_statcache_directory"]."/depositstat/$t"."_$additionalQL.txt");
                $to_return = $lines[0];
            } else {
                $querySTAT = "select count(id) as totalhitSTAT from eg_item_depo where DATE_FORMAT(FROM_UNIXTIME(timestamp), '%m/%Y') = '$monthStr' $appendSQL";
                $resultSTAT = mysqli_query($GLOBALS["conn"], $querySTAT);
                $myrowSTAT = mysqli_fetch_array($resultSTAT);
                file_put_contents("../".$GLOBALS["system_statcache_directory"]."/depositstat/$t"."_$additionalQL.txt", $myrowSTAT["totalhitSTAT"]."\n".time());
                $to_return = $myrowSTAT["totalhitSTAT"];
            }
            return $to_return;
        }
    }

    //updated code 20240812.1518
    function sw_updateDepositCount($filename, $query, $report_count_generator) {
        global $system_statcache_directory;
        $filePath = "../$system_statcache_directory/$filename";
        if (file_exists($filePath) && $report_count_generator == 'daily') {
            $lines = file($filePath);
            $diff = time() - $lines[1];
            if (isset($diff) && $diff < 86400) {
                return $lines[0];
            }
        }
        $result = mysqli_query($GLOBALS["conn"], $query);
        $row = mysqli_fetch_array($result);
        $count = $row["totaldeposit"];
        file_put_contents($filePath, $count."\n".time());

        return $count;
    }
    function sw_readDepositCountTime($filename, $report_count_generator) {
        global $system_statcache_directory;
        $filePath = "../$system_statcache_directory/$filename";
        if (file_exists($filePath) && $report_count_generator == 'daily') {
            $lines = file($filePath);
            return $lines[1];
        } else {
            return "";
        }
    }
    $numSUMl  = sw_updateDepositCount("total_deposit_all.txt", "select count(id) as totaldeposit from eg_item_depo", $report_count_generator);
    $numSUMla = sw_updateDepositCount("total_deposit_accepted.txt", "select count(id) as totaldeposit from eg_item_depo where itemstatus like 'ACC%'", $report_count_generator);
    $numSUMlb = sw_updateDepositCount("total_deposit_rejected.txt", "select count(id) as totaldeposit from eg_item_depo where itemstatus like 'R_%'", $report_count_generator);
    $numSUMlr = sw_updateDepositCount("total_deposit_archived.txt", "select count(id) as totaldeposit from eg_item_depo where itemstatus like 'ARC%'", $report_count_generator);
    
    //unprocessed
    $querySUMlt = "select count(id) as totaldeposit from eg_item_depo where itemstatus not like 'ACC%' and itemstatus not like 'R_%' and itemstatus not like 'ARC%'";
    $resultSUMlt = mysqli_query($GLOBALS["conn"], $querySUMlt);
    $myrowSUMlt = mysqli_fetch_array($resultSUMlt);
    $numSUMlt = $myrowSUMlt["totaldeposit"];
        
?>
<table class=whiteHeader>
    <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=5><strong>Deposit Statistic (all time)</strong></td></tr>
    <tr style='background-color:#EDF0F6;'>
        <td style='width:20%;'><i class="fa-solid fa-upload" style='font-size:25pt;'></i><br/>
            TOTAL DEPOSIT: <br/><span style='font-size:22px;'><strong><?php echo "$numSUMl";?></strong></span>
            <br/><em>Generated on <?php echo date('Y-m-d H:i:s', sw_readDepositCountTime("total_deposit_all.txt",$report_count_generator));?></em>
        </td>

        <td style='width:20%;'><i class="fa-regular fa-pen-to-square" style='font-size:25pt;'></i><br/>
            UNPROCESSED: <br/><span style='font-size:22px;'><strong><?php echo "$numSUMlt";?></strong></span>
            <br/><em>Live Data</em>
        </td>

        <td style='width:20%;'><i class="fa-solid fa-square-check" style='font-size:25pt;'></i><br/>
            ACCEPTED: <br/><span style='font-size:22px;'><strong><?php echo "$numSUMla";?></strong></span>
            <br/><em>Generated on <?php echo date('Y-m-d H:i:s', sw_readDepositCountTime("total_deposit_accepted.txt",$report_count_generator));?></em>
        </td>

        <td style='width:20%;'><i class="fa-solid fa-circle-xmark" style='font-size:25pt;'></i><br/>
            REJECTED: <br/><span style='font-size:22px;'><strong><?php echo "$numSUMlb";?></strong></span>
            <br/><em>Generated on <?php echo date('Y-m-d H:i:s', sw_readDepositCountTime("total_deposit_rejected.txt",$report_count_generator));?></em>
        </td>

        <td style='width:20%;'><i class="fa-solid fa-box-archive" style='font-size:25pt;'></i><br/>
            ARCHIVED: <br/><span style='font-size:22px;'><strong><?php echo "$numSUMlr";?></strong></span>
            <br/><em>Generated on <?php echo date('Y-m-d H:i:s', sw_readDepositCountTime("total_deposit_archived.txt",$report_count_generator));?></em>
        </td>
    </tr>
    <?php if ($report_count_generator == 'daily' && isset($lines[1])) {?><tr style='background-color:#EDF0F6;'><td colspan=5><em>Statistic generated date and time: <?php echo date('Y-m-d H:i:s', $reported_timestamp) ?><br/>Statistic is valid for that date and time. New statistic will be generated 24 hours later.</em></td></tr><?php }?>
</table>
<table class=whiteHeader>
    <tr style='text-align:center'><td colspan=2 class='<?php echo $color_scheme."Back"; ?>'>Choose one of the following report generators:</td></tr>
    
    <tr style='background-color:#EDF0F6;text-align:center'><td colspan=2>
        <form name="getMonthStat" action="adsreport.php?toggle=5" method=post>
            Yearly stats: <input type="text" name="dlyearly" size="5" <?php if (isset($_SESSION[$ssn.'dlyearly']) && is_numeric($_SESSION[$ssn.'dlyearly'])) {echo 'value="'.$_SESSION[$ssn.'dlyearly'].'"';}?> maxlength="4"/>
        </form><br/>
        <?php
                if (isset($_SESSION[$ssn.'dlyearly']) && is_numeric($_SESSION[$ssn.'dlyearly'])) {
                    if ($_SESSION[$ssn.'dlyearly'] == date('Y')) {
                        $yearly = $_SESSION[$ssn.'dlyearly']-1;
                        $yearlyB = $_SESSION[$ssn.'dlyearly']-2;
                        $yearlyA = $_SESSION[$ssn.'dlyearly'];
                    } else {
                        $yearly = $_SESSION[$ssn.'dlyearly'];
                        $yearlyB = $_SESSION[$ssn.'dlyearly']-1;
                        $yearlyA = $_SESSION[$ssn.'dlyearly']+1;
                    }
                } else {
                    $yearly = '00';
                    $yearlyB = '00';
                    $yearlyA = '00';
                }
        ?>
        <?php
        function sw_create3month_comparetablestatD($leftHead, $rightHead1, $rightHead2, $rightHead3, $rightHead4, $year_select)
        {
            echo "<table style='text-align:center;border:1px solid;display: inline-block;'>";
            echo "<tr style='background-color:lightgrey;'>
                    <td style='text-align:center;border:1px solid;'>$leftHead</td>
                    <td style='text-align:center;border:1px solid;'>$rightHead1</td>
                    <td style='text-align:center;border:1px solid;'>$rightHead2</td>
                    <td style='text-align:center;border:1px solid;'>$rightHead3</td>
                    <td style='text-align:center;border:1px solid;'>$rightHead4</td>
                    </tr>";
            $total = 0;
            $totald = 0;
            $totala = 0;
            $totalr = 0;
            for ($x = 1; $x <= 12; $x++) {
                $y = ($x < 10) ? "0$x" : $x;
                ${"j".$x} = sw_countDepoHitsForMonth("$y/$year_select");
                ${"j".$x."d"} = sw_countDepoHitsForMonth("$y/$year_select", "ARC");
                ${"j".$x."a"} = sw_countDepoHitsForMonth("$y/$year_select", "ACC");
                ${"j".$x."r"} = sw_countDepoHitsForMonth("$y/$year_select", "R_");
                echo "<tr style='text-align:center;border:1px solid;'>";
                    echo "<td>$y/$year_select</td>";
                    echo "<td><a onclick='return js_openPopup(this.href,950,580);' href='adsreport_depodetails.php?hitsDate=$y/$year_select'>".${"j".$x}."</a></td>";
                    echo "<td>".${"j".$x."d"}."</td>";
                    echo "<td>".${"j".$x."a"}."</td>";
                    echo "<td>".${"j".$x."r"}."</td>";
                echo "</tr>";
                $total = $total + intval(${"j".$x});
                $totald = $totald + intval(${"j".$x."d"});
                $totala = $totala + intval(${"j".$x."a"});
                $totalr = $totalr + intval(${"j".$x."r"});
            }
            echo "<tr>
                <td style='text-align:center;border:1px solid;'>TOTAL:</td>
                <td style='text-align:center;border:1px solid;'>$total</td>
                <td style='text-align:center;border:1px solid;'>$totald</td>
                <td style='text-align:center;border:1px solid;'>$totala</td>
                <td style='text-align:center;border:1px solid;'>$totalr</td>
                </tr>";
            echo "</table> ";
        }
        sw_create3month_comparetablestatD('Month', 'Deposit Count', 'Archived', 'Accepted', 'Rejected', $yearlyB);
        sw_create3month_comparetablestatD('Month', 'Deposit Count', 'Archived', 'Accepted', 'Rejected', $yearly);
        sw_create3month_comparetablestatD('Month', 'Deposit Count', 'Archived', 'Accepted', 'Rejected', $yearlyA);
        ?>
    </td></tr>

</table>
