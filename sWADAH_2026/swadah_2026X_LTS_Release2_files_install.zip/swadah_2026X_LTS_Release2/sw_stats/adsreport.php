<?php
/*
Filename: sw_stats/adsreport.php
Usage: Main page for reporting module
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Report Generator";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';

    //create cache directory if not exist
    if (!is_dir("../$system_statcache_directory")) {
        mkdir("../$system_statcache_directory", 0755, true);
        file_put_contents("../$system_statcache_directory/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>\"\n"
                );
    }

    if (!is_dir("../$system_statcache_directory/searchstat")) {
        mkdir("../$system_statcache_directory/searchstat", 0755, true);
        file_put_contents("../$system_statcache_directory/searchstat/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/searchstat/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>\"\n"
                );
    }

    if (!is_dir("../$system_statcache_directory/bookmarkstat")) {
        mkdir("../$system_statcache_directory/bookmarkstat", 0755, true);
        file_put_contents("../$system_statcache_directory/bookmarkstat/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/bookmarkstat/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>\"\n"
                );
    }

    if (!is_dir("../$system_statcache_directory/depositstat")) {
        mkdir("../$system_statcache_directory/depositstat", 0755, true);
        file_put_contents("../$system_statcache_directory/depositstat/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/depositstat/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>\"\n"
                );
    }

    if (!is_dir("../$system_statcache_directory/alltypstat")) {
        mkdir("../$system_statcache_directory/alltypstat", 0755, true);
        file_put_contents("../$system_statcache_directory/alltypstat/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        file_put_contents(
                    "../$system_statcache_directory/alltypstat/.htaccess",
                    "<Files \"*.php\">\n".
                    "    <IfModule mod_authz_core.c>\n".
                    "        Require all denied\n".
                    "    </IfModule>\n".
                    "    <IfModule !mod_authz_core.c>\n".
                    "        deny from all\n".
                    "    </IfModule>\n".
                    "</Files>\n".
                    "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>\"\n"
                );
    }

?>

<html lang='en'>
<head>
    <?php include_once '../sw_inc/header.php'; ?>
    <script>
    $(document).ready(function() {
        $.ajax({
            url: 'load_toggle_1.php',
            success: function(data) {
                $("#toggle_1").html(data);
            }
        })
        $.ajax({
            url: 'load_toggle_2a.php',
            success: function(data) {
                $("#toggle_2a").html(data);
            }
        })
    });
    </script>
</head>

<body class='<?php echo $color_scheme;?>'>
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
                    
    <hr>

    <div style="text-align:center">
        
        <br/>Analytics:
        <?php if (in_array($system_function, ["full", "repo", "photo", "depo"])): ?>
            [<a class=thisonly href='adsreport.php?toggle=1'>Managers</a>]
        <?php endif; ?>
        <?php if (in_array($system_function, ["full", "repo", "photo"])): ?>
            [<a class=thisonly href='adsreport.php?toggle=2'>Access</a>]
            [<a class=thisonly href='adsreport.php?toggle=3&yearly=<?php echo date('Y');?>'>Search</a>]
        <?php endif; ?>

        <?php if (in_array($system_function, ["full", "repo"]) && $allow_user_to_login): ?>
            [<a class=thisonly href='adsreport.php?toggle=4&lyearly=<?php echo date('Y');?>'>Bookmark</a>]
        <?php endif; ?>

        <?php if (in_array($system_function, ["full", "depo"])): ?>
            [<a class=thisonly href='adsreport.php?toggle=5&dlyearly=<?php echo date('Y');?>'>Deposit</a>]
        <?php endif; ?>

        <?php if ($system_function == "photo"): ?>
            [<a class=thisonly href='adsreport.php?toggle=6&phyearly=<?php echo date('Y');?>'>Photo</a>]
        <?php endif; ?>
        <br/><br/>

        <?php if ((isset($_GET['toggle']) && $_GET['toggle'] == '1') || (!isset($_GET['toggle']))) {?>
            <div id="toggle_1">
                <img alt='Loading..' style='margin-top:20px;margin-bottom:20px;' src='../sw_asset/img/loading.gif' width=64><br/><span style='font-size:10px;'>Loading data. Please wait a while.</span><br/><br/>
            </div>
        <?php }?>

        <?php if (isset($_GET['toggle']) && $_GET['toggle'] == '2') {?>
            <h2 style='text-decoration:underline;'>Select from available analytic for access:</h2>
            <table style='border:0px none;margin-left:auto;margin-right:auto;'>
                <tr><td><span class="fa-solid fa-timeline" style='font-size:35px;'></span></td><td><span class="fa-solid fa-calendar-days" style='font-size:35px;'></span></td></tr>
                <tr><td><h3>[<a class=thisonly href='adsreport.php?toggle=2a'>Alltime Report</a>]</h3></td><td><h3>[<a class=thisonly href='adsreport.php?toggle=2b&acyearly=<?php echo date('Y');?>'>Yearly Report</a>]</h3></td></tr>
            </table>
        <?php }?>
    
        <?php if (isset($_GET['toggle']) && $_GET['toggle'] == '2a') {?>
            <div id="toggle_2a">
                <img alt='Loading..' style='margin-top:20px;margin-bottom:20px;' src='../sw_asset/img/loading.gif' width=64><br/><span style='font-size:10px;'>Loading data. Please wait a while.</span><br/><br/>
            </div>
        <?php }?>

        <?php
            if (isset($_GET['toggle']) && $_GET['toggle'] == '2b') {
                include_once 'load_toggle_2b.php';
            }
    
            if (isset($_GET['toggle']) && $_GET['toggle'] == '3') {
                include_once 'load_toggle_3.php';
            }
    
            if (isset($_GET['toggle']) && $_GET['toggle'] == '4') {
                include_once 'load_toggle_4.php';
            }

            if (isset($_GET['toggle']) && $_GET['toggle'] == '5') {
                include_once 'load_toggle_5.php';
            }

            if (isset($_GET['toggle']) && $_GET['toggle'] == '6' && $system_function == 'photo') {
                include_once 'load_toggle_6.php';
            }
        ?>
    </div>
                    
    <hr>
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
