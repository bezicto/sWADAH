<?php
/*
Filename: sw_stats/adsreport_typeaccess_more.php
Usage: Access details by type (list of items)
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Type Access Details - More";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';

    if (!is_numeric($_GET["type"])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Invalid parameter detected.</h2><em>Please contact the system administrator if you see this message.</em></div>";
        mysqli_close($GLOBALS["conn"]); exit();
    }
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <div style="text-align:center">
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Access details for <?php echo $_GET['acstat'];?></strong> :</td></tr>
        </table>
        
        <table class=whiteHeaderNoCenter>
            <tr class=whiteHeaderNoCenter><td style='width:50;'></td><td style='width:100;'>Doc ID</td><td>IP</td><td style='text-align:left;'>Title</td></tr>
            <?php
                $n = 1;
                $stmt_fsb = $new_conn->prepare("select eg_item_access.eg_item_id as eg_item_id, eg_item_access.39ipaddr as 39ipaddr
                 from eg_item_access inner join eg_item on eg_item.id=eg_item_access.eg_item_id
                  where eg_item.38typeid=? and DATE_FORMAT(STR_TO_DATE(eg_item_access.39logdate, '%a %d/%m/%Y %l:%i %p'), '/%m/%Y') = ?");
                $stmt_fsb->bind_param("is", $_GET["type"], $_GET["acstat"]);
                $stmt_fsb->execute();
                $result_fsb = $stmt_fsb->get_result();

                while ($myrow_fsb = $result_fsb->fetch_assoc()) {
                    $id_fsb = $myrow_fsb["eg_item_id"];
                    $ipaddr_fsb = $myrow_fsb["39ipaddr"];
                    
                    $query_title = "select 38title from eg_item where id='$id_fsb'";
                    $result_title = mysqli_query($GLOBALS["conn"], $query_title);
                    $myrow_title = mysqli_fetch_array($result_title);
                    $title = $myrow_title["38title"];

                    echo "<tr class=$color_scheme"."Hover><td style='width:50px;'>$n</td><td>$id_fsb</td><td>$ipaddr_fsb</td><td style='text-align:left;'>$title</td></tr>";
                    
                    $n=$n+1;
                }
            ?>
        </table>

        <br/><br/><a class='sButton' href='javascript:history.go(-1)'><span class='fas fa-arrow-circle-left'></span> Back to previous page</a>
    </div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
