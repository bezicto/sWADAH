<?php
/*
Filename: sw_stats/adsreport_keyworddetails.php
Usage: Hits details for a searches (by popular keywords)
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Keyword Stats";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php //include_once '../sw_inc/loggedinfo.php'; ?>

    <br/>
    
    <div style="text-align:center">

        <?php
            $show = isset($_GET['show']) ? $_GET['show'] : null;
                                                                                
            $sortby = $show == 'popular' ? "37freq" : "id";
            $query_userlog = "select * from eg_userlog order by $sortby desc LIMIT 100";
            $result_userlog = mysqli_query($GLOBALS["conn"], $query_userlog);
                        
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=$color_scheme"."HeaderCenter><td colspan=4>";
                    echo "Top 100 recorded unique search terms :";
                    echo "<br/>Sort by: ";
                        if (isset ($_GET['show']) && $show == 'popular') {
                            echo "<a href='adsreport_keyworddetails.php?show=latest'>Latest keyword</a> | <strong>Keyword popularity</strong>";
                        } else {
                            echo "<strong>Latest keyword</strong> | <a href='adsreport_keyworddetails.php?show=popular'>Keyword popularity</a>";
                        }
                echo "</td></tr>";
                
                echo "<tr class=whiteHeaderNoCenter><td></td><td>Terms</td><td>Total Hits</td><td>Last used</td></tr>";
                                                                
                $n = 1;
                while ($myrow_userlog = mysqli_fetch_array($result_userlog)) {
                    echo "<tr class=$color_scheme"."Hover><td>$n</td><td style='text-align:left;'>".$myrow_userlog["37keyword"]."</td><td>".$myrow_userlog["37freq"]."</td><td>".$myrow_userlog["37lastlog"]."</td></tr>";
                    $n = $n +1 ;
                }
            echo "</table>";
                        
        ?>
    
        <br/><br/>
        <a class='sButton' href='javascript:window.close();'><span class="fa-solid fa-rectangle-xmark"></span> Close</a>

    </div>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
