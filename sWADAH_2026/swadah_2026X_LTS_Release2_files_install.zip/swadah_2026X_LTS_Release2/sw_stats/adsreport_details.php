<?php
/*
Filename: sw_stats/adsreport_details.php
Usage: Report detail for a user
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Report Details";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    ini_set('max_execution_time', 180);
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
                    
    <hr>

    <div style="text-align:center">
        <?php
                
                if ($_SESSION[$ssn.'editmode'] == 'SUPER' && (isset($_GET['inf']) && $_GET['inf'] != '')) {
                    $get_inf = $_GET["inf"];
                    $get_infname = $_GET["infname"] ?: '';
                    $getappend = "&inf=$get_inf&infname=$get_infname";
                } else {
                    $get_inf = $_SESSION[$ssn.'username'];
                    $get_infname = "";
                    $getappend = "";
                }
                
                if (isset($_GET['inputyear'])) {$get_inputyear = $_GET["inputyear"];}
                                                                                                                            
                echo "<table class=$color_scheme"."Header><tr><td>";
                    $query_inputyear = "select distinct SUBSTRING(39inputdate,1,4) AS inputyear from eg_item order by inputyear";
                    $result_inputyear = mysqli_query($GLOBALS["conn"], $query_inputyear);
                    echo "<strong>Select year</strong> :";
                                
                    echo " <select name=\"inputyear\" ONCHANGE=\"location = this.options[this.selectedIndex].value;\">";
                        while ($myrow_inputyear = mysqli_fetch_array($result_inputyear)) {
                            $inputyear = $myrow_inputyear["inputyear"];
                            echo "<option value=\"adsreport_details.php?inputyear=$inputyear$getappend\"";
                            echo (isset($_GET["inputyear"]) && $_GET["inputyear"] == $inputyear) ? " selected" : "";
                            echo ">$inputyear</option>";
                        }
                        echo "<option value=\"adsreport_details.php?inputyear=All$getappend\"";
                        echo ((isset($_GET["inputyear"]) && $_GET["inputyear"] == 'All') || !isset($_GET["inputyear"])) ? " selected" : "";
                        echo " >All</option>";
                    echo "</select>";
                echo "</td></tr></table>";
                                        
                if (isset($_GET['inputyear']) && $_GET["inputyear"] <> 'All') {
                    $param = $get_inputyear."%";
                    $stmt_inputby= $new_conn->prepare("select SQL_CALC_FOUND_ROWS * from eg_item where 39inputby=? and 39inputdate like ? order by id desc");
                    $stmt_inputby->bind_param("ss", $get_inf, $param);
                } else {
                    $stmt_inputby= $new_conn->prepare("select SQL_CALC_FOUND_ROWS * from eg_item where 39inputby=? order by id desc");
                    $stmt_inputby->bind_param("s", $get_inf);
                }

                $stmt_inputby->execute();
                $result_inputby = $stmt_inputby->get_result();
                $num_results_affected = $result_inputby->num_rows;
    
                echo "<table class=$color_scheme"."Header><tr><td>";
                    echo "<strong>User Statistics : </strong>$get_infname ($get_inf)";
                    echo "<strong><br/>Total input ";
                    echo (isset($_GET["inputyear"]) && $_GET["inputyear"] != 'All') ? "for year " . $_GET["inputyear"] : "";
                    echo " :</strong> $num_results_affected";
                echo "</td></tr></table>";

                //months calculation
                if (isset($_GET["inputyear"]) && $_GET["inputyear"] != 'All') {
                    $month_array = array();
                    $pages_array = array();
                    
                    for ($counter=1; $counter<=12; $counter+=1) {
                        $counter_text = ($counter <= 9) ? '0' . $counter : $counter;
                        $get_monthcount = $get_inputyear.'-'.$counter_text;
                        
                        $param = $get_monthcount."%";
                        $stmt_ministat = $new_conn->prepare("select count(*) as total3 from eg_item where 39inputby=? and 39inputdate like ?");
                        $stmt_ministat->bind_param("ss", $get_inf, $param);
                        $stmt_ministat->execute();
                        $stmt_ministat->bind_result($month_array[]);
                        $stmt_ministat->fetch();$stmt_ministat->close();

                        //beta -- counted pdf pages --start
                        if ($usePdfInfo) {
                            $this_count = 0;
                            $this_photo_count = 0;
                            
                            $param = $get_monthcount."%";
                            $stmt_countpages= $new_conn->prepare("select id,39inputdate,41instimestamp,51_pagecount,52photo_count from eg_item where 39inputby=? and 39inputdate like ?");
                            $stmt_countpages->bind_param("ss", $get_inf, $param);
                            $stmt_countpages->execute();
                            $result_countpages = $stmt_countpages->get_result();
                            
                            while ($myrow_countpages = $result_countpages->fetch_assoc()) {
                                $dir_year = substr($myrow_countpages["39inputdate"], 0, 4);
                                $id_counted = $myrow_countpages["id"];
                                $timestamp_counted = $myrow_countpages["41instimestamp"];
                                $page_count = $myrow_countpages["51_pagecount"];
                                $photo_count = $myrow_countpages["52photo_count"];
                                
                                if ($page_count == 0 && $usePdfInfo && is_file("../$system_docs_directory/$dir_year/$id_counted"."_"."$timestamp_counted.pdf")) {
                                    $page_count = sfx_getPDFPages($appendroot, "../$system_docs_directory/$dir_year/$id_counted"."_"."$timestamp_counted.pdf");
                                    if ($page_count == 0) {
                                        $page_count = sfx_getPDFPagesSmalot($appendroot, "../$system_docs_directory/$dir_year/$id_counted"."_"."$timestamp_counted.pdf");
                                    }
                                    mysqli_query($GLOBALS["conn"], "update eg_item set 51_pagecount=$page_count where id=$id_counted");
                                }
                            
                                $this_count = $this_count + $page_count;
                                $this_photo_count = $this_photo_count + $photo_count;
                            }
                            $pages_array[] = $this_count;
                            $photos_array[] = $this_photo_count;
                        } else {
                            $pages_array[] = null;
                            $photos_array[] = null;
                        }
                        //beta -- counted pdf pages --end
                    }
                    
                    if ($_SESSION[$ssn.'editmode'] == 'SUPER') {
                        $userappend = "&user=$get_inf";
                    }

                    echo "<table class=$color_scheme"."Header>";
                    echo "<tr>";
                        $months = ["Jan", "Feb", "Mac", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        for ($i = 0; $i < 12; $i++) {
                            if ($i == 6) {
                                echo "</tr><tr>"; // Start a new row after June (6 months)
                            }
                            $month_number = str_pad($i + 1, 2, "0", STR_PAD_LEFT); // Format month number with leading zero
                            echo "<td><strong>{$months[$i]}</strong> <br/>
                                Title: <a href='adsreport_details_pop.php?month=$month_number&year=".$_GET['inputyear']."$userappend' onclick='return js_openPopup(this.href,390,400);'>{$month_array[$i]}</a><br/>
                                Pages: <span style='color:magenta;'>{$pages_array[$i]}</span><br/>
                                Photo: <span style='color:magenta;'>{$photos_array[$i]}</span></td>";
                        }
                    echo "</tr>";
                    echo "</table>";
                    
                    unset($month_array);
                }
                
                echo "<table class=whiteHeader style='width:100%;'>";
                echo "<tr style='text-decoration:underline;'>";
                    echo "<td width=25></td>";
                    echo "<td>Title</td>";
                    echo "<td width=60>Page Count</td>";
                    echo "<td width=60>Photo Count</td>";
                    echo "<td width=60>$type_as</td>";
                    echo "<td width=120>Input date</td>";
                echo "</tr>";
                    $n = 1;
                                                        
                    while ($myrow_inputby = $result_inputby->fetch_assoc()) {
                        $query_type = "select 38type from eg_item_type where 38typeid = '".$myrow_inputby["38typeid"]."'";
                        $result_type = mysqli_query($GLOBALS["conn"], $query_type);
                        $myrow_type = mysqli_fetch_array($result_type);
                        $type_text = $myrow_type ? $myrow_type["38type"] : "Undefined";
                     
                        echo "<tr class=$color_scheme"."Hover>";
                            echo "<td>$n</td>";
                            echo "<td style='text-align:left;'><a href='../sw_admin/details.php?det=".$myrow_inputby["id"]."'>".$myrow_inputby["38title"]."</a></td>";
                            echo "<td>".$myrow_inputby["51_pagecount"]."</td>";
                            echo "<td>".$myrow_inputby["52photo_count"]."</td>";
                            echo "<td>$type_text</td>";
                            echo "<td>".$myrow_inputby["39inputdate"]."</td>";
                        echo "</tr>";
                                                                        
                        $n = $n +1 ;
                    }
                echo "</table>";
                
        ?>
    </div>
        
    <br/><br/>
    <?php if ($_SESSION[$ssn.'editmode'] == 'SUPER') { ?>
        <div style="text-align:center"><a class='sButton' href='adsreport.php'><span class='fas fa-arrow-circle-left'></span> Back to report page</a></div>
    <?php }?>
    
    <br/><hr>
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
