<?php

/*
Filename: config.php
Usage: system config default file
Version: 20240709.1200
Last structural change: -

The following php extension need to be enable in php.ini:
bz2,curl,fileinfo,gd or gd2,gettext,intl,mbstring,exif,mysqli,openssl,pdo_mysql,pdo_sqlite
After uncomment the line to enable those above, restart Apache.

Read carefully all comments before proceeding. Failure and success at your own risks.

*/

//database connection properties
$dbhost = "localhost";//set the ip or host for mariadb/mysql database
$dbname = "system_db";//database name to access
$dbuser = "system_user";//username to access the database
$dbpass = "system_password";//password the username above

/*
AES KEY
=======
you will need to very careful and do not change the $aes_key mid way when using the
system as your user not be able to login unless you revert back to the old key.
set this once and never again edit it. please change this value as soon as possible.
*/
$aes_key = "45C798DB3EBC65DFBC69A0F36F605E6CA2447CD519C50B7DA0D0D45D2B0F2431";

//allowed IP for administration page
//only ip in this range are allowed to access administration page
//format range 10.x.x or 10.x or specific: 10.x.x.x
//works with ipv4
$allowed_ip_enabler = false; // enable allowed_ip below to enforce = true disable = false.
$allowed_ip = array(
    '::1',
    '127.0.0.1',
);
