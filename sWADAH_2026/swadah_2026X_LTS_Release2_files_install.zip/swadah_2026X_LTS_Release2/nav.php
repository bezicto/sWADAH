<?php
/*
Filename: nav.php
Usage: General page for displaying about or FAQ
Qualification: access point page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    
    include_once 'core.php';
    
    // keep this page in user browser for 12 hours
    if (!isset($_SESSION[$ssn.'username']) && !isset($_SESSION[$ssn.'username_guest'])) {
        header("Cache-Control: public, max-age=43200, immutable");
        header("Expires: " . gmdate("D, d M Y H:i:s", time() + 43200) . " GMT");
        header_remove("Pragma");
    }

    $stmt_fdb = $new_conn->prepare("select * from eg_composer where 45name=?");
    $stmt_fdb->bind_param("s", $_GET['page']);
    $stmt_fdb->execute();
    $result_fdb = $stmt_fdb->get_result();
    $num_results_affected = $result_fdb->num_rows;
    $myrow_fdb= $result_fdb->fetch_assoc();
    
    if ($num_results_affected >= 1) {
        $id_fdb = $myrow_fdb["id"];
        $name_fdb = $myrow_fdb["45name"];
        $desc_fdb = $myrow_fdb["45desc"];
        $value_fdb = $myrow_fdb["45value"];
    } else {
        echo "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>";
        exit;
    }

    $thisPageTitle = $desc_fdb;
?>

<html lang='en'>

<head>
    <?php include_once 'sw_inc/header.php'; ?>
</head>

<body class='<?= $color_scheme;?>'>
        
    <?php include_once 'sw_inc/loggedinfo.php'; ?>

    <hr>

    <?php
        if (isset($_SESSION[$ssn.'editmode']) && $_SESSION[$ssn.'editmode'] == 'SUPER') {
            echo "<div style='width:100%;text-align:right;'><i class=\"fas fa-edit\"></i> [<a href=\"sw_admin/composer.php#$name_fdb\">Edit this page</a>]</div><br/>";
        }

         echo $value_fdb;
    ?>

    <hr>
    
    <div style='text-align:center;'>
        <?php include_once 'sw_inc/footer.php';?>
    </div>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
