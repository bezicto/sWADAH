<?php
/*
Filename: sw_depos/depoactivate.php
Usage: Self activation module for user when they click on their received email
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Depositor Login Page";
    session_start();define('includeExist', true);
    include_once '../core.php';
    if (isset($_SESSION[$ssn.'useridentity'])) {unset($_SESSION[$ssn.'useridentity']);}
?>

<html lang='en'>

<head>
    <?php
        if ($system_function != 'full' && $system_function != 'depo') {
            header("Location: ../index.php");
            die();
        }
    ?>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>' style='text-align:center;'>
    
    <?php
                
        if (isset($_REQUEST['k']) && $_REQUEST["k"] != '' && ctype_alnum($_REQUEST["k"])) {
            $param_key = addslashes($_REQUEST['k']);
            
            $stmt_login = $new_conn->prepare("select registerkey from eg_auth_depo where registerkey=? and activation='NOTACTIVE'");
            $stmt_login->bind_param("s", $param_key);
            $stmt_login->execute();$stmt_login->store_result();
                $num_results_affected_login = $stmt_login->num_rows;
            $stmt_login->bind_result($registerkey);
            $stmt_login->fetch();$stmt_login->close();
            
            if ($num_results_affected_login <> 0) {
                $stmt_update = $new_conn->prepare("update eg_auth_depo set activation='ACTIVE' where registerkey=?");
                $stmt_update->bind_param("s", $param_key);
                $stmt_update->execute();$stmt_update->close();
                echo "<i class=\"fas fa-check-square fa-2xl\"></i><br/><br/><div style='text-align:center;color:blue;'>Your account has been activated.<br/><a href='$system_path"."sw_depos/depologin.php'>Click here</a> to login.<br/><br/></div>";
            } else {
                echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><div style='text-align:center;color:red;'>Invalid registration key or account has been activated. IP will be logged for security purposes.<br/><br/></div>";
            }
        } else {
            echo "<i class=\"fas fa-exclamation-triangle fa-2xl\"></i><br/><br/><div style='text-align:center;color:red;'>Invalid registration key. IP will be logged for security purposes.<br/><br/></div>";
        }
    ?>

    <?php include_once '../sw_inc/footer.php';?>
    
</body>
    
</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
