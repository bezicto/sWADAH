<?php
/*
Filename: detailsg.php
Usage: Detail page for others
Qualification: access point page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php

    $thisPageTitle = "Item Details";
    session_start();define('includeExist', true);
    header("Cache-Control: max-age=43200"); // keep this page in user browser for 12 hours
    
    include_once 'core.php';

    if (!isset($_SESSION[$ssn.'username']) && !isset($_SESSION[$ssn.'username_guest'])) {
        include_once 'sw_inc/access_ip.php';
    }
    include_once 'sw_inc/functions.php';

    if (isset($_SESSION[$ssn.'whichbrowser']) && $_SESSION[$ssn.'whichbrowser'] != 'listgenerator') {
        $_SESSION[$ssn.'whichbrowser'] = "detailsg";
    }
    
    sfx_check_is_blocked("$recorded_incidents_directory/", "");

    //loginless check, if loginless is for this page
    include_once 'sw_inc/loginless_check.php';

    $get_id_det = !is_numeric($_REQUEST["det"]) ? 0 : $_REQUEST["det"];

    //prevent unauthorize user to view folder assigned to specific users
    $allowed_folder_access = sfx_sGetValue("38folderid", "eg_item", "id", $get_id_det);
    if (((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) && $allowed_folder_access != 0) {
        if (isset($_SESSION[$ssn.'username'])) {
            $auth_user = $_SESSION[$ssn.'username'];
        } elseif (isset($_SESSION[$ssn.'username_guest'])) {
            $auth_user = $_SESSION[$ssn.'username_guest'];
        }
        $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$allowed_folder_access'";
        $result_user = mysqli_query($GLOBALS["conn"], $query_user);
        if (mysqli_num_rows($result_user) != 1) {
            sfx_echoPopupAlert("You don't have authorization to view the content go this item.", "goback");
            mysqli_close($GLOBALS["conn"]);
            exit();
        }
    } elseif ($allowed_folder_access != 0) {
        sfx_echoPopupAlert("You don't have authorization to view the content go this item.", "goback");
        mysqli_close($GLOBALS["conn"]);
        exit();
    }

    //check for allowed temporary access
    $allow_temp_access = false;
    if (isset($_GET['at']) && ctype_alnum($_GET['at'])) {
        $token = $_GET['at'];
        $stmt_at = $new_conn->prepare("select id,since,usagecount from eg_tempaccess where eg_item_id=? and token=?");
        $stmt_at->bind_param("is", $get_id_det, $token);
        $stmt_at->execute();
        $result_at = $stmt_at->get_result();
        $myrow_at = $result_at->fetch_assoc();
        if ($myrow_at) {
            if ((time() - $myrow_at["since"]) <= $tmpal_access_duration && $myrow_at["usagecount"] < $tmpal_access_count) {
                $allow_temp_access = true;
                $newcount = $myrow_at["usagecount"]+1;
                mysqli_query($GLOBALS["conn"], "update eg_tempaccess set usagecount=$newcount where id=".$myrow_at["id"]);
            } else {
                $allow_temp_access = false;
                if ($tmpal_delete_method == "delete") {
                    mysqli_query($GLOBALS["conn"], "delete from eg_tempaccess where eg_item_id=$get_id_det and token='$token'");
                }
                echo "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited. Link has exceeded usage policy.</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>";
                exit;
            }
        } else {
            echo "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited. Invalid Link.</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>";
            exit;
        }
    }

    //get item data to display after all checking above finished with no issue
    $stmt_item = $new_conn->prepare("select * from eg_item where id=? and 38status!='UNLISTED'");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
    
    $item_status5 = '0';//default, will be use to check if the item is available or not
    if ($num_results_affected == 1) {
        
        $id5 = $myrow_item["id"];
        
        // check if cookie 'recent_items' exist
        if (isset($_COOKIE['recent_items'])) {
            $recent_items = explode(',', $_COOKIE['recent_items']);// get the available cookie and change to array
        } else {
            $recent_items = array();// else start a new array
        }
        // add id to array if not exist
        if (!in_array($id5, $recent_items)) {
            $recent_items[] = $id5;
        }
        // set cookie to the new value
        setcookie('recent_items', implode(',', $recent_items), time() + (86400 * 1), "/"); // cookie will last one day

        $item_status5 = $myrow_item['50item_status'];
        $status5 = $myrow_item["38status"];

        $titlestatement5 = $myrow_item["38title"];
            $exploded_removed_words = explode(',', $remove_word_from_title);
            foreach ($exploded_removed_words as $value) {
                $titlestatement5 = str_replace($value, "", $titlestatement5);
            }
            $titlestatement5 = htmlspecialchars_decode($titlestatement5);
        
        $typestatement5 = $myrow_item["38typeid"];
        $location5 = $myrow_item["38location"];
        $link5 = $myrow_item["38link"];
        $authorname5 = $myrow_item["38author"];
        $callnumber5 = $myrow_item["38localcallnum"];
        $dir_year5 = substr($myrow_item["39inputdate"], 0, 4);
        $fulltext5 = $myrow_item["41fulltexta"];
        $reference5 = $myrow_item["41reference"];
        $isabstract5 = $myrow_item["41isabstract"];
        $instimestamp5 = $myrow_item["41instimestamp"];
        $subjectheading5 = $myrow_item["41subjectheading"];
        $accessnum5 = $myrow_item["38accessnum"];
        $isbn5 = $myrow_item["38isbn"];
        $issn5 = $myrow_item["38issn"];
        $edition5 = $myrow_item["38edition"];
        $publication5 = $myrow_item["38publication"];
        $physicaldesc5 = $myrow_item["38physicaldesc"];
        $series5 = $myrow_item["38series"];
        $notes5 = $myrow_item["38notes"];
        $source5 = $myrow_item["38source"];
        $hits5 = $myrow_item['41hits'];

        //get data from eg_item2 table
        $query_item_ex = "select * from eg_item2 where eg_item_id=$id5";
        $result_item_ex = mysqli_query($GLOBALS["conn"], $query_item_ex);
        $myrow_item_ex = mysqli_fetch_array($result_item_ex);
            $titlestatement5_b = $myrow_item_ex["38title_b"] ?? '';
            $titlestatement5_c = $myrow_item_ex["38title_c"] ?? '';
            $publication5_b = $myrow_item_ex["38publication_b"] ?? '';
            $publication5_c = $myrow_item_ex["38publication_c"] ?? '';
            if ($myrow_item_ex["38pname1"] != '') {
                $additional_authors = "<li>".$myrow_item_ex["38pname1"]."</li>" ?? '';
                if ($additional_authors) {
                    for ($i = 2; $i <= 10; $i++) {
                        if (!empty($myrow_item_ex["38pname$i"])) {
                            $additional_authors .= "<li>" . $myrow_item_ex["38pname$i"]."</li>";
                        }
                    }
                }
            } else {
                $additional_authors = "";
            }
            $vtitle5_a = $myrow_item_ex["38vtitle_a"] ?? '';
            $vtitle5_b = $myrow_item_ex["38vtitle_b"] ?? '';
            $vtitle5_g = $myrow_item_ex["38vtitle_g"] ?? '';
            $summary5_a = $myrow_item_ex["38summary_a"] ?? '';
            $se_pname5_a = $myrow_item_ex["38se_pname_a"] ?? '';
            $se_pname5_x = $myrow_item_ex["38se_pname_x"] ?? '';
            $se_pname5_y = $myrow_item_ex["38se_pname_y"] ?? '';
            $geographic_coverage_note5_a=$myrow_item_ex["38geographic_coverage_note_a"] ?? '';
            $original_version_note5_t=$myrow_item_ex["38original_version_note_t"] ?? '';
            $terms_governing_use5_a=$myrow_item_ex["38terms_governing_use_a"] ?? '';
            $other_relationship_entry5_n=$myrow_item_ex["38other_relationship_entry_n"] ?? '';
        
        //get hits count and update it on the main table (eg_item) every now and then this record get view by users
        if ($hits5 == 0) {
            $query_access = "select count(eg_item_access.id) as totalid from eg_item_access,eg_item where eg_item_access.eg_item_id=eg_item.id and eg_item_access.eg_item_id='$id5'";
            $result_access = mysqli_query($GLOBALS["conn"], $query_access);
            $myrow_access = mysqli_fetch_array($result_access);
            $inputhits = $myrow_access["totalid"] + 1;
        } else {
            $inputhits = $hits5 + 1;
        }
            mysqli_query($GLOBALS["conn"], "update eg_item set 41hits=$inputhits where id=$id5");
            $datePattern = date("D d/m/Y h:i a");
            $ip = $_SERVER['REMOTE_ADDR'];
            //check if user login from loginless
            $loginlessid = isset($_SESSION[$ssn.'lls_id']) ? $_SESSION[$ssn.'lls_id'] : 0;
            //put into statistics
            mysqli_query($GLOBALS["conn"], "insert into eg_item_access values(DEFAULT,$get_id_det,$loginlessid,'$datePattern','$ip')");
        
        //enable access to partial text/guest
        //this will always be shown to guest
        $pdocs_file = "$system_pdocs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf";
        
        //enable access to full text
        $docs_file = "sw_admin/temp/no_permission.pdf";//default
        if (
            (
                (sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || $allow_temp_access || isset($_SESSION[$ssn.'username_guest']))
                && $status5 == 'AVAILABLE'
            )
             ||
              $_SERVER["REMOTE_ADDR"] == $ezproxy_ip
               || (isset($_SESSION[$ssn.'lls']) && $_SESSION[$ssn.'lls'])
            ) {
            $docs_file = "$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf";
        }

        //enable access to image attachment
        //the main image attachment will always be shown as watermarked version
        $albums_file = "$system_albums_watermark_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg";
        
        //for handling freetype
        $isos_file = "sw_admin/temp/no_permission.pdf";//default
        if (is_dir("$system_isofile_directory/$dir_year5")) {
            $files_scanned = scandir("$system_isofile_directory/$dir_year5");
            foreach ($files_scanned as $fileitem) {
                if (preg_match("/$id5"."_"."$instimestamp5/i", $fileitem) == 1) {
                    $isos_file = "$system_isofile_directory/$dir_year5/$fileitem";
                    break;
                }
            }
        }
        
        //generate downloadkey
        if (empty($_SERVER['REQUEST_URI'])) {
            $_SERVER['REQUEST_URI'] = $_SERVER['SCRIPT_NAME'];
        }
        $url = preg_replace('/\?.*$/', '', $_SERVER['REQUEST_URI']);
        $folderpath = $system_path;
        $ip_address = $_SERVER["REMOTE_ADDR"];
        $time = date('U');
        $registerid = mysqli_query(
            $GLOBALS["conn"], "INSERT INTO eg_downloadkey
             (id,eg_item_id,ip_address,timestamped,downloads)
              VALUES(DEFAULT,'$id5','$ip_address','$time',DEFAULT)"
           );
           $key = 0;//if not inserted properly then the key will be 0
           if ($registerid) {
                $key = mysqli_insert_id($GLOBALS["conn"]);//if records are properly recorded then, we assign $key to the last inserted id from above statement
           }
    }//$num_results_affected == 1

    include_once 'sw_inc/token_validate.php';
    
?>

<html lang='en'>

<?php
//if $item_status5 == 0
if ($item_status5 == '0' || $num_results_affected == '0') {
?>
    <head><?php include_once 'sw_inc/header.php'; ?></head>
    <body class='<?= $color_scheme;?>'>
        <?php include_once 'sw_inc/navbar_guest.php'; ?>
        <div style='text-align:center'>
            <hr>
            <h3>Sorry. This item is not available.</h3>
            <?php
                if (!isset($_GET['h'])) {
                    echo "<a class='sButton' href='searcher.php'><span class='fas fa-arrow-circle-left'></span> Back to searcher</a>";
                }
            ?><br/>
        </div>
        <hr>
        <?php include_once 'sw_inc/footer.php'; ?>
    </body>
<?php
} elseif ($item_status5 == '1') {
?>
    <head>
        <meta name="description" content="<?= $system_title;?> Item Detail: <?= $titlestatement5; ?>" />
        <meta name="citation_title" content="<?= "$titlestatement5 $titlestatement5_b $titlestatement5_c"; ?>">
        <meta name="citation_author" content="<?= $authorname5; ?>">
        <meta name="citation_publication_date" content="<?= $dir_year5; ?>">
        <meta name="citation_journal_title" content="<?= ''; ?>">
        <meta name="citation_publisher" content="<?= $source5; ?>">
        <meta name="citation_volume" content="<?= ''; ?>">
        <meta name="citation_issue" content="<?= ''; ?>">
        <meta name="citation_firstpage" content="<?= '';?>">
        <meta name="citation_lastpage" content="<?= '';?>">
        <meta name="citation_abstract_html_url" content="<?= sfx_getCurrentBaseURL().'detailsg.php?det='.$id5; ?>">
        <?php if (is_file($pdocs_file)) { ?>
            <meta name="citation_pdf_url" content="<?= sfx_getCurrentBaseURL().'detailsg.php?det='.$id5; ?>">
        <?php
        }
            include_once 'sw_inc/header.php';
            //autologout
            if (isset($_SESSION[$ssn.'lls'])) {
                echo "<meta http-equiv=\"refresh\" content=\"1800;url=index.php?c=ls\" />";
            }
        ?>

        <script>
            $(document).ready(function() {
                var strText = '<?= $system_path;?>detailsg.php?det=<?= $id5;?>&h=1';
                jQuery('#selecteddiv').qrcode({
                    text : strText,width:128,height:128
                });
            });

            function js_handleClick(event) {
                // Array of link IDs to update
                const links = ['link_d', 'link_i', 'link_a'];
                
                setTimeout(() => {
                    // Update all links with the same changes
                    links.forEach(id => {
                        const link = document.getElementById(id);
                        if (link) {
                            link.style.pointerEvents = 'none';
                            link.style.color = 'grey';
                            link.innerHTML = 'Please reload page to generate new link for this document.';
                        }
                    });
                }, 1000);
            }
        </script>
        
    </head>

    <body class='<?= $color_scheme;?>'>
        
        <?php include_once 'sw_inc/navbar_guest.php'; ?>
        
        <hr>

        <div style='text-align:center'>
            <?php
                
                $get_highlight = $_GET["highlight"] ?? '';
                                
                //bookmarking handling -start
                if ((isset($_GET['bk']) && $_GET['bk'] == 'yes') && isset($_SESSION[$ssn.'username_guest'])) {
                    $query_charge = "select 40dc from eg_item_charge where 39patron='".$_SESSION[$ssn.'username_guest']."' and 38accessnum='$accessnum5'";
                    $result_charge = mysqli_query($GLOBALS["conn"], $query_charge);
                    $myrow_charge = mysqli_fetch_array($result_charge);
                    $num_results_charge = mysqli_num_rows($result_charge);
                                                            
                    $status_charge = '';
                    if ($num_results_charge >= 1) {
                        $status_charge = $myrow_charge["40dc"];
                    }
                                        
                    if ($status_charge == 'DC') {
                        mysqli_query(
                            $GLOBALS["conn"],
                            "update eg_item_charge set 39charged_on=".time().", 40dc='NO', 40dc_on='', 40dc_by=''
                                where 39patron = '".$_SESSION[$ssn.'username_guest']."' and 38accessnum='$accessnum5'"
                        );
                    } else {
                        mysqli_query(
                            $GLOBALS["conn"],
                            "insert into eg_item_charge values(
                                DEFAULT,
                                '$accessnum5',
                                '".$_SESSION[$ssn.'username_guest']."',
                                '".time()."',
                                '".$_SESSION[$ssn.'username_guest']."',
                                0,
                                'NO',
                                '',
                                ''
                                )"
                        );
                    }
                }
                if (isset ($_SESSION[$ssn.'username_guest'])) {
                    echo "<table class=whiteHeader><tr class=whiteHeaderCenter><td>";
                            $query_chargeid = "select id from eg_item_charge where 39patron = '".$_SESSION[$ssn.'username_guest']."' and 38accessnum='$accessnum5' and 40dc='NO'";
                            $result_chargeid = mysqli_query($GLOBALS["conn"], $query_chargeid);
                            if (mysqli_num_rows($result_chargeid) >= 1) {
                                echo "<input type='button' class='form-orange-button-noshadow' style='font-size:10pt' value='BOOKMARKED'><br/>";
                            } else {
                                if (sfx_isPatronEligibility($_SESSION[$ssn.'username_guest']) == 'FALSE' || sfx_isPatronEligibility($_SESSION[$ssn.'username_guest']) == 'DEPATRON') {
                                    echo "<input type='button' class='form-red-button-noshadow' style='font-size:10pt' value='You have reached maximum bookmark items'></span>";
                                } else {
                                    echo "[<a href='detailsg.php?det=$get_id_det&bk=yes'>Bookmark this item</a>]";
                                }
                            }
                    echo "</td></tr></table>";
                }
                //bookmarking handling -end
                
                //if system works as photo mode, then show main image above
                if ($system_function == 'photo' && is_file("$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg")) {
                    if ($debug_mode == 'yes') {
                        echo "<span style='color:red;'>Debug:</span> $dir_year5/$id5";
                    }
                        echo "
                            <div style='background-color:black;'>
                                <img id='expandedImg' style='width:380px;margin-top:40px;margin-bottom:40px;' src='sw_inc/image.php?d=$id5&t=w''>
                                <span id='imgtext'></span>
                            </div>
                            <script>
                            function imageClickFunction(imgs) {
                                var expandImg = document.getElementById(\"expandedImg\");
                                expandImg.src = imgs.src;
                                expandImg.parentElement.style.display = \"block\";
                                imgtext.innerHTML = \"<br/><i style='font-size:16px;color:white;' class='fas fa-search-plus'></i> <a style='font-size:12pt;' target='_blank' href='\"+imgs.src+\"&db=1'>Click here to enlarge</a><br/><br/><br/>\";
                                window.scrollTo(0, 0);
                            }
                            </script>
                        ";
                        echo "<div style='background-color:black;display:flex;overflow-x: scroll;'>";
                            $otherPhotoExist = false;
                            $otherPhotos = "<div style='float:left;width:250px;padding:5px;margin: 0 auto;'><img class='centered-and-cropped' style='width:150px;height:150px;cursor: pointer;' src='sw_inc/image.php?d=$id5&t=w' onerror=this.src='sw_asset/img/no_image.png' onclick='imageClickFunction(this);'>";
                            if ($debug_mode == 'yes') {
                                $otherPhotos .= "<span style='color:white;'>"."$system_albums_directory/ $dir_year5/ $id5"."_"."$instimestamp5.jpg"."</span>";
                            }
                            $otherPhotos .= "</div>";
                            for ($x = 2; $x <= $maximum_num_imageatt_allowed; $x++) {
                                if (!is_file("$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5"."/$x"."_wm.jpg") && is_file("$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$x.jpg")) {
                                    sfx_watermark_image("$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$x.jpg", $watermark_overlay_file, "$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5"."/$x"."_wm.jpg");
                                }
                                if (is_file("$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5"."/$x"."_wm.jpg")) {
                                        $otherPhotos .= "<div style='float:left;width:250px;padding:5px;margin: 0 auto;'><img class='centered-and-cropped' style='width:150px;height:150px;cursor: pointer;' src='sw_inc/image.php?d=$id5&t=$x' onerror=this.src='sw_asset/img/no_image.png' onclick='imageClickFunction(this);'>";
                                        if ($debug_mode == 'yes') {
                                            $otherPhotos .= "<span style='color:white;'>"."$system_albums_directory/ $dir_year5/ $id5"."_"."$instimestamp5"."/$x"."_wm.jpg"."</span>";
                                        }
                                        $otherPhotos .= "</div>";
                                        $otherPhotoExist = true;
                                    }
                            }
                            if ($otherPhotoExist) {
                                echo $otherPhotos;
                            }
                        echo "</div>";
                }
                
                if (isset($link5) && strpos($link5, 'youtube.com') !== false && $youtube_detector) {
                    echo "<table style='background-color:black;width:100%;'><tr><td><div class='video-container'>
                            <iframe src='".sfx_convertToEmbedUrl($link5)."' allow='accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
                        </div></td></tr></table>
                    ";
                }
                
                //the main content of this file, shows all meta data for the selected item
                echo "<table class=whiteHeaderNoCenter style='border: 0px solid lightgrey; max-width:100%;overflow-x: auto;' width=100%>
                    <tr>
                    <td style='display: inline-block; padding: 5px;min-width:300px;max-width:350px;vertical-align:top;'>
                        <table border=0 class=whiteHeaderNoCenter width=100%>";

                            if ($show_qr_code_for_item) {echo "<tr><td colspan=2 style='text-align:center;vertical-align:top;'><strong>QR Code Link :</strong><br/><br/><div style='text-align:center;' id='selecteddiv'></div></td></tr>";}

                            echo "<tr><td style='text-align:right;vertical-align:top;' width=150><strong>$type_as :</strong></td><td style='text-align:left;vertical-align:top;'>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $typestatement5)."</td></tr>";

                            if ($show_browser_bar_guest && $subjectheading5 <> null) {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$subject_heading_as :</strong></td><td style='text-align:left;vertical-align:top;'>".sfx_getSubjectHeadingNames($subject_heading_delimiter, $subjectheading5)."</td></tr>";}
                                                
                            if ($isbn5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_020 :</strong></td><td style='text-align:left;vertical-align:top;'>$isbn5</td></tr>";}
                            
                            if ($issn5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_022 :</strong></td><td style='text-align:left;vertical-align:top;'>$issn5</td></tr>";}
                            
                            if ($callnumber5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_090 :</strong></td><td style='text-align:left;vertical-align:top;'>$callnumber5</td></tr>";}
                            
                            if ($authorname5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_100 :</strong></td><td style='text-align:left;vertical-align:top;'>$authorname5</td></tr>";}
                            
                            if ($additional_authors != '') {
                                echo "<tr>
                                    <td style='text-align:right;vertical-align:top;'><strong>$tag_700 :</strong></td>
                                    <td style='text-align:left;vertical-align:top;'><ul class='custom-indent'>$additional_authors</ul></td>
                                </tr>";
                            }
                            
                            if ($se_pname5_a != '') {echo "<tr><td style='text-align:right;'><strong>$tag_600 :</strong></td><td style='text-align:left;vertical-align:top;'>$se_pname5_a $se_pname5_x $se_pname5_y</td></tr>";}
                            
                            echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_245 :</strong></td><td style='text-align:left;vertical-align:top;'>$titlestatement5 $titlestatement5_b $titlestatement5_c</td></tr>";
                            echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Hits :</strong></td><td style='text-align:left;vertical-align:top;'>$hits5</td></tr>";
                            
                        echo "</table>
                    </td>

                    <td style='display: inline-block; padding: 5px;min-width:300px;max-width:350px;vertical-align:top;'>
                        <table border=0 class=whiteHeaderNoCenter width=100%>";

                        if ($vtitle5_a != '') {echo "<tr><td style='text-align:right;'><strong>$tag_246 :</strong></td><td style='text-align:left;vertical-align:top;'>$vtitle5_a $vtitle5_b $vtitle5_g</td></tr>";}
                    
                        if ($edition5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_250 :</strong></td><td style='text-align:left;vertical-align:top;'>$edition5</td></tr>";}

                        if ($publication5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;' width=150><strong>$publisher_place_of_production :</strong></td><td style='text-align:left;vertical-align:top;'>$publication5</td></tr>";}
                        
                        if ($publication5_b != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$publisher_as :</strong></td><td style='text-align:left;vertical-align:top;'>$publication5_b</td></tr>";}
                        
                        if (isset($publication5_c) && $publication5_c != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$publisher_year_of_publication :</strong></td><td style='text-align:left;vertical-align:top;'>$publication5_c</td></tr>";}
                        
                        if ($physicaldesc5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_300 :</strong></td><td style='text-align:left;vertical-align:top;'>$physicaldesc5</td></tr>";}
                        
                        if ($series5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_490 :</strong></td><td style='text-align:left;vertical-align:top;'>$series5</td></tr>";}
                        
                        if ($notes5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_500 :</strong></td><td style='text-align:left;vertical-align:top;'>$notes5</td></tr>";}
                        
                        if ($summary5_a != '') {echo "<tr><td style='text-align:right;'><strong>$tag_520 :</strong></td><td style='text-align:left;vertical-align:top;'>$summary5_a</td></tr>";}

                        if ($geographic_coverage_note5_a != '') {echo "<tr><td style='text-align:right;'><strong>$tag_522 :</strong></td><td style='text-align:left;vertical-align:top;'>$geographic_coverage_note5_a</td></tr>";}
                        
                        if ($original_version_note5_t != '') {echo "<tr><td style='text-align:right;'><strong>$tag_534 :</strong></td><td style='text-align:left;vertical-align:top;'>$original_version_note5_t</td></tr>";}
                        
                        if ($terms_governing_use5_a != '') {echo "<tr><td style='text-align:right;'><strong>$tag_540 :</strong></td><td style='text-align:left;vertical-align:top;'>$terms_governing_use5_a</td></tr>";}

                        if ($source5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_710 :</strong></td><td style='text-align:left;vertical-align:top;'>$source5</td></tr>";}
                        
                        if ($other_relationship_entry5_n != '') {echo "<tr><td style='text-align:right;'><strong>$tag_787 :</strong></td><td style='text-align:left;vertical-align:top;'>$other_relationship_entry5_n</td></tr>";}

                        if ($location5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_852 :</strong></td><td style='text-align:left;vertical-align:top;'>$location5</td></tr>";}
                    
                        if ($link5 <> null) {
                            $link5 = urldecode($link5);
                            if (substr($link5, 0, 4) != 'http') {$link5 = 'http://'.$link5;}

                            echo "<tr>
                                    <td style='text-align:right;vertical-align:top;'><strong>$tag_856 :</strong></td>
                                    <td style='text-align:left;vertical-align:top;'>
                                    <a href='$link5' target='_blank'>Click to view web link</a>";
                                    if (isset($link5) && strpos($link5, 'youtube.com') !== false) {
                                        echo " <sup style='color:magenta;'>YOUTUBE</sup>";
                                    }
                                    echo "</td>
                            </tr>";
                        }
                                                
                        if ($system_function != 'photo') {
                            if (is_file($pdocs_file)) {
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Guest :</strong></td><td style='text-align:left;vertical-align:top;'>";
                                    echo "<a target='_blank' href='".$folderpath."sw_inc/doc.php?t=p&did=$id5&id=".$key."'>Click to view PDF file</a>";
                                echo "</td></tr>";
                            }

                            if ($docs_file != 'sw_admin/temp/no_permission.pdf' && is_file($docs_file)) {
                                if (
                                        ((sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || $allow_temp_access) && $status5 == 'AVAILABLE')
                                        ||
                                        ($_SERVER["REMOTE_ADDR"] == $ezproxy_ip && $status5 == 'AVAILABLE')
                                        ||
                                        (isset($_SESSION[$ssn.'lls']) && $_SESSION[$ssn.'lls'])
                                        ||
                                        (isset($_SESSION[$ssn.'username_guest']))
                                    ) {
                                        echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Full Text :</strong></td><td style='text-align:left;vertical-align:top;'>";
                                            if (sfx_sGetValue("count(eg_item_id) as totalid", "eg_commercialize", "eg_item_id", $id5) == 1) {
                                                echo "Item is currently on commercial list";
                                            } else {
                                                echo "<a id='link_d' onclick='js_handleClick(event)' target='_blank' href='".$folderpath."sw_inc/doc.php?t=d&did=$id5&id=".$key."'>Click to view PDF file</a>";
                                            }
                                        echo "</td></tr>";
                                } elseif (sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || $status5 == 'LIMITED') {
                                    echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Full Text :</strong></td><td style='text-align:left;vertical-align:top;'>The author has requested the full text of this item to be restricted.</td></tr>";
                                } elseif (sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || $status5 == 'EMBARGO') {
                                    echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Full Text :</strong></td><td style='text-align:left;vertical-align:top;'>Item embargoed.</td></tr>";
                                } else {
                                    echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Full Text :</strong></td><td style='text-align:left;vertical-align:top;'>$system_docs_login_warning</td></tr>";
                                }
                            } elseif ($docs_file == 'sw_admin/temp/no_permission.pdf') {
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Full Text :</strong></td><td style='text-align:left;vertical-align:top;'>You have no permission to view this item.</td></tr>";
                            }

                            if ($isos_file != 'sw_admin/temp/no_permission.pdf' && is_file($isos_file) && (sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || isset($_SESSION[$ssn.'username_guest']))) {
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>$system_isofile_name</span> File :</strong></td><td style='text-align:left;vertical-align:top;'>
                                        <a id='link_i' onclick='js_handleClick(event)' target='_blank' href='".$folderpath."sw_inc/doc.php?t=i&did=$id5&id=".$key."'>Click to view file</a>
                                      </td></tr>";
                            }

                            if ($albums_file != 'sw_admin/temp/no_permission.pdf' && is_file($albums_file) && (sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || isset($_SESSION[$ssn.'username_guest']))) {
                                echo "<tr>
                                        <td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>JPG</span></strong> <strong>Related Image</strong> :</td>
                                        <td style='text-align:left;vertical-align:top;'><a id='link_a' onclick='js_handleClick(event)' target='_blank' href='".$folderpath."sw_inc/doc.php?t=a&did=$id5&id=".$key."'>Click to view Image file</a></td>
                                      </tr>";
                            }
                            
                            //related files handling
                            if (is_dir("$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5") && (sfx_sGetValue("38gview", "eg_item_type", "38typeid", $typestatement5) == 1 || isset($_SESSION[$ssn.'username_guest']))) {
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Related Files :</strong></td>";
                                echo "<td style='text-align:left;vertical-align:top;'>";
                                        $files = sfx_listFiles("$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5");
                                        echo "<ol style='padding-left:15px;margin-top:0px;'>";
                                        $enx = 0;
                                        foreach ($files as $file):
                                            $accesstype = sfx_sGetValue("38accesstype", "eg_relatedfiles", "38filename", $file);
                                                if ($accesstype == 'openaccess') {
                                                    $encyrpted_f = base64_encode(openssl_encrypt("$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5/$file", "AES-128-CTR", $aes_key, 0, "1234567891011121"));
                                                    echo "<li>";
                                                    echo "<strong>".sfx_sGetValue("38desc", "eg_relatedfiles", "38filename", $file)."</strong><br/>";
                                                    echo "<a target='_blank' href='$folderpath"."sw_inc/doc.php?t=enx&did=$id5&v=$encyrpted_f'>Click to view</a>";
                                                    echo "</li><br/>";
                                                    $enx = 1;
                                                }
                                        endforeach;
                                        if ($enx == 0) {
                                            echo "<li>Not Available</li>";
                                        }
                                        echo "</ol>";
                                echo "</td></tr>";
                            }
                        }
                        echo "</table>
                    </td>
                    </tr>
                </table>";
                
                //if not in photo mode, display the abstract/fulltext and references
                if ($system_function != 'photo') {
                    if ($fulltext5 != null && $fulltext5 != '<html />') {
                        echo "<br/><table class=whiteHeaderNoCenter>
                            <tr style='text-align:center;'><td><strong>"; if ($isabstract5 == 1) {echo "Abstract";} else {echo "Full Text";} echo " : </strong><em>$source5</em></td></tr>";
                            $display_fulltext5 = $strip_tags_fulltext_abstract_composer ? strip_tags(html_entity_decode($fulltext5)) : $fulltext5;
                            echo "<tr><td style='text-align:left;vertical-align:top;'>".sfx_highlight(htmlspecialchars_decode($display_fulltext5), $get_highlight)."<br/></td></tr>
                        </table>";
                    }
                    
                    if ($reference5 != null && $reference5 != '<html />') {
                        $display_reference5 = $strip_tags_reference_composer ? strip_tags(html_entity_decode($reference5)) : html_entity_decode($reference5);
                        echo "<br/><table class=whiteHeaderNoCenter style='table-layout:fixed;'><tr style='text-align:center;'><td><strong>References</strong></td></tr>
                            <tr><td style='text-align:left;vertical-align:top;'><div style='width: 100%; height: 180px; overflow-y: scroll;'>$display_reference5</div><br/></td></tr>
                        </table>";
                    }
                }
                
                //if user logged in, show the feedback module
                if (isset($_SESSION[$ssn.'username_guest']) && $enable_feedback_function) {
                    if (isset($_POST['submit_button'])) {
                        $timestamp = time();
                        $stmt_insert = $new_conn->prepare("insert into eg_item_feedback values(DEFAULT,?,?,?,?,0,0,'','NO','','')");
                        $stmt_insert->bind_param("isss", $get_id_det, $_SESSION[$ssn.'username_guest'], $_POST['feedback1'], $timestamp);
                        $stmt_insert->execute();$stmt_insert->close();
                        sfx_echoPopupAlert("Your feedback has been recorded and will be moderated before it can be published.");
                    }
                    
                    if (isset($_GET["df"]) && is_numeric($_GET["df"])) {
                        $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["df"]);
                        $stmt_del = $new_conn->prepare("delete from eg_item_feedback where id = ? and eg_auth_username = ?");
                        $stmt_del->bind_param("is", $get_id_del, $_SESSION[$ssn.'username_guest']);
                        $stmt_del->execute();$stmt_del->close();
                    }

                    if (isset($_GET["fid"]) && is_numeric($_GET["fid"])) {
                        
                        $stmt_findvote = $GLOBALS["new_conn"]->prepare("select 38upvote,38downvote,38votebys from eg_item_feedback where id=?");
                            $stmt_findvote->bind_param("i", $_GET['fid']);
                            $stmt_findvote->execute();$stmt_findvote->store_result();
                            $stmt_findvote->bind_result($upvotecount, $downvotecount, $votebys);
                            $stmt_findvote->fetch();$stmt_findvote->close();

                        if (strpos($votebys, "*".$_SESSION[$ssn.'username_guest']."|") !== false) {
                            sfx_echoPopupAlert("You have cast your vote.");
                        } else {
                            if (isset($_GET['vote']) && $_GET['vote'] == 'up') {
                                $by_manipulated = $votebys."*".$_SESSION[$ssn.'username_guest']."|";
                                $upvotecount=$upvotecount+1;
                                $stmt_update = $new_conn->prepare("update eg_item_feedback set 38upvote=?, 38votebys=? where id=?");
                                $stmt_update->bind_param("isi", $upvotecount, $by_manipulated, $_GET["fid"]);
                            } elseif (isset($_GET['vote']) && $_GET['vote'] == 'down') {
                                $by_manipulated = $votebys."*".$_SESSION[$ssn.'username_guest']."|";
                                $downvotecount=$downvotecount+1;
                                $stmt_update = $new_conn->prepare("update eg_item_feedback set 38downvote=?, 38votebys=? where id=?");
                                $stmt_update->bind_param("isi", $downvotecount, $by_manipulated, $_GET["fid"]);
                            }
                            $stmt_update->execute();$stmt_update->close();
                        }
                    }
                    
                    echo "<br/><table class=whiteHeaderNoCenter>";
                        echo "<tr style='text-align:center;'><td><strong>Feedback</strong></td></tr>";
                        $stmt_fdb = $new_conn->prepare("select * from eg_item_feedback where eg_item_id=$id5 and 39moderated_status='YES' order by 38upvote desc");
                        $stmt_fdb->execute();
                        $result_fdb = $stmt_fdb->get_result();
                        $n=0;
                        while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                            $id_fdb = $myrow_fdb["id"];
                            $feedback_fdb = $myrow_fdb["38feedback"];
                            $feedback_by_fdb = $myrow_fdb["eg_auth_username"];
                            $feedback_ts_fdb = $myrow_fdb["38timestamp"];
                            $upvote_fdb = $myrow_fdb["38upvote"];
                            $downvote_fdb = $myrow_fdb["38downvote"];
                            $votebys_fdb =  $myrow_fdb["38votebys"];
                            $moderated_status = $myrow_fdb["39moderated_status"];
                            
                            echo "<tr style='text-align:left;'><td>$feedback_fdb<br/>by <em>".sfx_sGetValue("name", "eg_auth", "username", $feedback_by_fdb)."</em> on ".date('d/M/Y', $feedback_ts_fdb)." ";
                                if ($_SESSION[$ssn.'username_guest'] == $feedback_by_fdb && $moderated_status != 'YES') {
                                    echo "[<a href='detailsg.php?det=$id5&df=$id_fdb' onclick=\"return confirm('Are you sure ?');\">Delete</a>]";
                                }
                                echo " [";
                                    if (strpos($votebys_fdb, "*".$_SESSION[$ssn.'username_guest']."|") !== false) {
                                        echo "<span style='color:blue;'>Upvote: $upvote_fdb</span>";
                                    } else {
                                        echo "<a onclick=\"return confirm('Are you sure ? This action will be finalize.');\" style='color:blue;' href='detailsg.php?det=$id5&fid=$id_fdb&vote=up'>Upvote: $upvote_fdb</a>";
                                    }
                                echo "] [";
                                    if (strpos($votebys_fdb, "*".$_SESSION[$ssn.'username_guest']."|") !== false) {
                                        echo "<span style='color:red;'>Downvote: $downvote_fdb</span>";
                                    } else {
                                        echo "<a onclick=\"return confirm('Are you sure ? This action will be finalize.');\" style='color:red;' href='detailsg.php?det=$id5&fid=$id_fdb&vote=down'>Downvote: $downvote_fdb</a>";
                                    }
                                echo "]<br/><br/></td></tr>";
                                $n=1;
                        }

                        if ($n == 0) {
                            echo "<tr><td style='text-align:center;vertical-align:top;' class='$color_scheme"."Back'>
                                <i>No feedback found.</i>
                            </td></tr>";
                        }

                        if (sfx_countFeedbackForItemForUser($id5, $_SESSION[$ssn.'username_guest']) == 0) {
                            echo "<tr><td style='text-align:center;vertical-align:top;' class='$color_scheme"."Back'>
                                <form action='detailsg.php' method='post' enctype='multipart/form-data'>
                                    <strong>My feedback: </strong><br/>
                                    <textarea name='feedback1' style='width:50%;height:150px;' /></textarea>
                                    <br/>
                                    <input type='hidden' name='token' value=".$_SESSION[$ssn.'token'].">
                                    <input type='hidden' name='det' value='$id5'>
                                    <input type='submit' name='submit_button' value='Submit' />
                                    <input type='button' value='Cancel' onclick=\"location.href='detailsg.php?det=$id5';\">
                                </form>
                            </td></tr>";
                        }
                        
                    echo "</table>";
                }

                echo "<table class=whiteHeaderNoCenter><tr><td style='background-color:lightgrey;text-align:center;'><em>$copyright_info</td></tr></table>";
            ?>

            <br/>
            
            <?php
                if (isset($_SESSION[$ssn.'previous_url']) && isset($_SESSION[$ssn.'username_guest'])) {
                    echo "<a class='sButton' href='".$_SESSION[$ssn.'previous_url']."'><span class='fas fa-arrow-circle-left'></span> Back to search results</a>";
                } elseif (isset($_SESSION[$ssn.'previous_url']) && !isset($_SESSION[$ssn.'username_guest'])) {
                    unset($_SESSION[$ssn.'previous_url']);
                    echo "<a class='sButton' href='javascript:window.history.back();'><span class='fas fa-arrow-circle-left'></span> Back to previous page</a>";
                } elseif (isset($_SESSION[$ssn.'whichbrowser']) && !isset($_GET['at']) && !isset($_GET['bk'])) {
                    echo "<a class='sButton' href='javascript:window.history.back();'><span class='fas fa-arrow-circle-left'></span> Back to previous page</a>";
                } elseif (isset($_GET['bk']) && is_numeric($_GET['bk']) && $_GET['bk'] == '1') {
                    echo "<a class='sButton' href='dashboard.php?u=g'><span class='fas fa-arrow-circle-left'></span> Back to your dashboard</a>";
                } elseif (isset($_GET['at']) && ctype_alnum($_GET['at'])) {
                    echo "";
                } else {
                    echo "<a class='sButton' href='searcher.php'><span class='fas fa-arrow-circle-left'></span> Back to search page</a>";
                }
            ?>
                
        </div>
        
        <hr>
        <?php
            include_once 'sw_inc/footer.php';
        ?>
        
    </body>
<?php
} //if $item_status5 == 1
?>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
