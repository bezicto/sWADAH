<?php
/*
Filename: sw_inc/header.php
Usage: Header for every pages to have
Version: 20250101.0801
Last change: -
*/

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    header("Strict-Transport-Security:$hd_Strict_Transport_Security");
    header("X-Frame-Options: $hd_X_Frame_Options");
    header("Referrer-Policy: $hd_Referrer_Policy");
    header("Content-Security-Policy: $hd_Content_Security_Policy");
    header("X-Content-Type-Options: $hd_X_Content_Type_Options");
    header("Permissions-Policy: $hd_Permissions_Policy");

    //get the current working directory
    $currentdir = substr(getcwd(), -8);
        $directories = ['sw_admin', 'sw_splus', 'sw_stats', 'sw_depos', 'sw_brows', 'sw_asset'];
        $appendroot = in_array($currentdir, $directories) ? '../' : '';
    
    require_once $appendroot."sw_vendor/autoload.php";
    $detect = new \Detection\MobileDetect;

    $refresh_component = ($debug_mode == 'yes') ? "?".time() : "";
?>

<title>
    <?php
        echo "$system_title : $thisPageTitle";
        if ($_SERVER["REMOTE_ADDR"] == $ezproxy_ip) {echo " [EZPROXY MODE]";}
        elseif (isset($_SESSION[$ssn.'lls']) && $_SESSION[$ssn.'lls']) {echo " [LOGINLESS]";}
    ?>
</title>

<?php
    //handling cross side scripting if found any url ended with .php/[A-Z,0-9,specialchar] will change it to just .php
    //version 1.0.20220415.1547
    
    //for php8 == if (str_contains($_SERVER['REQUEST_URI'],'.php/'))
    if (strpos($_SERVER['REQUEST_URI'], '.php/') !== false) {
        $fixedURL = strstr($_SERVER['REQUEST_URI'], '.php/', true).".php" ?: $_SERVER['REQUEST_URI'];
        echo "<meta http-equiv='refresh' content=\"0;URL='$fixedURL'\" />";
        exit();
    }

    /*if ($detect->isMobile()) {
        echo "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1'>";
    }*/
?>
<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1'>
<link rel="icon" type="image/png" href="<?php echo $appendroot;?><?php echo $browser_icon;?><?php echo "$refresh_component";?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo $appendroot;?>sw_asset/css/style.css<?php echo "$refresh_component";?>"/>
<link rel="stylesheet" href="<?php echo $appendroot;?>sw_asset/js/fontawesomejs/css/all.css<?php echo "$refresh_component";?>">
<link rel="stylesheet" href="<?php echo $appendroot;?>sw_asset/css/jquery-ui.css<?php echo "$refresh_component";?>">
<script type="text/javascript" src="<?php echo $appendroot;?>sw_asset/js/jquery.min.js<?php echo "$refresh_component";?>"></script>
<script type="text/javascript" src="<?php echo $appendroot;?>sw_asset/js/jquery-ui.min.js<?php echo "$refresh_component";?>"></script>
<script type="text/javascript" src="<?php echo $appendroot;?>sw_asset/js/tiny_mce4/tinymce.min.js<?php echo "$refresh_component";?>"></script>
<script type="text/javascript" src="<?php echo $appendroot;?>sw_asset/js/main.js<?php echo "$refresh_component";?>"></script>
<script type="text/javascript" src="<?php echo $appendroot;?>sw_asset/js/jquery.qrcode.min.js<?php echo "$refresh_component";?>"></script>
<script type="text/javascript" src="<?php echo $appendroot;?>sw_asset/js/calendarDateInput.js<?php echo "$refresh_component";?>"></script>

<?php
    //original headers are here before move to the top
?>
