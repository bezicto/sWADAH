<?php
/*
Filename: sw_inc/reg_imagefield.php
Usage: Additional form field for inserting new JPGs
Version: 20250101.0801
Last change: -
*/

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");

    ${"displayT".$currentDisplay_image} = ($currentDisplay_image == '2') ? "" : "none";

?>
<tr id='t<?php echo $currentDisplay_image;?>' style="display:<?php echo ${"displayT".$currentDisplay_image};?>">
    <td style='text-align:right;vertical-align:top;'><strong>Additional JPG</strong> <span style='color:red;'>(Max <?php echo ($system_allow_imageatt_maxsize/1000000)."M";?>)</span></td>
    <td>:
        <input type="file" id="<?php echo $currentInput_image;?>" name="<?php echo $currentInput_image;?>" size="38" accept="<?php echo sfx_dotFileTypes($system_allow_imageatt_extension);?>"/>
        <?php if ($requirenext) {?>
            <a id="tl<?php echo $currentDisplay_image;?>" style="font-size:8pt;" onclick="document.getElementById('t<?php echo $currentDisplay_image+1;?>').style.display='';document.getElementById('tl<?php echo $currentDisplay_image;?>').style.display='none';">[+]</a>
        <?php }?>
    </td>
</tr>
