<?php
    /*
    Filename: sw_inc/loggedinfo.php
    Usage: Preselect which navbar to appear based on what user logged in
    Version: 20250101.0801
    Last change: -
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");

    if (isset($_SESSION[$ssn.'username'])) {
        include_once $appendroot.'sw_inc/navbar.php';
    } else {
        include_once $appendroot.'sw_inc/navbar_guest.php';
    }
