<?php
    /*
    Filename: sw_inc/firstrun_ssncheck.php
    Usage: check if dateinstalled.txt and ssn.txt exist or not, if not exist then create them
    Version: 20250301.0000
    Last change: -
    */
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    if (!file_exists("sw_installed/dateinstalled.txt")) {
        file_put_contents("sw_installed/dateinstalled.txt", date("Y-m-d"));

        if (!file_exists("sw_installed/ssn.txt")) {
            file_put_contents("sw_installed/ssn.txt", time());
        }
    }
