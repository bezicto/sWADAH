<?php
/*
Filename: sw_inc/add_files.php
Usage: Basic File Manager
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once 'access_isset.php';
include_once 'access_allowed_adminip.php';
include_once 'functions.php';

if (isset($_GET['year']) && is_numeric($_GET['year'])) {
    $_SESSION[$ssn.'uploadDirYear'] = $_GET['year'];
}

if (isset($_GET['fid'])) {
    $_SESSION[$ssn.'uploadFolderName'] = $_GET['fid'];
    $_SESSION[$ssn.'uploadID'] = explode('_', $_GET['fid'])[0];
}

$dirtocheck = "../$system_docs_directory/".$_SESSION[$ssn.'uploadDirYear']."/".$_SESSION[$ssn.'uploadFolderName'];

if (!is_dir($dirtocheck)) {
    mkdir($dirtocheck, 0755, true);
    file_put_contents($dirtocheck."/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
}

if (isset($_POST['submit']) && $_POST['submit'] == 'Upload File') {
    $filename = strtoupper(str_replace(' ', '_', preg_replace('/[^a-zA-Z0-9\s.]/', '',basename($_FILES["fileToUpload"]["name"]))));
    $target_file = $dirtocheck."/".$filename;
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". htmlspecialchars(basename($_FILES["fileToUpload"]["name"])). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
    mysqli_query($GLOBALS["conn"], "insert into eg_relatedfiles values(DEFAULT,".$_SESSION[$ssn.'uploadID'].",'$filename','".$_POST['desc']."','".$_POST['accesstype']."')");
}

if (isset($_GET['delfile'])) {
    $file = "$dirtocheck/" . $_GET['delfile'];
    if (file_exists($file)) {
        unlink($file);
        echo "File deleted successfully.";
    } else {
        echo "File does not exist.";
    }
}

$files = sfx_listFiles($dirtocheck);

?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <title>File Manager</title>
    <style>
        .file-list {
            margin-top: 20px;
        }
        .file-item {
            margin: 5px 0;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="../sw_asset/css/style.css"/>
</head>
<body>
    <h1>File Manager</h1>
    
    <form action="add_files.php" method="post" enctype="multipart/form-data">
        File Selection: <input type="file" name="fileToUpload" id="fileToUpload"><br/><br/>
        Description: <input type="text" name="desc" maxlength=255 style='width:350px;' required><br/><br/>
        Access Type:<select name="accesstype">
            <option value="openaccess">Open Access</option>
            <option value="restricted">Restricted</option>
        </select><br/><br/>
        <input type="submit" value="Upload File" name="submit">
    </form>
    
    <hr/>
    
    <div class="file-list">
        <h2>Files in Directory:</h2><ol>
        <?php foreach ($files as $file): ?>
            <div class="file-item">
                <li>
                    <strong>
                        <?php
                            $accesstype = sfx_sGetValue("38accesstype", "eg_relatedfiles", "38filename", $file);
                            $fcolor = ($accesstype == 'restricted') ? 'red' : 'blue';
                            echo sfx_sGetValue("38desc", "eg_relatedfiles", "38filename", $file)." [<span style='color:$fcolor;'>$accesstype</span>]";
                        ?>
                    </strong>
                    <br/><?php echo $file; ?>
                    <button onclick="js_deleteFile('<?php echo $file; ?>')">Delete</button>
                </li>
            </div>
        <?php endforeach; ?>
        </ol>
    </div>

    <script>
        function js_deleteFile(fileName) {
            if (confirm('Are you sure you want to delete ' + fileName + '?')) {
                window.location.href = 'add_files.php?delfile=' + fileName;
            }
        }
    </script>


    <br/><br/>
    <div style='text-align:center;'>
        <a class='sButtonRedSmall' href='javascript:window.opener.location.reload(true);window.close();'><span class='fas fa-window-close'></span> Close</a>
    </div>
    
</body>
</html>
