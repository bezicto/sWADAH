<?php
    /*
    Filename: sw_inc/mainbar.php
    Usage: Main bar for index2.php
    Version: 20250101.0801
    Last change: -
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    echo "<table class=whiteHeaderNoCenter><tr><td>";
            echo "<span style='color:blue;'>You have logged in as : </span>";
            echo "<strong>";
                echo $_SESSION[$ssn.'username']."  <a href='../sw_stats/adsreport_details.php'><span class=\"fas fa-info-circle\" title='View your data input history'></span></a>";
            echo "</strong>";
            echo "<br/><em><span style='color:black;font-size:10px'>Last logged in: ".$_SESSION[$ssn.'lastlogin']."</span></em>";
            echo "<br/><em><span style='color:grey;font-size:10px'>Current Session ID: ".session_id()."</span></em>";
            if ($system_mode == "demo") {echo "<br/><br/><span style='color:red;font-size:10px'>You are running DEMO mode. Some functionality are disabled.</span>";}
            if ($system_mode == "maintenance") {echo "<br/><br/><span style='color:red;font-size:10px'>You are running MAINTENANCE mode. User functionality are disabled.</span>";}
            echo "<br/><br/>Running $system_core $system_build<br/>".sfx_showDevelopedRight()." on PHP".phpversion();
            if ($system_function != 'depo') {
                echo "<br/>Installed Date: $installed_date";
            }

            if (!$_SESSION[$ssn.'needtochangepwd'] && $_SESSION[$ssn.'editmode'] == 'SUPER') {
                echo "<br/><br/>";
                if ($system_function != 'depo') {
                    if ($enable_oai_pmh) {
                        echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;cursor:pointer;' value='OAI is running' onclick=\"window.open('../oai2.php?verb=Identify','_blank')\"> ";
                    } else {
                        echo "<input type='button' class='form-grey-button-noshadow' style='font-size:8pt' value='OAI deactivated'> ";
                    }
                    
                    if ($enable_searcher_api) {
                        echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;cursor:pointer;' value='API is enabled' onclick=\"window.open('../searcherapi.php','_blank')\"> ";
                    } else {
                        echo "<input type='button' class='form-grey-button-noshadow' style='font-size:8pt' value='API deactivated'> ";
                    }

                    if ($enable_commercial_api) {
                        echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;cursor:pointer;' value='Commercial API is enabled' onclick=\"window.open('../searcherapi.php','_blank')\"> ";
                    } else {
                        echo "<input type='button' class='form-grey-button-noshadow' style='font-size:8pt' value='Commercial API disabled'> ";
                    }
                    
                    
                    include_once '../sw_vendor/autoload.php';
                    $parser = new \Smalot\PdfParser\Parser();
                    if (file_exists('temp/test.pdf')) {
                        $pdf = $parser->parseFile('temp/test.pdf');
                        if ($pdf) {
                            echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;cursor:pointer;' value='PDF Parser is working' onclick=\"window.location.href='checkpdfindexer.php'\"> ";
                        } else {
                            echo "<input type='button' class='form-grey-button-noshadow' style='font-size:8pt' value='PDF Parser not working'> ";
                        }
                    }
                }

                $php_post_max = preg_replace("/\D/", "", ini_get("post_max_size"));
                $php_upload_max = preg_replace("/\D/", "", ini_get("upload_max_filesize"));
                if (
                    ($php_post_max <= $php_upload_max)
                    ||
                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_document_maxsize/1000000)
                    ||
                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_imageatt_maxsize/1000000)
                    ||
                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_pdocument_maxsize/1000000)
                    ||
                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_txt_maxsize/1000000)
                    ||
                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_isofile_maxsize/1000000)
                    ) {
                        echo "<input type='button' class='form-orange-button-noshadow' style='font-size:8pt;' value='PHP.ini upload_max_filesize: ".ini_get('upload_max_filesize')."'> ";
                        echo "<input type='button' class='form-orange-button-noshadow' style='font-size:8pt;' value='PHP.ini post_max_size: ".ini_get('post_max_size')."'> ";
                } else {
                    echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;' value='PHP.ini upload_max_filesize: ".ini_get('upload_max_filesize')."'> ";
                    echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;' value='PHP.ini post_max_size: ".ini_get('post_max_size')."'> ";
                }

                echo "<input type='button' class='form-green-button-noshadow' style='font-size:8pt;' value='PHP Mode: ".php_sapi_name()."'> ";

            }
    echo "</td></tr></table>";
