<?php
    /*
    Filename: sw_inc/image.php
    Usage: Image generator to prevent people from accessing directly via local link
    Version: 20250101.0801
    Last change: -
    */
    
    if ((isset($_GET['d']) && !is_numeric($_GET['d'])) || !isset($_GET['d'])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Invalid Request.</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>";
        exit;
    }

    include_once '../core.php';

    $get_id_det = mysqli_real_escape_string($GLOBALS["conn"], $_GET['d']);
    $get_type = mysqli_real_escape_string($GLOBALS["conn"], $_GET['t']);

    if (is_numeric($get_id_det) && ($get_type == 't' || $get_type == 'w' || is_numeric($get_type))) {
        $query_item = "select id,39inputdate,41instimestamp from eg_item where id='$get_id_det'";
        $result_item = mysqli_query($GLOBALS["conn"], $query_item);
        $myrow_item = mysqli_fetch_array($result_item);
        
        $id = $myrow_item["id"];
        $inputdate = $myrow_item["39inputdate"];
        $instimestamp = $myrow_item["41instimestamp"];
        $dir_year = substr($inputdate, 0, 4);

        $timestamp = date("D d/m/Y h:i a");
        
        if ($get_type == 't') {
            $im = imagecreatefromjpeg("../$system_albums_thumbnail_directory/$dir_year/$id"."_"."$instimestamp.jpg");
        } elseif ($get_type == 'w') {
            if (isset($_GET['db']) && $_GET['db'] == "1") {
                $filename = "../$dir_year/$id"."_"."$instimestamp".".jpg";
                $stmt_insert = $new_conn->prepare("insert into eg_photo_access values(DEFAULT,?,?,?)");
                $stmt_insert->bind_param("iss", $id, $filename, $timestamp);
                $stmt_insert->execute();$stmt_insert->close();
            }

            $im = imagecreatefromjpeg("../$system_albums_watermark_directory/$dir_year/$id"."_"."$instimestamp.jpg");
        } else {
            if (isset($_GET['db']) && $_GET['db'] == "1") {
                $filename = "../$dir_year/$id"."_"."$instimestamp"."/$get_type"."_wm.jpg";
                $stmt_insert = $new_conn->prepare("insert into eg_photo_access values(DEFAULT,?,?,?)");
                $stmt_insert->bind_param("iss", $id, $filename, $timestamp);
                $stmt_insert->execute();$stmt_insert->close();
            }
            $im = imagecreatefromjpeg("../$system_albums_directory/$dir_year/$id"."_"."$instimestamp"."/$get_type"."_wm.jpg");
        }

        header('Content-Type: image/jpg');
        imagejpeg($im);
        imagedestroy($im);
    } else {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Invalid Request.</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>";
        mysqli_close($GLOBALS["conn"]);
        exit;
    }
