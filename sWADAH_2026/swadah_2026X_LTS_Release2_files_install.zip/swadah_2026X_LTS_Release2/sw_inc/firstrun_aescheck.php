<?php
    /*
    Filename: sw_inc/firstrun_aescheck.php
    Usage: check if aes key is using the default value or not, if yes then prompt user to change it
    Version: 20250301.0000
    Last change: -
    */
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    //aes key checker and generator - will only run on first run
    function aesfx_generateRandomStringAes($length = 64) {
        $characters = 'ABCDE0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    if ($aes_key == "45C798DB3EBC65DFBC69A0F36F605E6CA2447CD519C50B7DA0D0D45D2B0F2431" && isset($_GET['generate'])) {
        header('Content-Type: text/plain');
        echo aesfx_generateRandomStringAes();
        exit;
    }
    if ($aes_key == "45C798DB3EBC65DFBC69A0F36F605E6CA2447CD519C50B7DA0D0D45D2B0F2431") {
        echo "Please change the AES Key Value in config.php first. After that refresh this page.<br/><br/>";
        echo 'Hit our randomize automatic AES Key Generator button to get a value and copy it to <strong>$aes_key</strong> inside <strong>config.php</strong>: ';
        ?>
        <button id="generateBtn" onclick="generateRandomString()">Generate</button>
        <p id="result"></p>
        <script>
            function generateRandomString() {
                fetch('?generate=true')
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('result').textContent = data;
                    });
                document.getElementById('generateBtn').style.display = 'none';    
            }
        </script>
        <?php
        exit;
    }
