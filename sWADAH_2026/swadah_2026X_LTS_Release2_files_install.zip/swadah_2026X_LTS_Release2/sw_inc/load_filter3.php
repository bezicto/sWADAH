<?php
/*
Filename: sw_inc/load_filter3.php
Usage: AJAX for filter widget on searcher page
Version: 20250101.0801
Last change: -
*/

header('Content-Type: text/html');
session_start();
include_once '../core.php';
include_once '../sw_inc/functions.php';

if (isset($_SESSION[$ssn.'sear_scstr']) && $_SESSION[$ssn.'sear_scstr'] != '')
{
    $scstr_term = trim($_SESSION[$ssn.'sear_scstr']);
    if (isset($scstr_term) && $scstr_term != '') {
        $find_suggestion = "select 37keyword from eg_userlog where match (37keyword) against ('$scstr_term' in boolean mode) order by 37freq desc limit 5";
        $result_find_suggestion = mysqli_query($GLOBALS["conn"], $find_suggestion);
        while ($row_find_suggestion = mysqli_fetch_array($result_find_suggestion)) {
            echo "<div style='margin-top:5px;'>".preg_replace('/[^A-Za-z0-9\-]/', " ", $row_find_suggestion['37keyword'])."</div><br/>";
        }
    } else {
        echo "<div style='margin-top:10px;'><em>Suggestion engine unable to find titles related to this search term.</em></div>";
    }
} else {
    echo "<div style='margin-top:10px;'><em>No result from your search term.</em></div>";
}
