<?php
/*
Filename: sw_inc/ft.php
Usage: Fulltext viewer
Version: 20250101.0801
Last change: -
*/

    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    
    $get_id_det = mysqli_real_escape_string($GLOBALS["conn"], $_GET["det"]);

    if (is_numeric($get_id_det)) {
        $query_ft = "select 41pdfattach_fulltext from eg_item where id='$get_id_det'";
        $result_ft = mysqli_query($GLOBALS["conn"], $query_ft);
        $myrow_ft = mysqli_fetch_array($result_ft);
        echo htmlspecialchars($myrow_ft["41pdfattach_fulltext"]);
    } else {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>Invalid Request.</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>";
        mysqli_close($GLOBALS["conn"]);exit;
    }
