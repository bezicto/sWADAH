<?php
    /*
    Filename: sw_inc/index2_s_form.php
    Usage: Search form
    Version: 20250101.0801
    Last change: -
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    if ($detect->isMobile()) {
        $append_line_breaking = "<br/><br/>";
        $search_field_width = "100%";
        $search_combobox_width = "100%";
    }
?>
<form style="margin-right:20px;margin-left:20px;margin-top:20px;margin-bottom:20px;max-width:100%;" action="searcher.php" method="get" enctype="multipart/form-data">
    <input class='googleField' type="text" placeholder="&#x1F50D; Enter search terms" name="scstr" style='width:<?php echo $search_field_width ?? "50%";?>;font-size:14px' maxlength="255" value="<?php if (isset($_SESSION[$ssn.'sear_scstr_form'])) {echo $_SESSION[$ssn.'sear_scstr_form'];}?>" />
    <?php echo $append_line_breaking ?? "";?><select class='googleComboBox' style="width:<?php echo $search_combobox_width ?? "20%";?>;font-size:14px" id="sctype" name="sctype">
        <?php
            $sctype_select = $_SESSION[$ssn.'sear_sctype'] ?? '';
            echo '<option value="EveryThing" '; if ($sctype_select == 'EveryThing') {echo 'selected';} echo '>Everything</option>';
            $query_typelist = "select 38typeid, 38type, 38synonym from eg_item_type";
            $result_typelist = mysqli_query($GLOBALS["conn"], $query_typelist);
            while ($row_typelist = mysqli_fetch_array($result_typelist)) {
                echo '<option value="'.$row_typelist['38typeid'].'"'; if ($row_typelist['38typeid']==$sctype_select) {echo ' selected';} echo '>'. $row_typelist['38synonym'] . '</option>'."\n";
            }
        ?>
    </select>
    <?php echo $append_line_breaking ?? "";?><button type="submit" class="googleButtonSmall"><span class="fa fa-search"></span> Search</button>
    <br/>
    <?php if ($index_pdf) {?>
        <input style="margin-top:10px;" type="radio" value="0" name="sear_ft" <?php if ((isset($_SESSION[$ssn.'sear_ft']) && $_SESSION[$ssn.'sear_ft']=='0') || !isset($_SESSION[$ssn.'sear_ft'])) {echo "checked";}?>><label for="sft" class="radio-label">Smart Search</label>
        <input style="margin-top:10px;" type="radio" value="1" name="sear_ft" <?php if (isset($_SESSION[$ssn.'sear_ft']) && $_SESSION[$ssn.'sear_ft']=='1') {echo "checked";}?>><label for="sft" class="radio-label">Search Full Text (Slower)</label>
    <?php }?>
    <input type="hidden" name='sc' value='cl'/>
</form>
