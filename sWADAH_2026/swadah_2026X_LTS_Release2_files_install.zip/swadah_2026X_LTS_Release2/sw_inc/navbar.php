<?php
/*
Filename: sw_inc/navbar.php
Usage: Navbar for logged user
Version: 20250101.0801
Last change: -
*/

  defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
?>

<script>
function js_UpperMenuNav() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav <?php echo $color_scheme;?>topnav") {x.className += " responsive";}
    else {x.className = "topnav <?php echo $color_scheme;?>topnav";}
}
</script>

<?php
  function sw_createSubMenu($appendRoot,$link,$menuTitle,$fontAwesomeIcon,$onClickOpt = "")
  {
    echo "<a $onClickOpt href=\"$appendRoot"."$link\"><span class=\"$fontAwesomeIcon\"></span> $menuTitle</a>";
  }
  function sw_createMainButton($buttonTitle,$fontAwesomeIcon)
  {
    echo "<button class=\"dropbtn\"><span class=\"$fontAwesomeIcon\"></span> $buttonTitle <span class=\"fa fa-caret-down\"></span></button>";
  }
?>

<div class="topnav <?php echo $color_scheme;?>topnav" id="myTopnav">
  <a href="<?php echo $appendroot;?>sw_admin/index2.php?sc=cl" class="active"><img alt='Menu Icon' src='<?php echo $appendroot;?><?php echo $menu_icon;?>' width=20></a>
  
  <?php if (!$_SESSION[$ssn.'needtochangepwd']) {?>

    <?php if ($system_function == 'full' || $system_function == 'repo' || $system_function == 'photo') {?>
      <div class="dropdownNB">
        <?php sw_createMainButton("Item","fa fa-keyboard"); ?>
        <div class="dropdownNB-content">
          <?php
            if ($system_function == 'full' || $system_function == 'repo' || $system_function == 'photo') {
              if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                sw_createSubMenu($appendroot,"sw_admin/reg.php","Add new item","fas fa-folder-plus");
                sw_createSubMenu($appendroot,"sw_admin/dupfinder.php","Duplicate Finder","fas fa-paste");
                if ($enable_searcher_api) {
                  sw_createSubMenu($appendroot,"sw_admin/listcomposer.php","List Composer","fas fa-rectangle-list");
                }
              }
              if (($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') && $enable_feedback_function) {
                sw_createSubMenu($appendroot,"sw_admin/moderatefbk.php","Moderate Feedback","fas fa-comment-dots");
              }
              if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                sw_createSubMenu($appendroot,"sw_admin/lists.php","Prepared Lists","fas fa-list-ol");
              }
              sw_createSubMenu($appendroot,"sw_admin/templog.php","Temporary Access Links","fas fa-hourglass-end");
            }
          ?>
        </div>
      </div>
    <?php }?>

    <?php if (($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') && ($system_function == 'full' || $system_function == 'depo')) {?>
        <div class="dropdownNB">
          <?php sw_createMainButton("Submission","fa-solid fa-file-import"); ?>
          <div class="dropdownNB-content">
            <?php
              if ($system_function == 'full' || $system_function == 'depo') {
                sw_createSubMenu($appendroot,"sw_depos/depouser.php?show=NOTACTIVE","Depositor Account","fas fa-users");
              }
              if ($system_function == 'full' || $system_function == 'depo') {
                sw_createSubMenu($appendroot,"sw_depos/depoadmin.php?v=entry&pub=all&cub=all","Manage Submission","fas fa-file-circle-check");
              }
            ?>
          </div>
        </div>
    <?php }?>

    <?php if ($_SESSION[$ssn.'editmode'] == 'SUPER' && $enable_commercial_api && ($system_function == 'full' || $system_function == 'repo')) {?>
        <div class="dropdownNB">
          <?php sw_createMainButton("Commercial","fa fa-cart-plus"); ?>
          <div class="dropdownNB-content">
            <?php
              sw_createSubMenu($appendroot,"sw_admin/commercialtoken.php","API Token Management","fas fa-file-code");
              sw_createSubMenu($appendroot,"sw_admin/commercialized.php","Item List","fas fa-file-invoice-dollar");
            ?>
          </div>
        </div>
    <?php }?>
    
    <?php if ($_SESSION[$ssn.'editmode'] == 'SUPER') {?>
        <div class="dropdownNB">
          <?php sw_createMainButton("Foundation","fas fa-database"); ?>
          <div class="dropdownNB-content">
            <?php
              sw_createSubMenu($appendroot,"sw_admin/addpublisher.php",$publisher_as,"fas fa-book-open");
              if ($system_function == 'full' || $system_function == 'repo' || $system_function == 'photo') {
                sw_createSubMenu($appendroot,"sw_admin/addtype.php",$type_as,"fas fa-book");
                sw_createSubMenu($appendroot,"sw_admin/addsubject.php",$subject_heading_as,"fas fa-swatchbook");
                if ($enable_folder) {
                  sw_createSubMenu($appendroot,"sw_admin/addfolder.php","Folder","fas fa-folder");
                }
              }
            ?>
          </div>
        </div>
    <?php }?>
    
    <?php if ($_SESSION[$ssn.'editmode'] == 'SUPER') {?>
          <div class="dropdownNB">
            <?php sw_createMainButton("Administration","fas fa-toolbox"); ?>
            <div class="dropdownNB-content">
              <?php
                if ($ip_fence_enabled && ($system_function == 'full' || $system_function == 'repo')) {
                  sw_createSubMenu($appendroot,"sw_admin/ipcontrol.php","IP Fence","fas fa-shield-alt");
                }
                sw_createSubMenu($appendroot,"sw_admin/composer.php","FAQ & About Composer","fas fa-pen");
                if ($system_function == 'full' || $system_function == 'repo') {
                  sw_createSubMenu($appendroot,"sw_admin/loginless.php","Loginless Token Management","fas fa-passport");
                }
                if ($enable_searcher_api) {
                  sw_createSubMenu($appendroot,"sw_admin/gpt_guide.php","ChatGPT Integrator","fas fa-code-branch");
                }
                sw_createSubMenu($appendroot,"sw_stats/adsreport.php","Report Generator","fa-solid fa-magnifying-glass-chart");
                sw_createSubMenu($appendroot,"sw_admin/config_user.php?tab=allimportant","$system_title Configurator","fas fa-square-root-variable");
                if ($system_mode != 'demo') {
                  sw_createSubMenu($appendroot,"sw_admin/chanuser.php?sc=cl","User Account Management","fas fa-user-circle");
                }
                
              ?>
            </div>
          </div>
    <?php }?>

    <?php if ($_SESSION[$ssn.'editmode'] == 'SUPER' && (isset($enable_plus_menu) && $enable_plus_menu)) {?>
          <div class="dropdownNB">
            <?php sw_createMainButton("Plus","fa-solid fa-plug-circle-plus"); ?>
            <div class="dropdownNB-content">
              <?php
                sw_createSubMenu($appendroot,"sw_splus/convertkey.php","AES Key Convert","fas fa-mask","onclick=\"return confirm('Are you sure to enter AES Key Convert tool? Please use this tool with caution.')\"");
                sw_createSubMenu($appendroot,"sw_splus/logclearer.php","Export/Clear Logs","fas fa-history");
                sw_createSubMenu($appendroot,"sw_splus/keymaker.php","Random Key Maker","fas fa-key");
                sw_createSubMenu($appendroot,"sw_splus/admigration_script.php","Repopulate Hit/Download Counts","fas fa-chart-gantt");
              ?>
            </div>
          </div>
    <?php }?>

    <div class="dropdownNB">
      <?php sw_createMainButton("System","fas fa-window-maximize"); ?>
      <div class="dropdownNB-content">
        <?php
          sw_createSubMenu($appendroot,"nav.php?page=About","About","fas fa-circle-info");
          sw_createSubMenu($appendroot,"nav.php?page=FAQ","FAQ","fas fa-question-circle");
          if ($system_mode != 'demo') {
            sw_createSubMenu($appendroot,"passch.php?upd=.g","Change Password","fa fa-key");
          }
          sw_createSubMenu("","javascript:alert('Version $system_core $system_build');","Version","fas fa-code");
        ?>
      </div>
    </div>

  <?php }?>

  <a href="<?php echo $appendroot;?>index.php?log=out" onclick="return confirm('Are you sure?')"><span class="fa fa-user"></span> Logout</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="js_UpperMenuNav()">&#9776;</a>
  
</div>
