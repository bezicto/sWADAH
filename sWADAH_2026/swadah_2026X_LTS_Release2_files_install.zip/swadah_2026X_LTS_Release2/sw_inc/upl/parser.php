<?php
/*
Filename: sw_inc/upl/parser.php
Usage: PDF parser for uploaded PDF file
Version: 20250101.0801
Last change: -
*/

defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");

if ($index_pdf) {
    include_once '../sw_vendor/autoload.php';
    try {
        $parser = new \Smalot\PdfParser\Parser();
        $pdf = $parser->parseFile($affected_directory.'/'.$idUpload.'_'.$timestampUpload.'.'.$affected_fileextension);
        $pdftext_output = $pdf->getText();
        if ($usePdfInfo) {
            $pdfTotalPages = sfx_getPDFPages($appendroot, $affected_directory . '/' . $idUpload . '_' . $timestampUpload . '.' . $affected_fileextension);
            $pdfTotalPages = ($pdfTotalPages == 0) ? sfx_getPDFPagesSmalot($appendroot, $affected_directory . '/' . $idUpload . '_' . $timestampUpload . '.' . $affected_fileextension) : $pdfTotalPages;
        } else {
            $pdfTotalPages = 0;
        }
    } catch (Exception $e) {
        if ($e->getMessage()) {
            echo "<br/><br/>PDF Parser Status: <span style='color:red;'>".$e->getMessage()." The PDF will not be available for content search.</span>";
            $pdftext_output = '';
            $pdfTotalPages = 0;
        }
    }
} else {
    $pdftext_output = '';
    $pdfTotalPages = 0;
}

if ($successbutnotparse == 'TRUENOT') {
    echo "<br/><br/>PDF Parser Status: <span style='color:orange;'>File is not parsed because it is too large.</span>";
}

mysqli_query($GLOBALS["conn"], "update eg_item set 41pdfattach_fulltext='".htmlspecialchars($pdftext_output)."',51_pagecount=$pdfTotalPages where id=$idUpload");
