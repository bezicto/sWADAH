<?php
/*
Filename: sw_inc/update_imagefield.php
Usage: List additional JPGs associated with the point of calling
Version: 20250101.0801
Last change: -
*/

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    ${"displayT".$currentDisplay_image} = (is_file("../$system_albums_directory/$dir_year/$id"."_$instimestamp/$currentDisplay_image.jpg") || $currentDisplay_image == '2') ? "" : "none";
?>
<tr id='t<?php echo $currentDisplay_image;?>' style="display:<?php echo ${"displayT".$currentDisplay_image};?>">
    <td style='text-align:right;vertical-align:top;'><strong>Additional JPG</strong> <span style='color:red;'>(Max <?php echo ($system_allow_imageatt_maxsize/1000000)."M";?>)</span></td>
    <td>:
        <input type="file" id="<?php echo $currentInput_image;?>" name="<?php echo $currentInput_image;?>" size="38" accept="<?php echo sfx_dotFileTypes($system_allow_imageatt_extension);?>"/>
        <?php
            if (is_file("../$system_albums_directory/$dir_year/$id"."_"."$instimestamp/".$currentDisplay_image.".jpg")) {
                echo "[<a target='_blank' href='../$system_albums_directory/$dir_year/$id"."_"."$instimestamp/$currentDisplay_image.jpg'>Existing File</a>]";
                
            }
        
            if ($requirenext && !is_file("../$system_albums_directory/$dir_year/$id"."_"."$instimestamp/".($currentDisplay_image + 1).".jpg")) {
                echo " <a id='tl$currentDisplay_image' style='font-size:8pt;' onclick=\"document.getElementById('t".($currentDisplay_image+1)."').style.display='';document.getElementById('tl$currentDisplay_image').style.display='none';\" >[+]</a>";
            }?>
    </td>
</tr>
