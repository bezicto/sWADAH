<?php
/*
Filename: sw_inc/doc.php
Usage: Document loader when user click on a encrypted link
Version: 20250415.0900
Last change: -
    20250415.0900 - improve the code to use pdfjs viewer
*/

session_start();
include_once '../core.php';

if (isset($_GET['t']) && !ctype_alpha($_GET['t'])) {
    echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Resource time out.</h2><em>Please contact the system administrator if you see this message.</em></div>";
    mysqli_close($GLOBALS["conn"]); exit;
}

if ($_GET['t'] == 'enx' && isset($_GET['v'])) {
   
    $decryption_f = openssl_decrypt(base64_decode($_GET['v']), "AES-128-CTR", $aes_key, 0, "1234567891011121");
    header("Cache-Control: public, must-revalidate");
    header("Pragma: no-cache");
    header("Content-Type: application/octet-stream");
    header("Content-Length: " .(string)(filesize($decryption_f)));
    header("Content-Disposition: attachment; filename=".basename($decryption_f));//can be set to attachment or inline
    header("Content-Transfer-Encoding: binary\n");
    ob_end_clean();
    readfile($decryption_f);

} else {

    if (!isset($_GET['id'])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Resource time out.</h2><em>Please contact the system administrator if you see this message.</em></div>";
        mysqli_close($GLOBALS["conn"]); exit;
    }

    if (isset($_GET['id']) && ctype_alnum($_GET['id'])) {
        $id = $_GET['id'];
    } else {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Resource time out.</h2><em>Please contact the system administrator if you see this message.</em></div>";
        mysqli_close($GLOBALS["conn"]); exit();
    }

    // Get the key, timestamp, and number of downloads from the database
    $query = sprintf("SELECT * FROM eg_downloadkey WHERE id= '%s'", mysqli_real_escape_string($GLOBALS["conn"], $id));
    $result = mysqli_query($GLOBALS["conn"], $query);
    $row = mysqli_fetch_array($result);
    
    if (!$row) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>LINK EXPIRED</strong></span><h2>Invalid download link.</h2><em>Please contact the system administrator if you see this message.</em></div>";
    } else {
        
        //check if user click on the link provided or illegally tempered the url
        if (!isset($_GET['did']) || !is_numeric($_GET['did']) || $_GET['did'] != $row['eg_item_id']) {
            echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>ILLEGAL ACCESS</strong></span><h2>Invalid download link.</h2><em>Please contact the system administrator if you see this message.</em></div>";
            exit;
        }

        //check the duration since last download link generated and when the user access selected doc
        $timecheck = date('U') - $row['timestamped'];

        //20250711 - a new way to get download link directly from the database -start
        $stmt_getfilelocation = $new_conn->prepare("select id, 39inputdate, 41instimestamp from eg_item where id=? and 38status!='UNLISTED'");
        $stmt_getfilelocation->bind_param("i", $row['eg_item_id']);
        $stmt_getfilelocation->execute();
        $result_getfilelocation = $stmt_getfilelocation->get_result();
        $myrow_getfilelocation = $result_getfilelocation->fetch_assoc();

        $id_gfl = $myrow_getfilelocation["id"];
        $dir_gfl = substr($myrow_getfilelocation["39inputdate"], 0, 4);
        $instimestamp_gfl = $myrow_getfilelocation["41instimestamp"];

        $pdocs_gfl = "$system_pdocs_directory/$dir_gfl/$id_gfl"."_"."$instimestamp_gfl.pdf";
        $docs_gfl = "$system_docs_directory/$dir_gfl/$id_gfl"."_"."$instimestamp_gfl.pdf";
        $albums_gfl = "$system_albums_watermark_directory/$dir_gfl/$id_gfl"."_"."$instimestamp_gfl.jpg";
        //20250711 - a new way to get download link directly from the database -end
        
        //only timecheck if the user click on the download link other than partial/guest document
        if ($timecheck >= $max_time_link_availability && $_GET['t'] != 'p') {
            echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>LINK EXPIRED</strong></span><h2>Exceeded time allotted.</h2><em>Please contact the system administrator if you see this message.</em></div><br />";
            exit;
        } else {
            //only increment the download count if the user click on the download link other than partial/guest document
            $downloads = (int)$row['downloads'];
            if ($_GET['t'] != 'p') {
                $downloads += 1;
            }
            
            if ($downloads > $max_download_allowed && $_GET['t'] != 'p') {
                echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>LINK EXPIRED</strong></span><h2>Exceeded allowed downloads.</h2><em>Please contact the system administrator if you see this message.</em></div><br />";
                exit;
            } else {
            
                $sql = sprintf("UPDATE eg_downloadkey SET downloads = '".$downloads."' WHERE id= '%s'", mysqli_real_escape_string($GLOBALS["conn"], $id));
                $incrementdownloads = mysqli_query($GLOBALS["conn"], $sql);
                    
                ob_start();

                $contentdisposition = "inline";
                $contenttransferencoding = "binary";
                
                //download : application/octet-stream, inline : application/pdf
                if ($_GET['t'] == 'p' || $_GET['t'] == 'd') {

                    $_SESSION['access_from_doc_php'] = true;//only doc_inst.php can be able to access the pdf copies

                    if ($_GET['t'] == 'p') {
                        $mm_type="application/pdf";
                        $file = "../".$pdocs_gfl;//new way to get pdocs from the database
                        $filename = time()."G.pdf";
                        if (isset($_SESSION[$ssn.'fromapp']) &&  $_SESSION[$ssn.'fromapp']) {
                            $access_source = 'app';
                        } else {
                            $access_source = 'web';
                        }
                        mysqli_query($GLOBALS["conn"], "insert into eg_item_download values(DEFAULT,".$row['eg_item_id'].",'".date("D d/m/Y")."','".$_SERVER["REMOTE_ADDR"]."','$access_source')");
                    }
                    elseif ($_GET['t'] == 'd') {
                        $mm_type="application/pdf";
                        $file = "../".$docs_gfl;//new way to get docs from the database
                        $filename = time()."F.pdf";
                        if (isset($_SESSION[$ssn.'fromapp']) &&  $_SESSION[$ssn.'fromapp']) {
                            mysqli_query($GLOBALS["conn"], "insert into eg_item_download values(DEFAULT,".$row['eg_item_id'].",'".date("D d/m/Y")."','".$_SERVER["REMOTE_ADDR"]."','app')");
                        } else {
                            mysqli_query($GLOBALS["conn"], "insert into eg_item_download values(DEFAULT,".$row['eg_item_id'].",'".date("D d/m/Y")."','".$_SERVER["REMOTE_ADDR"]."','web')");
                            $query_curdownload = "select count(id) as totalid from eg_item_download where eg_item_id='".$row['eg_item_id']."'";
                            $result_curdownload = mysqli_query($GLOBALS["conn"], $query_curdownload);
                            $myrow_curdownload = mysqli_fetch_array($result_curdownload);
                            $inputdownloads = $myrow_curdownload["totalid"];
                            mysqli_query($GLOBALS["conn"], "update eg_item set 41downloads=$inputdownloads where id=".$row['eg_item_id']);
                        }
                    }
                    $encyrpted_fpdf_path = base64_encode(openssl_encrypt($file, "AES-128-CTR", $aes_key, 0, "1234567891011121"));
                    
                    if (isset($system_pdf_viewer) && $system_pdf_viewer == 'pdfjs') {
                        //this will utilizing pdfjs to view the pdf file
                        //if the pdfjs is not set, it will use the default browser pdf viewer
                        //if the pdfjs is set, it will use the pdfjs viewer
                    ?>
                        <!DOCTYPE html>
                        <html lang="en" xml:lang="en">
                        <head>
                            <meta charset="utf-8">
                            <title><?php echo $system_title;?> PDF Viewer</title>
                            <link rel="stylesheet" type="text/css" href="../sw_asset/css/doc-style.css"/>
                            <script>
                                document.addEventListener('contextmenu', function(event) {
                                    event.preventDefault();
                                });
                            </script>
                        </head>
                        <body>
                            <div id="loading-screen" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); display: flex; justify-content: center; align-items: center; z-index: 9999;">
                                <div style="text-align: center; color: white;">
                                    <h2>Please wait. Loading pages...</h2>
                                    <div style="width: 80%; background-color: #ddd; border-radius: 5px; margin: 10px auto;">
                                        <div id="loading-progress" style="height: 20px; width: 0%; background-color: #4caf50; border-radius: 5px;"></div>
                                    </div>
                                    <span id="loading-percentage" style="font-size: 18px;">0%</span>
                                </div>
                            </div>

                            <div class="container">
                                <div id="top-navigation" class="navigation">
                                    <strong><?php echo $system_title;?> PDF Viewer</strong>
                                </div>

                                <div id="pdf-container"></div>

                                <div id="bottom-navigation" class="navigation">
                                    <div class="nav-group">
                                        <span>Go to page:</span>
                                        <input type="number" class="page-input" min="1" placeholder="Page #">
                                        <button class="go-to-page">Go</button>
                                    </div>
                                    <div class="nav-group">
                                        <span>Total pages: <span class="total-pages">?</span></span>
                                    </div>
                                </div>
                            </div>

                            <script type="module">
                                import * as pdfjsLib from '../sw_asset/js/pdfjs5.1.91/build/pdf.js';
                                pdfjsLib.GlobalWorkerOptions.workerSrc = '../sw_asset/js/pdfjs5.1.91/build/pdf.worker.js';

                                let pdfDoc = null;
                                let totalPages = 0;
                                const scale = 1.5;
                                const pageInputs = document.querySelectorAll('.page-input');
                                const container = document.getElementById('pdf-container');

                                // Helper to update page counters and inputs
                                function js_updateNavigation(currentPage) {
                                    document.querySelectorAll('.total-pages').forEach(el => el.textContent = totalPages);
                                    pageInputs.forEach(input => input.value = currentPage);
                                }

                                // Add this to handle loading screen
                                function js_updateLoadingScreen(percentage) {
                                    const progressBar = document.getElementById('loading-progress');
                                    const percentageText = document.getElementById('loading-percentage');
                                    progressBar.style.width = percentage + '%';
                                    percentageText.textContent = percentage + '%';
                                }

                                // Update this function to include progress bar and text layer
                                function js_renderAllPages(pdf) {
                                    const renderPromises = [];
                                    let pagesRendered = 0;

                                    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                                        const renderPromise = pdf.getPage(pageNum).then(page => {
                                            const viewport = page.getViewport({ scale });
                                            
                                            // Create a container for the page
                                            const pageContainer = document.createElement('div');
                                            pageContainer.classList.add('pdf-page-container');
                                            pageContainer.style.position = 'relative';
                                            pageContainer.style.marginBottom = '10px';
                                            container.appendChild(pageContainer);

                                            // Create the canvas for the page
                                            const canvas = document.createElement('canvas');
                                            canvas.classList.add('pdf-page');
                                            canvas.dataset.pageNumber = pageNum;
                                            const ctx = canvas.getContext('2d', { alpha: false }); // Disable alpha for better performance
                                            canvas.width = viewport.width;
                                            canvas.height = viewport.height;
                                            pageContainer.appendChild(canvas);

                                            // Render the page on the canvas
                                            const renderContext = {
                                                canvasContext: ctx,
                                                viewport: viewport,
                                                enableWebGL: true
                                            };
                                            const renderTask = page.render(renderContext);

                                            return renderTask.promise;
                                        });

                                        renderPromises.push(renderPromise);

                                        // Update the loading progress
                                        renderPromise.then(() => {
                                            pagesRendered++;
                                            const percentage = Math.round((pagesRendered / pdf.numPages) * 100);
                                            js_updateLoadingScreen(percentage);
                                        });
                                    }

                                    // Once all pages are rendered, then update totalPages and hide the loading screen
                                    Promise.all(renderPromises).then(() => {
                                        js_updateNavigation(1);
                                        // Hide loading screen
                                        document.getElementById('loading-screen').style.display = 'none';
                                    });
                                }

                                // Fetch PDF path and render
                                let pdfPath;
                                fetch('doc_inst.php?pdf=<?=$encyrpted_fpdf_path;?>')
                                    .then(response => response.text())
                                    .then(path => {
                                        pdfPath = path.trim();
                                        if (!pdfPath) throw new Error("PDF path is empty.");

                                        pdfjsLib.getDocument(pdfPath).promise.then(pdf => {
                                            pdfDoc = pdf;
                                            totalPages = pdf.numPages;
                                            js_renderAllPages(pdf);
                                        }).catch(err => console.error('Error loading PDF:', err));
                                    })
                                    .catch(err => console.error('Error fetching PDF path:', err));

                                // Scroll to specific page on "Go"
                                document.querySelectorAll('.go-to-page').forEach((btn, index) => {
                                    btn.addEventListener('click', () => {
                                        const desiredPage = parseInt(pageInputs[index].value, 10);
                                        if (desiredPage >= 1 && desiredPage <= totalPages) {
                                            const targetCanvas = container.querySelector(`canvas[data-page-number="${desiredPage}"]`);
                                            if (targetCanvas) {
                                                targetCanvas.scrollIntoView({ behavior: 'smooth' });
                                                js_updateNavigation(desiredPage);
                                            }
                                        }
                                    });
                                });
                                </script>
                        </body>
                        </html>
                <?php
                    exit;
                    //exit if view using pdf.min.js do not need to download the pdf file
                    }
                } elseif ($_GET['t'] == 'a') {
                    $mm_type="image/jpeg";
                    $file = "../".$albums_gfl;//new way to get pdocs from the database
                    $filename = time()."I.jpg";
                } elseif ($_GET['t'] == 'i') {
                    $mm_type="application/octet-stream";
                    //disable this for now 20250711
                    /*$file = "../".$row['isos'];
                    $file_extension = substr($row['isos'], strrpos($row['isos'], '.') + 1);//get extension from $row['isos']
                    $filename = time()."S.$file_extension";
                    */
                    $contentdisposition = "attachment";
                } else {
                    echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID DOWNLOAD</strong></span><h2>Action not permitted.</h2><em>Please contact the system administrator if you see this message.</em></div>";
                    exit;
                }

                header("Cache-Control: public, must-revalidate");
                header("Pragma: no-cache");
                header("Content-Type: " . $mm_type);
                header("Content-Length: " .(string)(filesize($file)));
                header("Content-Disposition: $contentdisposition; filename=$filename");//can be set to attachment or inline
                header("Content-Transfer-Encoding: binary\n");
                ob_end_clean();
                readfile($file);
            }
        }
    }
}
