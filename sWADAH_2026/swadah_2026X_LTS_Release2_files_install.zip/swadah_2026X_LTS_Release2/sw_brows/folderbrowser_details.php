<?php
/*
Filename: sw_brows/folderbrowser_details.php
Usage: List all items related to current selected folder
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Folder -Contents";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/functions.php';
    
    //assign to browser
    $_SESSION[$ssn.'whichbrowser'] = "fb";

    $get_subacr = htmlspecialchars($_GET["subacr"]);
    if (!is_numeric($get_subacr)) {
        sfx_echoPopupAlert("Illegal operation.","link","folderbrowser.php");
        mysqli_close($GLOBALS["conn"]);
        exit();
    }

    if ((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) {
        $auth_user = $_SESSION[$ssn.'username'] ?? $_SESSION[$ssn.'username_guest'] ?? null;
        $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$get_subacr'";
        $result_user = mysqli_query($GLOBALS["conn"], $query_user);
        if (mysqli_num_rows($result_user) != 1) {
            sfx_echoPopupAlert("You don't have authorization to view the content of this folder.","link","folderbrowser.php");
            mysqli_close($GLOBALS["conn"]);
            exit();
        }
    }
?>

<html lang='en'>

<head>
    <?php
        include_once '../sw_inc/header.php';
        //autologout
        echo isset($_SESSION[$ssn.'lls']) ? '<meta http-equiv="refresh" content="1800;url=../index.php?c=ls" />' : '';

    ?>
</head>

<body class='<?php echo $color_scheme;?>'>

    <div style='text-align:center;'>

    <?php
        include_once '../sw_inc/loggedinfo.php';
        
        echo "<hr>";

        $query_fol = "select 38foldername from eg_item_folder where 38folderid=".$get_subacr;
        $result_fol = mysqli_query($GLOBALS["conn"], $query_fol);
        $row_fol = mysqli_fetch_array($result_fol);
        if (mysqli_num_rows($result_fol) >= 1) {
            $fol_name = $row_fol['38foldername'];

            if (isset($_GET['page'])) {$currentPage = $_GET['page'];}
            include_once '../sw_inc/paging-p1.php';
            
            $query1 = "
            select eg_item.id as id, eg_item.38title as 38title, eg_item.38typeid as 38typeid
             from eg_item left join eg_item2 on eg_item.id=eg_item2.eg_item_id
              where eg_item.38folderid='$get_subacr' and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' order by 38title LIMIT $offset, $rowsPerPage";
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
            
            $query_count = "
            select count(eg_item.id) as total
             from eg_item left join eg_item2 on eg_item.id=eg_item2.eg_item_id
              where eg_item.38folderid='$get_subacr' and eg_item.50item_status='1' and eg_item.38status!='UNLISTED'";
            $result_count = mysqli_query($GLOBALS["conn"], $query_count);

            $paging_type = 2;
            include_once '../sw_inc/paging-p2.php';
    ?>
                        
            <table class=<?php echo $color_scheme."Header";?>>
                <tr><td><img src='../sw_asset/img/bw_folder.png' style='width:16px;' alt='Folder_icon'> Folder:
                <?php
                    echo "<strong>$fol_name</strong> (<em>$num_results_affected_paging items</em>)";
                ?>
                </td></tr>
            </table>

            <table class=whiteHeaderNoCenter>
                <tr class=whiteHeader style='text-decoration:underline;'><td></td><td>Title</td><td style='width:150;'><?php echo $type_as;?></td></tr></tr>
                <?php
                        $n = $offset + 1;

                        while ($myrow1 = mysqli_fetch_array($result1)) {
                            echo "<tr class=$color_scheme"."Hover>";
                                $id2 = $myrow1["id"];
                                $type2 = $myrow1["38typeid"];
                                $title2 = $myrow1["38title"];
                                
                                if (!isset($_SESSION[$ssn.'username'])) {
                                    $exploded_removed_words = explode(',', $remove_word_from_title);
                                    foreach ($exploded_removed_words as $value) {
                                        $title2 = str_replace($value, "", $title2);
                                    }
                                    $title2 = htmlspecialchars_decode($title2);
                                }
                                                                    
                                echo "<td width=40>$n</td>";
                                echo "<td style='text-align:left;'>";
                                    if (!isset($_SESSION[$ssn.'username'])) {
                                        echo "<a class=thisonly href='../detailsg.php?det=$id2'>$title2</a>";
                                    } else {
                                        echo "<a class=thisonly href='../sw_admin/details.php?det=$id2'>$title2</a>";
                                    }
                                echo "</td>";
                                echo "<td>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $type2)."</td>";
                            echo "</tr>";
                                                                    
                            $n = $n +1 ;
                        }
                ?>
            </table>
            
            <?php
                $appendpaging = "&subacr=$get_subacr";
                include_once '../sw_inc/paging-p3.php';
            ?>
            
            <br/>
        
        <?php
        } else {
            echo "<br/>No result found.<br/><br/>";
        }
        
        echo "<a class='sButton' href='folderbrowser.php'><span class='fas fa-arrow-circle-left'></span> Go to Folder Listing</a> ";
        ?>
        
    </div>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
