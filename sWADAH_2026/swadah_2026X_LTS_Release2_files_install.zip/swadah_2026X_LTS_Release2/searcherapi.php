<?php
/*
Filename: searcherapi.php
Usage: SEARCHER API
Version: 3.0.20250707.1000 Beta
*/

    // Security headers
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');

    // Add CORS headers for API
    header('Access-Control-Allow-Origin: *'); // Restrict this in production
    header('Access-Control-Allow-Methods: GET');
    header('Access-Control-Allow-Headers: Content-Type');

    // Ensure only GET requests
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Method not allowed']);
        exit();
    }
    
    // for includeExist check to prevent direct access for sw_inc files
    define('includeExist', true);
    
    // Include necessary files
    include_once 'core.php';
    include_once 'sw_inc/functions.php';

    sfx_check_is_blocked("$recorded_incidents_directory/", "");

    // Ultra simple rate limiting
    function checkRateLimit() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $time_window = 60; // 1 minute
        $max_requests = 30; // 30 requests per minute
        
        $cache_file = sys_get_temp_dir() . '/api_rate_' . md5($ip);
        
        if (file_exists($cache_file)) {
            $data = json_decode(file_get_contents($cache_file), true);
            if (time() - $data['time'] < $time_window) {
                if ($data['count'] >= $max_requests) {
                    http_response_code(429);
                    header('Content-type:application/json;charset=utf-8');
                    echo json_encode(['error' => 'Rate limit exceeded']);
                    exit();
                }
                $data['count']++;
            } else {
                $data = ['time' => time(), 'count' => 1];
            }
        } else {
            $data = ['time' => time(), 'count' => 1];
        }
        
        file_put_contents($cache_file, json_encode($data));
    }
    checkRateLimit();

    // Security: Validate sctype parameter more strictly
    if (isset($_GET['sctype'])) {
        if (!is_numeric($_GET['sctype']) && $_GET['sctype'] !== 'EveryThing') {
            sfx_record_block_api("$recorded_incidents_directory/");
            http_response_code(400);
            header('Content-type:application/json;charset=utf-8');
            echo json_encode(['error' => 'Invalid sctype parameter. Incident recorded.']);
            exit();
        }
    }

    // Security: Better input validation for numeric parameters
    if (isset($_GET['agpt']) && (!is_numeric($_GET['agpt']) || $_GET['agpt'] < 0 || $_GET['agpt'] > 1)) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid agpt parameter']);
        exit();
    }
    
    // Security: Validate itemid parameter
    if (isset($_GET['itemid']) && (!is_numeric($_GET['itemid']) || $_GET['itemid'] <= 0)) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid itemid parameter']);
        exit();
    }

    // Validate usepage parameter
    if (isset($_GET['usepage']) && ($_GET['usepage'] !== '0' && $_GET['usepage'] !== '1')) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid usepage parameter']);
        exit();
    }

    // Validate page parameter
    if (isset($_GET['page']) && (!is_numeric($_GET['page']) || $_GET['page'] < 1)) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid page parameter']);
        exit();
    }

    // Validate per_page parameter
    if (isset($_GET['per_page']) && (!is_numeric($_GET['per_page']) || $_GET['per_page'] < 1 || $_GET['per_page'] > 100)) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid per_page parameter']);
        exit();
    }

    // Validate scpubid parameter
    if (isset($_GET['scpubid']) && (!is_numeric($_GET['scpubid']) || $_GET['scpubid'] <= 0)) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid scpubid parameter']);
        exit();
    }

    // Validate list parameters
    $list_params = ['listype', 'listpub', 'listsub'];
    foreach ($list_params as $param) {
        if (isset($_GET[$param]) && ($_GET[$param] !== '1' || !is_numeric($_GET[$param]))) {
            http_response_code(400);
            header('Content-type:application/json;charset=utf-8');
            echo json_encode(['error' => "Invalid $param parameter"]);
            exit();
        }
    }

    // Validate use parameter
    if (isset($_GET['use']) && $_GET['use'] !== 'help') {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid use parameter']);
        exit();
    }
    
    // Security: Validate mitemid parameter
    if (isset($_GET['mitemid']) && (!is_numeric($_GET['mitemid']) || $_GET['mitemid'] <= 0)) {
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'Invalid mitemid parameter']);
        exit();
    }

    // Validate input lengths
    $string_params = ['scstr', 'scpub', 'scsub', 'use'];
    foreach ($string_params as $param) {
        if (isset($_GET[$param]) && strlen($_GET[$param]) > 255) {
            http_response_code(400);
            header('Content-type:application/json;charset=utf-8');
            echo json_encode(['error' => "Parameter $param too long"]);
            exit();
        }
    }

    //pagination and limit logic
    $use_pagination = isset($_GET['usepage']) && $_GET['usepage'] == '1';
    $page = isset($_GET['page']) && is_numeric($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $per_page = isset($_GET['per_page']) && is_numeric($_GET['per_page']) ? min(100, max(1, (int)$_GET['per_page'])) : 20;
    // Update append_search_limit logic
    if ($use_pagination) {
        $offset = ($page - 1) * $per_page;
        $append_search_limit = "LIMIT $per_page OFFSET $offset";
    } else {
        $append_search_limit = (isset($_GET['agpt']) && is_numeric($_GET['agpt']) && $_GET['agpt'] == '1') ? "LIMIT 20" : "";
    }

    // Security fix: Use proper parameterization instead of string concatenation
    $use_limit = (isset($_GET['agpt']) && is_numeric($_GET['agpt']) && $_GET['agpt'] == '1');

    // default value for sctype_select,scstr_term
    $sctype_select = (isset($_GET['sctype']) && is_numeric($_GET['sctype'])) ? $_GET['sctype'] : 'EveryThing';
    $scstr_term = isset($_GET['scstr']) ? sfx_just_clean($_GET['scstr']) : '';
        $scstr_term = preg_replace('/\s+/', ' +', "+".$scstr_term);//add '+' in front of every word

    if (isset($_GET['sctype'])) {
        if ($scstr_term == '') {
            // Build base WHERE clause
            $base_where = "WHERE id<>0 AND 50item_status='1' AND 38status!='UNLISTED' AND 38folderid=0";
            // Empty search term - list all or by type
            if ($sctype_select == 'EveryThing') {
                $query1 = "SELECT SQL_CALC_FOUND_ROWS * FROM eg_item $base_where ORDER BY id DESC $append_search_limit";
                $stmt = $new_conn->prepare($query1);
            } else {
                $query1 = "SELECT SQL_CALC_FOUND_ROWS * FROM eg_item $base_where AND 38typeid = ? ORDER BY id DESC $append_search_limit";
                $stmt = $new_conn->prepare($query1);
                $stmt->bind_param("s", $sctype_select);
            }
        } else {
            // Handle search with terms
            $scstr_term = sfx_filterCommonWords($scstr_term);
            
            $base_query = "SELECT SQL_CALC_FOUND_ROWS *, MATCH (38title,38author) AGAINST (? IN BOOLEAN MODE) AS score 
                        FROM eg_item WHERE id<>0 AND 50item_status='1' AND 38status!='UNLISTED' AND 38folderid=0 
                        AND MATCH (38title,38author,41fulltexta) AGAINST (? IN BOOLEAN MODE)";
            
            if ($sctype_select == 'EveryThing') {
                $query1 = $base_query . " ORDER BY score DESC $append_search_limit";
                $stmt = $new_conn->prepare($query1);
                $stmt->bind_param("ss", $scstr_term, $scstr_term);
            } else {
                $query1 = $base_query . " AND 38typeid = ? ORDER BY score DESC $append_search_limit";
                $stmt = $new_conn->prepare($query1);
                $stmt->bind_param("sss", $scstr_term, $scstr_term, $sctype_select);
            }
        }

        $stmt->execute();
        $result_term = $stmt->get_result();

        // Get total count for pagination
        $total_stmt = $new_conn->prepare("SELECT FOUND_ROWS() as total");
        $total_stmt->execute();
        $total_result = $total_stmt->get_result();
        $total_count = $total_result->fetch_assoc()['total'];

        $posts = array();
        while ($myrow_term = $result_term->fetch_assoc()) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'year'=>sfx_sGetValue("38publication_c", "eg_item2", "eg_item_id", $myrow_term["id"]),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'origin_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }

        // Check if pagination is requested
        $use_pagination = isset($_GET['usepage']) && $_GET['usepage'] == '1';

        if ($use_pagination) {
            // Calculate pagination info
            $page = isset($_GET['page']) && is_numeric($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
            $per_page = isset($_GET['per_page']) && is_numeric($_GET['per_page']) ? min(100, max(1, (int)$_GET['per_page'])) : 20;
            $total_pages = ceil($total_count / $per_page);
            
            $response = array(
                'data' => $posts,
                'pagination' => array(
                    'current_page' => $page,
                    'per_page' => $per_page,
                    'total_items' => $total_count,
                    'total_pages' => $total_pages,
                    'has_next' => $page < $total_pages,
                    'has_prev' => $page > 1
                )
            );
            
            header('Content-type:application/json;charset=utf-8');
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        } else {
            // Legacy response format
            header('Content-type:application/json;charset=utf-8');
            echo json_encode($posts, JSON_UNESCAPED_UNICODE);
        }






    } elseif (isset($_GET['scpub'])) {
        $scpub2 = htmlspecialchars($_GET['scpub']);
        
        $param = "%".$scpub2."%";
        $stmt_term = $new_conn->prepare("
        select
        eg_item.id as id, eg_item.38title as 38title, eg_item.38author as 38author, eg_item.38typeid as 38typeid,
        eg_item2.38publication_b as 38publication_b, eg_item2.38publication_c as 38publication_c, eg_item2.38dissertation_note_b as 38dissertation_note_b
        from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id
         where eg_item2.38publication_b like ? and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0
        ");
        $stmt_term->bind_param("s", $param);//s string
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();
        
        $posts = array();

        while ($myrow_term = $result_term->fetch_assoc()) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'publication'=>htmlspecialchars($myrow_term["38publication_b"]),
                'year_of_publication'=>htmlspecialchars($myrow_term["38publication_c"]),
                'degree_type'=>htmlspecialchars($myrow_term["38dissertation_note_b"]),
                'origin_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);







    } elseif (isset($_GET['scpubid']) && is_numeric($_GET['scpubid'])) {
        $scpub2 = sfx_sGetValue("43publisher", "eg_publisher", "43pubid", $_GET['scpubid']);
        
        $param = "%".$scpub2."%";
        $stmt_term = $new_conn->prepare("
        select
        eg_item.id as id, eg_item.38title as 38title, eg_item.38author as 38author, eg_item.38typeid as 38typeid,
        eg_item2.38publication_b as 38publication_b, eg_item2.38publication_c as 38publication_c, eg_item2.38dissertation_note_b as 38dissertation_note_b
        from eg_item inner join eg_item2 on eg_item.id=eg_item2.eg_item_id
         where eg_item2.38publication_b like ? and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0
        ");
        $stmt_term->bind_param("s", $param);//s string
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();
        
        $posts = array();

        while ($myrow_term = $result_term->fetch_assoc()) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'publication'=>htmlspecialchars($myrow_term["38publication_b"]),
                'year_of_publication'=>htmlspecialchars($myrow_term["38publication_c"]),
                'degree_type'=>htmlspecialchars($myrow_term["38dissertation_note_b"]),
                'origin_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } elseif (isset($_GET['scsub'])) {
        $scsub2 = sfx_just_clean($_GET['scsub']);

        $param = "%".$scsub2."%";
        $stmt_term = $new_conn->prepare("select id, 38title, 38author, 38typeid, 41subjectheading from eg_item
         where 41subjectheading like ? and eg_item.50item_status='1' and eg_item.38status!='UNLISTED' and eg_item.38folderid=0");
        $stmt_term->bind_param("s", $param);//s string
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();

        $posts = array();
        while ($myrow_term = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$myrow_term["id"],
                'title'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38title"])),
                'author'=>sfx_filterHexadecimal(htmlspecialchars($myrow_term["38author"])),
                'type'=>sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $myrow_term["38typeid"]),
                'subject'=>htmlspecialchars($myrow_term["41subjectheading"]),
                'origin_link'=>$system_path."detailsg.php?det=".$myrow_term['id']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);





    } elseif (isset($_GET['listype']) && is_numeric($_GET['listype']) && $_GET['listype'] == '1') {
        $stmt_term = $new_conn->prepare("select 38typeid, 38type from eg_item_type");
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();

        $posts = array();
        while ($row_typelist = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$row_typelist['38typeid'],
                'type'=>$row_typelist['38type']
            );
        }
        array_push($posts, array(
            'id'=>'EveryThing',
            'type'=>'This will list everything'));
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } elseif (isset($_GET['listpub']) && is_numeric($_GET['listpub']) && $_GET['listpub'] == '1') {
        $stmt_term = $new_conn->prepare("select 43pubid, 43acronym, 43publisher from eg_publisher");
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();
        
        $posts = array();
        while ($row_publist = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$row_publist['43pubid'],
                'acronym'=>$row_publist['43acronym'],
                'publisher'=>$row_publist['43publisher']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);







    } elseif (isset($_GET['listsub']) && is_numeric($_GET['listsub']) && $_GET['listsub'] == '1') {
        $stmt_term = $new_conn->prepare("select 43subjectid, 43acronym, 43subject from eg_subjectheading");
        $stmt_term->execute();
        $result_term = $stmt_term->get_result();

        $posts = array();
        while ($row_sublist = mysqli_fetch_array($result_term)) {
            $posts[] = array(
                'id'=>$row_sublist['43subjectid'],
                'acronym'=>$row_sublist['43acronym'],
                'subject'=>$row_sublist['43subject']
            );
        }
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);







    } elseif ((isset($_GET['itemid']) && is_numeric($_GET['itemid'])) || (isset($_GET['mitemid']) && is_numeric($_GET['mitemid']))) {
        $iid = $_GET['itemid'] ?? $_GET['mitemid'] ?? 0;

        $stmt_detail = $new_conn->prepare("select * from eg_item where id=?");
        $stmt_detail->bind_param("i", $iid);//i integer
        $stmt_detail->execute();
        $result_detail = $stmt_detail->get_result();
        $row_detail = $result_detail->fetch_assoc();
        
        $fulltext = (isset($row_detail["41isabstract"]) && $row_detail["41isabstract"] == 1) ? 'abstract' : 'fulltext';

        //generate downloadkey -start
        if (empty($_SERVER['REQUEST_URI'])) {$_SERVER['REQUEST_URI'] = $_SERVER['SCRIPT_NAME'];}
        $url = preg_replace('/\?.*$/', '', $_SERVER['REQUEST_URI']);
        $folderpath = $system_path;
        $time = date('U');
        $ip_address = $_SERVER["REMOTE_ADDR"];
        //generate downloadkey -end

        $guest_file = "sw_admin/temp/no_permission.pdf";
        $pdocs_file = "sw_admin/temp/no_permission.pdf";
        $docs_file = "sw_admin/temp/no_permission.pdf";
        $image_file = "sw_admin/temp/no_permission.pdf";
        $albums_file = "sw_admin/temp/no_permission.pdf";
        $isos_file = "sw_admin/temp/no_permission.pdf";

        $inputdate_fdb = $row_detail["39inputdate"] ?? '00';
        $id_fdb = $row_detail['id'] ?? 0;
        $instimestamp_fdb = $row_detail['41instimestamp'] ?? 0;

        //create database entry for permission and granted access to the downloadkey
        $registerid = mysqli_query($GLOBALS["conn"], "INSERT INTO eg_downloadkey (id,eg_item_id,ip_address,timestamped,downloads) VALUES(DEFAULT,'".$id_fdb."','$ip_address','$time',DEFAULT)");
        $registeredid_justnow = $registerid ? mysqli_insert_id($GLOBALS["conn"]) : 0;

        if (is_file("$system_pdocs_directory/".substr($inputdate_fdb, 0, 4)."/".$id_fdb.""."_".$instimestamp_fdb.".pdf")) {
            $guest_file = "$system_path"."sw_inc/doc.php?t=p&did=$id_fdb&id=$registeredid_justnow";
        }
        
        if (is_file("$system_albums_directory/".substr($inputdate_fdb, 0, 4)."/".$id_fdb.""."_".$instimestamp_fdb.".jpg")) {
            $image_file = "$system_path"."sw_inc/doc.php?t=a&did=$id_fdb&id=$registeredid_justnow";
        }

        $posts = array(
            'id' => $row_detail['id'] ?? 0,
            'title' => sfx_filterHexadecimal($row_detail["38title"]) ?? 'N/A',
            'author' => sfx_filterHexadecimal($row_detail["38author"]) ?? 'N/A',
            'type' => sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $row_detail['38typeid'] ?? 0),
            'publication' => $row_detail["38publication"] ?? 'N/A',
            'source' => $row_detail["38source"] ?? 'N/A',
            'weblink' => urldecode($row_detail["38link"] ?? 'N/A'),
            'guest_file' => $guest_file,
            'image_file' => $image_file,
            'origin_link' => $system_path . "detailsg.php?det=" . $id_fdb,
        );
        
        if (isset($_GET['itemid'])) {
            $posts['fulltext'] = htmlspecialchars(strip_tags($row_detail["41fulltexta"] ?? ''));
            $posts['reference'] = htmlspecialchars(strip_tags($row_detail["41reference"] ?? ''));
        }
        
        header('Content-type:application/json;charset=utf-8');
        echo json_encode($posts, JSON_UNESCAPED_UNICODE);






    } elseif (isset($_GET['use']) && $_GET['use'] == 'help') {
        //display api documentation
        include_once 'sw_inc/searcherapi_html.php';
    
    
    
    

    } else {
        //do something if no parameters are provided
        http_response_code(400);
        header('Content-type:application/json;charset=utf-8');
        echo json_encode(['error' => 'No valid parameters provided', 'message' => "Please refer to the API documentation for valid parameters via ". htmlspecialchars($_SERVER['PHP_SELF'], ENT_QUOTES, 'UTF-8') . "?use=help"]);
    }
    
    mysqli_close($GLOBALS["conn"]); exit();
