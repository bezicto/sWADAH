<?php
/*
Filename: embargoed.php
Usage: Manage embargoed item
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Embargoed List";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
        
    <div style='text-align:center'>
        <?php
                                                                                            
            $query_emb = "select * from eg_item where 38status = 'EMBARGO' order by id desc";
            $result_emb = mysqli_query($GLOBALS["conn"], $query_emb);
        
            $row_emb = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
            $num_results_affected = $row_emb[0];

            echo "<table class=$color_scheme"."Header><tr>";
                echo "<td><strong>Embargoed List</strong>: $num_results_affected <em>record(s) found.</em></td>";
            echo "</tr></table>";
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'>
                        <td></td>
                        <td>Title</td>
                        <td>Author</td>
                        <td>Type</td>
                        <td>End date</td>
                    </tr>";
                                                                                
                $n = 1;
                                        
                while ($myrow_emb = mysqli_fetch_array($result_emb)) {
                    $id = $myrow_emb["id"];
                    $titlestatement = $myrow_emb["38title"];
                    $typestatement = sfx_sGetValue("38synonym", "eg_item_type", "38typeid",$myrow_emb["38typeid"]);
                    $authorname = $myrow_emb["38author"] ? $myrow_emb["38author"] : "";
                    $embargo_timestamp = $myrow_emb["51_embargo_timestamp"];
                    $status5_embargo_indicator = date("d M Y", $embargo_timestamp);

                    if ($embargo_timestamp <= time()) {
                        mysqli_query($GLOBALS["conn"], "update eg_item set 38status='AVAILABLE' where id=$id");
                    }

                    echo "<tr class=$color_scheme"."Hover>";
                        echo "<td>$n</td>";
                        echo "<td style='text-align:left;vertical-align:top;'><a href='details.php?det=$id'>$titlestatement</a></td>";
                        echo "<td>$authorname</td>";
                        echo "<td>$typestatement</td>";
                        echo "<td>$status5_embargo_indicator</td>";
                    echo "</tr>";
                                                                    
                    $n = $n +1 ;
                }
            echo "</table>";
        ?>
        <br/><em>Refresh the page to see the latest updates.</em>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
