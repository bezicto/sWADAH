<?php
/*
Filename: sw_admin/config_user.php
Usage: Read database setting and display for editing
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/token_validate.php';

    $thisPageTitle = "Configurator";
    
    $tabMapping = [
        'metadata' => 'metadata',
        'system'   => 'system',
        'depo'     => 'depo',
        'gui'      => 'gui',
        'dir'      => 'dir',
        'api'      => 'api',
        'oai'      => 'oai',
        'email'    => 'email',
        'sdepo'    => 'sdepo'
    ];
    
    if (isset($_GET['tab'])) {
        $tab = $_GET['tab'];
        if (isset($tabMapping[$tab])) {
            $_SESSION[$ssn.'tab'] = $tabMapping[$tab];
            $_SESSION[$ssn.'appendsql'] = " and ctype='$tab'";
            if ($_SESSION[$ssn.'tab'] == 'dir') {
                $_SESSION[$ssn.'appendsql'] = "and (ctype='$tab' or ctype='dirloca')";
            }
        } elseif ($tab == 'allimportant') {
            $_SESSION[$ssn.'tab'] = "allimportant";
            $_SESSION[$ssn.'appendsql'] = " and important='true'";
        }
    }
    
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
    <style>
        .highlight {
            background-color: yellow;
        }
        .current {
            background-color: orange;
        }
        .search-bar {
            position: fixed;
            bottom: 15px;
            right: 1px;
            background-color: grey;
            padding: 10px;
            border: 1px solid #ccc;
            z-index: 1000;
        }
        .table-container {
            width: 100%;
            max-width: 100%;
            overflow-x: auto;
            overflow-y: auto;
            /*max-height: 600px;*/
            position: relative;
        }
    </style>
</head>

<body class='<?php echo $color_scheme;?>'>
        
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"]) && (isset($enable_dev_plus_menu) && $enable_dev_plus_menu)) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from config_user where id = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();$stmt_del->close();
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"]) && (isset($enable_dev_plus_menu) && $enable_dev_plus_menu)) {
            sfx_echoPopupAlert("Illegal action recorded.","link","config_user.php");
            exit;
        }
                
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            if (isset($_POST["cname1"]) && isset($_POST["cdesc1"])) {
                $cname1 = trim(mysqli_real_escape_string($GLOBALS["conn"], $_POST["cname1"]));
                $cdesc1 = trim($_POST["cdesc1"]);
                $ctype1 = trim($_POST["ctype1"]);
                $possible_values1 = trim($_POST["possible_values1"]);
            }
            $appendAnchor = "";
            $cvalue1 = trim($_POST["cvalue1"]);
            if ($_REQUEST["submitted"] == "Insert" && (isset($enable_dev_plus_menu) && $enable_dev_plus_menu)) {
                $stmt_count = $new_conn->prepare("select count(*) from config_user where cname = ?");
                $stmt_count->bind_param("s", $cname1);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected_publisher);
                $stmt_count->fetch();$stmt_count->close();

                if ($num_results_affected_publisher == 0) {
                    if (!empty($cname1)) {
                        $important1 = 'false';
                        $stmt_insert = $new_conn->prepare("insert into config_user values(DEFAULT,?,?,?,?,?,?,?)");
                        $stmt_insert->bind_param("sssssss", $cname1, $cdesc1, $cvalue1, $cvalue1, $ctype1, $possible_values1, $important1);
                        $stmt_insert->execute();
                        $stmt_insert->close();
                        //sfx_echoPopupAlert("The config $cname1 has been inputed into the database.");
                        $messageToPop = "The config $cname1 has been inputed into the database.";
                    } else {
                        //sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                        $messageToPop = "Your input has been cancelled.Check if any field(s) left emptied before posting.";
                    }
                } elseif ($num_results_affected_publisher >= 1) {
                    //sfx_echoPopupAlert("Your input has been cancelled. Duplicate config detected.");
                    $messageToPop = "Your input has been cancelled. Duplicate config detected.";
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];
                if (!empty($cvalue1) && is_numeric($id1)) {
                    if (isset($enable_dev_plus_menu) && $enable_dev_plus_menu) {
                        $stmt_update = $new_conn->prepare("update config_user set cname=?, cdesc=?, cvalue=?, ctype=?, possible_values=? where id=?");
                        $stmt_update->bind_param("sssssi", $cname1, $cdesc1, $cvalue1, $ctype1, $possible_values1, $id1);
                    } else {
                        $stmt_update = $new_conn->prepare("update config_user set cvalue=? where id=?");
                        $stmt_update->bind_param("si", $cvalue1, $id1);
                    }
                    $stmt_update->execute();$stmt_update->close();
                    //sfx_echoPopupAlert("The config has been updated.","link","config_user.php#$id1");
                    $messageToPop = "The config has been updated.";
                } else {
                    //sfx_echoPopupAlert("Error. Please make sure there were no empty field(s) or invalid entry. The record has been restored to it original state.","link","config_user.php#$id1");
                    $messageToPop = "Error. Please make sure there were no empty field(s) or invalid entry. The record has been restored to it original state.";
                }
            }
            
            //reload init.php with new values
            $config_table = "config_user";
            $variable_write = "<?php".PHP_EOL;
            $variable_write .= "//do not alter this file. make changes in $system_core configurator instead.".PHP_EOL;
            $variable_write .= "//edited via $system_core configurator on: ".date('l jS \of F Y h:i:s A').PHP_EOL.PHP_EOL;
            ${"query_$config_table"} = "select * from $config_table order by cname,ctype";
            ${"result_$config_table"} = mysqli_query($GLOBALS["conn"], ${"query_$config_table"});
            while (${"row_$config_table"} = mysqli_fetch_array(${"result_$config_table"})) {
                $var_name = ${"row_$config_table"}['cname'];
                $var_value = ${"row_$config_table"}['cvalue'];
                if (${"row_$config_table"}['cvalue'] == 'true') {
                    $variable_write .= "$$var_name = true;". PHP_EOL;
                } elseif (${"row_$config_table"}['cvalue'] == 'false') {
                    $variable_write .= "$$var_name = false;". PHP_EOL;
                } else {
                    $variable_write .= "$$var_name = \"$var_value\";". PHP_EOL;
                }
            }
            $filename = 'init.php';
            file_put_contents('../init.php', $variable_write);
            sfx_echoPopupAlert($messageToPop,"link","config_user.php");
        }

        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select id,cname,cdesc,cvalue,cvalue_default,ctype,possible_values from config_user where id = ? ".$_SESSION[$ssn.'appendsql']);
            $stmt3->bind_param("i", $get_id_upd);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3,$cname3, $cdesc3, $cvalue3, $cvalue3_default, $ctype3, $possible_values3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","config_user.php");
            exit;
        }

        
  
    ?>

    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <div style='margin-top:15px;width:100%;text-align:center;font-size:12pt;'>
        Select:
        [<a href='config_user.php?tab=allimportant'>Important&nbspSettings</a>]
        [<a href='config_user.php?tab=system'>System</a>]
          [<a href='config_user.php?tab=gui'>GUI</a>]
           [<a href='config_user.php?tab=metadata'>Metadata</a>]
           [<a href='config_user.php?tab=sdepo'>Self&nbspSubmission</a>]
            [<a href='config_user.php?tab=depo'>Self&nbspDeposit&nbspSlip&nbspTemplate</a>]
             [<a href='config_user.php?tab=dir'>Directories&nbsp&&nbspUpload</a>]
              [<a href='config_user.php?tab=api'>API</a>]
               [<a href='config_user.php?tab=oai'>OAI</a>]
                [<a href='config_user.php?tab=email'>Email</a>]
                 [<a onclick='return js_openPopup(this.href,1000,580);' href='config_phpinfo.php'>Server&nbspPHP&nbspInfo</a>]
    </div><br/>

    <?php
    if (file_exists(stream_resolve_include_path('../userfiles/dev.config.sys.php'))) {
        echo "<div style='width:100%;text-align:center;'>Configuration might be loaded from from dev.config.sys.php because the file is exist.</div><br/>";
    }
    ?>
    
    <?php
    if ((isset($_GET['edt']) && is_numeric($_GET['edt'])) || (isset($_GET['create']) && $_GET['create'] == 'new')) {
    ?>
        <table class=whiteHeader>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong>Variable</strong></td></tr>
            <tr class=greyHeaderCenter><td colspan=2><br/>
                <form action="config_user.php" method="post" encdesc="multipart/form-data">
                    
                    <strong>CNAME: </strong>
                    <br/>
                    <?php
                    if (((isset($enable_dev_plus_menu) && $enable_dev_plus_menu) && isset($cname3)) || (isset($_GET['create']) && $_GET['create'] == 'new')) {
                    ?>
                    <input type="text" name="cname1" style="width:50%" maxlength="250" value="<?php if (isset($cname3)) {echo $cname3;} ?>"/>
                    <?php
                    } elseif (isset($cname3)) {
                        echo "<div style='color:green;'>$cname3</div>" ?? '';
                    }
                    ?>
                    <br/><br/>

                    <strong>CDESC: </strong>
                    <br/>
                    <?php
                    if (((isset($enable_dev_plus_menu) && $enable_dev_plus_menu) && isset($cdesc3)) || (isset($_GET['create']) && $_GET['create'] == 'new')) {
                    ?>
                    <input type="text" name="cdesc1" style="width:50%" maxlength="2000" value="<?php if (isset($cdesc3)) {echo $cdesc3;} ?>"/>
                    <?php
                    } elseif (isset($cname3)) {
                        echo "<div style='color:green;'>$cdesc3</div>" ?? '';
                    }
                    ?>
                    <br/><br/>

                    <strong>CVALUE: </strong>
                    <br/>
                    <textarea name="cvalue1" rows=4 style="width:50%"><?php if (isset($cvalue3)) {echo $cvalue3;} ?></textarea>
                    <br/><br/>Default:<br/><div style='width:50%;margin-left:auto;margin-right:auto;color:green;'><?php if (isset($cvalue3_default)) {echo htmlspecialchars($cvalue3_default) ?? '';}?></div>
                    <br/><br/>

                    <strong>CTYPE: </strong>
                    <br/>
                    <?php
                    if (((isset($enable_dev_plus_menu) && $enable_dev_plus_menu) && isset($ctype3)) || (isset($_GET['create']) && $_GET['create'] == 'new')) {
                    ?>
                    <input type="text" name="ctype1" style="width:50%" maxlength="2000" value="<?php if (isset($ctype3)) {echo $ctype3;} else { if ($_SESSION[$ssn.'tab'] != 'allimportant') {echo $_SESSION[$ssn.'tab'];} else {echo "";}} ?>"/>
                    <?php
                    } elseif (isset($ctype3)) {
                        echo "<div style='color:green;'>$ctype3</div>" ?? '';
                    }
                    ?>
                    <br/><br/>

                    <strong>POSSIBLE VALUES: </strong>
                    <br/>
                    <?php
                    if (((isset($enable_dev_plus_menu) && $enable_dev_plus_menu) && isset($possible_values3)) || (isset($_GET['create']) && $_GET['create'] == 'new')) {
                    ?>
                    <input type="text" name="possible_values1" style="width:50%" maxlength="2000" value="<?php if (isset($possible_values3)) {echo $possible_values3;} ?>"/>
                    <?php
                    } elseif (isset($possible_values3) && $possible_values3 != '') {
                        echo "<div style='color:green;'>$possible_values3</div>";
                    } else {
                        echo "<div style='color:orange;'>Not set</div>";
                    }
                    ?>
                    <br/><br/>

                    <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                    <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                    <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                    <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                    <input type="button" value="Cancel" onclick="location.href='config_user.php';">
                </form>
            </td>
            </tr>
        </table>
    
        <br/><br/>
    <?php
    }
    ?>

    <?php if (!isset($_GET['create']) && !isset($_GET['edt'])) {?>
    <script>
        function js_handleEnterKey(event) {
            if (event.key === 'Enter') {
                js_findText();
            }
        }
    </script>
    <div class="search-bar">
        <input type="text" id="searchText" placeholder="Enter text to find">
        <button onclick="js_findText()">Find</button>
        <button onclick="js_clearHighlights()">Clear</button>
        <button onclick="js_seekResult(-1)"><</button>
        <button onclick="js_seekResult(1)">></button>
    </div>
    <script>
        var inputElement = document.getElementById('searchText');
        inputElement.addEventListener('keydown', js_handleEnterKey);

        let currentIndex = -1;
        let highlights = [];

        function js_findText() {
            js_clearHighlights();// Clear any previous highlights

            const searchText = document.getElementById('searchText').value;// Get the search text
            if (!searchText) return;

            const textNodes = js_getTextNodes(document.body);// Find all text nodes in the body

            // Highlight matching text
            textNodes.forEach(node => {
                const regex = new RegExp(`(${searchText})`, 'gi');
                const newText = node.nodeValue.replace(regex, '<span class="highlight">$1</span>');
                const tempElement = document.createElement('div');
                tempElement.innerHTML = newText;

                while (tempElement.firstChild) {
                    node.parentNode.insertBefore(tempElement.firstChild, node);
                }
                node.parentNode.removeChild(node);
            });

            highlights = Array.from(document.querySelectorAll('.highlight'));// Collect all highlighted elements
            currentIndex = -1;

            if (highlights.length > 0) {
                js_seekResult(1); // Jump to the first found result
            }
        }
        function js_clearHighlights() {
            const highlightedElements = document.querySelectorAll('.highlight, .current');
            highlightedElements.forEach(span => {
                const parent = span.parentNode;
                parent.replaceChild(document.createTextNode(span.textContent), span);
                parent.normalize();
            });
            highlights = [];
            currentIndex = -1;
        }
        function js_seekResult(direction) {
            if (highlights.length === 0) return;

            // Remove the current highlight class from the previous element
            if (currentIndex >= 0) {
                highlights[currentIndex].classList.remove('current');
            }

            currentIndex += direction; // Update the current index

            // Ensure the index stays within bounds
            if (currentIndex >= highlights.length) {
                currentIndex = 0;
            } else if (currentIndex < 0) {
                currentIndex = highlights.length - 1;
            }

            const currentHighlight = highlights[currentIndex];// Add the current highlight class to the new element
            currentHighlight.classList.add('current');

            currentHighlight.scrollIntoView({ behavior: 'smooth', block: 'center' });// Scroll to the current highlight
        }
        function js_getTextNodes(node) {
            let textNodes = [];
            function js_recursiveSearch(node) {
                if (node.nodeType === 3) {
                    textNodes.push(node);
                } else if (node.nodeType === 1 && node.childNodes) {
                    node.childNodes.forEach(child => js_recursiveSearch(child));
                }
            }
            js_recursiveSearch(node);
            return textNodes;
        }
    </script>

    <div class="table-container">
    <table class=whiteHeader id='content' style='width:100%;border-collapse:collapse;'>
        <thead style='position: sticky;top: 0;z-index: 5;'>
            <tr class=<?php echo $color_scheme."HeaderCenter";?>>
                <td colspan=7>
                    <strong>Variable Controls:</strong>
                    <?php if (isset($enable_dev_plus_menu) && $enable_dev_plus_menu && $_SESSION[$ssn.'tab'] != 'allimportant') { ?>
                        [<a href='config_user.php?create=new'>Create new variable</a>]
                    <?php }?>
                    <?php if ($_SESSION[$ssn.'tab'] == 'dir') {
                        echo "<br/><em>Changing the directory location may cause document retrieval to fail. Avoid changing the directory location when you have many documents stored after installation. Use with caution.</em>";
                    }
                    ?>
                </td>
            </tr>
            <tr class=whiteHeaderCenterUnderline>
                <td style='width:5%;'></td>
                <td style='text-align:left;'>CNAME</td>
                <td style='text-align:left;'>CTYPE</td>
                <td style='text-align:left;'>CDESC</td>
                <td style='text-align:left;'>CVALUE</td>
                <td style='text-align:left;'>CVALUE (DEFAULT)</td>
                <td style='width:80px;'>Options</td>
            </tr>
        </thead>
        <tbody>
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select * from config_user where id<>0 ".$_SESSION[$ssn.'appendsql']." order by ctype,cname");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $trclassalternating = ($n % 2 == 0) ? "style='background-color: #f2f2f2;'" : "style='background-color: #ffffff;'";

                $id_fdb = $myrow_fdb["id"];
                $cname_fdb = $myrow_fdb["cname"];
                $cdesc_fdb = $myrow_fdb["cdesc"];
                $cvalue_fdb = $myrow_fdb["cvalue"];
                $ctype_fdb = $myrow_fdb["ctype"];
                $cvalue_default_fdb = $myrow_fdb["cvalue_default"];
                $possible_values_fdb = $myrow_fdb["possible_values"];

                $fontSimiliarColor = ($cvalue_fdb == $cvalue_default_fdb) ? "style='color:green;'" : "";

                echo "<tr class=$color_scheme"."Hover $trclassalternating>";
                    echo "<td style='vertical-align:top;'><span id=$id_fdb>$n</span></td>";
                    echo "<td style='width:250px;text-align:left;vertical-align:top;'>$cname_fdb</td>";
                    echo "<td style='text-align:left;vertical-align:top;'>$ctype_fdb</td>";
                    echo "<td style='text-align:left;vertical-align:top;color:darkgrey;'>$cdesc_fdb</td>";
                    echo "<td style='text-align:left;vertical-align:top;color:blue;'>";
                        echo "<div $fontSimiliarColor>".htmlspecialchars($cvalue_fdb)."</div>";
                        
                        if (file_exists(stream_resolve_include_path('../userfiles/dev.config.sys.php'))) {
                            echo "<span style='font-size:8pt;'><span style='color:grey'>Current loaded value:</span> <em>";
                                if (is_bool(${$cname_fdb})) {
                                    echo sfx_checkAndEcho(${$cname_fdb});
                                } else {
                                    echo htmlspecialchars(${$cname_fdb});
                                }
                            echo "</em></span>";
                        }
                    echo "</td>";
                    echo "<td style='text-align:left;vertical-align:top;color:green;'>
                            <div $fontSimiliarColor>".htmlspecialchars($cvalue_default_fdb)."</div>";
                            if (isset($possible_values_fdb) && $possible_values_fdb !='') {
                                echo "<span style='color:magenta;font-size:10px;font-style:italic;'>Possible Values: <span style='color:orange;font-style:normal;'>$possible_values_fdb</span></span>";
                            }
                    echo "</td>";
                    echo "<td style='width:80px;'>";
                        if (isset($enable_dev_plus_menu) && $enable_dev_plus_menu) {
                            echo "<a title='Delete this record' href='config_user.php?del=$id_fdb' onclick=\"return confirm('Are you sure ?');\"><i class=\"fas fa-trash\"></i></a> ";
                        }
                        echo "<a title='Update this record' href='config_user.php?edt=$id_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
        ?>
        </tbody>
    </table>
    </div>
    <?php }?>

    <hr>

    <?php include_once '../sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
