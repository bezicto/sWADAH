<?php
/*
Filename: moderatefbk.php
Usage: Manage feedback per item that has been submitted by register users
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle  = "Feedback List";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
        
    <hr>
        
    <div style='text-align:center'>
        <?php
                                                                                            
            $query_emb = "select * from eg_item_feedback where 39moderated_status = 'NO'";
            $result_emb = mysqli_query($GLOBALS["conn"], $query_emb);
            $row_emb = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
            $num_results_affected = $row_emb[0];

            echo "<table class=$color_scheme"."Header><tr><td>";
                echo "<strong>Feedback List</strong> : ";
                echo "$num_results_affected <em>record(s) found.</em>";
            echo "</td></tr></table>";
            
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'><td width=45></td><td width=60%>Feedback</td><td>Date posted</td></tr>";
                                                                                
                $n = 1;
                while ($myrow_emb = mysqli_fetch_array($result_emb)) {
                    $id = $myrow_emb["id"];
                    $item_id = $myrow_emb["eg_item_id"];
                        $title = sfx_sGetValue("38title", "eg_item", "id", $item_id);
                    $feedback = $myrow_emb["38feedback"];
                    $feedback_date = date("d M Y", $myrow_emb["38timestamp"]);
                    $feedback_by = $myrow_emb["eg_auth_username"];
                    
                    if ($title != '') {
                        echo "<tr class=$color_scheme"."Hover>";
                            echo "<td style='text-align:center;'>$n</td>";
                            echo "<td style='text-align:left;vertical-align:top;'>";
                                echo "<a href='details.php?det=$item_id'>$feedback</a> for item $title<br/>";
                                    echo "<strong>By</strong>: ".sfx_sGetValue("name", "eg_auth", "username", $feedback_by)."<br/>";
                            echo "</td>";
                            echo "<td style='vertical-align:top;'>";
                                echo $feedback_date;
                            echo "</td>";
                        echo "</tr>";
                        $n = $n +1 ;
                    }
                }
            echo "</table>";
        ?>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
