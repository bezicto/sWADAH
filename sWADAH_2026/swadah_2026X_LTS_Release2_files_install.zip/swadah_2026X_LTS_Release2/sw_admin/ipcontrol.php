<?php
/*
Filename: ipcontrol.php
Usage: Manage IPs that can access guest search and it details pages. Works when ip_restriction_enabled is enabled
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "IP Fence";
    session_start();define('includeExist', true);

    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
        
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enforce' && $proceedAfterToken) {
            if ($_REQUEST['ipaddress'] != '') {
                $ipaddress = mysqli_real_escape_string($GLOBALS["conn"], $_POST["ipaddress"]);
                
                $stmt_count = $new_conn->prepare("select count(id) as totalcount from eg_auth_ip where ipaddress=?");
                $stmt_count->bind_param("s", $ipaddress);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected);
                $stmt_count->fetch();$stmt_count->close();
                
                if ($num_results_affected == 0) {
                    $stmt_insert = $new_conn->prepare("insert into eg_auth_ip values(DEFAULT,?)");
                    $stmt_insert->bind_param("s", $ipaddress);
                    $stmt_insert->execute();$stmt_insert->close();
                    sfx_echoPopupAlert("Record has been inputted into the database.");
                } elseif ($num_results_affected == 1) {
                    sfx_echoPopupAlert("Duplicate IP detected.");
                }
            } else {
                sfx_echoPopupAlert("IP address cannot be empty.");
            }
        }
        
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == "Update" && $proceedAfterToken) {
            if ($_REQUEST['ipaddress'] != '') {
                $ipaddress = mysqli_real_escape_string($GLOBALS["conn"], $_POST["ipaddress"]);
                $stmt_update = $new_conn->prepare("update eg_auth_ip set ipaddress=? where id=?");
                $stmt_update->bind_param("si", $ipaddress, $_POST['aid']);
                $stmt_update->execute();$stmt_update->close();
                sfx_echoPopupAlert("White listed IPs updated.");
            } else {
                sfx_echoPopupAlert("IP address cannot be empty.");
            }
        }

        if (isset($_GET["del"]) && $_GET["del"] <> null && is_numeric($_GET["del"])) {
            $get_id_del = $_GET["del"];
            $stmt_del = $new_conn->prepare("delete from eg_auth_ip where id=?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();$stmt_del->close();
        }
        
        $ipaddressA = "";
        if (isset($_GET['aid']) && is_numeric($_GET['aid'])) {
            $stmt3 = $new_conn->prepare("select ipaddress from eg_auth_ip where id = ?");
            $stmt3->bind_param("i", $_GET['aid']);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($ipaddressA);
            $stmt3->fetch();$stmt3->close();
        }
        
    ?>
    
    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>>
            <td>
                <strong>IP Fence</strong><br/>
                Set up a fence so that only specific IPs or ranges can access the site without logging in.
                <strong>ip_fence_enabled</strong> in <?php echo $system_title;?> Configurator must be set to <strong>true</strong> before this can be enforced.<br/><br/>
                <div style='color:blue;'><strong>E.g. :</strong><br/>
                <em>192.168.1.1 (for a specific IP) OR<br/>143.123.78 (for all in range 143.123.78.x) OR<br/> 12.128 (for all in range 12.128.x.x)</em></div>
            </td>
        </tr>
        
        <tr class=greyHeaderCenter><td style='width:370;'><br/>
        <form action="ipcontrol.php" method="post" enctype="multipart/form-data">
            <table style='margin-left:auto;margin-right:auto;'>
                <tr>
                <td><strong>IP Address: </strong></td>
                <td><input type="text" name="ipaddress" size="35" maxlength="70" value="<?php echo $ipaddressA;?>"/></td>
                </tr>

                <tr><td colspan='2' style='text-align:center;'><br/>
                    <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                    <?php
                        if (isset($_GET['aid']) && is_numeric($_GET['aid'])) {
                            echo "<input type='hidden' name='aid' value='".$_GET['aid']."' />";
                            echo "<input type='submit' name='submitted' value='Update' /> ";
                            echo "<input type='button' name='reset' value='Cancel' onclick=\"window.location='ipcontrol.php';\"/>";
                        } else {
                            echo "<input type='submit' name=\"submitted\" value=\"Enforce\" /> ";
                            echo "<input type='button' name=\"reset\" value=\"Reset\" onclick=\"window.location='ipcontrol.php';\"/>";
                        }
                    ?>
                    
                </td></tr>
            </table>
        </form>
        </td></tr>
    </table>
        
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=3><strong>IP Listing Allow List (allowed for access to guest search and details pages):</strong></td></tr>
        <tr class=whiteHeaderCenterUnderline>
            <td></td>
            <td style='text-align:left;'>IP Address</td>
            <td>Options</td>
        </tr>
        <?php
            $query_fdb = "select * from eg_auth_ip";
            $result_fdb = mysqli_query($GLOBALS["conn"], $query_fdb);
            $n = 1;
            while ($myrow_fdb = mysqli_fetch_array($result_fdb)) {
                $id_fdb = $myrow_fdb["id"];
                $ipaddress_fdb = $myrow_fdb["ipaddress"];
                echo "<tr class=$color_scheme"."Hover>";
                echo "<td width=25>$n</td>";
                echo "<td style='text-align:left;'>$ipaddress_fdb</td>";
                echo "<td width=150>";
                    echo "<a title='Edit this eligibility' href='ipcontrol.php?aid=$id_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "<a title='Delete this record' href='ipcontrol.php?del=$id_fdb' onclick=\"return confirm('Are you sure ?');\"><i class=\"fas fa-trash\"></i></a> ";
                echo "</td></tr>";
                $n = $n + 1;
            }
        ?>
    </table>
    
    <br/>

    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
