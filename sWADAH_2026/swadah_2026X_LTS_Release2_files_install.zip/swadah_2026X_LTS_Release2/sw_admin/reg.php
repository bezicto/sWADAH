<?php
/*
Filename: reg.php
Usage: Insert new item in the database
Version: 20250101.0801
Last change: -
    20250417.1006 - add normalize button. normalize function for text of wadahComposer/fulltext1
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Add new item";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    $is_upd = false; if ((isset($_GET["upd"]) && is_numeric($_GET["upd"])) || (isset($_POST['submit_button']) && $_POST['submit_button'] == 'Update')) {$is_upd = true;}

    include_once '../sw_inc/token_validate.php';

    //convert to bytes for things involving file size; original is in MB
    $system_allow_document_maxsize = $system_allow_document_maxsize*1000000;
    $system_allow_pdocument_maxsize = $system_allow_pdocument_maxsize*1000000;
    $system_allow_txt_maxsize = $system_allow_txt_maxsize*1000000;
    $system_allow_imageatt_maxsize = $system_allow_imageatt_maxsize*1000000;
    $system_allow_isofile_maxsize = $system_allow_isofile_maxsize*1000000;
    $max_allow_parser_to_work = $max_allow_parser_to_work*1000000;
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
    <script type="text/javascript">
        <?php
            sfx_generateFileBoxAllowedExtensionRule("pfile1", $system_allow_pdocument_extension);
            sfx_generateFileBoxAllowedExtensionRule("file1", $system_allow_document_extension);
            sfx_generateFileBoxAllowedExtensionRule("txtindex_file1", $system_allow_txt_extension);
            sfx_generateFileBoxAllowedExtensionRule("imageatt1", $system_allow_imageatt_extension);
            sfx_generateFileBoxAllowedExtensionRule("isofile1", $system_allow_isofile_extension);
        ?>
    </script>
</head>

<body class='<?php echo $color_scheme;?>'>

    <?php if (!$is_upd) {include_once '../sw_inc/loggedinfo.php';} ?>
            
    <hr>
    
    <?php
            
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE' && $proceedAfterToken) {
            //notice handler for posted item that do not assigned with a value
            $val_folderid1=(int)sfx_stringRemoveScriptTag($_POST["folderid1"] ?? '0');
            $val_typestatement1=sfx_stringRemoveScriptTag($_POST["typestatement1"] ?? '');
            $val_accessnum1=sfx_stringRemoveScriptTag($_POST["accessnum1"] ?? '');
            $val_status1=sfx_stringRemoveScriptTag($_POST["status1"] ?? '');
            $val_isbn1=sfx_stringRemoveScriptTag($_POST["isbn1"] ?? '');
            $val_isbn1_c=sfx_stringRemoveScriptTag($_POST["isbn1_c"] ?? '0.00');
            $val_issn1=sfx_stringRemoveScriptTag($_POST["issn1"] ?? '');
            $val_langcode1=sfx_stringRemoveScriptTag($_POST["langcode1"] ?? '');
            $val_notes1=sfx_stringRemoveScriptTag($_POST["notes1"] ?? '');
            $val_callnum1=sfx_stringRemoveScriptTag($_POST["callnum1"] ?? '');
            $val_edition1=sfx_stringRemoveScriptTag($_POST["edition1"] ?? '');
            $val_publication1=sfx_stringRemoveScriptTag($_POST["publication1"] ?? '');
            $val_series1=sfx_stringRemoveScriptTag($_POST["series1"] ?? '');
            $val_location1=sfx_stringRemoveScriptTag($_POST["location1"] ?? '');
            $val_link1=sfx_stringRemoveScriptTag($_POST["link1"] ?? '');
            $val_subjectheading1=sfx_stringRemoveScriptTag($_POST["subjectheading1"] ?? '');
            $val_publication1_b=sfx_stringRemoveScriptTag($_POST["publication1_b"] ?? '');
            $val_publication1_c=sfx_stringRemoveScriptTag($_POST["publication1_c"] ?? '');
            $val_dissertation_note1=sfx_stringRemoveScriptTag($_POST["dissertation_note1"] ?? '');
            $val_dissertation_note1_b=sfx_stringRemoveScriptTag($_POST["dissertation_note1_b"] ?? '');
            $val_dissertation_note1_c=sfx_stringRemoveScriptTag($_POST["dissertation_note1_c"] ?? '');
            $val_dissertation_note1_d=sfx_stringRemoveScriptTag($_POST["dissertation_note1_d"] ?? '');
            $val_callnum1_b=sfx_stringRemoveScriptTag($_POST["callnum1_b"] ?? '');
            $val_authorname1=sfx_stringRemoveScriptTag($_POST["authorname1"] ?? '');
            $val_authorname1_c=sfx_stringRemoveScriptTag($_POST["authorname1_c"] ?? '');
            $val_authorname1_d=sfx_stringRemoveScriptTag($_POST["authorname1_d"] ?? '');
            $val_authorname1_e=sfx_stringRemoveScriptTag($_POST["authorname1_e"] ?? '');
            $val_authorname1_q=sfx_stringRemoveScriptTag($_POST["authorname1_q"] ?? '');
            $val_titlestatement1=sfx_stringRemoveScriptTag($_POST["titlestatement1"] ?? '');
            $val_titlestatement1_b=sfx_stringRemoveScriptTag($_POST["titlestatement1_b"] ?? '');
            $val_titlestatement1_c=sfx_stringRemoveScriptTag($_POST["titlestatement1_c"] ?? '');
            $val_vtitle1_a=sfx_stringRemoveScriptTag($_POST["vtitle1_a"] ?? '');
            $val_vtitle1_b=sfx_stringRemoveScriptTag($_POST["vtitle1_b"] ?? '');
            $val_vtitle1_g=sfx_stringRemoveScriptTag($_POST["vtitle1_g"] ?? '');
            $val_physicaldesc1=sfx_stringRemoveScriptTag($_POST["physicaldesc1"] ?? '');
            $val_physicaldesc1_b=sfx_stringRemoveScriptTag($_POST["physicaldesc1_b"] ?? '');
            $val_physicaldesc1_c=sfx_stringRemoveScriptTag($_POST["physicaldesc1_c"] ?? '');
            $val_physicaldesc1_e=sfx_stringRemoveScriptTag($_POST["physicaldesc1_e"] ?? '');
            $val_contenttype1_a=sfx_stringRemoveScriptTag($_POST["contenttype1_a"] ?? '');
            $val_contenttype1_2=sfx_stringRemoveScriptTag($_POST["contenttype1_2"] ?? '');
            $val_mediatype1_a=sfx_stringRemoveScriptTag($_POST["mediatype1_a"] ?? '');
            $val_mediatype1_2=sfx_stringRemoveScriptTag($_POST["mediatype1_2"] ?? '');
            $val_carriertype1_a=sfx_stringRemoveScriptTag($_POST["carriertype1_a"] ?? '');
            $val_carriertype1_2=sfx_stringRemoveScriptTag($_POST["carriertype1_2"] ?? '');
            $val_series1_v=sfx_stringRemoveScriptTag($_POST["series1_v"] ?? '');
            $val_subject_entry1a=sfx_stringRemoveScriptTag($_POST["subject_entry1a"] ?? '');
            $val_subject_entry2a=sfx_stringRemoveScriptTag($_POST["subject_entry2a"] ?? '');
            $val_subject_entry3a=sfx_stringRemoveScriptTag($_POST["subject_entry3a"] ?? '');
            $val_sumber1=sfx_stringRemoveScriptTag($_POST["sumber1"] ?? '');
            $val_sumber1_b=sfx_stringRemoveScriptTag($_POST["sumber1_b"] ?? '');
            $val_sumber1_e=sfx_stringRemoveScriptTag($_POST["sumber1_e"] ?? '');
            $val_location1_b=sfx_stringRemoveScriptTag($_POST["location1_b"] ?? '');
            $val_location1_c=sfx_stringRemoveScriptTag($_POST["location1_c"] ?? '');
            $val_summary1_a=sfx_stringRemoveScriptTag($_POST["summary1_a"] ?? '');
            $val_geographic_coverage_note1_a=sfx_stringRemoveScriptTag($_POST["geographic_coverage_note1_a"] ?? '');
            $val_original_version_note1_t=sfx_stringRemoveScriptTag($_POST["original_version_note1_t"] ?? '');
            $val_terms_governing_use1_a=sfx_stringRemoveScriptTag($_POST["terms_governing_use1_a"] ?? '');
            $val_other_relationship_entry1_n=sfx_stringRemoveScriptTag($_POST["other_relationship_entry1_n"] ?? '');
            $val_se_pname1_a=sfx_stringRemoveScriptTag($_POST["se_pname1_a"] ?? '');
            $val_se_pname1_x=sfx_stringRemoveScriptTag($_POST["se_pname1_x"] ?? '');
            $val_se_pname1_y=sfx_stringRemoveScriptTag($_POST["se_pname1_y"] ?? '');
            $val_pname1=sfx_stringRemoveScriptTag($_POST["pname1"] ?? '');$val_pname1_s=sfx_stringRemoveScriptTag($_POST["pname1_s"] ?? '');
            $val_pname2=sfx_stringRemoveScriptTag($_POST["pname2"] ?? '');$val_pname2_s=sfx_stringRemoveScriptTag($_POST["pname2_s"] ?? '');
            $val_pname3=sfx_stringRemoveScriptTag($_POST["pname3"] ?? '');$val_pname3_s=sfx_stringRemoveScriptTag($_POST["pname3_s"] ?? '');
            $val_pname4=sfx_stringRemoveScriptTag($_POST["pname4"] ?? '');$val_pname4_s=sfx_stringRemoveScriptTag($_POST["pname4_s"] ?? '');
            $val_pname5=sfx_stringRemoveScriptTag($_POST["pname5"] ?? '');$val_pname5_s=sfx_stringRemoveScriptTag($_POST["pname5_s"] ?? '');
            $val_pname6=sfx_stringRemoveScriptTag($_POST["pname6"] ?? '');$val_pname6_s=sfx_stringRemoveScriptTag($_POST["pname6_s"] ?? '');
            $val_pname7=sfx_stringRemoveScriptTag($_POST["pname7"] ?? '');$val_pname7_s=sfx_stringRemoveScriptTag($_POST["pname7_s"] ?? '');
            $val_pname8=sfx_stringRemoveScriptTag($_POST["pname8"] ?? '');$val_pname8_s=sfx_stringRemoveScriptTag($_POST["pname8_s"] ?? '');
            $val_pname9=sfx_stringRemoveScriptTag($_POST["pname9"] ?? '');$val_pname9_s=sfx_stringRemoveScriptTag($_POST["pname9_s"] ?? '');
            $val_pname10=sfx_stringRemoveScriptTag($_POST["pname10"] ?? '');$val_pname10_s=sfx_stringRemoveScriptTag($_POST["pname10_s"] ?? '');
            $val_i_020=sfx_stringRemoveScriptTag($_POST["i_020"] ?? '');
            $val_i_022=sfx_stringRemoveScriptTag($_POST["i_022"] ?? '');
            $val_i_041=sfx_stringRemoveScriptTag($_POST["i_041"] ?? '');
            $val_i_090=sfx_stringRemoveScriptTag($_POST["i_090"] ?? '');
            $val_i_100=sfx_stringRemoveScriptTag($_POST["i_100"] ?? '');
            $val_i_245=sfx_stringRemoveScriptTag($_POST["i_245"] ?? '');
            $val_i_246=sfx_stringRemoveScriptTag($_POST["i_246"] ?? '');
            $val_i_250=sfx_stringRemoveScriptTag($_POST["i_250"] ?? '');
            $val_i_264=sfx_stringRemoveScriptTag($_POST["i_264"] ?? '');
            $val_i_300=sfx_stringRemoveScriptTag($_POST["i_300"] ?? '');
            $val_i_490=sfx_stringRemoveScriptTag($_POST["i_490"] ?? '');
            $val_i_500=sfx_stringRemoveScriptTag($_POST["i_500"] ?? '');
            $val_i_502=sfx_stringRemoveScriptTag($_POST["i_502"] ?? '');
            $val_i_520=sfx_stringRemoveScriptTag($_POST["i_520"] ?? '');
            $val_i_600=sfx_stringRemoveScriptTag($_POST["i_600"] ?? '');
            $val_i_650_1=sfx_stringRemoveScriptTag($_POST["i_650_1"] ?? '');
            $val_i_650_2=sfx_stringRemoveScriptTag($_POST["i_650_2"] ?? '');
            $val_i_650_3=sfx_stringRemoveScriptTag($_POST["i_650_3"] ?? '');
            $val_i_700=sfx_stringRemoveScriptTag($_POST["i_700"] ?? '');
            $val_i_700_2=sfx_stringRemoveScriptTag($_POST["i_700_2"] ?? '');
            $val_i_700_3=sfx_stringRemoveScriptTag($_POST["i_700_3"] ?? '');
            $val_i_700_4=sfx_stringRemoveScriptTag($_POST["i_700_4"] ?? '');
            $val_i_700_5=sfx_stringRemoveScriptTag($_POST["i_700_5"] ?? '');
            $val_i_700_6=sfx_stringRemoveScriptTag($_POST["i_700_6"] ?? '');
            $val_i_700_7=sfx_stringRemoveScriptTag($_POST["i_700_7"] ?? '');
            $val_i_700_8=sfx_stringRemoveScriptTag($_POST["i_700_8"] ?? '');
            $val_i_700_9=sfx_stringRemoveScriptTag($_POST["i_700_9"] ?? '');
            $val_i_700_10=sfx_stringRemoveScriptTag($_POST["i_700_10"] ?? '');
            $val_i_710=sfx_stringRemoveScriptTag($_POST["i_710"] ?? '');
            $val_i_852=sfx_stringRemoveScriptTag($_POST["i_852"] ?? '');
            $val_i_856=sfx_stringRemoveScriptTag($_POST["i_856"] ?? '');
            $val_i_522=sfx_stringRemoveScriptTag($_POST["i_522"] ?? '');
            $val_i_534=sfx_stringRemoveScriptTag($_POST["i_534"] ?? '');
            $val_i_540=sfx_stringRemoveScriptTag($_POST["i_540"] ?? '');
            $val_i_787=sfx_stringRemoveScriptTag($_POST["i_787"] ?? '');
            
            $val_isabstract1 = (isset($_POST["isabstract1"]) && $_POST["isabstract1"] == '1') ? 1 : 0;
            $val_fulltext1 = sfx_stringRemoveScriptTag($_POST['fulltext1'] ?? '');
            $val_reference1 = sfx_stringRemoveScriptTag($_POST['reference1'] ?? '');

            $search_cloud = sfx_stringRemoveScriptTag(mysqli_real_escape_string($GLOBALS["conn"], $val_typestatement1." . ".$val_titlestatement1_b." . ".$val_titlestatement1_c." .  ".$val_vtitle1_a." .  ".$val_vtitle1_b." .  ".$val_vtitle1_g." .  ".$val_authorname1." . ".$val_pname1." . ".$val_pname2." . ".$val_pname3." . ".$val_pname4." . ".$val_pname5." . ".$val_pname6." . ".$val_pname7." . ".$val_pname8." . ".$val_pname9." . ".$val_pname10." . ".$val_notes1));
                
            echo "<table class=whiteHeader>";
            echo "<tr><td>";

                if (!empty($_POST["titlestatement1"]) && !empty($_POST["typestatement1"])) {
                    // if insert new
                    if ($_POST['submit_button'] == 'Insert') {
                        //new insert into eg_item 2025-04-17
                        $insertQuery = "insert into eg_item values (DEFAULT,
                            $val_folderid1,'$val_accessnum1','$val_typestatement1','$val_status1',
                            '$val_isbn1','$val_issn1','$val_langcode1','$val_callnum1','$val_authorname1',
                            '$val_titlestatement1','$val_edition1','$val_publication1','$val_physicaldesc1','$val_series1',
                            '$val_notes1','$val_dissertation_note1','$val_sumber1','$val_location1','$val_link1',
                            '".date("Y-m-d")."','".$_SESSION[$ssn.'username']."',
                            'FALSE','','',
                            '','0',
                            ".sfx_stringRemoveScriptTag($_POST["instimestamp1"]).",
                            0,0,
                            '$val_fulltext1','$val_reference1','',
                            '$val_subjectheading1',
                            $val_isabstract1,
                            '$search_cloud','1',0,0,DEFAULT
                            )";

                        $result_insertQuery = mysqli_query($GLOBALS["conn"], $insertQuery);
                        $error_Query = false;
                        if (!$result_insertQuery) {
                            $error_Query = true;
                            $error_Log = mysqli_error($GLOBALS["conn"]);
                        }

                        //old insert into eg_item
                        /*mysqli_query(
                            $GLOBALS["conn"],
                            "insert into eg_item values (DEFAULT,
                            $val_folderid1,'$val_accessnum1','$val_typestatement1','$val_status1',
                            '$val_isbn1','$val_issn1','$val_langcode1','$val_callnum1','$val_authorname1',
                            '$val_titlestatement1','$val_edition1','$val_publication1','$val_physicaldesc1','$val_series1',
                            '$val_notes1','$val_dissertation_note1','$val_sumber1','$val_location1','$val_link1',
                            '".date("Y-m-d")."','".$_SESSION[$ssn.'username']."',
                            'FALSE','','',
                            '','0',
                            ".sfx_stringRemoveScriptTag($_POST["instimestamp1"]).",
                            0,0,
                            '$val_fulltext1','$val_reference1','',
                            '$val_subjectheading1',
                            $val_isabstract1,
                            '$search_cloud','1',0,0,DEFAULT
                            )"
                        );*/

                        //prompt user to get the id for the item that has been inputted
                        if (!$error_Query) {
                            $queryN = "select id from eg_item where 41instimestamp='".sfx_stringRemoveScriptTag($_POST["instimestamp1"])."' and 39inputby='".$_SESSION[$ssn.'username']."'";
                            $resultN = mysqli_query($GLOBALS["conn"], $queryN);
                            $myrowN = mysqli_fetch_array($resultN);
                            $id1 = $myrowN["id"];
                            if ($val_status1 == 'EMBARGO') {
                                $enddate = strtotime($_POST['enddate']);
                                mysqli_query($GLOBALS["conn"], "update eg_item set 51_embargo_timestamp='".$enddate."' where id=$id1");
                            }
                            echo "<br/><i class=\"fas fa-check-square fa-2xl\"></i><br/><br/>All provided data has been inputted into the database. The item ID will be displayed onto your screen, then press OK to continue.";
                        } else {
                            echo "<br/><i class=\"fas fa-times-circle\"></i><br/><br/>Error insert into database. Please contact the system administrator: ".$error_Log;
                        }
                    } elseif ($_POST['submit_button'] == 'Update') {
                        $id1=$_POST["id1"];
                        $inputdate1=$_POST["inputdate1"];
                        $status1_ori=$_POST["status1_ori"];
                        //updating main table new 2020-04-17
                        $updateQuery = "update eg_item set 38folderid='$val_folderid1',
                            38title='$val_titlestatement1',38langcode='$val_langcode1',38typeid='$val_typestatement1',
                            38location='$val_location1',
                            38link='$val_link1',
                            38status='$val_status1',
                            38author='$val_authorname1',
                            38source='$val_sumber1',
                            38localcallnum='$val_callnum1',
                            38isbn='$val_isbn1',38issn='$val_issn1',
                            38edition='$val_edition1',38publication='$val_publication1',38physicaldesc='$val_physicaldesc1',38series='$val_series1',
                            38notes='$val_notes1',
                            40lastupdateby='".$_SESSION[$ssn.'username']."', 40lastupdatetimestamp='".time()."',
                            41fulltexta='$val_fulltext1',41isabstract='$val_isabstract1',41reference='$val_reference1',
                            41subjectheading='$val_subjectheading1',
                            50search_cloud='$search_cloud'
                            where id=$id1";

                        $result_updateQuery = mysqli_query($GLOBALS["conn"], $updateQuery);
                        $error_Query = false;
                        if (!$result_updateQuery) {
                            $error_Query = true;
                        }

                        //updating main table old version
                        /*
                        mysqli_query(
                            $GLOBALS["conn"],
                            "update eg_item set 38folderid='$val_folderid1',
                            38title='$val_titlestatement1',38langcode='$val_langcode1',38typeid='$val_typestatement1',
                            38location='$val_location1',
                            38link='$val_link1',
                            38status='$val_status1',
                            38author='$val_authorname1',
                            38source='$val_sumber1',
                            38localcallnum='$val_callnum1',
                            38isbn='$val_isbn1',38issn='$val_issn1',
                            38edition='$val_edition1',38publication='$val_publication1',38physicaldesc='$val_physicaldesc1',38series='$val_series1',
                            38notes='$val_notes1',
                            40lastupdateby='".$_SESSION[$ssn.'username']."', 40lastupdatetimestamp='".time()."',
                            41fulltexta='$val_fulltext1',41isabstract='$val_isabstract1',41reference='$val_reference1',
                            41subjectheading='$val_subjectheading1',
                            50search_cloud='$search_cloud'
                             where id=$id1"
                        );
                        */
                        if (!$error_Query) {
                            if ($val_status1 == 'EMBARGO') {
                                $enddate = strtotime($_POST['enddate']);
                                mysqli_query($GLOBALS["conn"], "update eg_item set 51_embargo_timestamp='".$enddate."' where id=$id1");
                            }
                            echo "<br/><i class=\"fas fa-check-square fa-2xl\"></i><br/><br/>All provided data has been updated into the database.";
                        } else {
                            echo "<br/><i class=\"fas fa-times-circle\"></i><br/><br/>Error update into database. Please contact the system administrator: ".$error_Log;
                        }
                    }//else if update existing

                    //only continue of insert/update query is successful or to proceed only if $id1 is exist
                    if (!$error_Query) {
                        //inserting or updating eg_item2 depending on existence
                        $query_exist_id = "select * from eg_item2 where eg_item_id=$id1";
                        $result_exist_id = mysqli_query($GLOBALS["conn"], $query_exist_id);
                        
                        //if exist then updating only
                        if (mysqli_num_rows($result_exist_id) >= 1) {
                            
                            // updating secondary table ----- primary field
                            mysqli_query(
                                $GLOBALS["conn"],
                                "update eg_item2 set
                                38_terms_of_availability='$val_isbn1_c',
                                38pname1='$val_pname1',38pname1_s='$val_pname1_s',
                                38pname2='$val_pname2',38pname2_s='$val_pname2_s',
                                38pname3='$val_pname3',38pname3_s='$val_pname3_s',
                                38pname4='$val_pname4',38pname4_s='$val_pname4_s',
                                38pname5='$val_pname5',38pname5_s='$val_pname5_s',
                                38pname6='$val_pname6',38pname6_s='$val_pname6_s',
                                38pname7='$val_pname7',38pname7_s='$val_pname7_s',
                                38pname8='$val_pname8',38pname8_s='$val_pname8_s',
                                38pname9='$val_pname9',38pname9_s='$val_pname9_s',
                                38pname10='$val_pname10',38pname10_s='$val_pname10_s',
                                38dissertation_note_b='$val_dissertation_note1_b',
                                38publication_b='$val_publication1_b',38publication_c='$val_publication1_c',
                                38vtitle_a='$val_vtitle1_a',38vtitle_b='$val_vtitle1_b',38vtitle_g='$val_vtitle1_g',
                                38summary_a='$val_summary1_a',
                                38se_pname_a='$val_se_pname1_a',38se_pname_x='$val_se_pname1_x',38se_pname_y='$val_se_pname1_y',
                                38geographic_coverage_note_a='$val_geographic_coverage_note1_a',38original_version_note_t='$val_original_version_note1_t',38geographic_coverage_note_a='$val_terms_governing_use1_a',38terms_governing_use_a='$val_other_relationship_entry1_n'
                                where eg_item_id='$id1'"
                                );

                            // updating secondary table ----- secondary field only when marc record input is selected
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                mysqli_query(
                                    $GLOBALS["conn"],
                                    "update eg_item2 set 38localcallnum_b='$val_callnum1_b',
                                    38author_c='$val_authorname1_c',38author_d='$val_authorname1_d',38author_e='$val_authorname1_e',38author_q='$val_authorname1_q',
                                    38title_b='$val_titlestatement1_b',38title_c='$val_titlestatement1_c',
                                    38publication_b='$val_publication1_b',38publication_c='$val_publication1_c',
                                    38physicaldesc_b='$val_physicaldesc1_b',38physicaldesc_c='$val_physicaldesc1_c',38physicaldesc_e='$val_physicaldesc1_e',
                                    38series_v='$val_series1_v',
                                    38dissertation_note_c='$val_dissertation_note1_c',38dissertation_note_d='$val_dissertation_note1_d',
                                    38subject_entry1='$val_subject_entry1a',38subject_entry2='$val_subject_entry2a',38subject_entry3='$val_subject_entry3a',
                                    38source_b='$val_sumber1_b',38source_e='$val_sumber1_e',
                                    38location_b='$val_location1_b',38location_c='$val_location1_c'
                                    where eg_item_id='$id1'"
                                    );
                                mysqli_query($GLOBALS["conn"], "update eg_item set 38dissertation_note='$val_dissertation_note1' where id=$id1");
                            }
                        } else {
                            //else will insert new

                            //48 fields on eg_item2
                            mysqli_query(
                                $GLOBALS["conn"],
                                "insert into eg_item2 values(DEFAULT,
                                $id1,'$val_isbn1_c',
                                '$val_callnum1_b',
                                '$val_authorname1_c','$val_authorname1_d','$val_authorname1_e','$val_authorname1_q',
                                '$val_titlestatement1_b','$val_titlestatement1_c',
                                    '$val_vtitle1_a','$val_vtitle1_b','$val_vtitle1_g',
                                '$val_publication1_b','$val_publication1_c',
                                '$val_physicaldesc1_b','$val_physicaldesc1_c','$val_physicaldesc1_e',
                                '$val_series1_v',
                                '$val_dissertation_note1_b','$val_dissertation_note1_c','$val_dissertation_note1_d',
                                    '$val_summary1_a','$val_geographic_coverage_note1_a','$val_original_version_note1_t','$val_terms_governing_use1_a',
                                    '$val_se_pname1_a','$val_se_pname1_x','$val_se_pname1_y',
                                '$val_subject_entry1a','$val_subject_entry2a','$val_subject_entry3a',
                                '$val_pname1','$val_pname1_s',
                                '$val_pname2','$val_pname2_s',
                                '$val_pname3','$val_pname3_s',
                                '$val_pname4','$val_pname4_s',
                                '$val_pname5','$val_pname5_s',
                                '$val_pname6','$val_pname6_s',
                                '$val_pname7','$val_pname7_s',
                                '$val_pname8','$val_pname8_s',
                                '$val_pname9','$val_pname9_s',
                                '$val_pname10','$val_pname10_s',
                                '$val_sumber1_b','$val_sumber1_e','$val_other_relationship_entry1_n','$val_location1_b','$val_location1_c'
                                )"
                            );
                        }

                        //inserting or updating eg_item2_indicator depending on existance
                        $query_exist_id = "select * from eg_item2_indicator where eg_item_id=$id1";
                        $result_exist_id = mysqli_query($GLOBALS["conn"], $query_exist_id);
                        if (mysqli_num_rows($result_exist_id) >= 1 && $_SESSION[$ssn.'viewmode'] == 'marc') {
                            mysqli_query(
                                $GLOBALS["conn"],
                                "update eg_item2_indicator set i_020='$val_i_020',i_022='$val_i_022',i_041='$val_i_041',i_090='$val_i_090',
                                i_100='$val_i_100',
                                i_245='$val_i_245',i_246='$val_i_246',i_250='$val_i_250',i_264='$val_i_264',
                                i_300='$val_i_300',
                                i_490='$val_i_490',
                                i_500='$val_i_500',i_502='$val_i_502',i_520='$val_i_520',
                                i_600='$val_i_600',i_650_1='$val_i_650_1',i_650_2='$val_i_650_2',i_650_3='$val_i_650_3',
                                i_700='$val_i_700',i_700_2='$val_i_700_2',i_700_3='$val_i_700_3',i_700_4='$val_i_700_4',i_700_5='$val_i_700_5',i_700_6='$val_i_700_6',i_700_7='$val_i_700_7',i_700_8='$val_i_700_8',i_700_9='$val_i_700_9',i_700_10='$val_i_700_10',i_710='$val_i_710',
                                i_852='$val_i_852',i_856='$val_i_856',
                                i_522='$val_i_522',i_534='$val_i_534',i_540='$val_i_540',i_787='$val_i_787'
                                where eg_item_id='$id1'"
                            );
                        } elseif (mysqli_num_rows($result_exist_id) == 0 && $_SESSION[$ssn.'viewmode'] == 'marc') {
                            mysqli_query(
                                $GLOBALS["conn"],
                                "insert into eg_item2_indicator values(DEFAULT,
                                $id1,
                                '$val_i_020','$val_i_022','$val_i_041','$val_i_090',
                                '$val_i_100',
                                '$val_i_245','$val_i_246','$val_i_250','$val_i_264',
                                '$val_i_300',
                                '$val_i_490',
                                '$val_i_500','$val_i_502','$val_i_520','$val_i_522','$val_i_534','$val_i_540',
                                '$val_i_600','$val_i_650_1','$val_i_650_2','$val_i_650_3',
                                '$val_i_700','$val_i_700_2','$val_i_700_3','$val_i_700_4','$val_i_700_5','$val_i_700_6','$val_i_700_7','$val_i_700_8','$val_i_700_9','$val_i_700_10','$val_i_710','$val_i_787',
                                '$val_i_852','$val_i_856'
                                )"
                            );
                        }
                        
                        //start uploading things regardless insert new or update the existing one
                        $idUpload = $id1; //reassign and pass it to upload.php
                        $timestampUpload = sfx_stringRemoveScriptTag($_POST["instimestamp1"]); //reassign and pass it to upload.php
                        if (isset($inputdate1)) {$dir_year = substr($inputdate1, 0, 4);} else {$dir_year = date("Y");}//pass it to upload.php
                        
                        //full text upload to server
                        if (isset($_FILES['file1']['name']) && $_FILES['file1']['name'] != null) {
                            echo "<br/><br/>File upload status: ";
                            
                            $affected_directory = "../$system_docs_directory/$dir_year";
                            $affected_filefield = "file1";
                            $targetted_filemaxsize = $GLOBALS["system_allow_document_maxsize"];
                            $targetted_filetype = $GLOBALS["system_allow_document_extension"];
                            $successful_upload_mesage = "File attachment uploaded successfully !";
                            $incorrect_filetype_mesage = "Upload aborted ! Incorrect file type. Please update this record if you need to reupload the file using the record ID.";
                            $incorrect_filesize_mesage = "Upload aborted ! Attachment file size > than expected. Please update this record if you need to reupload the file using the record ID.";
                            $allow_parser_to_parse_internally = true;
                            $targetted_field_to_update = null;
                            $parse_txt_file = false;
                            $upload_type = "text";

                            include '../sw_inc/upl/upload.php';

                            //run pdf indexer only with pdf files
                            if ($_FILES['file1']['size'] <= $max_allow_parser_to_work && $affected_fileextension == 'pdf') {
                                include_once '../sw_inc/upl/parser.php';
                            }
                        }

                        //guest file upload to server
                        if (isset($_FILES['pfile1']['name']) && $_FILES['pfile1']['name'] != null) {
                            echo "<br/><br/>Guest file upload status: ";

                            $affected_directory = "../$system_pdocs_directory/$dir_year";
                            $affected_filefield = "pfile1";
                            $targetted_filemaxsize = $GLOBALS["system_allow_pdocument_maxsize"];
                            $targetted_filetype = $GLOBALS["system_allow_pdocument_extension"];
                            $successful_upload_mesage = "Guest file attachment uploaded successfully !";
                            $incorrect_filetype_mesage = "Upload aborted ! Incorrect file type. Please update this record if you need to reupload the file using the record ID.";
                            $incorrect_filesize_mesage = "Upload aborted ! Attachment file size > than expected. Please update this record if you need to reupload the file using the record ID.";
                            $allow_parser_to_parse_internally = false;
                            $targetted_field_to_update = null;
                            $parse_txt_file = false;
                            $upload_type = "text";

                            include '../sw_inc/upl/upload.php';
                        }

                        //txt upload to server
                        if (isset($_FILES['txtindex_file1']['name']) && $_FILES['txtindex_file1']['name'] != null) {
                            echo "<br/><br/>Index upload status: ";

                            $affected_directory = "../$system_txts_directory/$dir_year";
                            $affected_filefield = "txtindex_file1";
                            $targetted_filemaxsize = $GLOBALS["system_allow_txt_maxsize"];
                            $targetted_filetype = $GLOBALS["system_allow_txt_extension"];
                            $successful_upload_mesage = "Index attachment uploaded successfully !";
                            $incorrect_filetype_mesage = "Upload aborted ! Incorrect file type. Please update this record if you need to reupload the file using the record ID.";
                            $incorrect_filesize_mesage = "Upload aborted ! Attachment file size > than expected. Please update this record if you need to reupload the file using the record ID.";
                            $allow_parser_to_parse_internally = false;
                            $targetted_field_to_update = "41pdfattach_fulltext";
                            $parse_txt_file = true;
                            $upload_type = "text";

                            include '../sw_inc/upl/upload.php';
                        }
                        
                        //isofile upload to server
                        if (isset($_FILES['isofile_file1']['name']) && $_FILES['isofile_file1']['name'] != null) {
                            echo "<br/><br/>$system_isofile_name upload status: ";

                            $affected_directory = "../$system_isofile_directory/$dir_year";
                            $affected_filefield = "isofile_file1";
                            $targetted_filemaxsize = $GLOBALS["system_allow_isofile_maxsize"];
                            $targetted_filetype = $GLOBALS["system_allow_isofile_extension"];
                            $successful_upload_mesage = "$system_isofile_name attachment uploaded successfully !";
                            $incorrect_filetype_mesage = "Upload aborted ! Incorrect $system_isofile_name type. Please update this record if you need to reupload the file using the record ID.";
                            $incorrect_filesize_mesage = "Upload aborted ! Attachment $system_isofile_name size > than expected. Please update this record if you need to reupload the file using the record ID.";
                            $allow_parser_to_parse_internally = false;
                            $targetted_field_to_update = null;
                            $parse_txt_file = false;
                            $upload_type = "isofile";
                            include '../sw_inc/upl/upload.php';//allow any extension to get through
                        }
                    
                        //image upload to server
                        if (isset($_FILES['imageatt1']['name']) && $_FILES['imageatt1']['name'] != null) {
                            echo "<br/><br/>Image upload status: ";

                            $affected_directory = "../$system_albums_directory/$dir_year";
                            $affected_watermark_directory = "../$system_albums_watermark_directory/$dir_year";
                            $affected_thumbnail_directory = "../$system_albums_thumbnail_directory/$dir_year";
                            $affected_filefield = "imageatt1";
                            $targetted_filemaxsize = $GLOBALS["system_allow_imageatt_maxsize"];
                            $targetted_filetype = $GLOBALS["system_allow_imageatt_extension"];
                            $successful_upload_mesage = "Image attachment uploaded successfully !";
                            $incorrect_filetype_mesage = "Upload aborted ! Incorrect image type. Please update this record if you need to reupload the file using the record ID.";
                            $incorrect_filesize_mesage = "Upload aborted ! Attachment image size > than expected. Please update this record if you need to reupload the file using the record ID.";
                            $allow_parser_to_parse_internally = false;
                            $targetted_field_to_update = null;
                            $parse_txt_file = false;
                            $upload_type = "image";

                            include '../sw_inc/upl/upload.php';
                        }

                        //uploading additional images - new codes
                        for ($x = 2; $x <= $maximum_num_imageatt_allowed; $x++) {
                            $imagenumber = "$x";
                            $imagefield = "imageatt$imagenumber";
                            if (isset($_FILES[$imagefield]['name']) && $_FILES[$imagefield]['name'] != null) {
                                echo "<br/><br/>Image upload status: ";
                                
                                $affected_directory = "../$system_albums_directory/$dir_year/$idUpload"."_"."$timestampUpload";
                                $affected_filefield = $imagefield;
                                $targetted_filemaxsize = $GLOBALS["system_allow_imageatt_maxsize"];
                                $targetted_filetype = $GLOBALS["system_allow_imageatt_extension"];
                                $successful_upload_mesage = "Additional image #$imagenumber uploaded successfully !";
                                $incorrect_filetype_mesage = "Upload aborted ! Incorrect image type. Please update this record if you need to reupload the file using the record ID.";
                                $incorrect_filesize_mesage = "Upload aborted ! Attachment image size > than expected. Please update this record if you need to reupload the file using the record ID.";
                                $allow_parser_to_parse_internally = false;
                                $targetted_field_to_update = null;
                                $parse_txt_file = false;
                                $upload_type = "multiimage";

                                include '../sw_inc/upl/upload.php';
                            }
                        }

                        if ($_POST['submit_button'] == 'Insert') {
                            echo "<br/><br/>Click <a href='reg.php'>here</a> to begin a new input.<br/><br/>";
                        } elseif ($_POST['submit_button'] == 'Update') {
                            echo "<br/><br/><div style='text-align:center;'><a class='sButtonRedSmall' href='javascript:window.opener.location.reload(true);window.close();'><span class='fas fa-window-close'></span> Close</a></div>";
                        }
                    }
                } else {
                    echo " <i class=\"fas fa-exclamation-triangle fa-2xl\"></i>
                            <br/><br/><span style='color:red;'>Your previous input has been cancelled.Check if any field(s) left emptied before posting.</span>
                            <br/><br/>Click <a href='reg.php'>here</a> to begin a new input.<br/><br/>";
                }

            echo "</td></tr>";
            echo "</table><br/><br/>";
        }//if submitted
        
        //initialize variables for in use with populate all fields below
        $id="";$title="";$folderid="";$typeid="";$status="";$location="";$link="";$author="";$langcode="";$source="";
        $localcallnum="";$inputdate="";$dir_year="";$lastupdateby="";$fulltexta="";$reference="";$isabstract="";
        $pdfattach_fulltext="";$instimestamp="";$subjectheading="";$accessnum="";
        $isbn="";$isbn_c="";$issn="";$edition="";$publication="";$physicaldesc="";$series="";$notes="";$dissertation_note="";
        $localcallnum_b="";$author_c="";$author_d="";$author_e="";$author_q="";$title_b="";$title_c="";
            $vtitle_a = "";$vtitle_b = "";$vtitle_g = "";$publication_b="";$publication_c="";$physicaldesc_b ="";$physicaldesc_c="";$physicaldesc_e="";$series_v="";
        $dissertation_note_b="";$dissertation_note_c="";$dissertation_note_d="";$summary_a="";$se_pname_a="";$se_pname_x="";$se_pname_y="";
        $subject_entry1="";$subject_entry2="";$subject_entry3="";
        $source_b="";$source_e="";$location_b ="";$location_c="";
        $geographic_coverage_note_a="";$original_version_note_t="";$terms_governing_use_a="";$other_relationship_entry_n="";
        $pname1="";$pname1_s="";
        $pname2="";$pname2_s="";
        $pname3="";$pname3_s="";
        $pname4="";$pname4_s="";
        $pname5="";$pname5_s="";
        $pname6="";$pname6_s="";
        $pname7="";$pname7_s="";
        $pname8 ="";$pname8_s="";
        $pname9="";$pname9_s="";
        $pname10="";$pname10_s="";
        $i_020="";$i_022="";$i_041="";$i_090="";$i_100="";$i_245="";$i_246="";$i_250="";$i_264="";$i_300="";$i_490="";$i_500="";$i_502="";
        $i_520="";$i_600="";$i_650_1="";$i_650_2="";$i_650_3="";$i_700="";$i_700_2="";$i_700_3="";$i_700_4="";$i_700_5="";$i_700_6="";$i_700_7="";$i_700_8="";$i_700_9="";$i_700_10="";$i_710="";$i_852="";$i_856="";
        $i_522="";$i_534="";$i_540="";$i_787="";
        $embargo_enddate="";
        
        //populate all fields with values for update operation
        $is_upd = false;
        if (isset($_GET["upd"]) && is_numeric($_GET["upd"])) {
            $get_id_upd = $_GET["upd"];
            $is_upd = true;

            //main table
            $query_value = "select * from eg_item where id = $get_id_upd";
            $result_value = mysqli_query($GLOBALS["conn"], $query_value);
            $myrow_value = mysqli_fetch_array($result_value);
                $id = $myrow_value["id"];
                $folderid = $myrow_value["38folderid"];
                $title = $myrow_value["38title"];$typeid = $myrow_value["38typeid"];$status = $myrow_value["38status"];$location = $myrow_value["38location"];$link = $myrow_value["38link"];
                $author = $myrow_value["38author"];
                $langcode = $myrow_value["38langcode"];
                $source = $myrow_value["38source"];
                $localcallnum = $myrow_value["38localcallnum"];
                $inputdate = $myrow_value["39inputdate"];
                    $dir_year = substr("$inputdate", 0, 4);
                $lastupdateby = $myrow_value["40lastupdateby"];
                $fulltexta = $myrow_value["41fulltexta"];$reference = $myrow_value["41reference"];$isabstract = $myrow_value["41isabstract"];$pdfattach_fulltext = $myrow_value["41pdfattach_fulltext"];
                $instimestamp = $myrow_value["41instimestamp"];
                $subjectheading = $myrow_value["41subjectheading"];
                $accessnum = $myrow_value["38accessnum"];
                $isbn = $myrow_value["38isbn"];$issn = $myrow_value["38issn"];
                $edition = $myrow_value["38edition"];$publication = $myrow_value["38publication"];$physicaldesc = $myrow_value["38physicaldesc"];$series = $myrow_value["38series"];
                $notes = $myrow_value["38notes"];$dissertation_note = $myrow_value["38dissertation_note"];
                $embargo_enddate = $myrow_value["51_embargo_timestamp"];
            
            //secondary table
            $query_value2 = "select * from eg_item2 where eg_item_id = $get_id_upd";
            $result_value2 = mysqli_query($GLOBALS["conn"], $query_value2);
            if (mysqli_num_rows($result_value2) >= 1) {
                $myrow_value2 = mysqli_fetch_array($result_value2);

                $localcallnum_b = $myrow_value2["38localcallnum_b"];
                $isbn_c = $myrow_value2["38_terms_of_availability"];
                $author_c = $myrow_value2["38author_c"];$author_d = $myrow_value2["38author_d"];$author_e = $myrow_value2["38author_e"];$author_q = $myrow_value2["38author_q"];
                $title_b = $myrow_value2["38title_b"];$title_c = $myrow_value2["38title_c"];
                    $vtitle_a = $myrow_value2["38vtitle_a"];$vtitle_b = $myrow_value2["38vtitle_b"];$vtitle_g = $myrow_value2["38vtitle_g"];
                $publication_b = $myrow_value2["38publication_b"];$publication_c = $myrow_value2["38publication_c"];
                $physicaldesc_b = $myrow_value2["38physicaldesc_b"];$physicaldesc_c = $myrow_value2["38physicaldesc_c"];$physicaldesc_e = $myrow_value2["38physicaldesc_e"];
                $series_v = $myrow_value2["38series_v"];
                $dissertation_note_b = $myrow_value2["38dissertation_note_b"];$dissertation_note_c = $myrow_value2["38dissertation_note_c"];$dissertation_note_d = $myrow_value2["38dissertation_note_d"];
                    $summary_a = $myrow_value2["38summary_a"];
                    $se_pname_a = $myrow_value2["38se_pname_a"];$se_pname_x = $myrow_value2["38se_pname_x"];$se_pname_y = $myrow_value2["38se_pname_y"];
                $subject_entry1 = $myrow_value2["38subject_entry1"];$subject_entry2 = $myrow_value2["38subject_entry2"];$subject_entry3 = $myrow_value2["38subject_entry3"];
                $source_b = $myrow_value2["38source_b"];$source_e = $myrow_value2["38source_e"];
                $location_b = $myrow_value2["38location_b"];$location_c = $myrow_value2["38location_c"];
                $geographic_coverage_note_a=$myrow_value2["38geographic_coverage_note_a"];
                $original_version_note_t=$myrow_value2["38original_version_note_t"];
                $terms_governing_use_a=$myrow_value2["38terms_governing_use_a"];
                $other_relationship_entry_n=$myrow_value2["38other_relationship_entry_n"];

                $pname1 = $myrow_value2["38pname1"];$pname1_s = $myrow_value2["38pname1_s"];
                $pname2 = $myrow_value2["38pname2"];$pname2_s = $myrow_value2["38pname2_s"];
                $pname3 = $myrow_value2["38pname3"];$pname3_s = $myrow_value2["38pname3_s"];
                $pname4 = $myrow_value2["38pname4"];$pname4_s = $myrow_value2["38pname4_s"];
                $pname5 = $myrow_value2["38pname5"];$pname5_s = $myrow_value2["38pname5_s"];
                $pname6 = $myrow_value2["38pname6"];$pname6_s = $myrow_value2["38pname6_s"];
                $pname7 = $myrow_value2["38pname7"];$pname7_s = $myrow_value2["38pname7_s"];
                $pname8 = $myrow_value2["38pname8"];$pname8_s = $myrow_value2["38pname8_s"];
                $pname9 = $myrow_value2["38pname9"];$pname9_s = $myrow_value2["38pname9_s"];
                $pname10 = $myrow_value2["38pname10"];$pname10_s = $myrow_value2["38pname10_s"];
            }
            
            //loading indicators
            $query_value3 = "select * from eg_item2_indicator where eg_item_id = $get_id_upd";
            $result_value3 = mysqli_query($GLOBALS["conn"], $query_value3);
            if (mysqli_num_rows($result_value3) >= 1) {
                $myrow_value3 = mysqli_fetch_array($result_value3);

                $i_020 = $myrow_value3["i_020"];$i_022 = $myrow_value3["i_022"];$i_041 = $myrow_value3["i_041"];$i_090 = $myrow_value3["i_090"];
                $i_100 = $myrow_value3["i_100"];
                $i_245 = $myrow_value3["i_245"];$i_246 = $myrow_value3["i_246"];$i_250 = $myrow_value3["i_250"];$i_264 = $myrow_value3["i_264"];
                $i_300 = $myrow_value3["i_300"];
                $i_490 = $myrow_value3["i_490"];
                $i_500 = $myrow_value3["i_500"];$i_502 = $myrow_value3["i_502"];$i_520 = $myrow_value3["i_520"];
                $i_600 = $myrow_value3["i_600"];$i_650_1 = $myrow_value3["i_650_1"];$i_650_2 = $myrow_value3["i_650_2"];$i_650_3 = $myrow_value3["i_650_3"];
                $i_700 = $myrow_value3["i_700"];$i_700_2 = $myrow_value3["i_700_2"];$i_700_3 = $myrow_value3["i_700_3"];$i_700_4 = $myrow_value3["i_700_4"];$i_700_5 = $myrow_value3["i_700_5"];$i_700_6 = $myrow_value3["i_700_6"];
                    $i_700_7 = $myrow_value3["i_700_7"];$i_700_8 = $myrow_value3["i_700_8"];$i_700_9 = $myrow_value3["i_700_9"];$i_700_10 = $myrow_value3["i_700_10"];$i_710 = $myrow_value3["i_710"];
                $i_852 = $myrow_value3["i_852"];$i_856 = $myrow_value3["i_856"];
                $i_522=$myrow_value3["i_522"];$i_534=$myrow_value3["i_534"];$i_540=$myrow_value3["i_540"];$i_787=$myrow_value3["i_787"];
            }
        }
    ?>
            
    <?php
    //the main form for this page
        if (!isset($_REQUEST['submitted'])) {
    ?>
            <?php
                if ($default_view_input == 'marc') {
                    $_SESSION[$ssn.'viewmode'] = 'marc';
                } else {
                    $_SESSION[$ssn.'viewmode'] = 'simple';
                }
            ?>
            <table class=<?php echo $color_scheme."Header";?> >
                <tr>
                    <td>
                        <strong>Fill in the fields for inserting a new record: </strong>
                        <?php
                            if ($debug_mode == 'yes') {
                                $php_post_max = preg_replace("/\D/", "", ini_get("post_max_size"));
                                $php_upload_max = preg_replace("/\D/", "", ini_get("upload_max_filesize"));
                                if (
                                    ($php_post_max <= $php_upload_max)
                                    ||
                                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_document_maxsize/1000000)
                                    ||
                                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_imageatt_maxsize/1000000)
                                    ||
                                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_pdocument_maxsize/1000000)
                                    ||
                                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_txt_maxsize/1000000)
                                    ||
                                    ($php_post_max > $php_upload_max && $php_upload_max <= $system_allow_isofile_maxsize/1000000)
                                    ) {
                                    echo "<br/><span style='color:red;font-size:10px'>WARNING: You might have issue with upload. Server upload setting (php.ini) Post Max Size: ".ini_get("post_max_size")." Upload Max Size: ".ini_get("upload_max_filesize").".<br/>Post max size must be set higher value than upload max size. You must also see the limit you set on various file upload fields in this form. They must be lower than both post max size and upload max size.</span>";
                                }
                            }
                        ?>
                    </td>
                </tr>
            </table>
            
            <form name="mainform" action="reg.php" method="post" enctype="multipart/form-data">
                <table class=greyBody>
                
                        <tr>
                            <td style='text-align:right;vertical-align:top;'>
                                <strong>
                                    <?php echo $type_as;?>
                                    <br/><span style='color:orange;font-size:8pt;'>dc.type</span>
                                </strong>
                            </td>
                            <td>:
                            <?php if ($_SESSION[$ssn.'viewmode'] == 'marc') {?><span style='color:lightgrey;'>|a</span><?php }?>
                                <select name="typestatement1">
                                <?php
                                    $queryB = "select 38typeid, 38type, 38default, 38synonym from eg_item_type";
                                    $resultB = mysqli_query($GLOBALS["conn"], $queryB);
                                    while ($myrowB=mysqli_fetch_array($resultB)) {
                                        echo "<option value='".$myrowB["38typeid"]."' ";
                                            if (($is_upd && isset($typeid) && $typeid == $myrowB["38typeid"]) || (!$is_upd && $myrowB["38default"] == 'TRUE')) {echo "selected";}
                                        echo ">".$myrowB["38synonym"]."</option>";
                                    }
                                ?>
                                </select>
                            </td>
                        </tr>
                        
                        <?php if ($init_status_visibility == 'show') {?>
                        <tr>
                            <td style='text-align:right;vertical-align:top;'><strong>Initial status </strong></td>
                            <td>:
                                <?php if ($_SESSION[$ssn.'viewmode'] == 'marc') {?><span style='opacity:0.0;'>|?</span><?php }?>
                                <input type='hidden' name='status1_ori' value='<?php echo $status;?>'>
                                <select name="status1">
                                    <option value="AVAILABLE" <?php if (isset($status) && $is_upd && $status == 'AVAILABLE') {echo "selected";}?>>Available - Public</option>
                                    <option value="LIMITED" <?php if (isset($status) && $is_upd && $status == 'LIMITED') {echo "selected";}?>>Limited - For Registered User</option>
                                    <option value="FINALPROCESSING" <?php if (isset($status) && $is_upd && $status == 'FINALPROCESSING') {echo "selected";}?>>Final Processing</option>
                                    <option value="EMBARGO" <?php if (isset($status) && $is_upd && $status == 'EMBARGO') {echo "selected";}?>>Embargo</option>
                                    <option value="UNLISTED" <?php if (isset($status) && $is_upd && $status == 'UNLISTED') {echo "selected";}?>>Unlisted</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style='text-align:right;vertical-align:top;'></td>
                            <td>:
                                <?php if ($_SESSION[$ssn.'viewmode'] == 'marc') {?><span style='opacity:0.0;'>|?</span><?php }?>
                                <?php
                                    if (isset($embargo_enddate) && $embargo_enddate <> 0 && $embargo_enddate != "") {
                                        $embargo_enddate_todisplay = date("Y-m-d", (int)$embargo_enddate);
                                    } else {
                                        $embargo_enddate_todisplay = date("Y-m-d", strtotime("+$embargoed_duration days"));
                                    }
                                ?>
                                <em>*End date for embargo</em>: <input type="date" name="enddate" value="<?php echo $embargo_enddate_todisplay;?>"/>
                            </td>
                        </tr>
                        <?php } else { echo "<input type='hidden' name='status1_ori' value='AVAILABLE'><input type='hidden' name='status1' value='AVAILABLE'>"; }?>
                        
                        <?php if ($enable_folder) {?>
                        <tr>
                            <td style='text-align:right;vertical-align:top;'><strong>Folder </strong></td>
                            <td>:
                                <?php if ($_SESSION[$ssn.'viewmode'] == 'marc') {?><span style='opacity:0.0;'>|?</span><?php }?>
                                <input type="text" id="foldername1" name="foldername1" style="width:60%" maxlength="255" value="<?php if (isset($folderid)) {echo sfx_sGetValue("38foldername", "eg_item_folder", "38folderid", $folderid, "i");}?>"/>
                                <input type="hidden" id="folderid1" name="folderid1" value="<?php if (isset($folderid)) {echo $folderid;}?>">
                                <input type="button" name="folderButton" value="..." onClick="js_showFolder()" />
                                <input type="button" name="clearFL" value="Clear" onClick="folderid1.value='';foldername1.value='';">
                            </td>
                        </tr>
                        <?php } else { echo "<input type='hidden' name='folderid1' value=''>"; }?>

                        <?php if ($enable_subject_entry) {?>
                        <tr>
                            <td style='text-align:right;vertical-align:top;'><strong><?php echo $subject_heading_as;?> </strong></td>
                            <td>:
                                <?php if ($_SESSION[$ssn.'viewmode'] == 'marc') {?><span style='opacity:0.0;'>|?</span><?php }?>
                                <input type="text" id="subjectheading1" name="subjectheading1" style="width:60%" maxlength="150" value="<?php if (isset($subjectheading)) {echo $subjectheading;}?>"/>
                                <input type="button" name="subjectheadingButton" value="..." onClick="js_showList()" />
                                <input type="button" name="clearSH" value="Clear" onClick="subjectheading1.value='';">
                            </td>
                        </tr>
                        <?php }?>
                        
                        <?php if ($show_accession_number) {?>
                        <tr>
                            <td style='text-align:right;vertical-align:top;'><strong>Accession Number </strong></td>
                            <td>:
                                <?php if ($_SESSION[$ssn.'viewmode'] == 'marc') {?><span style='opacity:0.0;'>|?</span><?php }?>
                                <?php
                                    if (!$is_upd) {
                                        echo "<input type='text' name='accessnum1' style='width:80%' maxlength='150' readonly value='";echo sfx_millitime()."'/>";
                                    } elseif ($is_upd && isset($accessnum)) {
                                        echo $accessnum."<input type='hidden' name='accessnum1' value='$accessnum'>";
                                    }
                                ?>
                            </td>
                        </tr>
                        <?php } else { echo "<input type='hidden' name='accessnum1' value='";echo sfx_millitime();echo "'/>"; }?>

                        <?php
                            //generate form fields using special functions
                            sfx_regRowGenerate(false, $tag_020_show, $_SESSION[$ssn.'viewmode'], $tag_020, "", true, "i_020", "", "isbn1", "", "|a", "80%", "60", $is_upd, $isbn, $i_020);
                            sfx_regRowGenerate(false, $tag_022_show, $_SESSION[$ssn.'viewmode'], $tag_022, "", true, "i_022", "", "issn1", "", "|a", "80%", "60", $is_upd, $issn, $i_022);

                            if ($tag_041_show) {
                                sfx_regRowGenerateSelectBox($tag_041_show, $_SESSION[$ssn.'viewmode'], $tag_041, "i_041", "|a", $tag_041_selectable, $tag_041_selectable_default, "langcode1", $tag_041_inputtype, true, $is_upd, $langcode, $i_041);
                            }

                            sfx_regRowGenerate(false, $tag_090_show, $_SESSION[$ssn.'viewmode'], $tag_090, "", true, "i_090", "", "callnum1", "", "|a", "80%", "70", $is_upd, $localcallnum, $i_090);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_090_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "callnum1_b", "", "|b", "80%", "70", $is_upd, $localcallnum_b);
                            }
                                                
                            sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], $tag_100, "", true, "i_100", "", "authorname1", "", "|a", "80%", "150", $is_upd, $author, $i_100);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "authorname1_c", "", "|c", "80%", "150", $is_upd, $author_c);
                                sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "authorname1_d", "", "|d", "80%", "150", $is_upd, $author_d);
                                sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "authorname1_e", "", "|e", "80%", "150", $is_upd, $author_e);
                                sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "authorname1_q", "", "|q", "80%", "150", $is_upd, $author_q);
                            }
                            
                            $checkduplicatebutton = "<input title=\"Check Duplicate\" type=\"button\" style='width:5ch' value=\"&#128270;\" onClick='window.open(\"dupfindermini.php?scstr=\"+document.mainform.titlestatement1.value+\"&sctype=EveryThing&onlytitle=yes&mf=9999\",\"duplicatefindermini\",\"width=800,height=300,left=150,top=200,toolbar=0,status=0,\");'/>";
                            sfx_regRowGenerate(true, true, $_SESSION[$ssn.'viewmode'], $tag_245, "", true, "i_245", "", "titlestatement1", "", "|a", "70%", "255", $is_upd, $title, $i_245, "text", $checkduplicatebutton);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "titlestatement1_b", "", "|b", "80%", "255", $is_upd, $title_b);
                                sfx_regRowGenerate(false, true, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "titlestatement1_c", "", "|c", "80%", "255", $is_upd, $title_c);
                            }

                            sfx_regRowGenerate(false, $tag_246_show, $_SESSION[$ssn.'viewmode'], $tag_246, "", true, "i_246", "", "vtitle1_a", "", "|a", "80%", "255", $is_upd, $vtitle_a, $i_246);
                            sfx_regRowGenerate(false, $tag_246_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "vtitle1_b", "", "|b", "80%", "255", $is_upd, $vtitle_b);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_246_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "vtitle1_g", "", "|g", "80%", "255", $is_upd, $vtitle_g);
                            }

                            sfx_regRowGenerate(false, $tag_250_show, $_SESSION[$ssn.'viewmode'], $tag_250, "", true, "i_250", "", "edition1", "", "|a", "80%", "255", $is_upd, $edition, $i_250);
                        
                            sfx_regRowGenerate(false, $tag_264_show, $_SESSION[$ssn.'viewmode'], $tag_264, $publisher_place_of_production, true, "i_264", "", "publication1", $tag_264_a_default, "|a", "80%", "255", $is_upd, $publication, $i_264);
                            sfx_regRowGenerate(false, $tag_264_show, $_SESSION[$ssn.'viewmode'], "", $publisher_as, false, "", "", "publication1_b", "", "|b", "68%", "255", $is_upd, $publication_b, "", "text", "<input type='button' name='publisherButton' value='...' onClick=\"js_showPublisher()\" />");
                            sfx_regRowGenerate(false, $tag_264_show, $_SESSION[$ssn.'viewmode'], "", $publisher_year_of_publication, false, "", "", "publication1_c", "", "|c", "80%", "255", $is_upd, $publication_c);
                                                
                            sfx_regRowGenerate(false, $tag_300_show, $_SESSION[$ssn.'viewmode'], $tag_300, "", true, "i_300", "", "physicaldesc1", "", "|a", "80%", "255", $is_upd, $physicaldesc, $i_300);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_300_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "physicaldesc1_b", "", "|b", "80%", "255", $is_upd, $physicaldesc_b);
                                sfx_regRowGenerate(false, $tag_300_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "physicaldesc1_c", "", "|c", "80%", "255", $is_upd, $physicaldesc_c);
                                sfx_regRowGenerate(false, $tag_300_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "physicaldesc1_e", "", "|e", "80%", "255", $is_upd, $physicaldesc_e);
                            }

                            sfx_regRowGenerate(false, $tag_490_show, $_SESSION[$ssn.'viewmode'], $tag_490, "", true, "i_490", "", "series1", "", "|a", "80%", "150", $is_upd, $series, $i_490);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_490_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "series1_v", "", "|v", "80%", "150", $is_upd, $series_v);
                            }

                            sfx_regRowGenerate(false, $tag_500_show, $_SESSION[$ssn.'viewmode'], $tag_500, "", true, "i_500", "", "notes1", "", "|a", "80%", "0", $is_upd, $notes, $i_500, "textarea");
                         
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_502_show, $_SESSION[$ssn.'viewmode'], $tag_502, "", true, "i_502", "", "dissertation_note1", "", "|a", "80%", "150", $is_upd, $dissertation_note, $i_502);
                            }
                            
                            sfx_regRowGenerateSelectBox($tag_502_show, $_SESSION[$ssn.'viewmode'], $tag_502_b, 'i_502', "|b", $tag_502_b_selectable, $tag_502_b_selectable_default, "dissertation_note1_b", $tag_502_inputtype, false, $is_upd, $dissertation_note_b);

                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_502_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "dissertation_note1_c", "", "|c", "80%", "50", $is_upd, $dissertation_note_c);
                                sfx_regRowGenerate(false, $tag_502_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "dissertation_note1_d", "", "|d", "80%", "50", $is_upd, $dissertation_note_d);
                            }
                        
                            sfx_regRowGenerate(false, $tag_520_show, $_SESSION[$ssn.'viewmode'], $tag_520, "", true, "i_520", "", "summary1_a", "", "|a", "80%", "0", $is_upd, $summary_a, $i_520, "textarea");
                            
                            //20240924 newly added
                            //new tag 522 |a
                            sfx_regRowGenerate(false, $tag_522_show, $_SESSION[$ssn.'viewmode'], $tag_522, "", true, "i_522", "", "geographic_coverage_note1_a", "", "|a", "80%", "150", $is_upd, $geographic_coverage_note_a, $i_522);
                            //new tag 534 |a
                            sfx_regRowGenerate(false, $tag_534_show, $_SESSION[$ssn.'viewmode'], $tag_534, "", true, "i_534", "", "original_version_note1_t", "", "|t", "80%", "150", $is_upd, $original_version_note_t, $i_534);
                            //new tag 540 |a
                            sfx_regRowGenerate(false, $tag_540_show, $_SESSION[$ssn.'viewmode'], $tag_540, "", true, "i_540", "", "terms_governing_use1_a", "", "|a", "80%", "150", $is_upd, $terms_governing_use_a, $i_540);
                           
                            sfx_regRowGenerate(false, $tag_600_show, $_SESSION[$ssn.'viewmode'], $tag_600, "Personal name", true, "i_600", "", "se_pname1_a", "", "|a", "80%", "255", $is_upd, $se_pname_a, $i_600);
                                sfx_regRowGenerate(false, $tag_600_show, $_SESSION[$ssn.'viewmode'], "", "General subdivision", false, "", "", "se_pname1_x", "", "|x", "80%", "255", $is_upd, $se_pname_x);
                                sfx_regRowGenerate(false, $tag_600_show, $_SESSION[$ssn.'viewmode'], "", "Chronological subdivision", false, "", "", "se_pname1_y", "", "|y", "80%", "255", $is_upd, $se_pname_y);
                         
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                sfx_regRowGenerate(false, $tag_650_show, $_SESSION[$ssn.'viewmode'], $tag_650, "", true, "i_650_1", "", "subject_entry1a", "", "|a", "80%", "255", $is_upd, $subject_entry1, $i_650_1);
                                sfx_regRowGenerate(false, $tag_650_show, $_SESSION[$ssn.'viewmode'], $tag_650, "", true, "i_650_2", "", "subject_entry2a", "", "|a", "80%", "255", $is_upd, $subject_entry2, $i_650_2);
                                sfx_regRowGenerate(false, $tag_650_show, $_SESSION[$ssn.'viewmode'], $tag_650, "", true, "i_650_3", "", "subject_entry3a", "", "|a", "80%", "255", $is_upd, $subject_entry3, $i_650_3);
                             }

                            sfx_regRowGenerateRepeats2f($tag_700_show, 10, $_SESSION[$ssn.'viewmode'], $tag_700, "i_700", "", "|a", "pname", $is_upd, $pname1, $pname1_s, $tag_700_e,$i_700);

                            sfx_regRowGenerate(false, $tag_710_show, $_SESSION[$ssn.'viewmode'], $tag_710, "", true, "i_710", "", "sumber1", $tag_710_a_default, "|a", "80%", "255", $is_upd, $source, $i_710);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                    sfx_regRowGenerate(false, $tag_710_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "sumber1_b", $tag_710_b_default, "|b", "80%", "255", $is_upd, $source_b);
                                    sfx_regRowGenerate(false, $tag_710_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "sumber1_e", $tag_710_e_default, "|e", "80%", "255", $is_upd, $source_e);
                                }

                            //new tag 787 |n
                            sfx_regRowGenerate(false, $tag_787_show, $_SESSION[$ssn.'viewmode'], $tag_787, "", true, "i_787", "", "other_relationship_entry1_n", "", "|n", "80%", "150", $is_upd, $other_relationship_entry_n, $i_787);
    
                            sfx_regRowGenerate(false, $tag_852_show, $_SESSION[$ssn.'viewmode'], $tag_852, "", true, "i_852", "", "location1", "", "|a", "80%", "255", $is_upd, $location, $i_852);
                            if ($_SESSION[$ssn.'viewmode'] == 'marc') {
                                    sfx_regRowGenerate(false, $tag_852_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "location1_b", "", "|b", "80%", "255", $is_upd, $location_b);
                                    sfx_regRowGenerate(false, $tag_852_show, $_SESSION[$ssn.'viewmode'], "", "", false, "", "", "location1_c", "", "|c", "80%", "255", $is_upd, $location_c);
                                }

                            sfx_regRowGenerate(false, $tag_856_show, $_SESSION[$ssn.'viewmode'], $tag_856, "", true, "i_856", "", "link1", "", "|u", "80%", "255", $is_upd, $link, $i_856);
                            
                            if ($enable_commercial_api) {
                                sfx_regRowGenerate(false, $tag_020_c_show, $_SESSION[$ssn.'viewmode'], $tag_020_c, "", true, "i_020", "", "isbn1_c", "", "|c", "80%", "60", $is_upd, $isbn_c,'null');
                            }

                            if ($system_function != 'photo' && $allow_guestpdf_insert_by_admin) {
                                sfx_regRowGenerateFileUploadBox("Guest PDF", $system_allow_pdocument_maxsize, "pfile1", $system_allow_pdocument_extension, $is_upd, "../$system_pdocs_directory/$dir_year/"."$id"."_"."$instimestamp".".pdf");
                            }

                            sfx_regRowGenerateFileUploadBox("Full Text PDF", $system_allow_document_maxsize, "file1", $system_allow_document_extension, $is_upd, "../$system_docs_directory/$dir_year/"."$id"."_"."$instimestamp".".pdf");
                            
                            if ($system_function != 'photo' && $allow_txt_insert_by_admin) {
                                sfx_regRowGenerateFileUploadBox("TXT ", $system_allow_txt_maxsize, "txtindex_file1", $system_allow_txt_extension, $is_upd, null);
                            }

                            //handling freetype file
                            $get_freetypefilename = "../$system_isofile_directory/$dir_year/NODIR.XXX";
                            if (is_dir("../$system_isofile_directory/$dir_year")) {
                                $files_scanned = scandir("../$system_isofile_directory/$dir_year");
                                foreach ($files_scanned as $fileitem) {
                                    if (preg_match("/$id"."_"."$instimestamp/i", $fileitem) == 1 && !strpos($fileitem, ".deleted")) {
                                        $get_freetypefilename = "../$system_isofile_directory/$dir_year/$fileitem";
                                        break;
                                    }
                                }
                            }
                            if ($system_function != 'photo' && $allow_isofile_insert_by_admin) {
                                sfx_regRowGenerateFileUploadBox("$system_isofile_name ", $system_allow_isofile_maxsize, "isofile_file1", $system_allow_isofile_extension, $is_upd, $get_freetypefilename);
                            }

                            if ($allow_image_insert_by_admin) {
                                sfx_regRowGenerateFileUploadBox("Primary JPG ", $system_allow_imageatt_maxsize, "imageatt1", $system_allow_imageatt_extension, $is_upd, "../$system_albums_directory/$dir_year/"."$id"."_"."$instimestamp".".jpg");
                                if ($system_function == 'photo') {
                                    
                                    for ($x = 2; $x <= $maximum_num_imageatt_allowed; $x++) {
                                        $currentDisplay_image = "$x";
                                        $currentInput_image = "imageatt$currentDisplay_image";
                                        if ($x == ($maximum_num_imageatt_allowed)) {
                                            $requirenext=false;
                                        } else {
                                            $requirenext=true;
                                        }
                                        
                                        if ($is_upd) {
                                            include "../sw_inc/update_imagefield.php";
                                        } else {
                                            include "../sw_inc/reg_imagefield.php";
                                        }
                                    }
                                 }
                            }

                        ?>
                        
                        <?php if ($system_function != 'photo' && $enable_fulltext_abstract_composer) {?>
                            <tr>
                                <td style='text-align:center;vertical-align:top;' colspan=2>
                                    <br/><br/><strong>Full Text Composer </strong>: <input type=checkbox name="isabstract1" value="1" <?php if (($is_upd && $isabstract == '1') || (!$is_upd && $default_is_abstract)) {echo "checked";} ?>>This is Abstract
                                </td>
                            </tr>
                            <tr>
                                <td style='vertical-align:top;' colspan=2>
                                    <textarea <?php if ($fulltext_abstract_composer_type == 'richtext') {echo "id='wadahComposer'";} else {echo "id='fulltext1'";} ?> style="resize: none; width: 100%;" name="fulltext1" cols="72" rows="30"><?php echo $fulltexta;?></textarea>
                                    <button type="button" id="normalizeBtn">Normalize Text</button>
                                    <script>
                                        document.addEventListener('DOMContentLoaded', function () {
                                            document.getElementById('normalizeBtn').addEventListener('click', function () {
                                                // Check if TinyMCE is initialized and get content from the editor
                                                if (typeof tinymce !== 'undefined' && tinymce.get('wadahComposer')) {
                                                    let content = tinymce.get('wadahComposer').getContent();
                                                    // Normalize the content by first converting HTML entities to characters
                                                    const tempDiv = document.createElement('div');
                                                    tempDiv.innerHTML = content;
                                                    content = tempDiv.textContent;
                                                    // Now normalize the text
                                                    content = content
                                                        .normalize('NFD')
                                                        .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
                                                        .replace(/[^\x00-\x7F]/g, '_') // Replace non-ASCII with underscore
                                                        .replace(/\s+/g, ' '); // Normalize spaces
                                                    
                                                    // Convert back to HTML and set content
                                                    content = content
                                                        .replace(/&/g, '&amp;')
                                                        .replace(/</g, '&lt;')
                                                        .replace(/>/g, '&gt;')
                                                        .replace(/"/g, '&quot;')
                                                        .replace(/'/g, '&#039;');
                                                    
                                                    tinymce.get('wadahComposer').setContent(content);
                                                } else {
                                                    // Fallback to regular textarea
                                                    const ta = document.getElementById('fulltext1');
                                                    if (ta) {
                                                        let txt = ta.value
                                                            .normalize('NFD')
                                                            .replace(/[\u0300-\u036f]/g, '')
                                                            .replace(/[^\x00-\x7F]/g, '_')
                                                            .replace(/\s+/g, ' ');
                                                        ta.value = txt;
                                                    }
                                                }
                                            });
                                        });
                                    </script>
                                </td>
                            </tr>
                        <?php }?>

                        <?php if ($system_function != 'photo' && $enable_reference_composer) {?>
                            <tr>
                                <td style='text-align:center;vertical-align:top;' colspan=2>
                                    <br/><br/><strong>Reference Composer </strong>:
                                </td>
                            </tr>
                            <tr>
                                <td style='vertical-align:top;' colspan=2>
                                    <textarea <?php if ($reference_composer_type == 'richtext') {echo "id='referenceComposer'";} ?> style="resize: none; width: 100%;" name="reference1" cols="72" rows="30"><?php echo $reference;?></textarea>
                                </td>
                            </tr>
                        <?php }?>

                        <tr><td colspan='2' style='text-align:center;vertical-align:top;'>
                            <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                            <?php
                            if (!$is_upd) {
                                echo "
                                    <input type='hidden' name='instimestamp1' value='".time()."' />
                                    <input type='hidden' name='submitted' value='TRUE' />
                                    <br/>
                                    <input type='submit' name='submit_button' value='Insert' />
                                ";
                            } elseif ($is_upd) {
                                echo "
                                    <input type='hidden' name='id1' value='$id' />
                                    <input type='hidden' name='instimestamp1' value='$instimestamp' />
                                    <input type='hidden' name='inputdate1' value='$inputdate' />
                                    <input type='hidden' name='submitted' value='TRUE' />
                                    <br/>
                                    <input type='submit' name='submit_button' value='Update' />
                                ";
                                echo "<br/><br/><div style='text-align:center;'><a class='sButtonRedSmall' href='javascript:window.opener.location.reload(true);window.close();'><span class='fas fa-window-close'></span> Close</a></div>";
                            }
                            ?>
                            <br/><br/>
                        </td></tr>
                </table>
            </form>

    <?php
        }//if submitted
    ?>

        <hr>
        <?php if (!$is_upd) {include_once '../sw_inc/footer.php';}?>

    </body>

    </html>
    
    <?php mysqli_close($GLOBALS["conn"]); exit(); ?>
