<?php
/*
Filename: sw_admin/checkpdfindexer.php
Usage: Tool to check whether smalot pdfindexer is working or not
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Check PDF Indexer";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>' style='font-size:12pt;'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <?php
    
        echo "<strong>This tool will test whether you have installed pdf parser correctly or not by reading this file: <a target='_blank' href='temp/test.pdf'>test.pdf</a></strong>";

        include_once '../sw_vendor/autoload.php';
        $parser = new \Smalot\PdfParser\Parser();
        if (file_exists('temp/test.pdf')) {
            $pdf = $parser->parseFile('temp/test.pdf');

            if ($pdf) {
                echo "<br/><br/>Output:<br/></h2>start of file--<br/><br/>";
                $text = $pdf->getText();

                echo $text."<br/><br/>--end of file";

                $pdfTotalPages = sfx_getPDFPages($appendroot, "temp/test.pdf");
                if ($pdfTotalPages == 0) {
                    $pdfTotalPages = sfx_getPDFPagesSmalot($appendroot, "temp/test.pdf");
                }
                
                echo "<br/><br/><strong><u>Total page(s) detected</u></strong>:<br/> $pdfTotalPages page(s)";
            } else {
                echo "<br/><br/>Error.";
            }
        } else {
            echo "<br/><br/>Error.";
        }
    ?>
    
    <br/><br/><hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
