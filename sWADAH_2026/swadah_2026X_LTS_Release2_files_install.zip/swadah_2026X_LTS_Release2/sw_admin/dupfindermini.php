<?php
/*
Filename: dupfindermini.php
Usage: Duplicate finder made for reg.php
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Duplicate Finder Mini";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<?php
    //session management for search fields
    if (isset($_GET['scstr'])) {$_SESSION[$ssn.'sear_scstr'] = preg_replace('/\s+/', ' +', "+".sfx_just_clean($_GET['scstr']));}
    if (isset($_GET['sctype']) && (is_numeric($_GET['sctype']) || $_GET['sctype'] == 'EveryThing' || $_GET['sctype'] == 'Control Number' || $_GET['sctype'] == 'Author')) {$_SESSION[$ssn.'sear_sctype'] = $_GET['sctype'];}
    if (isset($_GET['page']) && is_numeric($_GET['page'])) {$_SESSION[$ssn.'sear_page'] = $_GET['page'];}

    $sctype_select = $_SESSION[$ssn.'sear_sctype'] ?? '';

?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
                              
    <hr>
                            
    <div style='text-align:center;'>
        <?php
            //start paging 1
            if (isset($_SESSION[$ssn.'sear_page'])) {$currentPage = $_SESSION[$ssn.'sear_page'];}
            include_once '../sw_inc/paging-p1.php';
            
            if (isset($_SESSION[$ssn.'sear_scstr']) || (isset($_SESSION[$ssn.'sear_sctype']) && $_SESSION[$ssn.'sear_sctype'] <> null)) {
                $scstr_term = $_SESSION[$ssn.'sear_scstr'];
                $latest = "FALSE";
                include_once '../sw_inc/index2_s_boolean.php';
            }
                                    
            $time_start = sfx_getmicrotime();
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
                                                    
            //start paging 2
            include_once '../sw_inc/paging-p2.php';

            if ($latest == "FALSE") {
                echo "<table class=whiteHeaderNoCenter><tr><td>";
                    echo "<strong>Total records found :</strong> $num_results_affected_paging for</strong> ' $scstr_term '";
                echo "</td></tr></table>";
            }

            if ($debug_mode == 'yes') {
                echo "<table class=whiteHeaderNoCenter><tr><td><span style='font-size:8pt;'><span style='color:blue;'>Final query:</span> ".$query1."</span></td></tr></table>";
            }

            echo "<table class=whiteHeaderNoCenter>";

            $n = 1;
    
            while ($myrow1 = mysqli_fetch_array($result1)) {
                echo "<tr class=$color_scheme"."Hover>";
                
                    $id2 = $myrow1["id"];
                    $folderid2 = $myrow1["38folderid"];
                    $status2 = $myrow1["38status"];
                    $titlestatement2 = $myrow1["38title"];
                    $typestatement2 = $myrow1["38typeid"];
                    $authorname2 = $myrow1["38author"];
                    $link2 = $myrow1["38link"];
                    $inputdate2 = $myrow1["39inputdate"];
                    $hits2 = $myrow1["41hits"];
                    $inputby2 = $myrow1["39inputby"];
                    $fulltext2 = $myrow1["41fulltexta"];
                    $pdfattach_fulltext2 = $myrow1["41pdfattach_fulltext"];
                    $isabstract2 = $myrow1["41isabstract"];
                    $localcallnum2 = $myrow1["38localcallnum"];
                    $instimestamp2 = $myrow1["41instimestamp"];
                    $accessnum2 = $myrow1["38accessnum"];
                    $item_status2 = $myrow1["50item_status"];
                    $reference2 = $myrow1["41reference"];
                    $dir_year2 = substr("$inputdate2", 0, 4);
                    
                    echo "<td style='text-align:center;vertical-align:top;' width=40>$n</td>";
                                        
                    echo "<td style='text-align:left;vertical-align:top;'>";
                        echo sfx_highlight($titlestatement2, $scstr_term);
                        
                        if ($authorname2 != '') {echo "<br/><a class=myclass2 href='index2.php?scstr=$authorname2&sctype=Author&sc=cl'>$authorname2</a>";}
                        
                        if ($item_status2 == '1') {
                            echo "<br/>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $typestatement2)."<br/>";

                            if ($fulltext2 != null && $fulltext2 != '<html />') {
                                if ($isabstract2 == 1) {
                                    echo "<img src='../sw_asset/img/ind_abstract_yes.png' width=24 alt='Click to view' title='HTML Abstract.'>";
                                } else {
                                    echo "<img src='../sw_asset/img/ind_html_yes.png' width=24 alt='Click to view' title='HTML Full Text.'>";
                                }
                            }

                            if ($link2 <> null) {
                                $link2 = urldecode($link2);
                                if (substr($link2, 0, 4) != 'http') {$link2 = 'http://'.$link2;}
                                echo " <a href='$link2' target='_blank'><img src='../sw_asset/img/ind_url_yes.png' width=24 alt='Click to view' title='Quick access to online version of this material.'></a>";
                            }
                                                
                            if (is_file("$system_docs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf")) {
                                echo " <a href='$system_docs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf' target='_blank'><img src='sw_asset/img/ind_pdf_yes.png' width=24 alt='Click to view' title='PDF Available.'></a>";
                            }
    
                            if (is_file("$system_albums_directory/$dir_year2/$id2"."_"."$instimestamp2.jpg")) {
                                echo " <img width=24 src='../sw_asset/img/ind_image_yes.png' alt='Click to view' title='Photo Available'>";
                            }
                                                    
                            if ($pdfattach_fulltext2 != '') {
                                echo " <img src='../sw_asset/img/ind_pdf_yes_indexed.png' width=24 alt='Click to view' title='PDF contents indexed in the database.'>";
                            }

                            if (is_file("$system_pdocs_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf")) {
                                echo " <img src='../sw_asset/img/ind_pdf_yes_g.png' width=24 alt='Click to view' title='Guest File Available.'>";
                            }

                            //for handling freetype
                            if (is_dir("$system_isofile_directory/$dir_year2")) {
                                $files_scanned = scandir("$system_isofile_directory/$dir_year2");
                                foreach ($files_scanned as $fileitem) {
                                    if (preg_match("/$id2"."_"."$instimestamp2/i", $fileitem) == 1) {
                                        echo " <img src='../sw_asset/img/ind_general_file.png' width=24 alt='Click to view' title='$system_isofile_name Available'>";
                                        break;
                                    }
                                }
                            }
                            
                            if ($reference2 != '') {echo " <img src='../sw_asset/img/ind_reference_yes.png' width=24 alt='Click to view' title='Reference is entered.'>";}
                            
                            //show locked icon for item unpermitted for current user
                            if (((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) && $folderid2 != 0) {
                                $auth_user = $_SESSION[$ssn.'username'] ?? $_SESSION[$ssn.'username_guest'];
                                $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$folderid2'";
                                $result_user = mysqli_query($GLOBALS["conn"], $query_user);
                                if (mysqli_num_rows($result_user) != 1) {
                                    echo " <img src='../sw_asset/img/cu_locked.png' width=24 alt='Click to view' title='Item locked to you.'>";
                                }
                            }
                        }
                        if ($item_status2 == '0') {echo "<br/><em>Item is undiscoverable.</em>";}
                    echo "</td>";
                                                    
                    echo "<td style='vertical-align:top;font-size:10px;' width=100>";
                        switch ($status2) {
                            case 'AVAILABLE' : $colorStatus = 'green'; break;
                            case 'FINALPROCESSING' : $colorStatus = 'blue'; break;
                            case 'EMBARGO' : $colorStatus = 'red'; break;
                            default: $colorStatus = 'orange'; break;
                        }
                        echo "<span style='color:$colorStatus;'>$status2</span>
                                <br/>
                                <strong><span style='color:black;'>Added by :</span>
                                <br/>
                                </strong>".sfx_sGetValue("name", "eg_auth", "username", $inputby2)."
                                <br/>
                                <strong><span style='color:black;'>Date Added</span> :</strong> $inputdate2 ";
                    echo "</td>";
                
                echo "</tr>";
                $n = $n +1 ;
            }
            echo "</table>";
                                
        //start paging 3
        if ($maxPage > 1) {
            include_once '../sw_inc/paging-p3.php';
        }
    
        ?>
    </div>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
