/***********************************************
 Fool-Proof Date Input Script with DHTML Calendar
 by Jason Moon - http://calendar.moonscript.com/dateinput.cfm

 Modernized by Khairul Asyrani and ChatGPT
 ************************************************/

// Customizable variables
const DefaultDateFormat = 'MM/DD/YYYY'; // If no date format is supplied, this will be used instead
const HideWait = 3; // Number of seconds before the calendar will disappear
const Y2kPivotPoint = 76; // 2-digit years before this point will be created in the 21st century
const UnselectedMonthText = ''; // Text to display in the 1st month list item when the date isn't required
const FontSize = 11; // In pixels
const FontFamily = 'Tahoma';
const CellWidth = 35;//ubah nilai ini jika css datangkan masalah
const CellHeight = 16;
const ImageURL = '../sw_asset/img/cal_calendar.gif';
const NextURL = '../sw_asset/img/cal_next.gif';
const PrevURL = '../sw_asset/img/cal_prev.gif';
const CalBGColor = 'white';
const TopRowBGColor = 'buttonface';
const DayBGColor = 'lightgrey';

// Global variables
let ZCounter = 100;
let Today = new Date();
let WeekDays = new Array('S','M','T','W','T','F','S');
let MonthDays = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
let MonthNames = new Array('January','February','March','April','May','June','July','August','September','October','November','December');

// Write out the stylesheet definition for the calendar
document.writeln('<style>');
document.writeln('td.calendarDateInput {letter-spacing:normal;line-height:normal;font-family:' + FontFamily + ',Sans-Serif;font-size:' + FontSize + 'px;}');
document.writeln('select.calendarDateInput {letter-spacing:.06em;font-family:Verdana,Sans-Serif;font-size:11px;}');
document.writeln('input.calendarDateInput {letter-spacing:.06em;font-family:Verdana,Sans-Serif;font-size:11px;}');
document.writeln('</style>');


// Only allows certain keys to be used in the date field
function YearDigitsOnly(e) {
   let KeyCode = (e.keyCode) ? e.keyCode : e.which;
   return ((KeyCode == 8) // backspace
        || (KeyCode == 9) // tab
        || (KeyCode == 37) // left arrow
        || (KeyCode == 39) // right arrow
        || (KeyCode == 46) // delete
        || ((KeyCode > 47) && (KeyCode < 58)) // 0 - 9
   );
}

// Gets the absolute pixel position of the supplied element
function GetTagPixels(StartTag, Direction) {
   let PixelAmt = (Direction == 'LEFT') ? StartTag.offsetLeft : StartTag.offsetTop;
   while ((StartTag.tagName != 'BODY') && (StartTag.tagName != 'HTML')) {
      StartTag = StartTag.offsetParent;
      PixelAmt += (Direction == 'LEFT') ? StartTag.offsetLeft : StartTag.offsetTop;
   }
   return PixelAmt;
}

// Is the specified select-list behind the calendar?
function BehindCal(SelectList, CalLeftX, CalRightX, CalTopY, CalBottomY, ListTopY) {
   let ListLeftX = GetTagPixels(SelectList, 'LEFT');
   let ListRightX = ListLeftX + SelectList.offsetWidth;
   let ListBottomY = ListTopY + SelectList.offsetHeight;
   return (((ListTopY < CalBottomY) && (ListBottomY > CalTopY)) && ((ListLeftX < CalRightX) && (ListRightX > CalLeftX)));
}

// Sets the form elements after a day has been picked from the calendar
function PickDisplayDay(ClickedDay) {
   this.show();
   let MonthList = this.getMonthList();
   let DayList = this.getDayList();
   let YearField = this.getYearField();
   FixDayList(DayList, GetDayCount(this.displayed.yearValue, this.displayed.monthIndex));
   // Select the month and day in the lists
   for (let i=0;i<MonthList.length;i++) {
      if (MonthList.options[i].value == this.displayed.monthIndex) MonthList.options[i].selected = true;
   }
   for (let j=1;j<=DayList.length;j++) {
      if (j == ClickedDay) DayList.options[j-1].selected = true;
   }
   this.setPicked(this.displayed.yearValue, this.displayed.monthIndex, ClickedDay);
   // Change the year, if necessary
   YearField.value = this.picked.yearPad;
   YearField.defaultValue = YearField.value;
}

// Builds the HTML for the calendar days -start
   function BuildCalendarDays() {
      const Rows = calculateRows(this.displayed.dayCount, this.displayed.firstDay);
      let HTML = '<table width="' + (CellWidth * 7) + '" cellspacing="0" cellpadding="1" style="cursor:default">';
      for (let j = 0; j < Rows; j++) {
         HTML += buildTableRow(j, this.displayed, this.picked, this.objName);
      }
      return HTML + '</table>';
   }

   function calculateRows(dayCount, firstDay) {
      if (((dayCount == 31) && (firstDay > 4)) || ((dayCount == 30) && (firstDay == 6))) return 6;
      else if ((dayCount == 28) && (firstDay == 0)) return 4;
      return 5;
   }

   function buildTableRow(rowIndex, displayed, picked, objName) {
      let HTML = '<tr>';
      for (let i = 1; i <= 7; i++) {
         let Day = (rowIndex * 7) + (i - displayed.firstDay);
         HTML += buildTableCell(Day, displayed, picked, objName);
      }
      return HTML + '</tr>';
   }

   function buildTableCell(Day, displayed, picked, objName) {
      if (Day >= 1 && Day <= displayed.dayCount) {
         let { TextStyle, BackColor } = getCellStyle(Day, displayed, picked);
         if (isToday(displayed, Day)) TextStyle += 'border:1px solid darkred;padding:0px;';
         return `<td align="center" class="calendarDateInput" style="cursor:default;height:${CellHeight};width:${CellWidth};${TextStyle};background-color:${BackColor}" onClick="${objName}.pickDay(${Day})" onMouseOver="return ${objName}.displayed.dayHover(this,true,'${BackColor}',${Day})" onMouseOut="return ${objName}.displayed.dayHover(this,false,'${BackColor}')">${Day}</td>`;
      } else {
         return `<td class="calendarDateInput" style="height:${CellHeight}">&nbsp;</td>`;
      }
   }

   function getCellStyle(Day, displayed, picked) {
      let TextStyle, BackColor;
      if (displayed.yearValue == picked.yearValue && displayed.monthIndex == picked.monthIndex && Day == picked.day) {
         TextStyle = 'color:white;font-weight:bold;';
         BackColor = DayBGColor;
      } else {
         TextStyle = 'color:black;';
         BackColor = CalBGColor;
      }
      return { TextStyle, BackColor };
   }

   function isToday(displayed, Day) {
      return displayed.yearValue == Today.getFullYear() && displayed.monthIndex == Today.getMonth() && Day == Today.getDate();
   }
// Builds the HTML for the calendar days -end

// Determines which century to use (20th or 21st) when dealing with 2-digit years
function GetGoodYear(YearDigits) {
   if (YearDigits.length == 4) return YearDigits;
   else {
      let Millennium = (YearDigits < Y2kPivotPoint) ? 2000 : 1900;
      return Millennium + parseInt(YearDigits,10);
   }
}

// Returns the number of days in a month (handles leap-years)
function GetDayCount(SomeYear, SomeMonth) {
   return ((SomeMonth == 1) && ((SomeYear % 400 == 0) || ((SomeYear % 4 == 0) && (SomeYear % 100 != 0)))) ? 29 : MonthDays[SomeMonth];
}

// Highlights the buttons
function VirtualButton(Cell, ButtonDown) {
   if (ButtonDown) {
      Cell.style.borderLeft = 'buttonshadow 0px none';
      Cell.style.borderTop = 'buttonshadow 0px none';
      Cell.style.borderBottom = 'buttonhighlight 0px none';
      Cell.style.borderRight = 'buttonhighlight 0px none';
   }
   else {
      Cell.style.borderLeft = 'buttonhighlight 0px none';
      Cell.style.borderTop = 'buttonhighlight 0px none';
      Cell.style.borderBottom = 'buttonshadow 0px none';
      Cell.style.borderRight = 'buttonshadow 0px none';
   }
}

// Mouse-over for the previous/next month buttons -start
   function NeighborHover(Cell, Over, DateObj) {
      if (Over) {
         VirtualButton(Cell, false);
      }
      else {
         Cell.style.border = 'buttonface 0px none';
      }
      return true;
   }

   // Adds/removes days from the day list, depending on the month/year
   function FixDayList(DayList, NewDays) {
      let DayPick = DayList.selectedIndex + 1;

      if (NewDays !== DayList.length) {
         let OldSize = DayList.length;
         
         // Adjust the size of the DayList
         for (let k = Math.min(NewDays, OldSize); k < Math.max(NewDays, OldSize); k++) {
            if (k >= NewDays) {
               // Remove extra options
               DayList.options[k] = null;
            } else {
               // Add new options
               DayList.options[k] = new Option(k + 1, k + 1);
            }
         }
         
         // Adjust the selection index
         DayPick = Math.min(DayPick, NewDays);
         if (DayPick > 0) {
            DayList.options[DayPick - 1].selected = true;
         }
      }
      
      return DayPick;
   }
// Mouse-over for the previous/next month buttons -end

// Resets the year to its previous valid value when something invalid is entered
function FixYearInput(YearField) {
   let YearRE = new RegExp('\\d{' + YearField.defaultValue.length + '}');
   if (!YearRE.test(YearField.value)) YearField.value = YearField.defaultValue;
}

// Displays a message in the status bar when hovering over the calendar icon
function CalIconHover(Over) {
   return true;
}

// Starts the timer over from scratch
function CalTimerReset() {
   eval('clearTimeout(' + this.timerID + ')');
   eval(this.timerID + '=setTimeout(\'' + this.objName + '.show()\',' + (HideWait * 1000) + ')');
}

// The timer for the calendar
function DoTimer(CancelTimer) {
   if (CancelTimer) eval('clearTimeout(' + this.timerID + ')');
   else {
      eval(this.timerID + '=null');
      this.resetTimer();
   }
}

// Show or hide the calendar
function ShowCalendar() {
   let StopTimer;
   if (this.isShowing()) {
      StopTimer = true;
      this.getCalendar().style.zIndex = --ZCounter;
      this.getCalendar().style.visibility = 'hidden';
   }
   else {
      StopTimer = false;
      this.getCalendar().style.zIndex = ++ZCounter;
      this.getCalendar().style.visibility = 'visible';
   }
   this.handleTimer(StopTimer);
}

// Hides the input elements when the "blank" month is selected
function SetElementStatus(Hide) {
   this.getDayList().style.visibility = (Hide) ? 'hidden' : 'visible';
   this.getYearField().style.visibility = (Hide) ? 'hidden' : 'visible';
   this.getCalendarLink().style.visibility = (Hide) ? 'hidden' : 'visible';
}

// Sets the date, based on the month selected
function CheckMonthChange(MonthList) {
   let DayList = this.getDayList();
   if (MonthList.options[MonthList.selectedIndex].value == '') {
      DayList.selectedIndex = 0;
      this.hideElements(true);
      this.setHidden('');
   }
   else {
      this.hideElements(false);
      if (this.isShowing()) {
         this.resetTimer(); // Gives the user more time to view the calendar with the newly-selected month
         this.getCalendar().style.zIndex = ++ZCounter; // Make sure this calendar is on top of any other calendars
      }
      let DayPick = FixDayList(DayList, GetDayCount(this.picked.yearValue, MonthList.options[MonthList.selectedIndex].value));
      this.setPicked(this.picked.yearValue, MonthList.options[MonthList.selectedIndex].value, DayPick);
   }
}

// Sets the date, based on the day selected
function CheckDayChange(DayList) {
   if (this.isShowing()) this.show();
   this.setPicked(this.picked.yearValue, this.picked.monthIndex, DayList.selectedIndex+1);
}

// Changes the date when a valid year has been entered
function CheckYearInput(YearField) {
   if ((YearField.value.length == YearField.defaultValue.length) && (YearField.defaultValue != YearField.value)) {
      if (this.isShowing()) {
         this.resetTimer(); // Gives the user more time to view the calendar with the newly-entered year
         this.getCalendar().style.zIndex = ++ZCounter; // Make sure this calendar is on top of any other calendars
      }
      let NewYear = GetGoodYear(YearField.value);
      let NewDay = FixDayList(this.getDayList(), GetDayCount(NewYear, this.picked.monthIndex));
      this.setPicked(NewYear, this.picked.monthIndex, NewDay);
      YearField.defaultValue = YearField.value;
   }
}

// Holds characteristics about a date
function dateObject() {
   let ParentObject,ArgumentStart;
   if (Function.call) { // Used when 'call' method of the Function object is supported
      ParentObject = this;
      ArgumentStart = 0;
   }
   else { // Used with 'call' method of the Function object is NOT supported
      ParentObject = arguments[0];
      ArgumentStart = 1;
   }
   ParentObject.date = (arguments.length == (ArgumentStart+1)) ? new Date(arguments[ArgumentStart+0]) : new Date(arguments[ArgumentStart+0], arguments[ArgumentStart+1], arguments[ArgumentStart+2]);
   ParentObject.yearValue = ParentObject.date.getFullYear();
   ParentObject.monthIndex = ParentObject.date.getMonth();
   ParentObject.monthName = MonthNames[ParentObject.monthIndex];
   ParentObject.fullName = ParentObject.monthName + ' ' + ParentObject.yearValue;
   ParentObject.day = ParentObject.date.getDate();
   ParentObject.dayCount = GetDayCount(ParentObject.yearValue, ParentObject.monthIndex);
   let FirstDate = new Date(ParentObject.yearValue, ParentObject.monthIndex, 1);
   ParentObject.firstDay = FirstDate.getDay();
}

// Keeps track of the date that goes into the hidden field
function StoredMonthObject(DateFormat, DateYear, DateMonth, DateDay) {
   let Delimiter;
   (Function.call) ? dateObject.call(this, DateYear, DateMonth, DateDay) : dateObject(this, DateYear, DateMonth, DateDay);
   this.yearPad = this.yearValue.toString();
   this.monthPad = (this.monthIndex < 9) ? '0' + String(this.monthIndex + 1) : this.monthIndex + 1;
   this.dayPad = (this.day < 10) ? '0' + this.day.toString() : this.day;
   this.monthShort = this.monthName.substr(0, 3).toUpperCase();
   
   // Formats the year with 2 digits instead of 4
   if (DateFormat.indexOf('YYYY') == -1) this.yearPad = this.yearPad.substr(2);
   
   // Define the date-part delimiter
   if (DateFormat.indexOf('/') >= 0) Delimiter = '/';
   else if (DateFormat.indexOf('-') >= 0) Delimiter = '-';
   else Delimiter = '';

   // Determine the order of the months and days using match()
   let matchDDMon = DateFormat.match(/DD?.?((MON)|(MM?M?))/);
   let matchMonDD = DateFormat.match(/((MON)|(MM?M?))?.?DD?/);

   if (matchDDMon) {
      this.formatted = this.dayPad + Delimiter;
      this.formatted += (matchDDMon[1].length == 3) ? this.monthShort : this.monthPad;
   } 
   else if (matchMonDD) {
      this.formatted = (matchMonDD[1] && matchMonDD[1].length == 3) ? this.monthShort : this.monthPad;
      this.formatted += Delimiter + this.dayPad;
   }

   // Either prepend or append the year to the formatted date
   this.formatted = (DateFormat.substr(0, 2) == 'YY') ? this.yearPad + Delimiter + this.formatted : this.formatted + Delimiter + this.yearPad;
}


// Object for the current displayed month
function DisplayMonthObject(ParentObject, DateYear, DateMonth, DateDay) {
   (Function.call) ? dateObject.call(this, DateYear, DateMonth, DateDay) : dateObject(this, DateYear, DateMonth, DateDay);
   this.displayID = ParentObject.hiddenFieldName + '_Current_ID';
   this.getDisplay = new Function('return document.getElementById(this.displayID)');
   this.goCurrent = new Function(ParentObject.objName + '.getCalendar().style.zIndex=++ZCounter;' + ParentObject.objName + '.setDisplayed(Today.getFullYear(),Today.getMonth());');
   if (ParentObject.formNumber >= 0) this.getDisplay().innerHTML = this.fullName;
}

// Object for the previous/next buttons
function NeighborMonthObject(ParentObject, IDText, DateMS) {
   (Function.call) ? dateObject.call(this, DateMS) : dateObject(this, DateMS);
   this.buttonID = ParentObject.hiddenFieldName + '_' + IDText + '_ID';
   this.hover = new Function('C','O','NeighborHover(C,O,this)');
   this.getButton = new Function('return document.getElementById(this.buttonID)');
   this.go = new Function(ParentObject.objName + '.getCalendar().style.zIndex=++ZCounter;' + ParentObject.objName + '.setDisplayed(this.yearValue,this.monthIndex);');
   if (ParentObject.formNumber >= 0) this.getButton().title = this.monthName;
}

// Sets the currently-displayed month object
function SetDisplayedMonth(DispYear, DispMonth) {
   this.displayed = new DisplayMonthObject(this, DispYear, DispMonth, 1);
   // Creates the previous and next month objects
   this.previous = new NeighborMonthObject(this, 'Previous', this.displayed.date.getTime() - 86400000);
   this.next = new NeighborMonthObject(this, 'Next', this.displayed.date.getTime() + (86400000 * (this.displayed.dayCount + 1)));
   // Creates the HTML for the calendar
   if (this.formNumber >= 0) this.getDayTable().innerHTML = this.buildCalendar();
}

// Sets the current selected date
function SetPickedMonth(PickedYear, PickedMonth, PickedDay) {
   this.picked = new StoredMonthObject(this.format, PickedYear, PickedMonth, PickedDay);
   this.setHidden(this.picked.formatted);
   this.setDisplayed(PickedYear, PickedMonth);
}

// The calendar object
function calendarObject(DateName, DateFormat, DefaultDate) {

   /* Properties */
   this.hiddenFieldName = DateName;
   this.monthListID = DateName + '_Month_ID';
   this.dayListID = DateName + '_Day_ID';
   this.yearFieldID = DateName + '_Year_ID';
   this.monthDisplayID = DateName + '_Current_ID';
   this.calendarID = DateName + '_ID';
   this.dayTableID = DateName + '_DayTable_ID';
   this.calendarLinkID = this.calendarID + '_Link';
   this.timerID = this.calendarID + '_Timer';
   this.objName = DateName + '_Object';
   this.format = DateFormat;
   this.formNumber = -1;
   this.picked = null;
   this.displayed = null;
   this.previous = null;
   this.next = null;

   /* Methods */
   this.setPicked = SetPickedMonth;
   this.setDisplayed = SetDisplayedMonth;
   this.checkYear = CheckYearInput;
   this.fixYear = FixYearInput;
   this.changeMonth = CheckMonthChange;
   this.changeDay = CheckDayChange;
   this.resetTimer = CalTimerReset;
   this.hideElements = SetElementStatus;
   this.show = ShowCalendar;
   this.handleTimer = DoTimer;
   this.iconHover = CalIconHover;
   this.buildCalendar = BuildCalendarDays;
   this.pickDay = PickDisplayDay;
   this.setHidden = new Function('D','if (this.formNumber >= 0) this.getHiddenField().value=D');
   // Returns a reference to these elements
   this.getHiddenField = new Function('return document.forms[this.formNumber].elements[this.hiddenFieldName]');
   this.getMonthList = new Function('return document.getElementById(this.monthListID)');
   this.getDayList = new Function('return document.getElementById(this.dayListID)');
   this.getYearField = new Function('return document.getElementById(this.yearFieldID)');
   this.getCalendar = new Function('return document.getElementById(this.calendarID)');
   this.getDayTable = new Function('return document.getElementById(this.dayTableID)');
   this.getCalendarLink = new Function('return document.getElementById(this.calendarLinkID)');
   this.getMonthDisplay = new Function('return document.getElementById(this.monthDisplayID)');
   this.isShowing = new Function('return !(this.getCalendar().style.visibility != \'visible\')');

   /* Constructor */
   // Functions used only by the constructor
   function getMonthIndex(MonthAbbr) {
      let index = 0;
      for (const month of MonthNames) {
         if (month.slice(0, 3).toUpperCase() === MonthAbbr.toUpperCase()) {
            return index;
         }
         index++;
      }
      return -1; // Return -1 if the month abbreviation is not found
   }
   function SetGoodDate(CalObj, Notify) { // Notifies the user about their bad default date, and sets the current system date
      CalObj.setPicked(Today.getFullYear(), Today.getMonth(), Today.getDate());
      if (Notify) alert('WARNING: The supplied date is not in valid \'' + DateFormat + '\' format: ' + DefaultDate + '.\nTherefore, the current system date will be used instead: ' + CalObj.picked.formatted);
   }
   // Main part of the constructor
   if (DefaultDate != '') {
      if ((this.format == 'YYYYMMDD') && (/^(\d{4})(\d{2})(\d{2})$/.test(DefaultDate))) this.setPicked(RegExp.$1, parseInt(RegExp.$2,10)-1, RegExp.$3);
      else {
         // Get the year
         if ((this.format.substr(0,2) == 'YY') && (/^(\d{2,4}[/-])/.test(DefaultDate))) { // Year is at the beginning
            let YearPart = GetGoodYear(RegExp.$1);
            // Determine the order of the months and days
            if (/([/-])(\w{1,3})([/-])(\w{1,3})$/.test(DefaultDate)) {
               const regex = /(-|\/)(\w{1,3})(-|\/)(\w{1,3})$/;
               const match = regex.exec(DefaultDate);
               let MidPart = match[2];
               let EndPart = match[4];
               let DayPart,MonthPart;
               if (this.format.endsWith('D')) { // Ends with days
                  DayPart = EndPart;
                  MonthPart = MidPart;
               }
               else {
                  DayPart = MidPart;
                  MonthPart = EndPart;
               }
               MonthPart = (/\d{1,2}/i.test(MonthPart)) ? parseInt(MonthPart,10)-1 : getMonthIndex(MonthPart);
               this.setPicked(YearPart, MonthPart, DayPart);
            }
            else SetGoodDate(this, true);
         }
         else if (/(-|\/)(\d{2,4})$/.test(DefaultDate)) { // Year is at the end
            let match = /(-|\/)(\d{2,4})$/.exec(DefaultDate);
            let YearPart = GetGoodYear(match[2]);
            // Determine the order of the months and days
            if (/^(\w{1,3})(-|\/)(\w{1,3})(-|\/)/.test(DefaultDate)) {
                match = /^(\w{1,3})(-|\/)(\w{1,3})(-|\/)/.exec(DefaultDate);
                let DayPart, MonthPart;
                if (this.format.substr(0,1) === 'D') { // Starts with days
                    DayPart = match[1];
                    MonthPart = match[3];
                } else { // Starts with months
                    MonthPart = match[1];
                    DayPart = match[3];
                }
                MonthPart = (/\d{1,2}/i.test(MonthPart)) ? parseInt(MonthPart, 10) - 1 : getMonthIndex(MonthPart);
                this.setPicked(YearPart, MonthPart, DayPart);
            } else {
                SetGoodDate(this, true);
            }
        }        
         else SetGoodDate(this, true);
      }
   }
}

// Main function that creates the form elements
function DateInput(DateName, Required, DateFormat, DefaultDate) {
   if (arguments.length == 0) document.writeln('<span style="color:red;font-size:' + FontSize + 'px;font-family:' + FontFamily + ';">ERROR: Missing required parameter in call to \'DateInput\': [name of hidden date field].</span>');
   else {
      // Handle DateFormat
      if (arguments.length < 3) { // The format wasn't passed in, so use default
         DateFormat = DefaultDateFormat;
         if (arguments.length < 2) Required = false;
      }
      else if (/^(Y{2,4}(-|\/)?)?((MON)|(MM?M?)|(DD?))(-|\/)?((MON)|(MM?M?)|(DD?))((-|\/)Y{2,4})?$/i.test(DateFormat)) DateFormat = DateFormat.toUpperCase();
      else { // Passed-in DateFormat was invalid, use default format instead
         let AlertMessage = 'WARNING: The supplied date format for the \'' + DateName + '\' field is not valid: ' + DateFormat + '\nTherefore, the default date format will be used instead: ' + DefaultDateFormat;
         DateFormat = DefaultDateFormat;
         if (arguments.length == 4) { // DefaultDate was passed in with an invalid date format
            let CurrentDate = new StoredMonthObject(DateFormat, Today.getFullYear(), Today.getMonth(), Today.getDate());
            AlertMessage += '\n\nThe supplied date (' + DefaultDate + ') cannot be interpreted with the invalid format.\nTherefore, the current system date will be used instead: ' + CurrentDate.formatted;
            DefaultDate = CurrentDate.formatted;
         }
         alert(AlertMessage);
      }
      // Define the current date if it wasn't set already
      let CurrentDate;
      if (!CurrentDate) CurrentDate = new StoredMonthObject(DateFormat, Today.getFullYear(), Today.getMonth(), Today.getDate());
      // Handle DefaultDate
      if (arguments.length < 4) { // The date wasn't passed in
         DefaultDate = (Required) ? CurrentDate.formatted : ''; // If required, use today's date
      }
      // Creates the calendar object!
      eval(DateName + '_Object=new calendarObject(\'' + DateName + '\',\'' + DateFormat + '\',\'' + DefaultDate + '\')');
      // Determine initial viewable state of day, year, and calendar icon
      let InitialStatus,InitialDate;
      if ((Required) || (arguments.length == 4)) {
         InitialStatus = '';
         InitialDate = eval(DateName + '_Object.picked.formatted');
      }
      else {
         InitialStatus = ' style="visibility:hidden"';
         InitialDate = '';
         eval(DateName + '_Object.setPicked(' + Today.getFullYear() + ',' + Today.getMonth() + ',' + Today.getDate() + ')');
      }
      // Create the form elements
      // Tanpa penggunaan 'with', semua rujukan kepada 'document' dinyatakan secara eksplisit.
      document.writeln('<input type="hidden" name="' + DateName + '" value="' + InitialDate + '">');

      // Cari nombor borang ini
      for (let form of document.forms) {
         for (let element of form.elements) {
            if (typeof element.type == 'string') {
               if (element.type === 'hidden' && element.name === DateName) {
                  eval(DateName + '_Object.formNumber=' + Array.prototype.indexOf.call(document.forms, form));
                  break;
               }
            }
         }
      }
      
      document.writeln('<table cellpadding="0" cellspacing="2"><tr>' + String.fromCharCode(13) + '<td valign="middle">');
      document.writeln('<select class="calendarDateInput" id="' + DateName + '_Month_ID" onChange="' + DateName + '_Object.changeMonth(this)">');

      if (!Required) {
         let NoneSelected = (DefaultDate == '') ? ' selected' : '';
         document.writeln('<option value=""' + NoneSelected + '>' + UnselectedMonthText + '</option>');
      }

      for (let i = 0; i < 12; i++) {
         let MonthSelected = ((DefaultDate != '') && (eval(DateName + '_Object.picked.monthIndex') == i)) ? ' selected' : '';
         document.writeln('<option value="' + i + '"' + MonthSelected + '>' + MonthNames[i].slice(0, 3) + '</option>');
      }

      document.writeln('</select>' + String.fromCharCode(13) + '</td>' + String.fromCharCode(13) + '<td valign="middle">');
      document.writeln('<select' + InitialStatus + ' class="calendarDateInput" id="' + DateName + '_Day_ID" onChange="' + DateName + '_Object.changeDay(this)">');

      for (let j = 1; j <= eval(DateName + '_Object.picked.dayCount'); j++) {
         let DaySelected = ((DefaultDate != '') && (eval(DateName + '_Object.picked.day') == j)) ? ' selected' : '';
         document.writeln('<option' + DaySelected + '>' + j + '</option>');
      }

      document.writeln('</select>' + String.fromCharCode(13) + '</td>' + String.fromCharCode(13) + '<td valign="middle">');

      document.writeln('<input' + InitialStatus + ' class="calendarDateInput" type="text" id="' + DateName + '_Year_ID" size="' + eval(DateName + '_Object.picked.yearPad.length') + '" maxlength="' + eval(DateName + '_Object.picked.yearPad.length') + '" title="Year" value="' + eval(DateName + '_Object.picked.yearPad') + '" onKeyPress="return YearDigitsOnly(window.event)" onKeyUp="' + DateName + '_Object.checkYear(this)" onBlur="' + DateName + '_Object.fixYear(this)">');

      document.write('<td valign="middle">' + String.fromCharCode(13) + '<a' + InitialStatus + ' id="' + DateName + '_ID_Link" href="javascript:' + DateName + '_Object.show()" onMouseOver="return ' + DateName + '_Object.iconHover(true)" onMouseOut="return ' + DateName + '_Object.iconHover(false)"><img src="' + ImageURL + '" align="baseline" title="Calendar" border="0"></a>&nbsp;');

      document.writeln('<span id="' + DateName + '_ID" style="position:absolute;visibility:hidden;width:' + (CellWidth * 7) + 'px;background-color:' + CalBGColor + ';border:0px none dimgray;" onMouseOver="' + DateName + '_Object.handleTimer(true)" onMouseOut="' + DateName + '_Object.handleTimer(false)">');
      document.writeln('<table border=0 width="' + (CellWidth * 7) + '" cellspacing="0" cellpadding="1">' + String.fromCharCode(13) + '<tr style="background-color:' + TopRowBGColor + ';">');

      document.writeln('<td id="' + DateName + '_Previous_ID" style="cursor:default" align="center" class="calendarDateInput" style="height:' + CellHeight + '" onClick="' + DateName + '_Object.previous.go()" onMouseDown="VirtualButton(this,true)" onMouseUp="VirtualButton(this,false)" onMouseOver="return ' + DateName + '_Object.previous.hover(this,true)" onMouseOut="return ' + DateName + '_Object.previous.hover(this,false)" title="' + eval(DateName + '_Object.previous.monthName') + '"><img src="' + PrevURL + '"></td>');

      document.writeln('<td colspan="5" id="' + DateName + '_Current_ID" style="cursor:pointer" align="center" class="calendarDateInput" style="height:' + CellHeight + '" onClick="' + DateName + '_Object.displayed.goCurrent()"' + eval(DateName + '_Object.displayed.fullName') + '</td>');

      document.writeln('<td id="' + DateName + '_Next_ID" style="cursor:default" align="center" class="calendarDateInput" style="height:' + CellHeight + '" onClick="' + DateName + '_Object.next.go()" onMouseDown="VirtualButton(this,true)" onMouseUp="VirtualButton(this,false)" onMouseOver="return ' + DateName + '_Object.next.hover(this,true)" onMouseOut="return ' + DateName + '_Object.next.hover(this,false)" title="' + eval(DateName + '_Object.next.monthName') + '"><img src="' + NextURL + '"></td></tr>' + String.fromCharCode(13) + '<tr>');

      for (let w = 0; w < 7; w++) {
         document.writeln('<td width="' + CellWidth + '" align="center" class="calendarDateInput" style="height:' + CellHeight + ';width:' + CellWidth + ';font-weight:bold;border-top:0px none dimgray;border-bottom:0px none dimgray;">' + WeekDays[w] + '</td>');
      }

      document.writeln('</tr>' + String.fromCharCode(13) + '</table>' + String.fromCharCode(13) + '<span id="' + DateName + '_DayTable_ID">' + eval(DateName + '_Object.buildCalendar()') + '</span>' + String.fromCharCode(13) + '</span>' + String.fromCharCode(13) + '</td>' + String.fromCharCode(13) + '</tr>' + String.fromCharCode(13) + '</table>');

   }
}