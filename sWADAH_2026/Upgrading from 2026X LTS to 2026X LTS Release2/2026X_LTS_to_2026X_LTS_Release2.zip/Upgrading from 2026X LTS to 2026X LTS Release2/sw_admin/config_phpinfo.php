<?php
/*
Filename: sw_splus/config_phpinfo.php
Usage: Show phpinfo() in a controlled admin environment
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "PHP Info";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/access_super.php';
?>

<html lang='en'>

<head><title>PHP Info</title></head>

<body>
    <?php phpinfo();?>
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
