<?php
/*
Filename: sw_admin/details.php
Usage: Detail page for admins
Version: 20250101.0801
Last change:
20250201.0000 -
fix error when generating watermark file at line 386
*/
?>
<!DOCTYPE HTML>
<?php
    
    $thisPageTitle = "Item Details";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    
    $get_id_det = (isset($_GET["det"]) && is_numeric($_GET["det"])) ? $_GET["det"] : 0;
    $get_scstr = isset($_SESSION[$ssn.'sear_scstr']) ? $_SESSION[$ssn.'sear_scstr'] : "";
        
    $stmt_item = $new_conn->prepare("select * from eg_item where id=?");
    $stmt_item->bind_param("i", $get_id_det);
    $stmt_item->execute();
    $result_item = $stmt_item->get_result();
    $num_results_affected = $result_item->num_rows;
    $myrow_item = $result_item->fetch_assoc();
    if ($num_results_affected == 1) {
        $id5 = $myrow_item["id"];
        $folderid5 = $myrow_item["38folderid"];
        $titlestatement5 = $myrow_item["38title"];
        $typestatement5 = $myrow_item["38typeid"];
        $status5 = $myrow_item["38status"];
        $location5 = $myrow_item["38location"];
        $link5 = $myrow_item["38link"];

        $authorname5 = $myrow_item["38author"];
        $callnumber5 = $myrow_item["38localcallnum"];
        $langcode5 = $myrow_item["38langcode"];
        $inputdate5 = $myrow_item["39inputdate"];
            $dir_year5 = substr("$inputdate5", 0, 4);
        $input_by5 = $myrow_item["39inputby"];
        $input_by5 = $myrow_item["39inputby"];
        $lastupdateby5 = $myrow_item["40lastupdateby"];
        $lastupdatetimestamp5 = $myrow_item["40lastupdatetimestamp"];
            $lastupdatetimestamp5 = (is_numeric($lastupdatetimestamp5) && (int)$lastupdatetimestamp5 > 0) ? (int)$lastupdatetimestamp5 : mktime(0, 0, 0, 11, 29, 1922);
        $fulltext5 = $myrow_item["41fulltexta"];
        $reference5 = $myrow_item["41reference"];
        $isabstract5 = $myrow_item["41isabstract"];
        $pdfattach_fulltext5 = $myrow_item["41pdfattach_fulltext"];
        $instimestamp5 = $myrow_item["41instimestamp"];
        $subjectheading5 = $myrow_item["41subjectheading"];
        $accessnum5 = $myrow_item["38accessnum"];
        $isbn5 = $myrow_item["38isbn"];
        $issn5 = $myrow_item["38issn"];
        $edition5 = $myrow_item["38edition"];
        $publication5 = $myrow_item["38publication"];
        $physicaldesc5 = $myrow_item["38physicaldesc"];
        $series5 = $myrow_item["38series"];
        $notes5 = $myrow_item["38notes"];
        $source5 = $myrow_item["38source"];
        $item_status5 = $myrow_item["50item_status"];
        $pagecount5 = $myrow_item["51_pagecount"];
        $embargo_timestamp5 = $myrow_item["51_embargo_timestamp"];

        $deletereq5 = $myrow_item["39proposedelete"];
        $deletereq_by5 = $myrow_item["39proposedeleteby"];
        $deletereq_reason5 = $myrow_item["39proposedelete_reason"];

        $query_item_ex = "select * from eg_item2 where eg_item_id=$id5";
        $result_item_ex = mysqli_query($GLOBALS["conn"], $query_item_ex);
            $is_data_available = mysqli_num_rows($result_item_ex) >= 1;
            $myrow_item_ex = $is_data_available ? mysqli_fetch_array($result_item_ex) : [];
            $isbn5_c = $is_data_available ? $myrow_item_ex["38_terms_of_availability"] : '0.00';
            $titlestatement5_b = $myrow_item_ex["38title_b"] ?? '';
            $titlestatement5_c = $myrow_item_ex["38title_c"] ?? '';
            $publication5_b = $myrow_item_ex["38publication_b"] ?? '';
            $publication5_c = $myrow_item_ex["38publication_c"] ?? '';
            $vtitle5_a = $myrow_item_ex["38vtitle_a"] ?? '';
            $vtitle5_b = $myrow_item_ex["38vtitle_b"] ?? '';
            $vtitle5_g = $myrow_item_ex["38vtitle_g"] ?? '';
            $summary5_a = $myrow_item_ex["38summary_a"] ?? '';
            $se_pname5_a = $myrow_item_ex["38se_pname_a"] ?? '';
            $se_pname5_x = $myrow_item_ex["38se_pname_x"] ?? '';
            $se_pname5_y = $myrow_item_ex["38se_pname_y"] ?? '';
            if ($myrow_item_ex["38pname1"] != '') {
                $additional_authors = "<li>".$myrow_item_ex["38pname1"]."</li>" ?? '';
                if ($additional_authors) {
                    for ($i = 2; $i <= 10; $i++) {
                        if (!empty($myrow_item_ex["38pname$i"])) {
                            $additional_authors .= "<li>" . $myrow_item_ex["38pname$i"]."</li>";
                        }
                    }
                }
            } else {
                $additional_authors = "";
            }

            //new 20240924
            $geographic_coverage_note5_a=$myrow_item_ex["38geographic_coverage_note_a"] ?? '';
            $original_version_note5_t=$myrow_item_ex["38original_version_note_t"] ?? '';
            $terms_governing_use5_a=$myrow_item_ex["38terms_governing_use_a"] ?? '';
            $other_relationship_entry5_n=$myrow_item_ex["38other_relationship_entry_n"] ?? '';

        //prevent unauthorize user to view folder assigned to specific users
        if (((isset($_SESSION[$ssn.'username']) && $_SESSION[$ssn.'username'] != 'admin') || (isset($_SESSION[$ssn.'username_guest']) && $_SESSION[$ssn.'username_guest'] != 'admin')) && $folderid5 != 0) {
            if (isset($_SESSION[$ssn.'username'])) {
                $auth_user = $_SESSION[$ssn.'username'];
            } elseif (isset($_SESSION[$ssn.'username_guest'])) {
                $auth_user = $_SESSION[$ssn.'username_guest'];
            }
            
            $query_user = "select id from eg_item_folder_auth where eg_auth_username='$auth_user' and eg_item_folder_id='$folderid5'";
            $result_user = mysqli_query($GLOBALS["conn"], $query_user);
            if (mysqli_num_rows($result_user) != 1) {
                sfx_echoPopupAlert("You don't have authorization to view the content go this item.", "goback");
                mysqli_close($GLOBALS["conn"]);
                exit();
            }
        }
    }
?>

<html lang='en'>

<head>
    <?php include_once '../sw_inc/header.php'; ?>
</head>

<body class='<?php echo $color_scheme;?>'>
        
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <div style='text-align:center'>
        <?php
            //if item existed
            if ($num_results_affected == 1) {
                echo "<table class=whiteHeader><tr class=$color_scheme"."HeaderCenter><td><strong>Record Details</strong> : </td>";
                if (sfx_sGetValue("count(eg_item_id) as totalid", "eg_commercialize", "eg_item_id", $id5) == 1 && $enable_commercial_api) {
                    echo "<td style='width:100px;text-align:right;'><input type='button' class='form-orange-button-noshadow' style='font-size:8pt' value='COMMERCIAL'></td>";
                }
                echo "</tr></table>";
                
                echo "<table class=whiteHeaderNoCenter style='border: 1px solid lightgrey; max-width:100%;overflow-x: auto;' width=100%>";
                echo "<tr>";

                    echo "<td style='display: inline-block; padding: 5px;min-width:300px;max-width:350px;vertical-align:top;'>";
                        echo "<table class=whiteHeaderNoCenter width=100%>";
                            
                                if ($show_control_number) {
                                    echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Control Number :</strong></td><td style='text-align:left;vertical-align:top;'>$id5</td></tr>";
                                }
                                
                                echo "<tr>
                                    <td style='text-align:right;width:150px;max-width:150px;vertical-align:top;'><strong>Hits :</strong></td>
                                    <td style='text-align:left;vertical-align:top;max-width:70%;'><a onclick=\"return js_openPopup(this.href,900,580);\" title='Hits for $id5' target='_blank' href='../sw_stats/adsreport_ipitems.php?det=$id5'>".sfx_sGetValue("count(id) as accesshits", "eg_item_access", "eg_item_id", $id5, "i")."</a></td>
                                </tr>";
                                        
                                echo "<tr>
                                    <td style='text-align:right;vertical-align:top;'><strong>Downloads :</strong></td>
                                    <td style='text-align:left;vertical-align:top;'>".sfx_sGetValue("count(id) as downloadhits", "eg_item_download", "eg_item_id", $id5, "i")."</td>
                                </tr>";
                                
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$type_as :</strong></td><td style='text-align:left;vertical-align:top;'>".sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $typestatement5)."</td></tr>";
                                
                                if ($show_browser_bar_admin && $subjectheading5 <> null) {
                                    echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$subject_heading_as:</strong></td><td style='text-align:left;vertical-align:top;'>".sfx_getSubjectHeadingNames($subject_heading_delimiter, $subjectheading5)."</td></tr>";
                                }
                                
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Status :</strong></td><td style='text-align:left;vertical-align:top;'>";
                                    $status5_embargo_indicator = '';
                                    if ($status5 == 'EMBARGO') {
                                        if ($embargo_timestamp5 <= time()) {
                                            mysqli_query($GLOBALS["conn"], "update eg_item set 38status='AVAILABLE' where id=$id5");
                                            $status5 = 'AVAILABLE';
                                        } else {
                                            $status5_embargo_indicator = " <sup>End date: ".date("d M Y", $embargo_timestamp5)."</sup>";
                                        }
                                    }
                                    echo "$status5 $status5_embargo_indicator";
                                echo "</td></tr>";
                                
                                if ($show_accession_number) {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Accession Number :</strong></td><td style='text-align:left;vertical-align:top;'>$accessnum5</td></tr>";}
                                
                                if ($isbn5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_020 :</strong></td><td style='text-align:left;vertical-align:top;'>$isbn5</td></tr>";}
                                
                                if ($issn5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_022 :</strong></td><td style='text-align:left;vertical-align:top;'>$issn5</td></tr>";}
                                
                                if ($callnumber5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_090 :</strong></td><td style='text-align:left;vertical-align:top;'>$callnumber5</td></tr>";}
                                
                                if ($authorname5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_100 :</strong></td><td style='text-align:left;vertical-align:top;'>$authorname5</td></tr>";}
                                
                                if (isset($additional_authors) && $additional_authors != '') {
                                    echo "<tr>
                                        <td style='text-align:right;vertical-align:top;'><strong>$tag_700 :</strong></td>
                                        <td style='text-align:left;vertical-align:top;'><ul class='custom-indent'>$additional_authors</ul></td>
                                    </tr>";
                                }
                                
                                if ($se_pname5_a != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_600 :</strong></td><td style='text-align:left;vertical-align:top;'>$se_pname5_a $se_pname5_x $se_pname5_y</td></tr>";}
                                
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_245 :</strong></td><td style='text-align:left;vertical-align:top;'>$titlestatement5 $titlestatement5_b $titlestatement5_c</td></tr>";
                                
                                if ($vtitle5_a != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_246 :</strong></td><td style='text-align:left;vertical-align:top;'>$vtitle5_a $vtitle5_b $vtitle5_g</td></tr>";}
                                
                                if ($langcode5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_041 :</strong></td><td style='text-align:left;vertical-align:top;'>$langcode5</td></tr>";}

                                if ($edition5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_250 :</strong></td><td style='text-align:left;vertical-align:top;'>$edition5</td></tr>";}
                            
                        echo "</table>";
                    echo "</td>";

                    echo "<td style='display: inline-block; padding: 5px;min-width:300px;max-width:350px;vertical-align:top;'>";
                        echo "<table class=whiteHeaderNoCenter width=100%>";

                            $publication5 = $publication5 ?: "N/A";

                            echo "<tr><td style='text-align:right;vertical-align:top;width:150px;max-width:150px;'><strong>$publisher_place_of_production :</strong></td><td style='text-align:left;vertical-align:top;'>$publication5</td></tr>";
                            
                            if ($publication5_b != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$publisher_as :</strong></td><td style='text-align:left;vertical-align:top;'>$publication5_b</td></tr>";}
                            
                            if ($publication5_c != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$publisher_year_of_publication :</strong></td><td style='text-align:left;vertical-align:top;'>$publication5_c</td></tr>";}
                            
                            if ($physicaldesc5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_300 :</strong></td><td style='text-align:left;vertical-align:top;'>$physicaldesc5</td></tr>";}
                            
                            if ($series5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_490 :</strong></td><td style='text-align:left;vertical-align:top;'>$series5</td></tr>";}
                            
                            if ($notes5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_500 :</strong></td><td style='text-align:left;vertical-align:top;'>$notes5</td></tr>";}
                            
                            if ($summary5_a != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_520 :</strong></td><td style='text-align:left;vertical-align:top;'>$summary5_a</td></tr>";}
                            
                            if ($geographic_coverage_note5_a != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_522 :</strong></td><td style='text-align:left;vertical-align:top;'>$geographic_coverage_note5_a</td></tr>";}
                            if ($original_version_note5_t != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_534 :</strong></td><td style='text-align:left;vertical-align:top;'>$original_version_note5_t</td></tr>";}
                            if ($terms_governing_use5_a != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_540 :</strong></td><td style='text-align:left;vertical-align:top;'>$terms_governing_use5_a</td></tr>";}

                            if ($source5 != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_710 :</strong></td><td style='text-align:left;vertical-align:top;'>$source5</td></tr>";}

                            if ($other_relationship_entry5_n != '') {echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_787 :</strong></td><td style='text-align:left;vertical-align:top;'>$other_relationship_entry5_n</td></tr>";}
                            
                            if ($location5 != '') {
                                echo "<tr>
                                        <td style='text-align:right;vertical-align:top;'><strong>$tag_852 :</strong></td>
                                        <td style='text-align:left;vertical-align:top;'>$location5</td>
                                </tr>";
                            }

                            if ($enable_commercial_api && $isbn5_c != '') {echo "<tr><td style='text-align:right;'><strong>$tag_020_c :</strong></td><td style='text-align:left;vertical-align:top;'>$tag_020_c_currency $isbn5_c</td></tr>";}

                            if ($link5 <> null) {
                                $link5 = urldecode($link5);
                                if (substr($link5, 0, 4) != 'http') {$link5 = 'http://'.$link5;}
                                echo "<tr>
                                        <td style='text-align:right;vertical-align:top;'><strong>$tag_856 :</strong></td>
                                        <td style='text-align:left;vertical-align:top;'>";
                                            echo "<a href='$link5' target='_blank'>Click here</a>";
                                            if (isset($link5) && strpos($link5, 'youtube.com') !== false) {
                                                echo " <sup style='color:magenta;'>YOUTUBE</sup>";
                                            }
                                echo "  </td>
                                </tr>";
                                if (isset($link5) && strpos($link5, 'youtube.com') !== false && $youtube_detector) {
                                    echo "<tr><td colspan=2>";
                                    echo "<table style='width:100%;'><tr><td><div class='video-containerSmaller'>
                                            <iframe src='".sfx_convertToEmbedUrl($link5)."' allow='accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
                                        </div></td></tr></table>
                                    ";
                                    echo "</td></tr>";
                                }
                            }

                            if (is_file("../$system_pdocs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf")) {
                                echo "<tr><td style='text-align:right;vertical-align:top;'>";
                                    echo "<strong><span style='font-size:10px;color:darkred;'>PDF</span> Guest :</strong></td><td style='text-align:left;vertical-align:top;'><a href='../$system_pdocs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf' target='_blank'>$id5"."_"."$instimestamp5.pdf</a>";
                                    if ($usePdfInfo) {
                                        $pdfTotalPages = sfx_getPDFPages($appendroot, "../$system_pdocs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf");
                                        if ($pdfTotalPages == 0) {
                                            $pdfTotalPages = sfx_getPDFPagesSmalot($appendroot, "../$system_pdocs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf");
                                        }
                                        $pdfColor = ($pdfTotalPages <= $max_page_toshow_red_color) ? "red" : "blue";
                                        echo ($pdfTotalPages >= 1) ? " <sup style='color:$pdfColor;text-decoration:none;'>$pdfTotalPages page(s)</sup>" : "";
                                    }
                                    if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                                        echo " <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' href='../sw_inc/del_inst.php?defg=$id5'><i class=\"fas fa-trash\"></i></a>";
                                    }
                                echo "</td></tr>";
                            }

                            if (is_file("../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf")) {
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>PDF</span> Full Text :</strong></td><td style='text-align:left;vertical-align:top;'><a href='../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf' target='_blank'>$id5"."_"."$instimestamp5.pdf</a>";
                                    if ($pdfattach_fulltext5 != '') {
                                        echo " <sup><a style='color:#1b90ad;text-decoration:none;' target='_blank' href='../sw_inc/ft.php?det=$get_id_det'>CONTENT&nbspINDEXED</a></sup>";
                                    }

                                    if ($usePdfInfo && $pagecount5 == 0) {
                                        $pdfTotalPages = sfx_getPDFPages($appendroot, "../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf");
                                        if ($pdfTotalPages == 0) {
                                            $pdfTotalPages = sfx_getPDFPagesSmalot($appendroot, "../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf");
                                        }
                                        mysqli_query($GLOBALS["conn"], "update eg_item set 51_pagecount=$pdfTotalPages where id=$id5");
                                    } else {
                                        $pdfTotalPages = $pagecount5;
                                    }

                                    $pdfColor = ($pdfTotalPages <= $max_page_toshow_red_color) ? "red" : "blue";
                                    
                                    if ($pdfTotalPages <> 0) {
                                        echo " <sup style='color:$pdfColor;text-decoration:none;'>$pdfTotalPages page(s)</sup>";
                                    }
                                    if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                                        echo " <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' href='../sw_inc/del_inst.php?deff=$id5'><i class=\"fas fa-trash\"></i></a>";
                                    }
                                echo "</td></tr>";
                            }
                                
                            //for handling freetype
                            if (is_dir("../$system_isofile_directory/$dir_year5")) {
                                $files_scanned = scandir("../$system_isofile_directory/$dir_year5");
                                foreach ($files_scanned as $fileitem) {
                                    if (preg_match("/$id5"."_"."$instimestamp5/i", $fileitem) == 1 && !strpos($fileitem, ".deleted")) {
                                        //file found
                                        echo "<tr><td style='text-align:right;vertical-align:top;'><strong><span style='font-size:10px;color:darkred;'>$system_isofile_name</span> File :</strong></td><td style='text-align:left;vertical-align:top;'><a href='../$system_isofile_directory/$dir_year5/$fileitem' target='_blank'>$fileitem</a>";
                                        if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                                            echo " <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' href='../sw_inc/del_inst.php?deif=$id5'><i class=\"fas fa-trash\"></i></a>";
                                        }
                                        echo "</td></tr>";
                                        break;
                                    }
                                }
                            }
                            
                            //for handling related files
                            if ($enable_related_files_upload) {
                                echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Related Files :</strong>";
                                    if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                                        echo "<br/><i class='far fa-window-restore'></i> <a style='cursor:pointer;text-decoration:underline;' onclick='js_openPopup(\"../sw_inc/add_files.php?year=$dir_year5&fid=$id5"."_$instimestamp5\",800,600);'>File Browser..</a>";
                                    }
                                echo "</td>";
                                echo "<td style='text-align:left;vertical-align:top;'>";
                                        if (is_dir("../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5")) {
                                            $files = sfx_listFiles("../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5");
                                            echo "<ol style='padding-left:15px;margin-top:0px;'>";
                                            foreach ($files as $file):
                                                echo "<li>";
                                                    $accesstype = sfx_sGetValue("38accesstype", "eg_relatedfiles", "38filename", $file);
                                                    $fcolor = ($accesstype == 'restricted') ? "red" : "blue";
                                                    echo "<strong>".sfx_sGetValue("38desc", "eg_relatedfiles", "38filename", $file)."</strong>
                                                    <br/><em style='background-color:lightblue;'>".pathinfo($file, PATHINFO_EXTENSION)."</em> <span style='color:$fcolor;'>$accesstype</span><br/>";
                                                    echo "<a target='_blank' title=\"$file\" href=\"../$system_docs_directory/$dir_year5/$id5"."_"."$instimestamp5/$file\">".sfx_cutLongFileName($file)."</a>";
                                                echo "</li><br/>";
                                            endforeach;
                                            echo "</ol>";
                                        }
                                echo "</td></tr>";
                            }

                        echo "</table>";
                    echo "</td>";
                
                echo "</tr>";
                echo "</table>";

                //for handling photos
                echo "<table class=whiteHeaderNoCenter style='border: 1px solid lightgrey;'>";
                    if (is_file("../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg")) {
                            echo "<tr><td colspan=2 style='text-align:center;'><strong><u><span style='font-size:10px;color:darkred;'>JPG</span> Image :</u></strong> ";
                                if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                                    echo "[<a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' href='sw_inc/del_inst.php?defj=$id5'>Delete This Image</a>]";
                                }
                            echo "</td></tr>";
                            echo "<tr><td colspan=2 style='text-align:center;vertical-align:top;'>";
                                echo "<table style='border: 0px solid lightgrey; width:100%;overflow-x: auto;'><tr>";
                                        echo "<td style='font-size:8pt;display: inline-block; padding: 5px; width:150px;'>";
                                            echo "<strong>Original :</strong>";
                                            echo "<img class='centered-and-cropped' src='../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg?=".time()."' width=128px height=128px onerror=this.src='../sw_asset/img/no_image.png'><br/>";
                                            echo "<a onclick='return js_openPopup(this.href,800,600);' target='_blank' href='../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg' title='$titlestatement5'>Main.jpg</a>";
                                        echo "</td>";
                                    
                                    if (is_file("../$system_albums_watermark_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg")) {
                                        echo "<td style='font-size:8pt;display: inline-block; padding: 5px; width:150px;'>";
                                            echo "<strong>Watermarked :</strong>";
                                            echo "<img class='centered-and-cropped' src='../$system_albums_watermark_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg?=".time()."' width=128px height=128px onerror=this.src='../sw_asset/img/no_image.png'><br/>";
                                            echo "<a onclick='return js_openPopup(this.href,800,680);' target='_blank' href='../$system_albums_watermark_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg' title='$titlestatement5'>Main.jpg</a>";
                                        echo "</td>";
                                    }

                                    if (is_file("../$system_albums_thumbnail_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg")) {
                                        echo "<td style='font-size:8pt;display: inline-block; padding: 5px; width:150px;'>";
                                            echo "<strong>Thumbnail :</strong>";
                                            echo "<img class='centered-and-cropped' src='../$system_albums_thumbnail_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg?=".time()."' width=128px height=128px onerror=this.src='../sw_asset/img/no_image.png'><br/>";
                                            echo "<a onclick='return js_openPopup(this.href,800,600);' target='_blank' href='../$system_albums_thumbnail_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg' title='$titlestatement5'>Main.jpg</a>";
                                        echo "</td>";
                                    }
                                echo "</tr></table>";
                            echo "</td>";
                            echo "</tr>";
                    }
                    if ($system_function == 'photo' && is_file("../$system_albums_thumbnail_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg")) {
                            echo "<tr><td colspan=2 style='text-align:center;'><strong><u><span style='font-size:10px;color:darkred;'>JPG</span> More Images :</u></strong></td></tr>
                                <tr>
                                <td colspan=2 style='text-align:center;vertical-align:top;'>";
                                    echo "<table style='border: 0px solid lightgrey; width:100%;overflow-x: auto;'><tr>";
                                        for ($x = 2; $x <= $maximum_num_imageatt_allowed; $x++) {
                                            $currentimage_num = "$x";
                                            if (is_file("../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num.jpg")) {
                                                if (!is_file("../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_wm.jpg")) {
                                                    sfx_watermark_image("../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num.jpg", "../$watermark_overlay_file", "../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_wm.jpg");
                                                }
                                                echo "<td style='font-size:8pt;display: inline-block; padding: 5px; width:150px;'>";
                                                        if (is_file("../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_tb.jpg")) {
                                                            echo "<img class='centered-and-cropped' src='../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_tb.jpg' width=128px height=128px onerror=this.src='../sw_asset/img/no_image.png'>";
                                                        } else {
                                                            $thumbnailed_target_File = "../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_tb.jpg";
                                                            sfx_thumbnail_image025("../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_wm.jpg", $thumbnailed_target_File);
                                                            echo "<img class='centered-and-cropped' src='../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_tb.jpg' width=128px height=128px onerror=this.src='../sw_asset/img/no_image.png'>";
                                                        }
                                                        echo "<br/>
                                                        [<a onclick='return js_openPopup(this.href,800,680);' target='_blank' href='../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num.jpg'>$currentimage_num.jpg</a>]";
                                                        echo " [<a onclick='return js_openPopup(this.href,800,680);' target='_blank' href='../$system_albums_directory/$dir_year5/$id5"."_"."$instimestamp5/$currentimage_num"."_wm.jpg'>Watermarked</a>]";
                                                        if ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF') {
                                                            echo " [<a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' href='../sw_inc/del_inst.php?defi=$id5&pic=$currentimage_num'>Delete</a>]";
                                                        }
                                                echo "</td>";
                                            }
                                        }
                                    echo "</tr></table>";
                            echo "</td></tr>";
                        }
                echo "</table>";
                
                //for handling abstract/fulltext and references
                echo "<table class=whiteHeaderNoCenter style='border: 1px solid lightgrey;'>";
                    if ($fulltext5 != null && $fulltext5 != '<html />') {
                            echo "<tr><td class='$color_scheme"."Back' colspan=2 style='text-align:center;'><strong>";
                                echo ($isabstract5 == 1) ? "Abstract" : "Full Text";
                            echo " :</strong></td></tr>";

                            $display_fulltext5 = $strip_tags_fulltext_abstract_composer ? strip_tags(html_entity_decode($fulltext5)) : $fulltext5;
                            echo "<tr><td colspan=2 style='text-align:left;vertical-align:top;'>".sfx_highlight($display_fulltext5, $get_scstr)."<br/></td></tr>";
                            //echo "<tr><td colspan=2 style='text-align:left;vertical-align:top;'>".$display_fulltext5."<br/></td></tr>";
                        }
                        
                        if ($reference5 != null && $reference5 != '<html />') {
                            echo "<tr><td class='$color_scheme"."Back' colspan=2 style='text-align:center;'><strong>References:</strong></td></tr>";

                            $display_reference5 = $strip_tags_reference_composer ? strip_tags(html_entity_decode($reference5)) : html_entity_decode($reference5);
                            echo "<tr><td colspan=2 style='text-align:left;vertical-align:top;'><div style='width: 100%; height: 180px; overflow-y: scroll;'>$display_reference5</div><br/></td></tr>";
                        }
                echo "</table>";
                
                //administrator yellow panel starts
                echo "<br/><table class=$color_scheme"."AdminFill style='max-width:100%;overflow-x: auto;' width=100%>";
                    echo "<tr><td class='$color_scheme"."Back' colspan=2 style='text-align:center;'><strong>Administrative :</strong></td></tr>";
                    
                    echo "<tr><td style='text-align:right;width:15%;'><strong>Input by : </strong></td><td style='text-align:left;width:30%'>".sfx_sGetValue("name", "eg_auth", "username", $input_by5)." on $inputdate5</td></tr>";
                    
                    if ($lastupdatetimestamp5 <> 0) {
                        echo "<tr><td style='text-align:right;'><strong>Last update by : </strong></td><td style='text-align:left;'>".sfx_sGetValue("name", "eg_auth", "username", $lastupdateby5)." on ".date("Y-m-d", $lastupdatetimestamp5)."</td></tr>";
                    }
                                     
                    //options start here
                    echo "<tr><td style='text-align:right;vertical-align:top;'><strong>Option :</strong></td><td style='text-align:left;'><div style='padding-right:10px;padding-left:10px;padding-top:10px;padding-bottom:10px;'>";

                        //Update option
                        if ($item_status5 == '1' && ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF')) {
                            echo "<i class=\"fas fa-edit\"></i> <a onclick='return js_openPopup(this.href,950,580);' href='reg.php?upd=$id5'>Update</a><br/><br/>";
                        }

                        //Set to unlisted option
                        if ($status5 != 'UNLISTED' && ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF')) {
                            echo "<i class=\"fas fa-trash\"></i> <a style='text-decoration: underline;cursor: pointer;' onclick='if (confirm(\"Are you sure to set this to unlisted?\")) {return js_openPopup(\"../sw_inc/set_unlstd.php?id=$id5\",200,200);}'>Set to Unlisted</a><br/><br/>";
                        }

                        //delete option
                        if ($_SESSION[$ssn.'editmode'] == 'SUPER') {
                            if ($item_status5 == '1') {
                                if ($delete_method == 'permanent') {
                                    echo "<i class=\"fas fa-trash\"></i> <a style='text-decoration: underline;cursor: pointer;' onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(\"../sw_inc/del_inst.php?del=$id5\",200,200);}'>Delete</a><br/><br/>";
                                } elseif ($delete_method == 'takecover') {
                                    echo "<i class=\"fas fa-eye-slash\"></i> <a style='text-decoration: underline;cursor: pointer;' onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(\"../sw_inc/del_inst.php?tel=tc&del=$id5\",200,200);}'>Hide</a><br/><br/>";
                                }
                            } else {
                                echo "<i class=\"fas fa-retweet\"></i> <a onclick='return js_openPopup(this.href,200,200);' target='_blank' href='../sw_inc/recover_code.php?rec=$id5'>Recover</a><br/><br/>";
                            }
                        }
                            
                        //delete request
                        if ($item_status5 == '1' && ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF')) {
                            if ($deletereq5 == 'TRUE') {
                                $deletereq_by5 = $myrow_item["39proposedeleteby"];
                                $deletereq_reason5 = $myrow_item["39proposedelete_reason"];
                                if ($_SESSION[$ssn.'username'] == $deletereq_by5 || $_SESSION[$ssn.'editmode'] == 'SUPER') {
                                    echo "<i class=\"fas fa-undo\"></i> <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/undodelreq_code.php?itemid=$id5'>Undo Delete Request</a>";
                                }
                                echo "<br/>This item is on Delete Request list. Delete request made by <span style='color:red;'>$deletereq_by5</span> with the reason <span style='color:red;'>$deletereq_reason5</span>.<br/><br/>";
                            } else {
                                echo "<i class=\"fas fa-copy\"></i> <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/assigndelreq_code.php?itemid=$id5&reason=duplicate+detected'>Delete Request: Duplicate</a><br/><br/>";
                                echo "<i class=\"fas fa-user-secret\"></i> <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/assigndelreq_code.php?itemid=$id5&reason=request+by+a+higher+authority'>Delete Request: Request by a higher authority</a><br/><br/>";
                            }
                        }
                        
                        //commercialize
                        if ($enable_commercial_api  && ($_SESSION[$ssn.'editmode'] == 'SUPER' || $_SESSION[$ssn.'editmode'] == 'STAFF')) {
                            if (sfx_sGetValue("count(eg_item_id) as totalid", "eg_commercialize", "eg_item_id", $id5) == 0) {
                                echo "<i class=\"fas fa-money-bill-alt\"></i> <a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/cmz.php?itemid=$id5&cmz=t'>Commercialize</a><br/><br/>";
                            } else {
                                echo "<i class=\"fas fa-money-bill-alt\"></i> This item already commercialized (<a onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/cmz.php?itemid=$id5&cmz=u'>Pull Down</a>)<br/><br/>";
                            }
                        }

                        echo "<i class=\"fas fa-user-clock\"></i> <a onclick='if (confirm(\"Are you sure? This will create a temporary access link to this item. Only valid for 24 hours.\")) {return js_openPopup(this.href,600,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/templink.php?itemid=$id5'>Create temporary access link</a>";

                    echo "</div></td></tr>";
                    //options end here

                echo "</table>";

                //feedback moderation
                if ($enable_feedback_function) {
                    echo "<br/>";
                    echo "<table class=$color_scheme"."AdminFill>";
                        echo "<tr class=$color_scheme"."HeaderCenter><td><strong>Feedback</strong></td></tr>";
                        $stmt_fdb = $new_conn->prepare("select * from eg_item_feedback where eg_item_id=$id5 order by 38upvote desc");
                        $stmt_fdb->execute();
                        $result_fdb = $stmt_fdb->get_result();
                        $n=0;
                        while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                            $id_fdb = $myrow_fdb["id"];
                            $feedback_fdb = $myrow_fdb["38feedback"];
                            $feedback_by_fdb = $myrow_fdb["eg_auth_username"];
                            $feedback_ts_fdb = $myrow_fdb["38timestamp"];
                            $upvote_fdb = $myrow_fdb["38upvote"];
                            $downvote_fdb = $myrow_fdb["38downvote"];
                            $votebys_fdb =  $myrow_fdb["38votebys"];
                            $moderated_status = $myrow_fdb["39moderated_status"];
                            $moderated_by = $myrow_fdb["39moderated_by"];
                            $moderated_ts = $myrow_fdb["39moderated_timestamp"];
                            
                            echo "<tr style='text-align:left;'><td>$feedback_fdb<br/><span style='color:grey'>by <em>".sfx_sGetValue("name", "eg_auth", "username", $feedback_by_fdb)."</em> on ".date('d/M/Y', $feedback_ts_fdb)."</span>";
                                echo "<br/>Current approval status: [<a title='Click to change from NO to YES or vice versa' onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/setstatusfeedback_code.php?fid=$id_fdb&ms=$moderated_status'>$moderated_status</a>]";
                                echo " <span style='color:blue;'>Upvote: $upvote_fdb</span>";
                                echo " <span style='color:red;'>Downvote: $downvote_fdb</span>";
                                echo "<br/>[<a title='Click to change from NO to YES or vice versa' onclick='if (confirm(\"Are you sure?\")) {return js_openPopup(this.href,200,200);}else{event.stopPropagation(); event.preventDefault();};' target='_blank' href='../sw_inc/removefeedback_code.php?fid=$id_fdb'>Remove this feedback</a>]<br/><br/></td></tr>";
                                $n=1;
                        }

                        if ($n == 0) {
                            echo "<tr><td style='text-align:center;vertical-align:top;'>";
                                echo "<i>No feedback found.</i>";
                            echo "</td></tr>";
                        }
                    echo "</table>";
                }
            } else { //if item not existed
                echo "<div style='padding-top:10px;font-size:18px;'>Item is not available.</div>";
            }
        ?>

        <br/>
        <?php
            echo "<a class='sButton' href='javascript:history.go(-1)'><span class='fas fa-arrow-circle-left'></span> Back to previous page</a>";
            if ($debug_mode == 'yes' && $_SESSION[$ssn.'editmode'] == 'SUPER') {
                echo " <a accesskey='n' class='sButton' href='details.php?det=".($get_id_det + 1)."'>Go to next record <span class='fas fa-arrow-circle-right'></span></a>";
            }
        ?>
    </div>

    <hr>
        
    <?php include_once '../sw_inc/footer.php';?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
