<?php
/*
Filename: sw_admin/addpublisher.php
Usage: Create and manage publisher in eg_publisher
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/token_validate.php';
    $thisPageTitle = "$publisher_as Listing";
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
        
    <?php

        if (isset($_GET["del"]) && is_numeric($_GET["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_publisher where 43pubid = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();$stmt_del->close();
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","addpublisher.php");
            exit;
        }
                
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $acronym1 = sfx_just_clean($_POST["acronym1"], 'min');
            $publisher1 = sfx_just_clean($_POST["publisher1"], 'min');
            $sstatus1 = $_POST["sstatus1"];
            if ($_REQUEST["submitted"] == "Insert") {
                $stmt_count = $new_conn->prepare("select count(*) from eg_publisher where 43acronym = ?");
                $stmt_count->bind_param("s", $acronym1);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected_publisher);
                $stmt_count->fetch();$stmt_count->close();
                if ($num_results_affected_publisher == 0) {
                    if (!empty($acronym1) && (!empty($publisher1))) {
                        $stmt_insert = $new_conn->prepare("insert into eg_publisher values(DEFAULT,?,?,?,DEFAULT,DEFAULT)");
                        $stmt_insert->bind_param("ssi", $acronym1, $publisher1, $sstatus1);
                        $stmt_insert->execute();
                        $stmt_insert->close();
                        sfx_echoPopupAlert("The $publisher_as $publisher1 ($acronym1) has been inputed into the database.");
                    } else {
                        sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                    }
                } elseif ($num_results_affected_publisher >= 1) {
                    sfx_echoPopupAlert("Your input has been cancelled. Duplicate $publisher_as detected.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];
                if (!empty($publisher1) && !empty($acronym1)) {
                    $stmt_update = $new_conn->prepare("update eg_publisher set 43publisher=?, 43acronym=?, 43sstatus=? where 43pubid=?");
                    $stmt_update->bind_param("ssii", $publisher1, $acronym1, $sstatus1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("The record has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s). The record has been restored to it original state.");
                }
            }
        }

        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select 43pubid, 43publisher, 43acronym, 43sstatus from eg_publisher where 43pubid = ?");
            $stmt3->bind_param("i", $get_id_upd);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $publisher3, $acronym3, $sstatus3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.","link","addpublisher.php");
            exit;
        }
    
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td><strong><?php echo $publisher_as;?> Addition</strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
            <form action="addpublisher.php" method="post" enctype="multipart/form-data">
                <strong><?php echo $publisher_as;?>: </strong>
                <br/>
                <input type="text" required name="publisher1" style="width:50%" maxlength="250" value="<?php if (isset($publisher3)) {echo $publisher3;} ?>"/>
                <br/><br/>
                <strong>Acronym: </strong>
                <br/>
                <input type="text" required name="acronym1" style="width:50%" maxlength="50" value="<?php if (isset($acronym3)) {echo $acronym3;} ?>"/>
                <br/><br/>
                <strong>Selectable Status: </strong> (only on self submission page)
                <br/>
                <input type="radio" required name="sstatus1" value="1" <?php if (isset($sstatus3) && $sstatus3=='1') {echo "checked";} ?>><label for="1">Selectable</label><br>
                <input type="radio" required name="sstatus1" value="0" <?php if (isset($sstatus3) && $sstatus3=='0') {echo "checked";} ?>><label for="0">Not-selectable</label><br><br>
                <br/><br/>
                <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                <input type="button" value="Cancel" onclick="location.href='addpublisher.php';">
            </form>
        </td>
        </tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>>
            <td colspan=5><strong><?php echo $publisher_as;?> Controls :</strong></td>
        </tr>
        
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'></td>
            <td style='text-align:left;'><?php echo $publisher_as;?></td>
            <td style='width:150;'>Acronym</td>
            <td style='width:150;'>Status</td>
            <td style='width:150;'>Options</td>
        </tr>
        
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select 43pubid, 43acronym, 43publisher, 43sstatus from eg_publisher order by 43acronym");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $pubid_fdb = $myrow_fdb["43pubid"];
                $acronym_fdb = $myrow_fdb["43acronym"];
                $publisher_fdb = $myrow_fdb["43publisher"];
                $sstatus_fdb = $myrow_fdb["43sstatus"];
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>$publisher_fdb</td>";
                    echo "<td>$acronym_fdb</td>";
                    echo "<td>";
                    if ($sstatus_fdb == 1) {echo "Selectable";} else {echo "Not-selectable";}
                    echo "</td>";
                    echo "<td>";
                        echo "<a title='Delete this record' href='addpublisher.php?del=$pubid_fdb' onclick=\"return confirm('Are you sure ? You are advisable to change all items based on this publisher to the another before proceeding.');\"><i class=\"fas fa-trash\"></i></a> ";
                        echo "<a title='Update this record' href='addpublisher.php?edt=$pubid_fdb'><i class=\"fas fa-edit\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
        ?>
    </table>

    <hr>

    <?php include_once '../sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
