<?php
/*
Filename: passch.php
Usage: Password change page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Password Control";
    session_start();define('includeExist', true);
    
    include_once 'core.php';
    
    if (isset($_SESSION[$ssn.'username'])) {
        include_once 'sw_inc/access_isset.php';
    } else {
        include_once 'sw_inc/access_isset_guest.php';
    }

    if (isset($_SESSION[$ssn.'username'])) {
        include_once 'sw_inc/access_allowed_adminip.php';
    }

    include_once 'sw_inc/functions.php';
    include_once 'sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once 'sw_inc/header.php';?></head>

<body class='<?= $color_scheme;?>'>
    
    <?php include_once 'sw_inc/loggedinfo.php';?>
    
    <hr>
                
    <?php
        $username3 = $_SESSION[$ssn.'username'] ?? $_SESSION[$ssn.'username_guest'];
                
        if (isset($_REQUEST["upd"]) && $_REQUEST["upd"] <> null) {
    ?>
            <table class=<?= $color_scheme."Header";?>>
                <tr class=<?= $color_scheme."HeaderCenter";?>><td>
                    <strong>Please input your new password alongside with it confirmation :</strong>
                </td></tr>
            </table>
                        
            <form action="passch.php" method="post">
                <table class=greyBody>
                    <tr style='text-align:center;'><td>
                        <?php if ($username3 != 'admin') { ?>
                            <strong>Old Password:</strong><br/><input class="roundInputTextMin" type="password" name="password_oldverify" size="25" maxlength="40"/><br/><br/>
                        <?php }?>
                        <strong>New Password:</strong><br/><input class="roundInputTextMin" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" type="password" name="password_new" size="25" maxlength="40"/><br/><br/>
                        <strong>New Password (Again):</strong><br/><input class="roundInputTextMin" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" type="password" name="password_newagain" size="25" maxlength="40"/><br/><br/>
                        
                        <input type="hidden" name="submitted" value="TRUE" />
                        <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                        <input type="hidden" name="upd" value=".g" />
                        <input class="googleButton" type="submit" name="submit_button" value="Update"/>
                    </td></tr>
                </table>
            </form>
    <?php
        }
                
        if (isset($_POST["submitted"]) && $proceedAfterToken) {
            //get old password
            $stmt_getoldpwd = $new_conn->prepare("select AES_DECRYPT(syspassword,'$aes_key') as syspassword from eg_auth where username=? and id > 0");
            $stmt_getoldpwd->bind_param("s", $username3);
            $stmt_getoldpwd->execute();
            $stmt_getoldpwd->bind_result($password_old);
            $stmt_getoldpwd->fetch();$stmt_getoldpwd->close();
            
            $password4o = isset($_POST["password_oldverify"]) ? mysqli_real_escape_string($GLOBALS["conn"], $_POST["password_oldverify"]) : '';
            
            $password4 = mysqli_real_escape_string($GLOBALS["conn"], $_POST["password_new"]);
            $password4a = mysqli_real_escape_string($GLOBALS["conn"], $_POST["password_newagain"]);
            
            if ($password4o == $password_old || $username3 == 'admin') {
                if (!empty($password4)) {
                    if ($password4 == $password4a) {
                        $stmt_update = $new_conn->prepare("update eg_auth set syspassword=AES_ENCRYPT(?,'$aes_key') where username=?");
                        $stmt_update->bind_param("ss", $password4, $username3);
                        $stmt_update->execute();$stmt_update->close();
                        sfx_echoPopupAlert("Your password has been updated. Please login again.", "link", "index.php?log=out");
                    } else {
                        sfx_echoPopupAlert("Confirmation failed.", "goback");
                        exit(); mysqli_close($GLOBALS["conn"]);
                    }
                } else {
                    sfx_echoPopupAlert("Please insert any empty field.", "goback");
                    exit(); mysqli_close($GLOBALS["conn"]);
                }
            } else {
                sfx_echoPopupAlert("Please verify your old password.", "goback");
                exit(); mysqli_close($GLOBALS["conn"]);
            }
        }
    ?>

    <hr>
        
    <?php include_once 'sw_inc/footer.php';?>

    <?php
    if ((isset($_SESSION[$ssn.'needtochangepwd']) && $_SESSION[$ssn.'needtochangepwd']) && isset($_SESSION[$ssn.'username'])) {
        sfx_createModalPopupMenuAuto('changePassword', 'Change Password', 'You will need to change your password before using this system.');
    }
    ?>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
