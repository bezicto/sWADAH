<?php
/*
Filename: sw_stats/load_toggle_2_subload_1.php (Access)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change: -
*/

session_start();

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
ini_set('max_execution_time', 180);

if (!isset($_GET['t'])) {exit;}
$t = mysqli_real_escape_string($GLOBALS["conn"], $_GET['t']); if (!is_numeric($t)) {$t = 0;}

function sw_echoandputcontents_items($t, $system_statcache_directory)
{
    $query_totalcount = "select count(id) as totalid from eg_item where 38typeid='$t'";
    $result_totalcount = mysqli_query($GLOBALS["conn"], $query_totalcount);
    $myrow_totalcount = mysqli_fetch_array($result_totalcount);
    echo $myrow_totalcount["totalid"];

    file_put_contents("../$system_statcache_directory/".$t."_itemscount.txt", $myrow_totalcount["totalid"]."\n".time());
}

if (file_exists("../$system_statcache_directory/".$t."_itemscount.txt") && $report_count_generator == 'daily') {
    $lines = file("../$system_statcache_directory/".$t."_itemscount.txt");
    $diff = time() - $lines[1];
    if ($diff < 86400) {
        echo $lines[0];
    } else {
        sw_echoandputcontents_items($t, $system_statcache_directory);
    }
} else {
    sw_echoandputcontents_items($t, $system_statcache_directory);
}

