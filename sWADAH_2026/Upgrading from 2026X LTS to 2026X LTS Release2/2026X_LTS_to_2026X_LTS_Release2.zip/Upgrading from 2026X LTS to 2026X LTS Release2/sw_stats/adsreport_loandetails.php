<?php
/*
Filename: sw_stats/adsreport_loandetails.php
Usage: Bookmarks report within specific time frame
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Bookmarking Activity Report";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>

    <div style="text-align:center">
    
        <?php
            
            $hitsDate = $_GET['hitsDate'];
        
            $param = "%".$hitsDate."%";
            $stmt_fsb = $new_conn->prepare("select SQL_CALC_FOUND_ROWS * from eg_item_charge where DATE_FORMAT(FROM_UNIXTIME(39charged_on), '%d/%m/%Y') like ? order by 39charged_on desc");
            $stmt_fsb->bind_param("s", $param);
            $stmt_fsb->execute();
            $result_fsb = $stmt_fsb->get_result();
            $num_results_affected = $result_fsb->num_rows;
    
            echo "<table class=whiteHeaderNoCenter>";
                echo "<tr class=$color_scheme"."HeaderCenter><td colspan=4>Total recorded bookmarks : <strong>$num_results_affected</strong> for <strong>$hitsDate</strong></td></tr>";
                echo "<tr class=whiteHeaderNoCenter style='text-decoration:underline;'><td></td><td><strong>Item</strong></td><td><strong>Transaction Info</strong></td><td><strong>Transaction Date</strong></td></tr>";
                                                                
                $n = 1;
                
                while ($myrow_fsb = $result_fsb->fetch_assoc()) {
                    echo "<tr class=$color_scheme"."Hover>";
                    
                    $accession_fsb = $myrow_fsb["38accessnum"];
                        $query_title = "select 38title from eg_item where 38accessnum = '$accession_fsb'";
                        $result_title = mysqli_query($GLOBALS["conn"], $query_title);
                        $myrow_title = mysqli_fetch_array($result_title);
                        $title = isset($myrow_title['38title']) ? $myrow_title['38title'] : 'N/A';
                        
                    $patron_fsb = $myrow_fsb["39patron"];
                        $query_name = "select username, name from eg_auth where username = '$patron_fsb'";
                        $result_name = mysqli_query($GLOBALS["conn"], $query_name);
                        $myrow_name = mysqli_fetch_array($result_name);
                        $fullname = isset($myrow_name["name"]) ? $myrow_name["name"] : 'N/A';
                        $username = isset($myrow_name["username"]) ? $myrow_name["username"] : 'N/A';

                    $chargedon_fsb = date('d/m/Y H:i:s', $myrow_fsb["39charged_on"]);
                    
                    echo "<td>$n</td><td style='text-align:left;'>$title</td><td>$fullname ($username)</td><td>$chargedon_fsb</td></tr>";
                                                                                                                        
                    $n = $n +1 ;
                }
            echo "</table>";
                                                            
        ?>
        
        <br/><br/>
        <a class='sButton' href='javascript:window.close();'><span class="fa-solid fa-rectangle-xmark"></span> Close</a>
    
    </div>

</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
