<?php
/*
Filename: sw_stats/load_toggle_2a.php (Access)
Usage: AJAX load for making things display fast a little bit
Version: 20250101.0801
Last change: -
*/

session_start();

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
ini_set('max_execution_time', 180);

//table header
echo "<table class='whiteHeader'><tr class='$color_scheme"."HeaderCenter'><td>";
echo "<strong>Alltime Access Statistic</strong> : <br/><em>Detail statistic are shown when clicking any of the figures.</em>";
echo "</td></tr></table>";

echo "<table class='whiteHeader'>";
echo "<tr class='whiteHeaderCenterUnderline'>
        <td></td>
        <td style='text-align:left;'>$type_as</td>
        <td width='20%'>Total Item</td>
        <td width='20%'>Total Session</td>
        <td width='20%'>Total Access</td>
      </tr>";

$m = 1;

//ajax enabled - dynamic javascript
?>
<script>
    $(document).ready(function () {
        let totalItem = 0;
        let totalSession = 0;
        let totalHits = 0;

        <?php
        //sql statement -- will be reused also
        $query2 = "SELECT 38type, 38typeid, 38synonym FROM eg_item_type";
        $result2 = mysqli_query($GLOBALS["conn"], $query2);

        while ($myrow2 = mysqli_fetch_array($result2)) {
            $typestatement2 = $myrow2["38typeid"];
            $typedesc2 = $myrow2["38type"];
        ?>
        (function (m, typestatement2, typedesc2) {
            const urls = [
                `load_toggle_2_subload_1.php?t=${typestatement2}`,
                `load_toggle_2_subload_2.php?t=${typestatement2}`,
                `load_toggle_2_subload_3.php?t=${typestatement2}`
            ];

            const targets = [
                `#loaditemscount${m}`,
                `#loadsessionscount${m}`,
                `#loadhitscount${m}`
            ];

            urls.forEach((url, index) => {
                $.ajax({
                    url: url,
                    success: function (data) {
                        $(targets[index]).html(data);

                        //add up all totals
                        const value = parseInt(data, 10) || 0;
                        if (index === 0) totalItem += value;
                        if (index === 1) totalSession += value;
                        if (index === 2) totalHits += value;

                        //update totals accordingly
                        $('#totalitem').html(totalItem);
                        $('#totalsession').html(totalSession);
                        $('#totalhits').html(totalHits);
                    }
                });
            });
        })(<?= $m ?>, <?= json_encode($typestatement2) ?>, <?= json_encode($typedesc2) ?>);
        <?php
            $m++;
        }
        ?>
    });
</script>
<?php

//show all counts
$result2 = mysqli_query($GLOBALS["conn"], $query2);
$m = 1;
while ($myrow2 = mysqli_fetch_array($result2)) {
    $typestatement2 = $myrow2["38typeid"];
    $typedesc2 = $myrow2["38type"];
    $typesynonym2 = $myrow2["38synonym"];

    echo "<tr class='$color_scheme"."Hover'>";
        echo "<td>$m</td>";
        echo "<td style='text-align:left;'>$typesynonym2</td>";
        echo "<td><a href='adsreport_typedetails.php?type=$typestatement2'><span id='loaditemscount$m'>Loading data..</span></a></td>";
        echo "<td><a href='adsreport_typeaccess.php?type=$typestatement2'><span id='loadsessionscount$m'>Loading data..</span></a></td>";
        echo "<td><a href='adsreport_typeaccess.php?type=$typestatement2'><span id='loadhitscount$m'>Loading data..</span></a></td>";
    echo "</tr>";

    if (file_exists("../$system_statcache_directory/".$typestatement2."_itemscount.txt")) {
        $reported_timestamp = file("../$system_statcache_directory/".$typestatement2."_itemscount.txt")[1];
    }
    if (file_exists("../$system_statcache_directory/".$typestatement2."_sessionscount.txt")) {
        $reported_timestamp = file("../$system_statcache_directory/".$typestatement2."_sessionscount.txt")[1];
    }
    if (file_exists("../$system_statcache_directory/".$typestatement2."_hitscount.txt")) {
        $reported_timestamp = file("../$system_statcache_directory/".$typestatement2."_hitscount.txt")[1];
    }

    $m++;
}

//$reported_timestamp will be getting from the final generated *count.txt above, but it didn't so it will use the current time()
if (!isset($reported_timestamp)) {
    $reported_timestamp = time();
}

//total will be shown below
echo "<tr style='text-align:center;background-color:lightgrey'>
        <td colspan=2 style='text-align:right;background-color:white'><em>Total :</em></td>
        <td><span id='totalitem'></span></td>
        <td><span id='totalsession'></span></td>
        <td><span id='totalhits'></span></td>
      </tr>";
echo "</table>";

if ($report_count_generator == 'daily') {
    $refresh_time = $reported_timestamp + 24 * 3600; // statistic will be renewed after 24 hours
    $current_time = time(); // current time
    $time_remaining = $refresh_time - $current_time; // time balance in seconds

    if ($time_remaining > 0) {
        $hours_remaining = floor($time_remaining / 3600);
        $minutes_remaining = floor(($time_remaining % 3600) / 60);
        $seconds_remaining = $time_remaining % 60;
        $time_message = "{$hours_remaining} hours, {$minutes_remaining} minutes, dan {$seconds_remaining} seconds.";
    } else {
        $time_message = "Press <a href=''>here to refresh</a>.";
    }
    echo "<br/>
    <em>Statistic generated date and time: ".date('Y-m-d H:i:s', $reported_timestamp).".
    <br/>Statistic is valid for that date and time. New statistic will be generated 24 hours later.
    <br/>Time remaining before refresh: $time_message
    </em>";
}
?>
