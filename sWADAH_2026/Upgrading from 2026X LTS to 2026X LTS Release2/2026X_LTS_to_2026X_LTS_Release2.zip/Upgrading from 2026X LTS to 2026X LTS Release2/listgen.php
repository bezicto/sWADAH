<?php
/*
Filename: listgen.php
Usage: Custom link viewer. Only valid with valid tokens.
Qualification: access point page
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "List Generator";
    session_start();define('includeExist', true);
    
    include_once 'core.php';
    include_once 'sw_inc/functions.php';
    
    //previous url
    $_SESSION[$ssn.'previous_url'] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    //this is a browser, so assign it
    $_SESSION[$ssn.'whichbrowser'] = "listgenerator";
    
    if (isset($_GET["token"]) && ctype_alnum($_GET["token"])) {
        $_SESSION[$ssn.'listgentoken'] = $_GET["token"];
    }

    if (isset($_SESSION[$ssn.'listgentoken']) && ctype_alnum($_SESSION[$ssn.'listgentoken'])) {
        $get_token = mysqli_real_escape_string($GLOBALS["conn"], $_SESSION[$ssn.'listgentoken']);

        //find one result per prepared statement with mysqli $new_conn
        $stmt3 = $new_conn->prepare("select 43title, 43listid, 43type, 43filter from eg_list where 43token=?");
        $stmt3->bind_param("s", $get_token);//i integer, s string, d double, b blob
        $stmt3->execute();
        $stmt3->store_result();
        $stmt3->bind_result($title_s, $id_s, $type_s, $filter_s);
        $stmt3->fetch();
        $stmt3->close();

        if (isset($id_s)) {
            $proceed = true;
            if ($type_s == 'EveryThing') {
                $appendSQL = "";
                $type_statement = "Everything";
            } else {
                $appendSQL = "and 38typeid='$type_s'";
                $type_statement = sfx_sGetValue("38synonym", "eg_item_type", "38typeid", $type_s);
            }
        } else {
            $proceed = false;
        }
    }
?>
<html lang='en'>

<head>
    <?php include_once 'sw_inc/header.php'; ?>
</head>

<body class='<?= $color_scheme;?>'>

    <?php
        include_once 'sw_inc/loggedinfo.php';

        if (isset($proceed) && $proceed) {
    ?>

    <hr>

    <table class="<?= $color_scheme."banner_guest";?>">
          <tr>
            <td style='height:29;text-align:right;'><?= "<span style='color:green;font-size:16pt;'>$title_s</span><br/><span>Type: $type_statement</span>";?></td>
            <td style='width:10px;font-size:24px;'><i class="far fa-list-alt"></i></td>
          </tr>
    </table>

    <div style='text-align:center;'>
        <?php
            $json = file_get_contents($system_path."searcherapi.php?scstr=".str_replace(" ", "+", $filter_s)."&sctype=$type_s");
            $objs = json_decode($json);
           
            echo "<table class=whiteHeaderNoCenter>";
            $n=1;
            foreach($objs as $obj) {
                echo "<tr class=$color_scheme"."Hover>
                        <td style='text-align:center;vertical-align:top;width:50px;'><strong>$n</strong></td>";
                            
                        echo "<td style='text-align:center;vertical-align:top;color:#0066CC;font-size:10px;' width=28>
                            <strong>".$obj->type."</strong><br/><i class=\"far fa-list-alt\"></i>
                        </td>";
                    
                        echo "<td style='text-align:left;'>";
                            //title
                            $exploded_removed_words = explode(',', $remove_word_from_title);
                            foreach ($exploded_removed_words as $value) {
                                $titlestatement2 = str_replace($value, "", $obj->title);
                            }
                            $converted_title = htmlspecialchars_decode($titlestatement2);
                            if (isset($_SESSION[$ssn.'username'])) {
                                echo " <a style='font-size:$searcher_title_font_size;' title='Click here to view detail' class='myclassOri' href='sw_admin/details.php?det=".$obj->id."'>$converted_title</a>";
                            }
                            else {
                                echo " <a style='font-size:$searcher_title_font_size;' title='Click here to view detail' class='myclassOri' href='detailsg.php?det=".$obj->id."'>$converted_title</a>";
                            }
                                                    
                            //author
                            echo "<br/>" . (!empty($obj->author) ? $obj->author : 'N/A');
        
                        echo "</td>
                </tr>";
                $n=$n+1;
            }
            echo "</table>";
        ?>
    </div>

    <?php
        } else {
            echo "<div style='margin-top:20px;text-align:center;width:100%'>Error.</div>";
        }
    ?>
    
    <br/><hr>
    
    <?php include_once 'sw_inc/footer.php'; ?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
