<?php
/*
Filename: sw_inc/paging-p1.php
Usage: Pagination segment 1
Version: 20250101.0801
Last change: -
*/

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    $rowsPerPage = $system_wide_resultPerPage;
    $pageNum = isset($currentPage) ? $currentPage : 1;
    $offset = ($pageNum - 1) * $rowsPerPage;
