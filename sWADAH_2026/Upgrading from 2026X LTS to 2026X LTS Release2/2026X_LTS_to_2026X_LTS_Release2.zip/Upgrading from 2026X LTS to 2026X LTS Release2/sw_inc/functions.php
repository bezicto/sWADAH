<?php
/*
Filename: sw_inc/functions.php
Usage: Function declarations
Version: 20250101.0801
Last change: -
20250201.0000 -
fix error when generating watermark file at line 579
*/

    function sfx_filterCommonWords($search_term) {
        $search_term = " ".$search_term." ";//put spaces in front and at the end to let the filter work properly

        $remove = array(
            "and","as","at","an","a","about","all","after","also","among",
            "by","be","before","between","because",
            "could","can","cause",
            "delete","do","day","del",
            "entry","echo",
            "from","for","false",
            "go","get",
            "have","has","had","how",
            "i","if","in","if","is","its",
            "join",
            "me","may","most","more",
            "no","nope","none",
            "or","out","over","on","of",
            "print",
            "rmdir","rm",
            "select",
            "the","to","there","their","they","then","than","true",
            "up","update","unlink","union",
            "we","with","would","which","who","whom","whose","what","want",
            "yes","yet",
            "ada","apa","akan",
            "bagaimana","bentuk",
            "di","dan","dalam","dari","daripada","dapat",
            "pada",
            "ini","ia","itu",
            "kalangan","ke","kepada","kerana",
            "lagi",
            "mana","menerusi",
            "oleh",
            "perlu",
            "siapa","sana","sini",
            "tetapi",
            "untuk",
            "yang","ya"
        );
        
        foreach ($remove as $word) {
            $search_term = preg_replace("/\s". $word ."\s/i", " ", $search_term);// '/i' for case insensitive replace
        }
        
        $search_term = trim($search_term);//remove white spaces
        $search_term = str_replace('\'s', '', $search_term);//remove single quote
        
        return $search_term;
    }

    function sfx_getCurrentBaseURL() {
        return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/";
    }
    
    function sfx_echoPopupAlert($msg, $type=null, $gotourl=null){
        echo "<script>alert(\"$msg\");";
        switch ($type) {
            case 'link':
                echo "window.location.replace('$gotourl');";
                break;
            case 'goback':
                echo "history.go(-1);";
                break;
            case 'closeafteralert':
                echo "window.close();";
                break;
            default:
                echo "";
                break;
        }
        echo "</script>";
    }

    function sfx_checkAndEcho($var) {
        if (is_bool($var)) {
            return $var ? 'true' : 'false';
        } else {
            return $var;
        }
    }

    function sfx_checkBooleanValue($var) {
        return $var == 1 ? 'TRUE' : 'FALSE';
    }

    function sfx_formatBytes($size, $precision = 2)
    {
        $base = log($size, 1024);
        $suffixes = array('', 'K', 'M', 'G', 'T');

        return round(pow(1024, $base - floor($base)), $precision) .' '. $suffixes[floor($base)];
    }

    function sfx_showDevelopedRight()
    {
        return base64_decode("RGV2ZWxvcGVkIGJ5IFBlcnB1c3Rha2FhbiBUdWFua3UgQmFpbnVuLCBVbml2ZXJzaXRpIFBlbmRpZGlrYW4gU3VsdGFuIElkcmlz");
    }

    function sfx_filterHexadecimal($data) {
        return preg_replace('/\\\\x[0-9A-Fa-f]{2}/', '', $data);
    }

    function sfx_refreshAndClose($messageText, $duration = '500')
    {
        echo "
            <script>function sfx_refreshAndClose() {window.opener.location.reload(true);window.close();}setTimeout('self.close()', $duration)</script>
            <body onbeforeunload='sfx_refreshAndClose();'><div align=center>$messageText This windows will close automatically.</div></body>
            ";
    }

    function sfx_get_ip()
    {
            // Mendapatkan IP pengguna dari pelbagai sumber
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            // Memastikan IP adalah IPv4
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                return $ip;
            } else {
                return ($_SERVER["REMOTE_ADDR"] == '::1' || $_SERVER["REMOTE_ADDR"] == '127.0.0.1') ? '127.0.0.1' : 'Alamat IPv4 tidak dijumpai.';
            }
    }

    function sfx_declare_blockcount()
    {
        switch ($GLOBALS["invalid_access_detection"]) {
            case 'strict':
                return 1;
            case 'precaution':
                return 5;
            default:
                return 99;
        }
    }

    function sfx_check_is_blocked($dirtowrite, $up)
    {
        //this function will check whether if the ip exist 3 times in a row for the current date of ip blocked list.
        //the ip will only get daily ban. will clear the next day.
        
        $blockcount = sfx_declare_blockcount();

        if (is_file($dirtowrite.date("Ymd").".txt")) {
            $handle = fopen($dirtowrite.date("Ymd").".txt", "r");
            if ($handle) {
                $n=0;
                while (($buffer = fgets($handle)) !== false) {
                    if (strpos($buffer, sfx_get_ip()) !== false) {
                        $n=$n+1;
                    }
                    if ($n>=$blockcount) {
                        echo "<script>alert('Your session have been blocked. Illegal operation detected.');window.location.replace('$up"."index.php');</script>";
                        mysqli_close($GLOBALS["conn"]); fclose($handle); exit();
                    }
                }
                fclose($handle);
            }
        }
    }

    function sfx_checkstring_Exist_And_redirect_to_parent($thefullstring, $word_to_check, $page_to_redirect)
    {
        if (strpos($thefullstring, $word_to_check) !== false) {
            echo "<script>window.location.replace('$page_to_redirect');</script>";
        }
    }
    
    function sfx_checkPHPExtension($extensionToCheck)
    {
        if (extension_loaded($extensionToCheck)) {
            return "";
        } else {
            return "<table style=\"padding-top:1px;width:100%;text-align:center;\">
            <tr style=\"background-color:red;color:white;\"><td style=\"color:white;\">
                PHP extension <u>$extensionToCheck</u> not loaded. Please check your php.ini setting.This extension is mandatory.
            </td></tr>
            </table>";
        }
    }

    function sfx_countImageForID($appendroot,$itemid)
    {
        $stmt_item = $GLOBALS["new_conn"]->prepare("select * from eg_item where id=?");
        $stmt_item->bind_param("i", $itemid);
        $stmt_item->execute();
        $result_item = $stmt_item->get_result();
        $num_results_affected = $result_item->num_rows;
        $myrow_item = $result_item->fetch_assoc();

        $total_image = 0 ;

        if ($num_results_affected >= 1) {
            $inputdate = $myrow_item["39inputdate"];
            $dir_year = substr($inputdate, 0, 4);
            $instimestamp = $myrow_item["41instimestamp"];

            if (is_file($appendroot.$GLOBALS["system_albums_directory"]."/$dir_year/$itemid"."_"."$instimestamp.jpg")) {
                $total_image = 1;
            }
            for ($x = 2; $x <= $GLOBALS["maximum_num_imageatt_allowed"]; $x++) {
                $currentimage_num = "$x";
                if (is_file($appendroot.$GLOBALS["system_albums_directory"]."/$dir_year/$itemid"."_"."$instimestamp/$currentimage_num.jpg")) {
                    $total_image = $total_image + 1;
                }
            }
        }

        return $total_image;
    }
    
    function sfx_createModalPopupMenu($menuID, $menuTitle, $menuDialog)
    {
        echo "
            <script>
                \$(function() {\$('#$menuID').click(function(e) {e.preventDefault();\$('#$menuID-confirm').dialog('open');});
                $( '#$menuID-confirm' ).dialog({
                    resizable: false,height:160,modal: true,minWidth: 350,autoOpen:false,
                    buttons: {'OK': function() {\$( this ).dialog( 'close' );}}
                    });
                });
            </script>
            <style>
                .ui-button.ui-corner-all.ui-widget.ui-button-icon-only.ui-dialog-titlebar-close {display: none;}
            </style>
            <div id='$menuID-confirm' title='$menuTitle' style='display:none;'>
                <p>
                    <span class='ui-icon ui-icon-alert' style='float:left; margin:0 7px 20px 0;'></span>$menuDialog
                </p>
            </div>
        ";
    }

    function sfx_createModalPopupMenuAuto($menuID, $menuTitle, $menuDialog)
    {
        echo "
            <script>
                \$(function() {\$('#$menuID').click(function(e) {e.preventDefault();\$('#$menuID-confirm').dialog('open');});
                $( '#$menuID-confirm' ).dialog({
                    resizable: false,height:160,modal: true,minWidth: 350,autoOpen:false,
                    buttons: {'OK': function() {\$( this ).dialog( 'close' );}}
                    });
                });
            </script>
            <style>
                .ui-button.ui-corner-all.ui-widget.ui-button-icon-only.ui-dialog-titlebar-close {display: none;}
            </style>
            <div id='$menuID-confirm' title='$menuTitle' style='display:none;'>
                <p>
                    <span class='ui-icon ui-icon-alert' style='float:left; margin:0 7px 20px 0;'></span>$menuDialog
                </p>
            </div>
            <script>
                $(document).ready(function() {
                    $('#$menuID-confirm').dialog('open');
                });
            </script>
        ";
    }

    function sfx_sGetValue($fieldtoget, $tablename, $wherefield, $wherevalue, $wherevaluetype = "s")
    {
        $stmt = $GLOBALS["new_conn"]->prepare("select $fieldtoget from $tablename where $wherefield=?");
        $stmt->bind_param("$wherevaluetype", $wherevalue);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($returnvalue);
        $stmt->fetch();
        $stmt->close();

        if (($returnvalue == '' || $returnvalue == null) && $tablename == 'eg_item_type') {
            $stmt = $GLOBALS["new_conn"]->prepare("select 38type from eg_item_type where $wherefield=?");
            $stmt->bind_param("$wherevaluetype", $wherevalue);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($returnvalue);
            $stmt->fetch();
            $stmt->close();
        }
        return $returnvalue;
    }

    function sfx_sGetValueNot($fieldtoget, $tablename, $wherefield, $wherevalue, $wherevaluetype = "s")
    {
        $stmt = $GLOBALS["new_conn"]->prepare("select $fieldtoget from $tablename where $wherefield!=?");
        $stmt->bind_param("$wherevaluetype", $wherevalue);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($returnvalue);
        $stmt->fetch();
        $stmt->close();

        if (($returnvalue == '' || $returnvalue == null) && $tablename == 'eg_item_type') {
            $stmt = $GLOBALS["new_conn"]->prepare("select 38type from eg_item_type where $wherefield=?");
            $stmt->bind_param("$wherevaluetype", $wherevalue);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($returnvalue);
            $stmt->fetch();
            $stmt->close();
        }
        return $returnvalue;
    }

    function sfx_sGetValueOrAnd($params)
    {
        // Default values for the parameters
        $defaults = [
            'fieldtoget' => '',
            'tablename' => '',
            'wherefield1' => '',
            'wherefield2' => '',
            'wherevalue1' => '',
            'wherevalue2' => '',
            'wherevaluetype' => 'si',
            'operator' => 'OR',
        ];
    
        // Merge provided parameters with default values
        $params = array_merge($defaults, $params);
    
        // Extract values from the array
        $fieldtoget = $params['fieldtoget'];
        $tablename = $params['tablename'];
        $wherefield1 = $params['wherefield1'];
        $wherefield2 = $params['wherefield2'];
        $wherevalue1 = $params['wherevalue1'];
        $wherevalue2 = $params['wherevalue2'];
        $wherevaluetype = $params['wherevaluetype'];
        $operator = strtoupper($params['operator']);
    
        // Build the SQL query dynamically
        $stmt = $GLOBALS["new_conn"]->prepare("SELECT $fieldtoget FROM $tablename WHERE $wherefield1=? $operator $wherefield2=?");
        $stmt->bind_param($wherevaluetype, $wherevalue1, $wherevalue2);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($returnvalue);
        $stmt->fetch();
        $stmt->close();
    
        return $returnvalue;
    }
        
    function sfx_getDischargeStatus($username, $accessnum)
    {
        $stmt = $GLOBALS["new_conn"]->prepare("select 40dc from eg_item_charge where 39patron=? and 38accessnum=?");
        $stmt->bind_param("ss", $username, $accessnum);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($returnvalue);
        $stmt->fetch();
        $stmt->close();
        return $returnvalue;
    }

    function sfx_getUserInfo($username, $system_admin_contact_disclaimer)
    {
        $stmt = $GLOBALS["new_conn"]->prepare("select name,username,division,lastlogin from eg_auth where username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($name, $username, $division, $lastlogin);
        $stmt->fetch();
        $stmt->close();

        $text = "<strong>Logged as :</strong> <span style='color:green;'>$name</span>";
        $text .= "<br/><strong>Identification ID :</strong> $username";
        $text .= "<br/><strong>From :</strong> $division";
        $text .= "<br/><strong>Last login :</strong> $lastlogin";
        $text .= "<br/><br/><em>$system_admin_contact_disclaimer</em>";
        return $text;

    }
    
    function sfx_isPatronEligibility($patron_id)
    {
        $queryT = "select count(39patron) as countStillLoan from eg_item_charge where 39patron='$patron_id' and 40dc!='DC'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT = mysqli_fetch_array($resultT);
        
        $queryS = "select max_loanitem from eg_auth_eligibility where usertype='".sfx_sGetValue("usertype", "eg_auth", "username", $patron_id)."'";
        $resultS = mysqli_query($GLOBALS["conn"], $queryS);
        $myrowS = mysqli_fetch_array($resultS);
        
        return ($myrowT["countStillLoan"] < $myrowS["max_loanitem"]) ? "TRUE" : "FALSE";
    }

    function sfx_getEmailPhoneFromUserIdentity($useridentity)
    {
        $stmt = $GLOBALS["new_conn"]->prepare("select emailaddress,phonenum from eg_auth_depo where useridentity=?");
        $stmt->bind_param("s", $useridentity);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($emailaddress, $phonenum);
        $stmt->fetch();
        $stmt->close();
        return "$emailaddress / $phonenum";
    }
    
    function sfx_countFeedbackForItemForUser($id, $username)
    {
        $stmt = $GLOBALS["new_conn"]->prepare("select count(id) as thiscount from eg_item_feedback where eg_item_id=? and eg_auth_username=?");
        $stmt->bind_param("is", $id, $username);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($returnvalue);
        $stmt->fetch();
        $stmt->close();
        return $returnvalue;
    }

    //below function will use microtime as accession number
    function sfx_millitime()
    {
        $microtime = microtime();
        $comps = explode(' ', $microtime);
        return sprintf('%d%03d', $comps[1], $comps[0] * 1000);
    }

    function sfx_stringRemoveScriptTag($str, $fullProcess = true)
    {
        //disabled
        //$str = iconv('utf-8', 'ascii//TRANSLIT//IGNORE', $str);//translit or remove unknown ascii char

        if ($fullProcess) {
            // Full processing: sanitize for database and HTML output
            $str = mysqli_real_escape_string($GLOBALS["conn"], $str);
            $str = html_entity_decode($str, ENT_QUOTES, "UTF-8");
            $str = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $str);
            return htmlspecialchars($str);
        } else {
            // Simple processing: only remove <script> tags
            return preg_replace('#<script(.*?)>(.*?)</script>#is', '', $str);
        }
    }

    function sfx_getSubjectHeadingNames($subject_heading_delimiter, $subjectheading)
    {
        $subjectheadings = explode($subject_heading_delimiter, $subjectheading);
        $total = count($subjectheadings) - 1;
        $i = 1;
        $returnSH = "";
        foreach ($subjectheadings as $subjectheading) {
            $subjectheading = mysqli_real_escape_string($GLOBALS["conn"], trim($subjectheading));
            $query_subject = "select 43subject from eg_subjectheading where 43acronym = '$subjectheading'";
            $result_subject = mysqli_query($GLOBALS["conn"], $query_subject);
            $num_results_affected = mysqli_num_rows($result_subject);
            
            if ($num_results_affected >= 1) {
                $myrow_subject = mysqli_fetch_array($result_subject);
                if (isset($myrow_subject["43subject"])) {$returnSH .= $myrow_subject["43subject"];}
            } else {
                $returnSH .= "";
            }

            if ($i < $total) {
                $returnSH .= "<br/>";
            }

            $i=$i+1;
        }
        return $returnSH;
    }

    // old version of sfx_just_clean and sfx_highlight
    /*
    function sfx_just_clean($string, $cleanType = 'max')
    {
        //current version: 1.0.20241223
        
        // Sanitize the input by escaping special characters and HTML tags
        $string = mysqli_real_escape_string($GLOBALS["conn"], $string);
        $string = strip_tags($string);

        // Define special characters to remove
        $specialCharacters = ['#', '$', '%', '&', '@', '.', '�', '=', '\\', '/'];

        // Remove special characters
        $string = str_replace($specialCharacters, '', $string);

        // If 'max' is set, remove anything other than alphanumeric characters
        if ($cleanType == 'max') {
            $string = preg_replace('/[^a-zA-Z0-9]/', ' ', $string);
        }

        // Trim whitespace and condense multiple spaces to a single space
        return trim(preg_replace('/\s+/', ' ', $string));
    }
    function sfx_highlight($text, $words)
    {
        $words = trim($words);
        $wordsArray = explode(' ', $words);
        foreach ($wordsArray as $word) {
            if (strlen(trim($word)) > 2) {
                $word = sfx_just_clean($word);//remove unwanted special characters, replace it with nothing
                if ($word != '') {
                    $hlstart = "<span style=\"background-color:yellow;\">";
                    $hlend = "</span>";
                    $text = preg_replace("/$word/i", $hlstart.'\\0'.$hlend, $text);//php7
                }
            }
        }
        return $text;
    }
    */

    //new version of sfx_just_clean and sfx_highlight
    function sfx_just_clean($string, $cleanType = 'max')
    {
        // Strip HTML tags (safe for visible content)
        $string = strip_tags($string);

        // Remove specific unwanted characters
        $specialCharacters = ['#', '$', '%', '&', '@', '.', '�', '=', '\\', '/'];
        $string = str_replace($specialCharacters, '', $string);

        // If 'max', allow only alphanumeric characters and space
        if ($cleanType == 'max') {
            $string = preg_replace('/[^a-zA-Z0-9]/', ' ', $string);
        }

        // Collapse multiple spaces
        return trim(preg_replace('/\s+/', ' ', $string));
    }
    function sfx_highlight($text, $words)
    {
        $words = trim($words);
        $wordsArray = explode(' ', $words);
        $hlstart = '<span style="background-color:yellow;">';
        $hlend = '</span>';

        // Split text into HTML-safe chunks
        $parts = preg_split('/(<[^>]+>)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);

        foreach ($parts as &$part) {
            if (preg_match('/<[^>]+>/', $part)) continue;

            foreach ($wordsArray as $word) {
                $word = sfx_just_clean($word);
                if (strlen($word) > 2 && $word != '') {
                    $escaped = preg_quote($word, '/');
                    $part = preg_replace("/($escaped)/i", $hlstart.'\\1'.$hlend, $part);
                }
            }
        }

        return implode('', $parts);
    }


    function sfx_getmicrotime()
    {
        list($usec, $sec) = explode(" ", microtime());
        return (float)$usec + (float)$sec;
    }

    function sfx_timetaken($timelog)
    {
        $now_array = explode(' ', date("D d/m/Y h:i a"));
        $lasttime_array = explode(' ', $timelog);
        
        $now_ampm = explode(':', $now_array[2]);
        if ($now_array[3] == 'pm' && $now_ampm[0] <> 12) {
            $now_ampm[0] = $now_ampm[0]+12;
        }

        $now_array[2]=$now_ampm[0].":".$now_ampm[1];
    
        $lasttime_ampm = explode(':', $lasttime_array[2]);
        if ($lasttime_array[3] == 'pm' && $lasttime_ampm[0] <> 12) {
            $lasttime_ampm[0] = $lasttime_ampm[0]+12;
        }

        $lasttime_array[2]=$lasttime_ampm[0].":".$lasttime_ampm[1];
                                                    
        $now_days = explode('/', $now_array[1]);
        $now_days = implode('-', $now_days);
        $lasttime_days = explode('/', $lasttime_array[1]);
        $lasttime_days = implode('-', $lasttime_days);
        
        $now = strtotime(date($now_days." ".$now_array[2]));
        $lasttime = strtotime($lasttime_days." ".$lasttime_array[2]);
        
        $dateDiff = $now-$lasttime;
        $fullDays = floor($dateDiff/(60*60*24));
        $fullHours = floor(($dateDiff-($fullDays*60*60*24))/(60*60));
        $fullMinutes = floor(($dateDiff-($fullDays*60*60*24)-($fullHours*60*60))/60);

        return "$fullDays"."d, $fullHours"."h, $fullMinutes"."m";
    }

    function sfx_sendEmail($pathway, $mel_subject, $mel_body, $mel_address, $mel_success, $mel_failed)
    {
        
        if ($GLOBALS["useEmailNotification"]) {
            require_once "$pathway/sw_vendor/autoload.php";
            $mail = new PHPMailer\PHPMailer\PHPMailer(false);
            $mail->isSMTP();// Send using SMTP
            $mail->SMTPDebug=$GLOBALS["emailDebuggerEnable"];// Enable verbose debug output 0=disable 1=enable
            $mail->Host=$GLOBALS["emailHost"];// Set the SMTP server to send through
            $mail->SMTPAuth=$GLOBALS["emailAuthentication"];// Enable SMTP authentication
            $mail->Username=$GLOBALS["emailUserName"];// SMTP username
            $mail->Password=$GLOBALS["emailPassword"];// SMTP password
            $mail->SMTPSecure=$GLOBALS["emailMode"];// Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            $mail->SMTPAutoTLS=$GLOBALS["emailAutoTLS"];// AutoTLS setting
            $mail->Port=$GLOBALS["emailPort"];// TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
            $mail->setFrom($GLOBALS["emailSetFrom"], $GLOBALS["emailSetFromName"]);
            $mail->addAddress($mel_address);
            $mail->isHTML(true);
            $mail->Subject=$mel_subject;
            $mail->Body=$mel_body;
            if (!$mail->Send()) {
                echo $mel_failed;
            } else {
                echo $mel_success;
            }
        }
    }

    function sfx_getDepoStatus($itemstatus)
    {
        $statusMap = [
            "ENTRY" => "Pending Approval",
            "ACCEPTED" => "Accepted",
            "ARCHIVEDP" => "Live in Repository",
            "ARCHIVEDPM" => "Moved to Repository",
            "ARCHIVEDL" => "Archived for Limited Access",
            "ARCHIVEEX" => "Archived Externally",
            "R_INCOMPLETE" => "Rejected: Incomplete",
            "R_DUPLICATE" => "Rejected: Duplicate Entry",
            "R_CONTACT" => "Rejected: Contact Admin",
            "UPD_METADATA" => "Resubmission: Metadata Changes",
            "UPD_SUBMISSION" => "Resubmission: Digital File",
            "GRADED" => "Graded"
        ];

        return isset($statusMap[$itemstatus]) ? $statusMap[$itemstatus] : "Unknown Status";
    }
    
    //use preg_match to get page counts
    function sfx_getPDFPages($appendroot, $document)
    {
        unset($appendroot);
        $pdf = file_get_contents($document);
        return preg_match_all("/\/Page\W/", $pdf, $dummy);
    }

    //use smalot function instead to get page counts
    function sfx_getPDFPagesSmalot($appendroot, $document)
    {
        include_once $appendroot."sw_vendor/autoload.php";
        try {
            $parser = new \Smalot\PdfParser\Parser();
            $pdf = $parser->parseFile($document);
            $metaData = $pdf->getDetails();
            $pdfTotalPages = $metaData['Pages'];
        } catch (Exception $e) {
            $pdfTotalPages= 0;
        }
        return $pdfTotalPages;
    }

    function sfx_dotFileTypes($filetypes)
    {
        $separated = preg_split("/\,/", $filetypes);
        $str = "";
        foreach ($separated as $result) {
            $str .= ".".$result.",";
        }
        return rtrim($str, ",");
    }

    function sfx_watermark_image($target, $wtrmrk_file, $newcopy)
    {
        $orientation = '';
        $watermark = imagecreatefrompng("$wtrmrk_file");
        imagealphablending($watermark, false);
        imagesavealpha($watermark, true);
        
        $exif = @exif_read_data($target);
        if ($exif && isset($exif['Orientation'])) {
            $orientation = $exif['Orientation'];
        }

        //new code for handling image filetype
        switch(mime_content_type($target)) {
            case 'image/png':
              $img = imagecreatefrompng($target);
              break;
            case 'image/gif':
              $img = imagecreatefromgif($target);
              break;
            case 'image/jpeg':
              $img = imagecreatefromjpeg($target);
              break;
            case 'image/bmp':
              $img = imagecreatefrombmp($target);
              break;
            default:
              $img = null;
            }
        
        if ($orientation != 1) {
            switch ($orientation) {
                case 3:
                $deg = 180;
                break;
                case 6:
                $deg = 270;
                break;
                case 8:
                $deg = 90;
                break;
                default:
                $deg = 0;
            }
            if ($deg) {
                $img = imagerotate($img, $deg, 0);
            }
        }
        
        $img_w = intval(imagesx($img));
        $img_h = intval(imagesy($img));
        $wtrmrk_w = intval(imagesx($watermark));
        $wtrmrk_h = intval(imagesy($watermark));
        $dst_x = intval(($img_w / 2) - ($wtrmrk_w / 2)); // For centering the watermark on any image
        $dst_y = intval(($img_h / 2) - ($wtrmrk_h / 2)); // For centering the watermark on any image
        imagecopy($img, $watermark, $dst_x, $dst_y, 0, 0, $wtrmrk_w, $wtrmrk_h);
        imagejpeg($img, $newcopy, 100);
        imagedestroy($img);
        imagedestroy($watermark);
    }

    function sfx_thumbnail_image($watermarked_File, $thumbnailed_target_File)
    {
        $percent = 0.5; // percentage of resize
        list($width, $height) = getimagesize($watermarked_File);
        $new_width = intval($width * $percent);
        $new_height = intval($height * $percent);
        $imagethumbnail_p = imagecreatetruecolor($new_width, $new_height);// Resample
        $imagethumbnail = imagecreatefromjpeg($watermarked_File);
        imagecopyresampled($imagethumbnail_p, $imagethumbnail, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
        imagejpeg($imagethumbnail_p, $thumbnailed_target_File, 100);
    }

    function sfx_thumbnail_image025($watermarked_File, $thumbnailed_target_File)
    {
        $percent = 0.25; // percentage of resize
        list($width, $height) = getimagesize($watermarked_File);
        $new_width = intval($width * $percent);
        $new_height = intval($height * $percent);
        $imagethumbnail_p = imagecreatetruecolor($new_width, $new_height);// Resample
        $imagethumbnail = imagecreatefromjpeg($watermarked_File);
        imagecopyresampled($imagethumbnail_p, $imagethumbnail, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
        imagejpeg($imagethumbnail_p, $thumbnailed_target_File, 100);
    }

    function sfx_record_block($dirtowrite)
    {
        if (!is_dir($dirtowrite)) {
            mkdir($dirtowrite, 0777, true);
            file_put_contents("$dirtowrite"."index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        }

        if (!is_file("$dirtowrite".date("Ymd").".txt")) {
            file_put_contents($dirtowrite.date("Ymd").".txt", "Captured on: ".date("Ymd"));
        }
            
        $writefile = fopen($dirtowrite.date("Ymd").".txt", "a");
        fwrite($writefile, "\r\n". sfx_get_ip());
        fclose($writefile);

        echo "<script>alert('Illegal query. Incident has been recorded.');window.location.replace('searcher.php?sc=cl');</script>";
        mysqli_close($GLOBALS["conn"]); exit();
    }

    function sfx_record_block_api($dirtowrite)
    {
        if (!is_dir($dirtowrite)) {
            mkdir($dirtowrite, 0777, true);
            file_put_contents("$dirtowrite"."index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
        }

        if (!is_file("$dirtowrite".date("Ymd").".txt")) {
            file_put_contents($dirtowrite.date("Ymd").".txt", "Captured on: ".date("Ymd"));
        }
            
        $writefile = fopen($dirtowrite.date("Ymd").".txt", "a");
        fwrite($writefile, "\r\n". sfx_get_ip());
        fclose($writefile);
    }

    //create new field based on table row for new item insert on reg.php
    /*
    0 $mandatory = either true (if this field is needed) or false (not needed)
    1 $tag_show = check if tag is set to show or not usually either true or false
    2 $viewmode = either marc or simple, will control if the row will be printed out or not
    3 $tag_name = tag name with full description. refer to config.php
    4 $tag_alternative_name = when viewmode is on simple view, pipe will be represented with an alternative name instead
    5 $require_leftsection = description and indicators or not: true or false
    6 $indicator_name = field name for indicator input box
    7 $indicator_default = default value for indicator input box
    8 $textfield_name = field name for text field for inputting desciptor
    9 $textfield_defaultvalue = default value for text field above
    10 $pipe_selection = what pipe this field going to be
    12,13 $textfield_width, $textfield_maxlength = controls text field width and maxlength
    13 is_upd = pass if user use the form as update form (true) otherwise it will be as insert new (false)
    14 db_field_value = inserted database field value for err.. a field
    15 db_indicator_value = inserted database field value for indicator
    16 field_type = default is 'text', and can change it to 'textarea'
    17 $extrabit = you can inject additional html control. it will be beside the textfield
    */
        function sfx_regRowGenerate(
        $mandatory,
        $tag_show,
        $viewmode,
        $tag_name,
        $tag_alternative_name,
        $require_leftsection,
        $indicator_name,
        $indicator_default,
        $textfield_name,
        $textfield_defaultvalue,
        $pipe_selection,
        $textfield_width,
        $textfield_maxlength,
            $is_upd = false,
            $db_field_value = "",
            $db_indicator_value = "",
            $fieldtype = "text",
            $extrabit = "")
        {
            if ($tag_show) {
                $indicator_value = $is_upd ? $db_indicator_value : $indicator_default;
                $textfield_value = $is_upd ? $db_field_value : $textfield_defaultvalue;

                $required_field = $mandatory ? 'required' : '';
                
                echo "<tr>";
                    echo "<td style='text-align:right;vertical-align:top;'><strong>$tag_name";
                        if ($require_leftsection) {
                            if ($viewmode == 'marc' && $db_indicator_value != 'null') {
                                echo " <input type='text' name='$indicator_name' value='$indicator_value' style='width:3ch' maxlength=2/>";
                            }

                            $paramsOrAnd = [
                                'fieldtoget' => 'dc_element',
                                'tablename' => 'config_user',
                                'wherefield1' => 'cvalue',
                                'wherefield2' => 'ctype',
                                'wherevalue1' => $tag_name,
                                'wherevalue2' => 'metadata',
                                'wherevaluetype' => 'ss',
                                'operator' => 'AND'
                            ];
                            if (sfx_sGetValueOrAnd($paramsOrAnd) != 'false') {
                                echo "<br/><span style='color:orange;font-size:8pt;'>".sfx_sGetValue('dc_element', 'config_user', 'cvalue', $tag_name)."</span>";
                            }
                        }
                    echo "</strong></td>";
                    echo "<td style='vertical-align:top;'> ";
                        if ($viewmode == 'marc') {
                            echo ": <span style='color:green;'>$pipe_selection</span>";
                        } else {
                            echo ($tag_alternative_name != '') ? " $tag_alternative_name<br/>: " : ": ";
                        }
                        if ($fieldtype == "textarea") {
                            $marginleftwidth = ($viewmode == 'marc') ? '15pt' : '7pt';
                            echo "<br/><textarea name='$textfield_name' cols='40' rows='5' style='margin-left:$marginleftwidth;width:$textfield_width'>$textfield_value</textarea>";
                        } else {
                            echo "<input type='text' id='$textfield_name' name='$textfield_name' style='width:$textfield_width' value='$textfield_value' maxlength='$textfield_maxlength' $required_field/> $extrabit";
                        }
                    echo "</td>";
                echo "</tr>\n\n";
            }
        }
        
        //create new field based on table row for new item insert on reg.php (repeatable with 1st item mandatory)
        /*
        1 $tag_show = check if tag is set to show or not usually either true or false
        2 $totalinput = how many variable you want
        3 $viewmode = either marc or simple, will control if the row will be printed out or not
        4 $tag_name = tag name with full description. refer to config.php
        5 $indicator_name = field name for indicator input box
        6 $indicator_default = default value for indicator input box
        7 $pipe_selection = what pipe this field going to be
        8 $textfield_name = field name for text field for inputting desciptor
        9 is_upd = pass if user use the form as update form (true) otherwise it will be as insert new (false)
        10 db_field_value = inserted database field value for err.. a field
        12 db_indicator_value = inserted database field value for indicator
        */
        function sfx_regRowGenerateRepeats1f(
            $tag_show,
            $totalinput,
            $viewmode,
            $tag_name,
            $indicator_name,
            $indicator_default,
            $pipe_selection,
            $textfield_name,
                $is_upd = false,
                $db_field_value = "",
                $db_indicator_value = "")
        {
            if ($tag_show) {
                $indicator_value = $is_upd ? $db_indicator_value : $indicator_default;
                $textfield_value = $is_upd ? $db_field_value : '';

                echo "<tr>";
                    echo "<td style='text-align:right;vertical-align:top;'><strong>$tag_name";
                        if ($viewmode == 'marc') {
                            echo " <input type='text' name='$indicator_name' value='$indicator_value' style='width:3ch' maxlength=2/>";
                        }

                    echo "</strong></td>";
                    echo "<td style='vertical-align:top;'> :";
                        if ($viewmode == 'marc') {
                            echo " <span style='color:green;'>$pipe_selection</span>";
                        }
                        echo "<input type='text' name='$textfield_name"."1"."' style='width:80%' maxlength='255' value='$textfield_value' /> ";
                        if ($GLOBALS["$textfield_name"."2"] == '') {
                            echo "<a id='al1' style='font-size:8pt;' onclick=\"document.getElementById('a2').style.display='';document.getElementById('al1').style.display='none';\">[+]</a>";
                        }
                    echo "</td>";
                echo "</tr>\n\n";
                                            
                for ($x=2; $x<=$totalinput; $x++) {
                    if ($is_upd) {
                        $indicator_value = $GLOBALS["$indicator_name"."_".($x+0)];
                        $textfield_value = $GLOBALS["$textfield_name".($x+0)];
                        $textfield_value_next = ($x < $totalinput) ? $GLOBALS["{$textfield_name}".($x + 1)] : "";
                    } else {
                        $indicator_value = $indicator_default;
                        $textfield_value = "";
                        $textfield_value_next = "";
                    }
                    
                    if ($textfield_value != '') {$showthis = "show";} else {$showthis = "none";}

                    echo "
                        <tr id='a".($x+0)."' style='display:$showthis'>";
                        echo "<td style='text-align:right;vertical-align:top;'>$tag_name";
                            if ($viewmode == 'marc') {
                                echo " <input type='text' name='".$indicator_name."_".($x+0)."' value='$indicator_value' size=3 maxlength=2/>";
                            }
                        echo "</td>";
                        echo "<td style='vertical-align:top;'>: ";
                            echo ($viewmode == 'marc') ? "<span style='color:green;'>$pipe_selection</span>" : '';
                            echo "<input type='text' name='".$textfield_name.($x+0)."' value='$textfield_value' style='width:80%' maxlength='255'/> ";
                            if ($x <> $totalinput && $textfield_value_next == '') {
                                echo "<a id='al".($x+0)."' style='font-size:8pt;' onclick=\"document.getElementById('a".($x+1)."').style.display='';document.getElementById('al".($x+0)."').style.display='none';\">[+]</a>";
                            }
                        echo "</td>";
                        echo "</tr>\n\n
                    ";
                }
            }
        }
        //create new field based on table row for new item insert on reg.php (repeatable with 1st item mandatory)
        /*
        1 $tag_show = check if tag is set to show or not usually either true or false
        2 $totalinput = how many variable you want
        3 $viewmode = either marc or simple, will control if the row will be printed out or not
        4 $tag_name = tag name with full description. refer to config.php
        5 $indicator_name = field name for indicator input box
        6 $indicator_default = default value for indicator input box
        7 $pipe_selection = what pipe this field going to be
        8 $textfield_name = field name for text field for inputting desciptor
        9 is_upd = pass if user use the form as update form (true) otherwise it will be as insert new (false)
        10 db_field_value = inserted database field value for err.. a field
        11 db_indicator_value = inserted database field value for indicator
        */
        function sfx_regRowGenerateRepeats2f(
            $tag_show,
            $totalinput,
            $viewmode,
            $tag_name,
            $indicator_name,
            $indicator_default,
            $pipe_selection,
            $textfield_name,
                $is_upd = false,
                $db_field_value = "",
                $db_field_value_s = "",
                $db_field_value_e_simple = "",
                $db_indicator_value = "")
        {
            if ($tag_show) {
                $indicator_value = $is_upd ? $db_indicator_value : $indicator_default;
                $textfield_value = $is_upd ? $db_field_value : '';
                $textfield_value_s = $is_upd ? $db_field_value_s : '';

                echo "<tr>";
                    echo "<td style='text-align:right;vertical-align:top;'><strong>$tag_name";
                        if ($viewmode == 'marc') {
                            echo " <input type='text' name='$indicator_name' value='$indicator_value' style='width:3ch' maxlength=2/>";
                        }

                        $paramsOrAnd = [
                            'fieldtoget' => 'dc_element',
                            'tablename' => 'config_user',
                            'wherefield1' => 'cvalue',
                            'wherefield2' => 'ctype',
                            'wherevalue1' => $tag_name,
                            'wherevalue2' => 'metadata',
                            'wherevaluetype' => 'ss',
                            'operator' => 'AND'
                        ];
                        if (sfx_sGetValueOrAnd($paramsOrAnd) != 'false') {
                            echo "<br/><span style='color:orange;font-size:8pt;'>".sfx_sGetValue('dc_element', 'config_user', 'cvalue', $tag_name)."</span>";
                        }
                    echo "</strong></td>";
                    echo "<td style='vertical-align:top;'> :";
                        if ($viewmode == 'marc') {
                            echo " <span style='color:green;'>$pipe_selection</span>";
                        }

                        echo "<input type='text' name='$textfield_name"."1"."' style='width:50%' maxlength='255' value='$textfield_value' /> ";
                        echo ($viewmode == 'marc') ? "<span style='color:green;'>|e</span>" : $db_field_value_e_simple.":";
                        echo "<input type='text' name='$textfield_name"."1_s"."' style='width:28%' maxlength='255' value='$textfield_value_s' /> ";
                        if ($GLOBALS["$textfield_name"."2"] == '') {
                            echo "<a id='al1' style='font-size:8pt;' onclick=\"document.getElementById('a2').style.display='';document.getElementById('al1').style.display='none';\">[+]</a>";
                        }
                    echo "</td>";
                echo "</tr>\n\n";
                                            
                for ($x=2; $x<=$totalinput; $x++) {
                    if ($is_upd) {
                        $indicator_value = $GLOBALS["$indicator_name"."_".($x+0)];
                        $textfield_value = $GLOBALS["$textfield_name".($x+0)];
                        $textfield_value_s = $GLOBALS["$textfield_name".($x+0)."_s"];
                        $textfield_value_next = ($x < $totalinput) ? $GLOBALS["{$textfield_name}".($x + 1)] : "";
                    } else {
                        $indicator_value = $indicator_default;
                        $textfield_value = "";
                        $textfield_value_s = "";
                        $textfield_value_next = "";
                    }
                    
                    if ($textfield_value != '') {$showthis = "show";} else {$showthis = "none";}

                    echo "
                        <tr id='a".($x+0)."' style='display:$showthis'>";
                        echo "<td style='text-align:right;vertical-align:top;'>";
                            if ($viewmode == 'marc') {
                                echo "<input type='text' name='".$indicator_name."_".($x+0)."' value='$indicator_value' style='width:3ch' maxlength=2/>";
                            }
                        echo "</td>";
                        echo "<td style='vertical-align:top;'>: ";
                            echo ($viewmode == 'marc') ? "<span style='color:green;'>$pipe_selection</span>" : '';
                            echo "<input type='text' name='".$textfield_name.($x+0)."' value='$textfield_value' style='width:50%' maxlength='255'/> ";
                            echo ($viewmode == 'marc') ? "<span style='color:green;'>|e</span>" : $db_field_value_e_simple.":";
                            echo "<input type='text' name='".$textfield_name.($x+0)."_s' style='width:28%' maxlength='255' value='$textfield_value_s' /> ";
                            if ($x <> $totalinput && $textfield_value_next == '') {
                                echo "<a id='al".($x+0)."' style='font-size:8pt;' onclick=\"document.getElementById('a".($x+1)."').style.display='';document.getElementById('al".($x+0)."').style.display='none';\">[+]</a>";
                            }
                        echo "</td>";
                        echo "</tr>\n\n
                    ";
                }
            }
        }

        //create new selecction: select box based on table row for new item insert on reg.php
        /*
        1 $viewmode = either marc or simple, will control if the row will be printed out or not
        2 $tag_name = tag name with full description. refer to config.php
        3 $indicator_name = field name for indicator input box
        4 $indicator_default = default value for indicator input box
        5 $predefine_list = defined on config.php all the list involved in building this select box. see $tag_041_selectable for example
        6 $predefine_default = default selection for the select box. value must present at config.php per item no.6 above
        7 $fieldname = name for the input text field
        8 $fieldtype = what type it is either select or all the other(free text)
        9 $require_leftsection = description and indicators or not: true or false
        10 is_upd = pass if user use the form as update form (true) otherwise it will be as insert new (false)
        11 db_field_value = inserted database field value for err.. a field
        12 db_indicator_value = inserted database field value for indicator
        */
        function sfx_regRowGenerateSelectBox(
            $tag_show,
            $viewmode,
            $tag_name,
            $indicator_name,
            $indicator_default,
            $predefine_list,
            $predefine_default,
            $fieldname,
            $fieldtype,
                $require_leftsection = false,
                $is_upd = false,
                $db_field_value = "",
                $db_indicator_value = "")
        {
            if ($tag_show) {
                $indicator_value = $is_upd ? $db_indicator_value : '';
                $textfield_value = $is_upd ? $db_field_value : '';

                echo "<tr><td style='text-align:right;vertical-align:top;'><strong>$tag_name";
                    if ($require_leftsection && $viewmode == 'marc') {
                        echo " <input type='text' name='$indicator_name' style='width:3ch' maxlength=2 value='$indicator_value' />";
                    }

                    $paramsOrAnd = [
                        'fieldtoget' => 'dc_element',
                        'tablename' => 'config_user',
                        'wherefield1' => 'cvalue',
                        'wherefield2' => 'ctype',
                        'wherevalue1' => $tag_name,
                        'wherevalue2' => 'metadata',
                        'wherevaluetype' => 'ss',
                        'operator' => 'AND'
                    ];
                    if (sfx_sGetValueOrAnd($paramsOrAnd) != 'false') {
                        echo "<br/><span style='color:orange;font-size:8pt;'>".sfx_sGetValue('dc_element', 'config_user', 'cvalue', $tag_name)."</span>";
                    }
                echo "</strong></td>";
                echo "<td style='vertical-align:top;'>: ";
                    echo ($viewmode == 'marc') ? "<span style='color:green;'>$indicator_default</span>" : '';
                    if ($fieldtype == "select") {
                        $selectable = explode("|", $predefine_list);
                        echo "<select name='$fieldname'>";
                        for ($x = 0; $x < sizeof($selectable); $x++) {
                            echo "<option value='".$selectable[$x]."' ";
                                echo ($is_upd && $textfield_value == $selectable[$x]) || (!$is_upd && $selectable[$x] == $predefine_default) ? "selected" : "";
                            echo ">".$selectable[$x]."</option>";
                        }
                        echo "</select>";
                    } else {
                        echo "<input type='text' name='$fieldname' style='width:80%' maxlength='50'/>";
                    }
                echo "</td></tr>\n\n";
            }
        }

        //file upload box extension checker for reg.php --must be put at <head>
        function sfx_quotesFileTypes($filetypes)
        {
            $separated = preg_split("/\,/", $filetypes);
            $str = "";
            foreach ($separated as $result) {
                $str .= "'".$result."',";
            }
            return rtrim($str, ",");
        }
        function sfx_generateFileBoxAllowedExtensionRule($fileFieldName, $allowedExtensionList)
        {
            echo "
            $(function() {
                $('#$fileFieldName').change(function() {
                    var fileExtension = ["; echo sfx_quotesFileTypes($allowedExtensionList); echo "];
                    if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                        alert('Only "; echo sfx_dotFileTypes($allowedExtensionList); echo " formats are allowed.');
                        $fileFieldName.value = '';
                    }
                })
            })\n\n
            ";
        }
        
        //generate file upload box for reg.php
        function sfx_regRowGenerateFileUploadBox($whatThisFor, $fileMaxSize, $filefieldName, $fileAllowedExtension, $is_upd = false, $fileLocation = null)
        {
            echo "
            <tr>
                <td style='text-align:right;vertical-align:top;'><strong>$whatThisFor <span style='color:red;'>(Max ".($fileMaxSize/1000000)."M)</span></strong></td>
                <td>:
                <input type='file' id='$filefieldName' name='$filefieldName' size='38' accept='"; echo sfx_dotFileTypes($fileAllowedExtension); echo "' />";
                if ($is_upd && $fileLocation != null && is_file($fileLocation)) {
                    echo "[<a target='_blank' href='$fileLocation'>Existing File</a>]";
                }
                echo "</td>
            </tr>\n\n
            ";
        }

        function sfx_cutText($str,$cutcount) {
            if ($str <> null) {
                $text = substr($str, 0, $cutcount);
                if (strlen($str) >= $cutcount) {
                    return $text."...";
                } else {
                    return $str;
                }
            } else {
                return $str;
            }
        }

        function sfx_listFiles($dir) {
            $files = array_diff(scandir($dir), array('.', '..'));
            $files = array_filter($files, function($file) {
                return pathinfo($file, PATHINFO_EXTENSION) !== 'php';
            });
            return $files;
        }
        
        function sfx_cutLongFileName($teks) {
            return (strlen($teks) > 30) ? substr($teks, 0, 30) . '..' : $teks;
        }

        function sfx_getCurrentUrlWithoutQuery() {
            $url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            $parsedUrl = parse_url($url);
            return $parsedUrl['scheme'] . '://' . $parsedUrl['host'] . $parsedUrl['path'];
        }

        function sfx_deleteDirectory($dir) {
            if (!is_dir($dir)) {
                return false;
            }
            $items = scandir($dir);
            foreach ($items as $item) {
                if ($item == '.' || $item == '..') {
                    continue; // Abaikan "." dan ".."
                }
                $path = $dir . DIRECTORY_SEPARATOR . $item;
                if (is_dir($path)) {
                    sfx_deleteDirectory($path);
                } else {
                    unlink($path);
                }
            }
            return rmdir($dir);
        }

        function sfx_echoAjaxOutput($fetchURL,$divName) {
            echo "
            <script>
                    document.addEventListener(\"DOMContentLoaded\", function() {
                        function fetchSearchResults() {
                            var xhr = new XMLHttpRequest();
                            xhr.open('GET', '$fetchURL', true);
                            xhr.onreadystatechange = function() {
                                if (xhr.readyState === XMLHttpRequest.DONE) {
                                    if (xhr.status === 200) {
                                        const resultsDiv = document.getElementById('$divName');
                                        resultsDiv.innerHTML = xhr.responseText;
                                        resultsDiv.style.display = 'block';
                                    } else {
                                        console.error('Error fetching search results:', xhr.statusText);
                                    }
                                }
                            };
                            xhr.send();
                        }
                        fetchSearchResults();
                    });
                </script>
            ";
        }

        function sfx_ip_in_range($ip, $range) {
            $pattern = str_replace('x', '*', $range);
            return fnmatch($pattern, $ip);
        }
        function sfx_check_ip($user_ip,$complianceip) {
            $gotX = false;
            if (preg_match("/x/", $complianceip)) {
                $gotX = true;
            }

            $whattofinallyReturn = false;
            if ($gotX) {
                if (sfx_ip_in_range($user_ip, $complianceip)) {
                    $whattofinallyReturn = true;
                }
            } else {
                if ($user_ip === $complianceip) {
                    $whattofinallyReturn = true;
                }
            }
            return $whattofinallyReturn;
        }

        function sfx_convertToEmbedUrl($watchUrl) {
            // Parse the URL and extract the query parameters
            $urlParts = parse_url($watchUrl);
            parse_str($urlParts['query'], $queryParams);
        
            // Check if the 'v' parameter exists
            if (isset($queryParams['v'])) {
                $videoId = $queryParams['v'];
                // Create the embed URL
                return "https://www.youtube.com/embed/" . $videoId;
            } else {
                return "Invalid YouTube URL.";
            }
        }
