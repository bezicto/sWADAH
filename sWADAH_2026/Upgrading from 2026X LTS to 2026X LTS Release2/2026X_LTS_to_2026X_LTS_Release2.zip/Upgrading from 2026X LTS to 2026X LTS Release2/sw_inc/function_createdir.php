<?php
/*
Filename: sw_inc/function_createdir.php
Usage: Create apache writeable upload directories if not exist
Version: 20250101.0801
Last change: -
*/

    function sfx_createDirectory($createdDir)
    {
        if (!is_dir($createdDir)) {
            mkdir($createdDir, 0755, true);
            file_put_contents("$createdDir"."/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>");
            file_put_contents(
                "$createdDir/.htaccess",
                "<Files \"*.php\">\n".
                "    <IfModule mod_authz_core.c>\n".
                "        Require all denied\n".
                "    </IfModule>\n".
                "    <IfModule !mod_authz_core.c>\n".
                "        deny from all\n".
                "    </IfModule>\n".
                "</Files>\n".
                "ErrorDocument 403 \"<html lang='en'><head><title>403 Forbidden</title></head><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div></body></html>\"\n"
            );
        }
    }
    sfx_createDirectory($system_docs_directory);
    sfx_createDirectory($system_pdocs_directory);
    sfx_createDirectory($system_txts_directory);
    sfx_createDirectory($system_isofile_directory);
    sfx_createDirectory($system_albums_directory);
    sfx_createDirectory($system_albums_thumbnail_directory);
    sfx_createDirectory($system_albums_watermark_directory);
    sfx_createDirectory($system_dfile_directory);
    sfx_createDirectory($system_pfile_directory);
    sfx_createDirectory($recorded_incidents_directory);
    sfx_createDirectory($system_statcache_directory);
    sfx_createDirectory('sw_installed');
