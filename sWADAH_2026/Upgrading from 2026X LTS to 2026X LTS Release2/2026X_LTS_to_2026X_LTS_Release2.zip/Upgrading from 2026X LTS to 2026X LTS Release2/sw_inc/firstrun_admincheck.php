<?php

    /*
    Filename: sw_inc/firstrun_admincheck.php
    Usage: check if admin account exist or not, if not exist then create one
    Version: 20250301.0000
    Last change: -
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
    
    function fstfx_generateRandomPassword($length = 8) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomPassword = '';
        for ($i = 0; $i < $length; $i++) {
            $randomPassword .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomPassword;
    }
    //check if admin existed or not, if not exist then create one
    $stmt_countadmin = $new_conn->prepare("select count(*) from eg_auth where username='admin'");
    $stmt_countadmin->execute();
    $stmt_countadmin->bind_result($num_results_affected_username);
    $stmt_countadmin->fetch();$stmt_countadmin->close();
    if ($num_results_affected_username == 0) {
        $newRandomPassword = fstfx_generateRandomPassword();
        $stmt_insert = $new_conn->prepare("insert into eg_auth values(DEFAULT,'admin',AES_ENCRYPT('$newRandomPassword','$aes_key'),'SUPER','Administrator','Administrative','ALL','','OFF',0,DEFAULT,DEFAULT)");
        $stmt_insert->execute();
        $stmt_insert->close();
        echo "User: <strong>admin</strong> has been created. Default password is: <strong>$newRandomPassword</strong><br/>Copy this value and then refresh this page. It will not appear again.";
        exit;
    }
