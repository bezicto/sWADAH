<?php
    /*
    Filename: sw_inc/index2_s_boolean.php
    Usage: Search engine with SQL statements for admin only
    Version: 20250415.0853
    Last change: -
        20250415.0853 - add check for onlytitle in line 24
    */

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");

    //total number of result from duplicate finder page
    if (isset($_GET['mf']) && is_numeric($_GET['mf'])) {
        $appendmflimit = $_GET['mf'];
        $rowsPerPage = $_GET['mf'];//reset rowPerPage to $_GET[mf]
    } else {
        $appendmflimit = "$offset, $rowsPerPage";
    }

    $queryAppendVisibleOnly = "and 50item_status='1'";//show only item with item_status=1

    //add language filter
    $queryAppendLanguage = '';
    if ((isset($sclang_select) && $sclang_select != 'All') && !isset($_GET['onlytitle'])) {
        $queryAppendLanguage = "and 38langcode='$sclang_select'";
    }

    if ($sctype_select == 'EveryThing') {
        if ($scstr_term == '') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 $queryAppendLanguage order by id desc LIMIT $appendmflimit";
        } else {
            $query1 = "select SQL_CALC_FOUND_ROWS *, match (38title) against ('$scstr_term' in boolean mode) as score from eg_item where id<>0 $queryAppendLanguage and match (";
            $query1 .= (isset($_GET['onlytitle']) && $_GET['onlytitle'] == 'yes') ? "38title" : "38title,41fulltexta,41pdfattach_fulltext,50search_cloud";
            $query1 .= ") against ('$scstr_term' in boolean mode) order by score desc LIMIT $appendmflimit";
        }
    } elseif (isset($_SESSION[$ssn.'username']) && ($sctype_select == 'Control Number')) {
        if (is_numeric($scstr_term)) {
            if ($scstr_term <> '') {
                $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id=$scstr_term $queryAppendLanguage LIMIT $appendmflimit";
            } else {
                $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 $queryAppendLanguage LIMIT $appendmflimit";
            }
        } else {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 $queryAppendLanguage LIMIT $appendmflimit";
            sfx_echoPopupAlert("The input you have typed is not numerical. Please retype.");
        }
    } elseif ($sctype_select == 'Author') {
        if ($scstr_term <> '') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 $queryAppendLanguage and match (38author) against ('$scstr_term' in boolean mode) LIMIT $appendmflimit";
        } else {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where id<>0 $queryAppendLanguage LIMIT $appendmflimit";
        }
    } else {
        if ($scstr_term == '') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_item where 38typeid = '$sctype_select' $queryAppendLanguage order by id desc LIMIT $appendmflimit";
        } else {
            $query1 = "select SQL_CALC_FOUND_ROWS *, match (38title) against ('$scstr_term' in boolean mode) as score from eg_item where ";
            $query1 .= " 38typeid = '$sctype_select' $queryAppendLanguage and match (38title,41fulltexta,41pdfattach_fulltext,50search_cloud) against ('$scstr_term' in boolean mode)";
            $query1 .= " order by score desc LIMIT $appendmflimit";
        }
    }
