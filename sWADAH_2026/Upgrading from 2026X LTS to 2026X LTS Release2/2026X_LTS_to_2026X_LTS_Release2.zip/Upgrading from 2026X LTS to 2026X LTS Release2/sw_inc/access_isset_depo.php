<?php
/*
Filename: sw_inc/access_isset_depo.php
Usage: Check if useridentity session is set before can proceed to access the page that has this include
Version: 20250101.0801
Last change: -
*/

    if (!isset($_SESSION[$ssn.'useridentity'])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>";
        exit;
    }
