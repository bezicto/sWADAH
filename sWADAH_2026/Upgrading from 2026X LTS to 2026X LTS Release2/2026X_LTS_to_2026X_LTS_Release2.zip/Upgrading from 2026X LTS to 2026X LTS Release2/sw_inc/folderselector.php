<?php
/*
Filename: sw_inc/folderselector.php
Usage: Folder selector for reg.php
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Folder Selector";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_isset.php';
?>

<html lang='en'>

<head></head>

<body>
    <script language="JavaScript">
        function js_pick(symbol,symbol2) {
          if (window.opener && !window.opener.closed)
            {
                window.opener.document.mainform.folderid1.value = symbol;
                window.opener.document.mainform.foldername1.value = symbol2;
            }
             window.close();
        }
    </script>
    
    Select a folder related to the item :
    
    <hr>
                        
    <u>ID</u> <u>Publisher</u>
        
    <br/><br/>
    
    <?php
        $queryC = "select 38folderid,38foldername from eg_item_folder order by 38foldername";
        $resultC = mysqli_query($GLOBALS["conn"], $queryC);
        
        while ($myrowC = mysqli_fetch_array($resultC)) {
            $foldername = $myrowC["38foldername"];
            $folderid = $myrowC["38folderid"];
            echo "<span style='font-size:14px'>$folderid : <a href=\"javascript:js_pick('$folderid','$foldername')\">$foldername</a></span><br/><br/>";
        }
    ?>
    
    <br/><br/>

    <div style="text-align:center">[<a href='javascript:window.close();'>Close</a>]</div>
    <br/>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
