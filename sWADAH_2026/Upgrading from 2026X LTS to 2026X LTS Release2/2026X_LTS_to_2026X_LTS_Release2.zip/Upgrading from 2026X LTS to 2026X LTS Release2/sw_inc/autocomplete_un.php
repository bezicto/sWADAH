<?php
/*
Filename: sw_inc/autocomplete_un.php
Usage: Auto-complete username as used in sw_asset/js/main.js
Version: 20250101.0801
Last change: -
*/

include_once '../core.php';

// Get search term
if (!isset($_GET['term'])) {
        die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>");
}

$searchTerm = mysqli_real_escape_string($GLOBALS["conn"], $_GET['term']);

//Generate skills data array
$itemData = array();

$param = "%$searchTerm%";
$stmtB = $new_conn->prepare("SELECT username FROM eg_auth WHERE username LIKE ? order by username");
$stmtB->bind_param("s", $param);//s string
$stmtB->execute();
$resultB = $stmtB->get_result();
                                                        
while ($row = $resultB->fetch_assoc()) {
        array_push($itemData, $row['username']);
}

// Return results as json encoded array
echo json_encode($itemData);
