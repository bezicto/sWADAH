<?php
/*
Filename: sw_inc/setstatusfeedback_code.php
Usage: Set status for a feedback
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if (isset($_GET["fid"]) && is_numeric($_GET["fid"])) {
    if ($_GET['ms'] == 'YES') {
        $setstatus = 'NO';
    } elseif ($_GET['ms'] == 'NO') {
        $setstatus = 'YES';
    }
    
    $timestamp_for_approval = time();
    
    $stmt_update = $new_conn->prepare("update eg_item_feedback set 39moderated_status=?, 39moderated_by=?, 39moderated_timestamp=? where id=?");
    $stmt_update->bind_param("sssi", $setstatus, $_SESSION[$ssn.'username'], $timestamp_for_approval, $_GET["fid"]);
    $stmt_update->execute();$stmt_update->close();
    
    sfx_refreshAndClose("Setting status for feedback.");
}
