<?php
/*
Filename: sw_inc/cmz.php
Usage: Set or unset item to be commercialized
Version: 20250101.0801
Last change: -
*/

session_start();define('includeExist', true);

include_once '../core.php';
include_once '../sw_inc/access_isset.php';
include_once '../sw_inc/functions.php';

if (isset($_GET["itemid"]) && is_numeric($_GET["itemid"])) {
    $get_id_det = $_GET["itemid"];
} else {
    sfx_echoPopupAlert("Trying doing something illegal arent you ?");
}

$timestamp = time();
if (isset($_GET['cmz']) && $_GET['cmz'] == 't') {
    $stmt_insertcmz = $new_conn->prepare("insert into eg_commercialize values(DEFAULT,?,?)");
    $stmt_insertcmz->bind_param("is", $get_id_det, $timestamp);
    $stmt_insertcmz->execute();$stmt_insertcmz->close();
    sfx_refreshAndClose("Operation done.");
} elseif (isset($_GET['cmz']) && $_GET['cmz'] == 'u') {
    $stmt_del = $new_conn->prepare("delete from eg_commercialize where eg_item_id = ?");
    $stmt_del->bind_param("i", $get_id_det);
    $stmt_del->execute();$stmt_del->close();
    sfx_refreshAndClose("Operation done.");
} else {
    sfx_echoPopupAlert("Trying doing something illegal arent you ?");
}
