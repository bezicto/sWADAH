<?php
/*
Filename: sw_splus/admigration_script.php
Usage: Repopulate access hits and download counts for all items
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Access and Download Migration Script";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/functions.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>' style='font-size:12pt;'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>

    <u><strong>This tool will repopulate hit and download counts for all items in the database.</strong></u><br/>

    <br/>Select which repopulate function you want to use:
    <ul>
        <li><a onclick="return confirm('Are you sure to do this? Make sure you have backup the entire database before proceeding.')" href='admigration_script.php?rt=fresh'>Fresh</a>:
             This will reset hit and download counts for all items. The new value will be assigned based on current logs.
             <br/>For example, if item A already has 4 download counts, but in the log it has 6. The new download counts will be 6.
             <br/><span style='color:blue;'>When to use this?</span> After testing and when you want to start over with logs that available in the database.
            </li>
        <br/><br/>
        <li><a onclick="return confirm('Are you sure to do this? Make sure you have backup the entire database before proceeding.')" href='admigration_script.php?rt=append'>Append</a>:
             This will find the current counts for both hit and download; then it will add them to the counts that already inside the each items.
             <br/>For example, if item A already has 4 download counts, and in the log it has 6. The new download counts will be 10.
             <br/><span style='color:blue;'>When to use this?</span> When you already statisfied with the hit/download counts per item, and you have already delete all previous log that counts towards the number. All new one in the logs can be counts as new.
             <span style='color:red;'>Be sure to be very sure you want to do this. Do it at your own risks.</span>
            </li>
    </ul>

    <?php

    if (isset($_GET['rt']) &&  $_GET['rt'] == 'fresh') {
        $query_toupd = "select id from eg_item";
        $result_toupd = mysqli_query($GLOBALS["conn"], $query_toupd);
        $n=0;
        while ($row_toupd = mysqli_fetch_array($result_toupd)) {
            $live_ah = sfx_sGetValue("count(id) as accesshits", "eg_item_access", "eg_item_id", $row_toupd['id'], "i");
            $live_dl = sfx_sGetValue("count(id) as downloadhits", "eg_item_download", "eg_item_id", $row_toupd['id'], "i");
            
            $stmt_update = $new_conn->prepare("update eg_item set 41hits=?, 41downloads=? where id=?");
            $stmt_update->bind_param("iii", $live_ah, $live_dl, $row_toupd['id']);
            $stmt_update->execute();$stmt_update->close();
            
            $n=$n+1;
        }
        echo "<br/>Total records updated: $n<br/><br/>";
    } elseif (isset($_GET['rt']) &&  $_GET['rt'] == 'append') {
        $query_toupd = "select id,41hits,41downloads from eg_item";
        $result_toupd = mysqli_query($GLOBALS["conn"], $query_toupd);
        $n=0;
        while ($row_toupd = mysqli_fetch_array($result_toupd)) {
            $new_ah = sfx_sGetValue("count(id) as accesshits", "eg_item_access", "eg_item_id", $row_toupd['id'], "i") + $row_toupd['41hits'];
            $new_dl = sfx_sGetValue("count(id) as downloadhits", "eg_item_download", "eg_item_id", $row_toupd['id'], "i") + $row_toupd['41downloads'];
            
            $stmt_update = $new_conn->prepare("update eg_item set 41hits=?, 41downloads=? where id=?");
            $stmt_update->bind_param("iii", $new_ah, $new_dl, $row_toupd['id']);
            $stmt_update->execute();$stmt_update->close();
            
            $n=$n+1;
        }
        echo "<br/>Total records updated: $n<br/><br/>";
    }
    ?>
     
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
