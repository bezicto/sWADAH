<?php
/*
    Filename: sw_cmmsl/doc.php
    Usage: Commercial List Item Viewer
    Version: 1.0.20240619.1223 Alpha
    ------
    Notes:
    If you can read this, you are probably want to change something in this puddle of codes.

    call structure e.g.: /sw_cmmsl/doc.php?v=
    where v is passed as encrypted value from api
*/

session_start();
include_once '../core.php';

if (!isset($_GET['v'])) {
    echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Resource time out.</h2><em>Please contact the system administrator if you see this message.</em></div>";
    mysqli_close($GLOBALS["conn"]); exit;
}

//decrypt the v
$decryption_f = openssl_decrypt(base64_decode($_GET['v']), "AES-128-CTR", $aes_key, 0, "1234567891011121");

//resolve a decrypted path and only allow regular, non-executable files inside the repository document folders
function dfx_safeDocPath($requested, $root, $dirs, $systemPath = '')
{
    if (!is_string($requested) || $requested === '' || strpos($requested, "\0") !== false) {
        return false;
    }
    $candidates = [$requested];
    if ($systemPath !== '' && strpos($requested, $systemPath) === 0) {
        $candidates = [$root.'/'.ltrim(substr($requested, strlen($systemPath)), '/')];
    } elseif ($requested[0] !== '/') {
        $candidates[] = $root.'/'.$requested;
    }
    foreach ($candidates as $candidate) {
        $real = realpath($candidate);
        if ($real === false || !is_file($real) || preg_match('/\.(php\d*|phtml|phar|pht|inc|htaccess|htpasswd|ini)$/i', $real)) {
            continue;
        }
        foreach ($dirs as $dir) {
            $base = realpath($root.'/'.$dir);
            if ($base !== false && strpos($real, $base.DIRECTORY_SEPARATOR) === 0) {
                return $real;
            }
        }
    }
    return false;
}

$decryption_f = dfx_safeDocPath($decryption_f, realpath(__DIR__.'/..'), [$system_docs_directory, $system_pdocs_directory], $system_path);
if ($decryption_f === false) {
    http_response_code(404);
    echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>INVALID ACCCESS</strong></span><h2>Resource not available.</h2></div>";
    mysqli_close($GLOBALS["conn"]); exit;
}

$contentdisposition = "inline";
$contenttransferencoding = "binary";
$mm_type="application/pdf";
$file = $decryption_f;
$filename = time()."F.pdf";

function dfx_getValueBetween($string) {
    $pattern = "/\/([^\/]*)_/";
    preg_match($pattern, $string, $matches);
    return $matches[1] ?? null;
}
$idgot = dfx_getValueBetween($file);

function dfx_getStringAfterSecondLastSlash($input) {
    // Cari kedudukan simbol "/" kedua terakhir
    $lastSlashPos = strrpos($input, '/');
    $secondLastSlashPos = strrpos($input, '/', $lastSlashPos - strlen($input) - 1);

    // Dapatkan substring selepas simbol "/" kedua terakhir
    if ($secondLastSlashPos !== false) {
        return substr($input, $secondLastSlashPos + 1);
    } else {
        return $input; // Jika tiada dua simbol "/", kembalikan string asal
    }
}
$commercialfilelocation = dfx_getStringAfterSecondLastSlash($file);

//store access to this file into statistic
mysqli_query($GLOBALS["conn"], "insert into eg_item_download values(DEFAULT,$idgot,'".date("D d/m/Y")."','".$_SERVER["REMOTE_ADDR"]."','cml')");

ob_start();
    header("Cache-Control: public, must-revalidate");
    header("Pragma: no-cache");
    header("Content-Type: " . $mm_type);
    header("Content-Length: " .(string)(filesize($file)));
    header("Content-Disposition: $contentdisposition; filename=$filename");//can be set to attachment or inline
    header("Content-Transfer-Encoding: binary\n");
ob_end_clean();
readfile($file);
