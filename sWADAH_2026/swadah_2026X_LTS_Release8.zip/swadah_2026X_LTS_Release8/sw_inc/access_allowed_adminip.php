<?php
/*
Filename: sw_inc/access_allowed_adminip.php
Usage: Check IP agains IPs defined within $allowed_ip. Only works when allowed_ip_enabler is enabled
Version: 20250101.0801
Last change: -
*/

    if ($allowed_ip_enabler) {
        //only the TCP peer address can be trusted. HTTP_CLIENT_IP / X-Forwarded-For are client-controlled headers and must not be used to decide admin access
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        $canproceed = false;

        foreach ($allowed_ip as $value) {
            //allowed entries are address prefixes on an octet boundary e.g. 10.77 or 10.8.3. or a full address
            $value = rtrim(trim($value), '.');
            if ($value !== '' && ($ip === $value || strpos($ip, $value.'.') === 0)) {
                $canproceed = true;
                break;
            }
        }

        if (!$canproceed) {
            echo "<script>alert('Your IP is ".$_SERVER["REMOTE_ADDR"].". are blocked from accessing this page.');</script>";
            echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>403</strong></span><h2>Forbidden: Access prohibited</h2><em>Please contact the system administrator if you see this message.</em></div>";
            exit;
        }
    }
