<?php
/*
Filename: sw_admin/addfolder.php
Usage: Folder creation and modification
Version: 20250101.0801
Last change: -
*/
?>
<!DOCTYPE HTML>
<?php
    $thisPageTitle = "Add Folder";
    session_start();define('includeExist', true);
    
    include_once '../core.php';
    include_once '../sw_inc/access_allowed_adminip.php';
    include_once '../sw_inc/access_super.php';
    include_once '../sw_inc/functions.php';
    include_once '../sw_inc/token_validate.php';
?>

<html lang='en'>

<head><?php include_once '../sw_inc/header.php'; ?></head>

<body class='<?php echo $color_scheme;?>'>
    
    <?php include_once '../sw_inc/loggedinfo.php'; ?>
    
    <hr>
    
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"])) {
            $get_id_del = mysqli_real_escape_string($GLOBALS["conn"], $_GET["del"]);
            $stmt_del = $new_conn->prepare("delete from eg_item_folder where `38folderid` = ?");
            $stmt_del->bind_param("i", $get_id_del);
            $stmt_del->execute();$stmt_del->close();
        } elseif (isset($_GET["del"]) && !is_numeric($_GET["del"])) {
            sfx_echoPopupAlert("Illegal action recorded.", "link", "addfolder.php");
            exit;
        }
        
        if (isset($_REQUEST["submitted"]) && $proceedAfterToken) {
            $name1 = sfx_just_clean($_POST["name1"], 'min');
            if ($_REQUEST["submitted"] == "Insert") {
                $stmt_count = $new_conn->prepare("select count(*) from eg_item_folder where `38foldername` = ?");
                $stmt_count->bind_param("s", $name1);
                $stmt_count->execute();
                $stmt_count->bind_result($num_results_affected_type);
                $stmt_count->fetch();$stmt_count->close();
                
                if ($num_results_affected_type == 0) {
                    if (!empty($name1)) {
                        $stmt_insert = $new_conn->prepare("insert into eg_item_folder values(DEFAULT,?)");
                        $stmt_insert->bind_param("s", $name1);
                        $stmt_insert->execute();$stmt_insert->close();
                        sfx_echoPopupAlert("The folder $name1 has been created.");
                    } else {
                        sfx_echoPopupAlert("Your input has been cancelled.Check if any field(s) left emptied before posting.");
                    }
                } elseif ($num_results_affected_type >= 1) {
                    sfx_echoPopupAlert("Your input has been cancelled. Duplicate FOLDER detected.");
                }
            } elseif ($_REQUEST["submitted"] == "Update") {
                $id1 = $_POST["id1"];
                if (!empty($name1)) {
                    $stmt_update = $new_conn->prepare("update eg_item_folder set `38foldername`=? where `38folderid`=?");
                    $stmt_update->bind_param("si", $name1, $id1);
                    $stmt_update->execute();$stmt_update->close();
                    sfx_echoPopupAlert("Folder name has been updated.");
                } else {
                    sfx_echoPopupAlert("Error. Please make sure there were no empty field(s).<br/>The folder has been restored to it original state.");
                }
            }
        }

        if (isset($_GET["edt"]) && is_numeric($_GET["edt"])) {
            $get_id_upd = mysqli_real_escape_string($GLOBALS["conn"], $_GET["edt"]);
            $stmt3 = $new_conn->prepare("select `38folderid`, `38foldername` from eg_item_folder where `38folderid` = ?");
            $stmt3->bind_param("i", $get_id_upd);
            $stmt3->execute();$stmt3->store_result();
            $stmt3->bind_result($id3, $name3);
            $stmt3->fetch();$stmt3->close();
        } elseif (isset($_GET["edt"]) && !is_numeric($_GET["edt"])) {
            sfx_echoPopupAlert("Illegal action recorded.", "link", "addfolder.php");
            exit;
        }
        
    ?>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=2><strong>Create Folder :</strong></td></tr>
        <tr class=greyHeaderCenter><td colspan=2><br/>
        <form action="addfolder.php" method="post" enctype="multipart/form-data">
                <strong>Folder Name: </strong>
                <br/>
                <input type="text" name="name1" style="width:50%;" maxlength="150" value="<?php if (isset($name3)) {echo $name3;} ?>"/>
                <br/><br/>
                <input type="hidden" name="id1" value="<?php if (isset($id3)) {echo $id3;} ?>" />
                <input type="hidden" name="submitted" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                <input type="hidden" name="token" value="<?php echo $_SESSION[$ssn.'token'] ?? '' ?>">
                <input type="submit" name="submit_button" value="<?php if (isset($_GET['edt'])) {echo "Update";} else {echo "Insert";}?>" />
                <input type="button" value="Cancel" onclick="location.href='addfolder.php';">
        </form>
        </td></tr>
    </table>
    
    <br/><br/>

    <table class=whiteHeader>
        <tr class=<?php echo $color_scheme."HeaderCenter";?>><td colspan=3><strong>Folder Listing and Controls :</strong></td></tr>
        <tr class=whiteHeaderCenterUnderline>
            <td style='width:5%;'>ID</td>
            <td style='text-align:left;'>Folders</td>
            <td style='width:150;'>Options</td>
        </tr>
        <?php
            $n = 1;
            $stmt_fdb = $new_conn->prepare("select `38folderid`, `38foldername` from eg_item_folder");
            $stmt_fdb->execute();
            $result_fdb = $stmt_fdb->get_result();
            while ($myrow_fdb = $result_fdb->fetch_assoc()) {
                $folderid_fdb = $myrow_fdb["38folderid"];
                $foldername_fdb = $myrow_fdb["38foldername"];
                echo "<tr class=$color_scheme"."Hover>";
                    echo "<td>$n</td>";
                    echo "<td style='text-align:left;'>";
                        echo "<span style='color:blue;'>$foldername_fdb</span>";
                        echo "<br/>Current users: <em style='color:darkseagreen;'>";
                            $stmt_gdb = $new_conn->prepare("select * from eg_item_folder_auth where eg_item_folder_id=$folderid_fdb");
                            $stmt_gdb->execute();
                            $result_gdb = $stmt_gdb->get_result();
                            while ($myrow_gdb = $result_gdb->fetch_assoc()) {
                                echo sfx_sGetValue("name", "eg_auth", "username", $myrow_gdb["eg_auth_username"]).", ";
                            }
                            $stmt_gdb->close();
                        echo "</em>";
                    echo "</td>";
                    echo "<td>";
                        echo "<a title='Delete this record' href='addfolder.php?del=$folderid_fdb' onclick=\"return confirm('Are you sure ?');\"><i class=\"fas fa-trash\"></i></a> ";
                        echo "<a title='Update this record' href='addfolder.php?edt=$folderid_fdb'><i class=\"fas fa-edit\"></i></a> ";
                        echo "<a title='Add users to this folder' href='addfolder_auth.php?fid=$folderid_fdb'><i class=\"fas fa-user-plus\"></i></a>";
                    echo "</td>";
                echo "</tr>";
                $n = $n + 1;
            }
            $stmt_fdb->close();
        ?>
    </table>
    
    <hr>
    
    <?php include_once '../sw_inc/footer.php';?>
    
</body>

</html>
<?php mysqli_close($GLOBALS["conn"]); exit(); ?>
