-- 2023A:
CREATE TABLE `eg_item_folder` (`38folderid` int(4) NOT NULL,`38foldername` varchar(255) COLLATE utf8_swedish_ci NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;
CREATE TABLE `eg_item_folder_auth` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `eg_item_folder_id` INT(11) NOT NULL , `eg_auth_username` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `eg_item_folder` ADD PRIMARY KEY (`38folderid`), ADD KEY `38typeid` (`38folderid`);
ALTER TABLE `eg_item_folder` MODIFY `38folderid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `eg_item` ADD `38folderid` INT(11) NOT NULL DEFAULT '0' AFTER `id`;
ALTER TABLE `eg_item` DROP `41pdfattach`, DROP `41imageatt`, DROP `41ppdfattach`;
ALTER TABLE `eg_auth` ADD `publisheradmin` VARCHAR(255) NOT NULL DEFAULT 'ALL' AFTER `division`;
ALTER TABLE `eg_downloadkey` ADD `isos` TEXT NOT NULL AFTER `albums`;
CREATE TABLE `eg_composer` (`id` int(11) NOT NULL,`45name` varchar(255) NOT NULL,`45value` text NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `eg_composer` (`id`, `45name`, `45value`) VALUES
(1, 'FAQ', '<table class=whiteHeaderNoCenter>			\r\n<tr>\r\n<td colspan=2 style=\'font-size:16px;\'>\r\n<br/><br/><a href=\'#1\' style=\'text-decoration:none\'>1. The result list only shows up to 10 items but the result is more than that. How can I navigate to the next page ?</a>\r\n<br/><br/><a href=\'#2\' style=\'text-decoration:none\'>2. What is <em>exploded search term</em> ?</a>\r\n<br/><br/><a href=\'#3\' style=\'text-decoration:none\'>3. Is there any time-out when using the search function ?</a>\r\n<br/><br/><a href=\'#4\' style=\'text-decoration:none\'>4. Why some of words in my search terms did not being included in the search results ?</a>\r\n</td>\r\n</tr>\r\n<tr class=greyHeaderCenter><td colspan=2><div style=\'text-align:center;font-size:14px;\'><strong>Questions and Answers</strong></div></td></tr>\r\n<tr>\r\n<td colspan=2>\r\n<br/><a id=\'1\'>1. The result list only shows up to 10 items but the result is more than that. How can I navigate to the next page ?</a>\r\n<br/><span style=\'color:green;\'>At the bottom of the results list, you may see the navigation toolbar to browse to the next page of the resultset. Use \'Next\' to navigate further or \'Previous\' for prior pages.</span><br/><br/><a id=\'2\'>2. What is <em>exploded search term</em> ?</a>\r\n<br/><span style=\'color:green;\'>Whenever you typed multiple value in the search box, the \'Exploded Search Term\' function will be activated and separate those multiple value into segmented search entries. Click on any of those segmented search term will redo the search function using the new search term.</span><br/><br/><a id=\'3\'>3. Is there any time-out when using the search function ?</a>\r\n<br/><span style=\'color:green;\'>No. Normal user will be automatically be logged in as Guest. Guest mode do not have any specific access duration per session.</span><br/><br/><a id=\'4\'>4. Why some of words in my search terms did not being included in the search results ?</a><br/><span style=\'color:green;\'>Please take note that common words (often called \'noise terms\') will be filtered and not to be included in the final search result. This is to ensure that you will get hold of accurate result with given search terms.</span><br/>\r\n</td>		\r\n</tr>	\r\n</table>'),
(2, 'About', '<table class=whiteHeader>\r\n<tr>\r\n<td>sWADAH is developed by Perpustakaan Tuanku Bainun, Universiti Pendidikan Sultan Idris and it is targetted as an alternative digital repository for institutions. It features an easy to deploy system, easy to manage web based file repository system, following Google Scholar inclusion guideline, support OAI-PMH and also with fast, reliable and user-friendly interface.\r\n</td>\r\n</tr>\r\n</table>');
ALTER TABLE `eg_composer` ADD PRIMARY KEY (`id`);
ALTER TABLE `eg_composer` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

-- 2023B:
ALTER TABLE `eg_item` ADD `40lastupdatetimestamp` VARCHAR(255) NOT NULL DEFAULT '0' AFTER `40lastupdateby`;
ALTER TABLE `eg_item_depo` CHANGE `29dfile` `29dfile` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL DEFAULT 'NO', CHANGE `29pfile` `29pfile` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL DEFAULT 'NO';
ALTER TABLE `eg_item` ADD `52photo_count` INT(11) NOT NULL DEFAULT '0' AFTER `51_embargo_timestamp`;

-- 2023C:
ALTER TABLE `eg_item_depo` ADD `grade` VARCHAR(2) NOT NULL AFTER `itemstatus`;
ALTER TABLE `eg_item_depo` CHANGE `grade` `grade` VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL DEFAULT '-';

-- 2023D:
ALTER TABLE `eg_item_type` ADD `38synonym` VARCHAR(255) NULL DEFAULT NULL AFTER `38defaultlocation`, ADD `38desc` VARCHAR(255) NULL DEFAULT NULL AFTER `38synonym`;
UPDATE `eg_item_type` SET `38synonym` = `38type`;
ALTER TABLE `eg_auth_depo` ADD `totalpost` INT(11) NOT NULL DEFAULT '1' AFTER `registerkey`;
CREATE TABLE `eg_list` (
  `43listid` int(11) NOT NULL,
  `43title` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `43type` varchar(15) COLLATE utf8_swedish_ci NOT NULL,
  `43filter` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `43token` varchar(25) COLLATE utf8_swedish_ci NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;
ALTER TABLE `eg_list` ADD PRIMARY KEY (`43listid`);

-- 2023E:
CREATE TABLE `eg_photo_access` (`id` INT(11) NOT NULL AUTO_INCREMENT , `eg_item_id` INT(11) NOT NULL , `38filename` TEXT NOT NULL , `38timestamp` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `eg_composer` ADD `45desc` VARCHAR(255) NOT NULL AFTER `45name`;
UPDATE `eg_composer` SET `45desc` = 'Frequently Asked Questions' WHERE `eg_composer`.`id` = 1;
UPDATE `eg_composer` SET `45desc` = 'About This Repository' WHERE `eg_composer`.`id` = 2;

-- 2024A mandatory
CREATE TABLE `config_user` (
  `id` int(11) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `cdesc` varchar(2000) NOT NULL,
  `cvalue` varchar(4000) NOT NULL,
  `cvalue_default` varchar(4000) NOT NULL,
  `ctype` varchar(15) NOT NULL,
  `possible_values` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`) VALUES
(1, 'debug_mode', 'debugging mode yes|no', 'no', 'no', 'system', 'yes|no'),
(2, 'putenv', 'set time zone reference: https://en.wikipedia.org/wiki/List_of_tz_database_time_zones', 'TZ=Asia/Kuala_Lumpur', 'TZ=Asia/Kuala_Lumpur', 'system', ''),
(3, 'date_default_timezone_set', 'set php time zone reference: https://www.php.net/manual/en/timezones.php', 'Asia/Kuala_Lumpur', 'Asia/Kuala_Lumpur', 'system', ''),
(4, 'system_path', 'repository url (mention the subdirectory, if applicable) must begin with http:// or https:// and end with / eg. https://myir.myuni.edu/myrepo/ (if subdirectory) or https://myir.myuni.edu/ (if no subdirectory)', 'https://mydomain.institution.edu/myrepo/', 'https://mydomain.institution.edu/myrepo/', 'system', ''),
(5, 'system_identifier', 'system identifier (preferaby a domain without leading http or https) -- for in use at oai-pmh module', 'mydomain.institution.edu', 'mydomain.institution.edu', 'system', ''),
(6, 'system_policy_url', 'repository policy url', 'https://mydomain.institution.edu/policy.pdf', 'https://mydomain.institution.edu/policy.pdf', 'system', ''),
(7, 'system_function', 'repo : repository only | depo : self deposit mode only | full : self deposit and repository | photo : photo repository', 'repo', 'repo', 'system', 'repo|depo|full|photo'),
(8, 'system_mode', 'system running mode live|demo|maintenance in \'demo\' mode: password changing, user management module will be disabled. in \'maintenance\' mode: the searcher and user portion of this system will be disabled.', 'live', 'live', 'system', 'live|demo|maintenance'),
(9, 'system_title', 'system title - give a title to your sWADAH installation', 'sWADAH', 'sWADAH', 'system', ''),
(10, 'system_ip', 'this server ip address (internal network ip only)', '10.10.1.11', '10.10.1.11', 'system', ''),
(11, 'system_admin_contact_disclaimer', 'admin contact disclaimer. html5 enabled. you may use html tag on it to control size etc.', 'If you have enquiries, kindly contact us at contactus@swadah.com or 01-2345678', 'If you have enquiries, kindly contact us at contactus@swadah.com or 01-2345678', 'system', ''),
(12, 'system_owner', 'registered owner', 'sWADAH Support Unit', 'sWADAH Support Unit', 'system', ''),
(13, 'ezproxy_ip', 'set your ezproxy ip server here (if you have no ezproxy server, just type in your server ip address here). if sWADAH detected user access from ezproxy, the sWADAH automagically will enable full text access (if permittable)', '10.10.1.12', '10.10.1.12', 'system', ''),
(14, 'ezproxy_appended_domain', 'url that appended by ezproxy for this repository. it might look something like this sample url. http or https will not be required.', 'mydomain_institution_edu.ezproxy.institution.edu', 'mydomain_institution_edu.ezproxy.institution.edu', 'system', ''),
(15, 'main_logo', 'location of main logo to be displayed at front page and various oither pages. default is sw_asset/img/swadah_logo.png', 'sw_asset/img/swadah_logo.png', 'sw_asset/img/swadah_logo.png', 'gui', ''),
(16, 'main_logo_width', 'can be px or %', '50%', '50%', 'gui', ''),
(17, 'intro_words', 'intro words below the main logo. html5 enabled. you may use html tag on it to control size etc.', 'Welcome to sWADAH Digital Repository. This is developed by Tuanku Bainun Library for all libraries in the world. Welcome.', 'Welcome to sWADAH Digital Repository. This is developed by Tuanku Bainun Library for all libraries in the world. Welcome.', 'gui', ''),
(18, 'show_main_body_background_image', 'show background image for the main page true|false', 'false', 'false', 'gui', 'true|false'),
(19, 'main_body_background_image', 'the location of the background if enabled', 'sw_asset/img/bodybackground.jpg', 'sw_asset/img/bodybackground.jpg', 'gui', ''),
(20, 'browser_icon', 'browser mini icon on the title bar', 'sw_asset/img/swadah_icon_www.png', 'sw_asset/img/swadah_icon_www.png', 'gui', ''),
(21, 'menu_icon', 'menu icon for the navigation menu bar', 'sw_asset/img/swadah_big_icon.png', 'sw_asset/img/swadah_big_icon.png', 'gui', ''),
(22, 'footer_fontSize', 'control footer font size. in px.', '8px', '8px', 'gui', ''),
(23, 'show_build_number_on_footer', 'show build number on footer', 'false', 'false', 'gui', 'true|false'),
(24, 'show_admin_login_link', 'show admin login link on meta. if you set this to false, to access is by calling in.php', 'false', 'false', 'gui', 'true|false'),
(25, 'show_client_ip_on_startup', 'to show or not client ip on index page', 'false', 'false', 'gui', 'true|false'),
(26, 'show_browser_bar_guest', 'allow or not guest to access browser bar', 'true', 'true', 'gui', 'true|false'),
(27, 'show_browser_bar_admin', 'allow or not admin to access browser bar', 'true', 'true', 'gui', 'true|false'),
(28, 'show_subject_browser_bar', 'allow or not subject browser to be shown', 'true', 'true', 'gui', 'true|false'),
(29, 'show_publisher_browser_bar', 'allow or not publisher browser to be shown', 'true', 'true', 'gui', 'true|false'),
(30, 'show_year_browser_bar', 'allow or not year browser to be shown', 'true', 'true', 'gui', 'true|false'),
(31, 'show_folder_browser_bar', 'allow or not folder browser to be shown', 'true', 'true', 'gui', 'true|false'),
(32, 'allow_user_to_login', 'allow user to login to their page, enable the My Account button and Login link', 'false', 'false', 'system', 'true|false'),
(33, 'enable_feedback_function', 'enable or disable registered user feedback for items if user are allowed to login', 'false', 'false', 'system', 'true|false'),
(34, 'searcher_type_bar_visibility', 'search input bar on index page', 'true', 'true', 'gui', 'true|false'),
(35, 'searcher_show_frequency_of_toprateditems', 'true will show popular search items on searcher page.', 'false', 'false', 'gui', 'true|false'),
(36, 'system_wide_resultPerPage', 'for paging purposes, how many number per page per resultset', '20', '20', 'gui', ''),
(37, 'searcher_title_font_size', 'title font size in pixel', '16px', '16px', 'gui', ''),
(38, 'searcher_author_font_size', 'author font size in pixel', '14px', '14px', 'gui', ''),
(39, 'searcher_hits_font_size', 'hits count font size in pixel', '10px', '10px', 'gui', ''),
(40, 'searcher_show_icon_indicator', 'show (true) or hide (false) indicators on guest search page for results (below the title description)', 'false', 'false', 'gui', 'true|false'),
(41, 'ip_restriction_enabled', 'searcher access only for permitted IP addresses/range input using Administration > Allowed IP configuration. default is false to allow all', 'false', 'false', 'system', 'true|false'),
(42, 'remove_word_from_title', 'if title has any of these pattern, it will be unseen. items must be comma separated. affected only the search result.', '(IR),(SCOPUS)', '(IR),(SCOPUS)', 'system', ''),
(43, 'show_qr_code_for_item', 'show_qr_code_for_item : show or hide qr code on item detail page', 'true', 'true', 'gui', 'true|false'),
(44, 'copyright_info', 'disclaimer or copyright info for detail page. html5 enabled. you may use html tag on it to control size etc.', 'This material may be protected under Copyright Act which governs the making of photocopies or reproductions of copyrighted materials.<br/>You may use the digitized material for private study, scholarship, or research.', 'This material may be protected under Copyright Act which governs the making of photocopies or reproductions of copyrighted materials.<br/>You may use the digitized material for private study, scholarship, or research.', 'system', ''),
(45, 'embargoed_duration', 'default embargoed duration. if item is set it status to embargo, how long it would take to automatically set it back to available. in days.', '365', '365', 'system', ''),
(46, 'default_password_if_forgotten', 'set the default password to reset whenever reset password tool is used by admin for a user', '1', '1', 'system', ''),
(47, 'default_create_password', 'default creation password when creating new user', '1', '1', 'system', ''),
(48, 'default_num_attempt_login', 'num of login attempt before blocking mechanism start', '5', '5', 'system', ''),
(49, 'system_statcache_directory', 'cache directory for statistic generator', 'files/statcache', 'files/statcache', 'dir', ''),
(50, 'invalid_access_detection', 'system intruder detection mode for all guest enabled page such as searcher.php and all title listers: subject heading, year, publisher browsers. \'strict\' =user input will be sanitize AND will automatically block access to all related pages within even one try of invalid access/query. \'precaution\' =user input will be sanitize AND will automatically block access to all related pages within 5 invalid accesses/queries. \'guard\' =default, user input will be sanitize and will not be block until reached a hard limit of 99 invalid queries. should he/she cross that line, the access will be blocked. redirection to default page will be enforced. all above incidents are stored in files/blocked/ all bans will only valid for one day. will be automatically cleared the next day.', 'precaution', 'precaution', 'system', 'strict|precaution|guard'),
(51, 'blocked_file_location', 'incidents are stored in this location', 'files/blocked', 'files/blocked', 'dir', ''),
(52, 'enable_secure_folder', 'secure folder function', 'false', 'false', 'system', 'true|false'),
(53, 'usePdfInfo', 'pdfinfo will show number of page on detail page. true | false.', 'false', 'false', 'system', 'true|false'),
(54, 'max_page_toshow_red_color', 'what minimum page number when the total page number will be shown with red color when usePdfInfo is set to true', '30', '30', 'system', ''),
(55, 'max_download_allowed', 'the number of count digital document will be available before it is expired (per user session)', '3', '3', 'system', ''),
(56, 'max_time_link_availability', 'duration in seconds on which the digital document will be available before it is expired.', '86400', '86400', 'system', ''),
(57, 'enable_oai_pmh', 'oai-pmh enabler. true = enabled OAI-PMH request, false = disable', 'false', 'false', 'oai', 'true|false'),
(58, 'oai_rights', 'openAccess | restrictedAccess | closedAccess | embargoedAccess', 'openAccess', 'openAccess', 'oai', 'openAccess|restrictedAccess|closedAccess|embargoedAccess'),
(59, 'oai_main_language', 'must be in ISO 639-3 format', 'eng', 'eng', 'oai', ''),
(60, 'oai_main_format', 'oai-pmh format for display', 'text', 'text', 'oai', ''),
(61, 'enable_searcher_api', 'enable or disable access to SEARCHER API', 'false', 'false', 'api', 'true|false'),
(62, 'delete_method', 'item delete method : \'permanent\': item and all its detailing will be deleted entirely from the system. \'takecover\' : item will be set to undiscoverable, a hide button will appear instead of delete button. resources will be renamed to <filename>.<extension>.deleted', 'permanent', 'permanent', 'system', 'permanent|takecover'),
(63, 'default_view_input', 'marc | simple', 'simple', 'simple', 'system', ''),
(64, 'show_accession_number', 'accession number visibility on item detail page', 'false', 'false', 'gui', 'true|false'),
(65, 'show_control_number', 'control number visibility on item detail page', 'false', 'false', 'gui', 'true|false'),
(66, 'type_as', 'rebrand or reuse item type as', 'Type', 'Type', 'system', ''),
(67, 'enable_subject_entry', 'enable subject heading selection in input and update page', 'true', 'true', 'system', 'true|false'),
(68, 'subject_heading_as', 'rebrand subject heading as -  this will utilize/repurpose subject heading for a different means', 'Subject', 'Subject', 'system', ''),
(69, 'subject_heading_delimiter', 'if multiple subject heading can be selected, this will be the delimiter', ',', ',', 'system', ''),
(70, 'subject_heading_selectable', 'selectable subject heading : \'single\' will only able to select one | \'multi\' will be able to select multiple subject headings', 'multi', 'multi', 'system', 'single|multi'),
(71, 'init_status_visibility', 'hide|show initial status on add new item page. if hide, default will always be Available-Public', 'show', 'show', 'system', 'show|hide'),
(72, 'default_is_abstract', 'full text input field will be abstract', 'true', 'true', 'system', 'true|false'),
(73, 'enable_fulltext_abstract_composer', 'enable full text/abstract composer in add new / update', 'true', 'true', 'system', 'true|false'),
(74, 'fulltext_abstract_composer_type', 'simpletext | richtext', 'richtext', 'richtext', 'system', 'simpletext|richtext'),
(75, 'enable_reference_composer', 'enabled reference composer in add new / update', 'true', 'true', 'system', 'true|false'),
(76, 'reference_composer_type', 'simpletext | richtext', 'richtext', 'richtext', 'system', 'simpletext|richtext'),
(77, 'system_docs_directory', 'full text document for uploading new item directory location', 'files/docs', 'files/docs', 'dir', ''),
(78, 'system_allow_document_extension', 'full text document extensions', 'pdf', 'pdf', 'dir', ''),
(79, 'system_allow_document_maxsize', 'full text document max file size in MB', '100', '100', 'dir', ''),
(80, 'allow_guest_access_to_ft', 'allow guest access to full text without login', 'false', 'false', 'system', 'true|false'),
(81, 'index_pdf', 'allow indexing to the uploaded full text document', 'false', 'false', 'system', 'true|false'),
(82, 'system_pdocs_directory', 'guest document for uploading new item directory location', 'files/pdocs', 'files/pdocs', 'dir', ''),
(83, 'system_allow_pdocument_extension', 'guest document extensions', 'pdf', 'pdf', 'dir', ''),
(84, 'system_allow_pdocument_maxsize', 'guest document max file size in MB', '20', '20', 'dir', ''),
(85, 'allow_guestpdf_insert_by_admin', 'allow guest file input to be inserted for an item', 'true', 'true', 'system', 'true|false'),
(86, 'allow_guest_access_to_pt', 'allow guest to access guest document without login', 'true', 'true', 'system', 'true|false'),
(87, 'system_txts_directory', 'text file for uploading new item directory location', 'files/txts', 'files/txts', 'dir', ''),
(88, 'system_allow_txt_extension', 'text file extensions', 'txt', 'txt', 'dir', ''),
(89, 'system_allow_txt_maxsize', 'text file max file size in MB', '5', '5', 'dir', ''),
(90, 'allow_txt_insert_by_admin', 'allow text file input to be inserted', 'false', 'false', 'system', 'true|false'),
(91, 'system_isofile_directory', 'misc file type for uploading new item directory location', 'files/isofile', 'files/isofile', 'dir', ''),
(92, 'system_isofile_name', 'misc file name', 'FreeType', 'FreeType', 'dir', ''),
(93, 'system_allow_isofile_extension', 'allowed file extensions', 'iso,zip,xlsx,pptx', 'iso,zip,xlsx,pptx', 'dir', ''),
(94, 'system_allow_isofile_maxsize', 'allowed max filesize for misc file in MB', '10', '10', 'dir', ''),
(95, 'allow_isofile_insert_by_admin', 'allow misc file input to be inserted', 'false', 'false', 'system', 'true|false'),
(96, 'allow_guest_access_to_isofile', 'allow guest to access the misc file without login', 'false', 'false', 'system', 'true|false'),
(97, 'system_albums_directory', 'image attachment directory location for uploading new item', 'files/albums', 'files/albums', 'dir', ''),
(98, 'watermark_overlay_file', 'in use for image upload, will be automatically watermarked, must be transparent and png', 'sw_asset/img/watermark.png', 'sw_asset/img/watermark.png', 'system', ''),
(99, 'system_albums_thumbnail_directory', 'location of thumbnail directory', 'files/albums_thumbnailed', 'files/albums_thumbnailed', 'dir', ''),
(100, 'system_albums_watermark_directory', 'location of watermarked image directory', 'files/albums_watermarked', 'files/albums_watermarked', 'dir', ''),
(101, 'system_allow_imageatt_extension', 'allowed extensions for image attachments', 'jpg,jpeg', 'jpg,jpeg', 'dir', ''),
(102, 'system_allow_imageatt_maxsize', 'allowed max size for a single image attachment', '10', '10', 'dir', ''),
(103, 'maximum_num_imageatt_allowed', 'maximum number of additional image attachment allowed', '20', '20', 'system', ''),
(104, 'allow_image_insert_by_admin', 'allow image attachment function for item input', 'true', 'true', 'system', 'true|false'),
(105, 'allow_depositor_function', 'allow access to depositor page and depositor button on index page. will also provide admin to manage user deposit and depositor account management', 'true', 'true', 'sdepo', 'true|false'),
(106, 'allow_confidential_setup', 'allow self deposit user to set item confidentiality', 'true', 'true', 'sdepo', 'true|false'),
(107, 'enable_self_activation', 'allow self deposit user to self activate themselves via email links', 'false', 'false', 'sdepo', 'true|false'),
(108, 'enable_tutorial_button', 'enable tutorial button for self deposit', 'false', 'false', 'sdepo', 'true|false'),
(109, 'tutorial_link', 'link must for self submission. complete URL with http:// or https:// if tutorial button is set to true', 'https://mydomain.institution.edu/tutorial.pdf', 'https://mydomain.institution.edu/tutorial.pdf', 'sdepo', ''),
(110, 'system_dfile_directory', 'declaration file upload directory for self submission', 'files/depos/d', 'files/depos/d', 'dir', ''),
(111, 'system_allow_dfile_extension', 'allowed file extension for declaration file for self submission', 'pdf', 'pdf', 'dir', ''),
(112, 'system_allow_dfile_maxsize', 'declaration file for self submission max filesize in MB', '10', '10', 'dir', ''),
(113, 'system_pfile_directory', 'full text file for self submission upload directory', 'files/depos/p', 'files/depos/p', 'dir', ''),
(114, 'system_allow_pfile_extension', 'allowed extension for full text file for self submission', 'pdf', 'pdf', 'dir', ''),
(115, 'system_allow_pfile_maxsize', 'fulltext file for self submission max filesize in MB', '100', '100', 'dir', ''),
(116, 'hide_main_author', 'hide main author input in user deposit page', 'true', 'true', 'sdepo', 'true|false'),
(117, 'hide_additional_authors_entry', 'hide additional authors input in user deposit page', 'true', 'true', 'sdepo', 'true|false'),
(118, 'allow_declaration_submission', 'allow submission of item declaration in user deposit page', 'true', 'true', 'sdepo', 'true|false'),
(119, 'allow_abstract_submission', 'allow abstract submission in user deposit page', 'true', 'true', 'sdepo', 'true|false'),
(120, 'show_dateof_publication', 'show (true) or hide (false) date of publication input in user deposit page', 'false', 'false', 'sdepo', 'true|false'),
(121, 'depo_grades', 'grades selection separated by commas', 'A,A-,B+,B,B-,C+,C,C-,D+,D,E,F', 'A,A-,B+,B,B-,C+,C,C-,D+,D,E,F', 'sdepo', ''),
(122, 'depo_enable_forget_password', 'enable forget password subsystem for depositor', 'false', 'false', 'sdepo', 'true|false'),
(123, 'depo_forget_password_wording_if_subsystem_disable', 'if depo_enable_forget_password is set to false, this line will appear for reset password link', 'Please contact us via our support line for password reset.', 'Please contact us via our support line for password reset.', 'sdepo', ''),
(124, 'useEmailNotification', 'use email notification for certain feature ? true or false.', 'false', 'false', 'email', 'true|false'),
(125, 'emailDebuggerEnable', '0 disable , 1 enable (when enable, redirection will turn off for email sending pages and allow you to see debugging messages)', '0', '0', 'email', ''),
(126, 'emailMode', 'ssl|tls|false', 'ssl', 'ssl', 'email', 'ssl|tls|false'),
(127, 'emailAuthentication', 'true|false', 'true', 'true', 'email', 'true|false'),
(128, 'emailAutoTLS', 'auto tls setting', 'true', 'true', 'email', 'true|false'),
(129, 'emailHost', 'email smtp', 'smtp.gmail.com', 'smtp.gmail.com', 'email', ''),
(130, 'emailPort', 'email port for smtp', '465', '465', 'email', ''),
(131, 'emailUserName', 'username for email', 'actual_sending_user@gmail.com', 'actual_sending_user@gmail.com', 'email', ''),
(132, 'emailPassword', 'email password', 'mypassword', 'mypassword', 'email', ''),
(133, 'emailSetFrom', 'hide the real sender of email', 'noreply_hide_real_user@gmail.com', 'noreply_hide_real_user@gmail.com', 'email', ''),
(134, 'emailSetFromName', 'hide the name of real sender of email', 'sWADAH Mailer', 'sWADAH Mailer', 'email', ''),
(135, 'emailFooter', 'footer of the composed email content', '<hr>This is an automated email. Please do not reply to this email. If you have any question regarding your submission, contact us at user@gmail.com', '<hr>This is an automated email. Please do not reply to this email. If you have any question regarding your submission, contact us at user@gmail.com', 'email', ''),
(136, 'system_admin_email', 'Administrator Email', 'admin@swadah.com', 'admin@swadah.com', 'system', ''),
(137, 'tag_020_simple', 'display text for tag 020', 'ISBN', 'ISBN', 'metadata', ''),
(138, 'tag_020', 'display text for tag 020 with description', 'ISBN 020', 'ISBN 020', 'metadata', ''),
(139, 'tag_020_show', 'show tag 020 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(140, 'tag_020c_simple', 'display text for tag 020|c', 'Term of Availability', 'Term of Availability', 'metadata', ''),
(141, 'tag_020c', 'display text for tag 020|c with description', 'Term of Availability 020|c', 'Term of Availability 020|c', 'metadata', ''),
(142, 'tag_020c_currency', 'Currency value acronym. See https://www.bws.net/toolbox/currency for more info', 'MYR', 'MYR', 'metadata', ''),
(143, 'tag_020c_show', 'show tag 020|c in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(144, 'tag_022_simple', 'display text for tag 022', 'ISSN', 'ISSN', 'metadata', ''),
(145, 'tag_022', 'display text for tag 022 with description', 'ISSN 022', 'ISSN 022', 'metadata', ''),
(146, 'tag_022_show', 'show tag 022 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(147, 'tag_041_simple', 'display text for tag 041', 'Language Code', 'Language Code', 'metadata', ''),
(148, 'tag_041', 'display text for tag 041 with description', 'Language Code 041', 'Language Code 041', 'metadata', ''),
(149, 'tag_041_inputtype', 'select|keyin', 'select', 'select', 'metadata', 'select|keyin'),
(150, 'tag_041_selectable', 'selectable values. separated with |', 'zsm|eng|chi|tam|ara', 'zsm|eng|chi|tam|ara', 'metadata', ''),
(151, 'tag_041_selectable_default', 'default value for tag_041_selectable', 'zsm', 'zsm', 'metadata', ''),
(152, 'tag_041_show', 'show tag 041 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(153, 'tag_090_simple', 'display text for tag 090', 'Call Number', 'Call Number', 'metadata', ''),
(154, 'tag_090', 'display text for tag 090 with description', 'Call Number 090', 'Call Number 090', 'metadata', ''),
(155, 'tag_090_show', 'show tag 090 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(156, 'tag_100_simple', 'display text for tag 100', 'Main Author', 'Main Author', 'metadata', ''),
(157, 'tag_100', 'display text for tag 100 with description', 'Main Author 100', 'Main Author 100', 'metadata', ''),
(158, 'tag_100_default_ind', 'default indicator for tag 100', '0#', '0#', 'metadata', ''),
(159, 'tag_245_simple', 'display text for tag 245', 'Title', 'Title', 'metadata', ''),
(160, 'tag_245', 'display text for tag 245 with description', 'Title 245', 'Title 245', 'metadata', ''),
(161, 'tag_245_default_ind', 'default indicator for tag 245', '10', '10', 'metadata', ''),
(162, 'tag_246_simple', 'display text for tag 246', 'Varying Form of Title', 'Varying Form of Title', 'metadata', ''),
(163, 'tag_246', 'display text for tag 246 with description', 'Varying Form of Title 246', 'Varying Form of Title 246', 'metadata', ''),
(164, 'tag_246_show', 'show tag 246 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(165, 'tag_246_default_ind', 'default indicator for tag 246', '', '', 'metadata', ''),
(166, 'tag_250_simple', 'display text for tag 250', 'Edition', 'Edition', 'metadata', ''),
(167, 'tag_250', 'display text for tag 250 with description', 'Edition 250', 'Edition 250', 'metadata', ''),
(168, 'tag_250_show', 'show tag 250 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(169, 'tag_264_simple', 'display text for tag 264', 'Publication', 'Publication', 'metadata', ''),
(170, 'tag_264', 'display text for tag 264 with description', 'Publication 264', 'Publication 264', 'metadata', ''),
(171, 'tag_264_show', 'show tag 264 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(172, 'tag_264_a_default', 'default indicator for tag 246|a', 'Tanjong Malim', 'Tanjong Malim', 'metadata', ''),
(173, 'tag_264_default_ind', 'default indicator for tag 264', '##', '##', 'metadata', ''),
(174, 'publisher_as', 'Rebrand publisher as something else', 'Publisher', 'Publisher', 'metadata', ''),
(175, 'publisher_place_of_production', 'Rebrand publisher place of production', 'Place of Production', 'Place of Production', 'metadata', ''),
(176, 'publisher_year_of_publication', 'Rebrand year of publication', 'Year of Publication', 'Year of Publication', 'metadata', ''),
(177, 'tag_300_simple', 'display text for tag 300', 'Physical Description', 'Physical Description', 'metadata', ''),
(178, 'tag_300', 'display text for tag 300 with description', 'Physical Description 300', 'Physical Description 300', 'metadata', ''),
(179, 'tag_300_show', 'show tag 300 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(180, 'tag_300_default_ind', 'default indicator for tag 300', '##', '##', 'metadata', ''),
(181, 'tag_336_simple', 'display text for tag 336', 'Content Type', 'Content Type', 'metadata', ''),
(182, 'tag_336', 'display text for tag 336 with description', 'Content Type 336', 'Content Type 336', 'metadata', ''),
(183, 'tag_336_show', 'show tag 336 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(184, 'tag_336_default_a', 'default indicator for tag 336|a', 'still image', 'still image', 'metadata', ''),
(185, 'tag_336_default_2', 'default indicator for tag 336|2', 'rdacontent', 'rdacontent', 'metadata', ''),
(186, 'tag_336_default_ind', 'default indicator for tag 336', '##', '##', 'metadata', ''),
(187, 'tag_337_simple', 'display text for tag 337', 'Media Type', 'Media Type', 'metadata', ''),
(188, 'tag_337', 'display text for tag 337 with description', 'Media Type 337', 'Media Type 337', 'metadata', ''),
(189, 'tag_337_show', 'show tag 337 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(190, 'tag_337_default_a', 'default indicator for tag 337|a', 'computer', 'computer', 'metadata', ''),
(191, 'tag_337_default_2', 'default indicator for tag 337|2', 'rdamedia', 'rdamedia', 'metadata', ''),
(192, 'tag_337_default_ind', 'default indicator for tag 337', '##', '##', 'metadata', ''),
(193, 'tag_338_simple', 'display text for tag 338', 'Carrier Type', 'Carrier Type', 'metadata', ''),
(194, 'tag_338', 'display text for tag 338 with description', 'Carrier Type 338', 'Carrier Type 338', 'metadata', ''),
(195, 'tag_338_show', 'show tag 338 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(196, 'tag_338_default_a', 'default indicator for tag 338|a', 'online resource', 'online resource', 'metadata', ''),
(197, 'tag_338_default_2', 'default indicator for tag 338|2', 'rdacarrier', 'rdacarrier', 'metadata', ''),
(198, 'tag_338_default_ind', 'default indicator for tag 338', '##', '##', 'metadata', ''),
(199, 'tag_490_simple', 'display text for tag 490', 'Series', 'Series', 'metadata', ''),
(200, 'tag_490', 'display text for tag 490 with description', 'Series 490', 'Series 490', 'metadata', ''),
(201, 'tag_490_show', 'show tag 490 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(202, 'tag_500_simple', 'display text for tag 500', 'Notes', 'Notes', 'metadata', ''),
(203, 'tag_500', 'display text for tag 500 with description', 'Notes 500', 'Notes 500', 'metadata', ''),
(204, 'tag_500_hint', 'hint for tag 500 to ease value insert', '', '', 'metadata', ''),
(205, 'tag_500_show', 'show tag 500 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(206, 'tag_500_default_ind', 'default indicator for tag 500', '##', '##', 'metadata', ''),
(207, 'tag_502_simple', 'display text for tag 502', 'Degree Type', 'Degree Type', 'metadata', ''),
(208, 'tag_502', 'display text for tag 502 with description', 'Dissertation Note 502', 'Dissertation Note 502', 'metadata', ''),
(209, 'tag_502_show', 'show tag 502 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(210, 'tag_502_inputtype', 'keyin|select', 'select', 'select', 'metadata', 'keyin|select'),
(211, 'tag_502_b_selectable', 'values must be separated by |', 'Doctoral|Masters|Degree|Diploma|Others', 'Doctoral|Masters|Degree|Diploma|Others', 'metadata', ''),
(212, 'tag_502_b_selectable_default', 'values must one from tag_502_b_selectable', 'Degree', 'Degree', 'metadata', ''),
(213, 'tag_506_simple', 'display text for tag 506', 'Access Category', 'Access Category', 'metadata', ''),
(214, 'tag_506', 'display text for tag 506 with description', 'Access Category 506', 'Access Category 506', 'metadata', ''),
(215, 'tag_506_hint', 'hint for tag 506 to ease value insert', '', '', 'metadata', ''),
(216, 'tag_506_show', 'show tag 506 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(217, 'tag_520_simple', 'display text for tag 520', 'Summary', 'Summary', 'metadata', ''),
(218, 'tag_520', 'display text for tag 520 with description', 'Summary 520', 'Summary 520', 'metadata', ''),
(219, 'tag_520_show', 'show tag 520 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(220, 'tag_520_default_ind', 'default indicator for tag 520', '##', '##', 'metadata', ''),
(221, 'tag_600_simple', 'display text for tag 600', 'Subject Added Entry - Personal Name', 'Subject Added Entry - Personal Name', 'metadata', ''),
(222, 'tag_600', 'display text for tag 600 with description', 'Subject Added Entry - Personal Name 600', 'Subject Added Entry - Personal Name 600', 'metadata', ''),
(223, 'tag_600_show', 'show tag 600 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(224, 'tag_600_default_ind', 'default indicator for tag 600', '', '', 'metadata', ''),
(225, 'tag_650_simple', 'display text for tag 650', 'Subject Entry - Topical Term', 'Subject Entry - Topical Term', 'metadata', ''),
(226, 'tag_650', 'display text for tag 650 with description', 'Subject Entry - Topical Term 650', 'Subject Entry - Topical Term 650', 'metadata', ''),
(227, 'tag_650_show', 'show tag 650 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(228, 'tag_700_simple', 'display text for tag 700', 'Additional Authors', 'Additional Authors', 'metadata', ''),
(229, 'tag_700', 'display text for tag 700 with description', 'Additional Authors 700', 'Additional Authors 700', 'metadata', ''),
(230, 'tag_700_show', 'show tag 700 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(231, 'tag_700_default_ind', 'default indicator for tag 700', '0#', '0#', 'metadata', ''),
(232, 'tag_710_simple', 'display text for tag 710', 'Corporate Name', 'Corporate Name', 'metadata', ''),
(233, 'tag_710', 'display text for tag 710 with description', 'Corporate Name 710', 'Corporate Name 710', 'metadata', ''),
(234, 'tag_710_show', 'show tag 710 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(235, 'tag_710_a_default', 'default indicator for tag 710|a', 'Perpustakaan Tuanku Bainun', 'Perpustakaan Tuanku Bainun', 'metadata', ''),
(236, 'tag_710_b_default', 'default indicator for tag 710|b', 'Universiti Pendidikan Sultan Idris', 'Universiti Pendidikan Sultan Idris', 'metadata', ''),
(237, 'tag_710_e_default', 'default indicator for tag 710|e', 'Issuing body', 'Issuing body', 'metadata', ''),
(238, 'tag_710_default_ind', 'default indicator for tag 710', '2#', '2#', 'metadata', ''),
(239, 'tag_852_simple', 'display text for tag 852', 'Location', 'Location', 'metadata', ''),
(240, 'tag_852', 'display text for tag 852 with description', 'Location 852', 'Location 852', 'metadata', ''),
(241, 'tag_852_show', 'show tag 852 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(242, 'tag_856_simple', 'display text for tag 856', 'HTTP Link', 'HTTP Link', 'metadata', ''),
(243, 'tag_856', 'display text for tag 856 with description', 'HTTP Link 856', 'HTTP Link 856', 'metadata', ''),
(244, 'tag_856_show', 'show tag 856 in input field true|false', 'true', 'true', 'metadata', 'true|false'),
(245, 'depo_txt_identification', 'Depositor identification ID', 'Matrix Number', 'Matrix Number', 'depo', ''),
(246, 'depo_txt_slip_title', 'Title of the generated slip', 'DIGITAL DOCUMENT RECEIVING SLIP', 'DIGITAL DOCUMENT RECEIVING SLIP', 'depo', ''),
(247, 'depo_txt_institution', 'Name of institution', 'MY DIGITAL LIBRARY', 'MY DIGITAL LIBRARY', 'depo', ''),
(248, 'depo_txt_notvalidslip', 'Invalid slip ID prompt', 'INVALID SLIP ID', 'INVALID SLIP ID', 'depo', ''),
(249, 'depo_txt_declaration_to_library', 'Declaration of submission document. (HTML capable)', 'Declaration of submission to the Library PDF.<br/>For CONFIDENTIAL or RESTRICTED item only.', 'Declaration of submission to the Library PDF.<br/>For CONFIDENTIAL or RESTRICTED item only.', 'depo', ''),
(250, 'depo_txt_mandatory_fields', 'Mandatory field wording. (HTML capable)', 'Mandatory fields.<br/><span style=\'color:lightgrey;\'><em>Medan mandatori.</em></span>', 'Mandatory fields.<br/><span style=\'color:lightgrey;\'><em>Medan mandatori.</em></span>', 'depo', ''),
(251, 'depo_txt_optional_fields', 'Optional wording. (HTML capable)', 'Optional. Might be required on for certain degree type. Kindly refer to your uploading criteria.<br/><span style=\'color:lightgrey;\'><em>Medan pilihan. Mungkin diperlukan oleh beberapa jenis tahap pengajian. Sila rujuk kembali panduan memuatnaik bagi tahap pengajian anda.</em></span>', 'Optional. Might be required on for certain degree type. Kindly refer to your uploading criteria.<br/><span style=\'color:lightgrey;\'><em>Medan pilihan. Mungkin diperlukan oleh beberapa jenis tahap pengajian. Sila rujuk kembali panduan memuatnaik bagi tahap pengajian anda.</em></span>', 'depo', ''),
(252, 'depo_acknowledgement', 'Acknowledgement wording. (HTML capable)', 'Acknowlegdement.<br/><span style=\'color:lightgrey;\'><em>Pengesahan.</em></span>', 'Acknowlegdement.<br/><span style=\'color:lightgrey;\'><em>Pengesahan.</em></span>', 'depo', ''),
(253, 'depo_image_institution', 'Location of where logo to be displayed on the slip to be stored.', 'sw_asset/img/swadah_big_icon.png', 'sw_asset/img/swadah_big_icon.png', 'depo', ''),
(254, 'depo_para_acceptance_words', 'Words of acceptance. (HTML capable) ^^is fixed value that must be there. ^^name for the depositor name, ^^titlestatement for uploaded item title, ^^useridentity for the depositor ID.', 'Please be informed that your digital document with the title <br/><u><strong>^^titlestatement</strong></u> by <br/><u><strong>^^name</strong></u> with identification ID of <u><strong>^^useridentity</strong></u><br/>has been accepted by us on <u><strong>^^approvedOn</strong></u>.', 'Please be informed that your digital document with the title <br/><u><strong>^^titlestatement</strong></u> by <br/><u><strong>^^name</strong></u> with identification ID of <u><strong>^^useridentity</strong></u><br/>has been accepted by us on <u><strong>^^approvedOn</strong></u>.', 'depo', ''),
(255, 'depo_validation', 'Wording for validation of QR code. (HTML capable)', '<br/><div style=\'font-size:x-small;\'>For validation purposes, scan this QR code:</div><br/>', '<br/><div style=\'font-size:x-small;\'>For validation purposes, scan this QR code:</div><br/>', 'depo', ''),
(256, 'depo_para_autoremarks', 'This slip is automactically generated wording. (HTML capable)', 'THIS SLIP IS AUTOMATICALLY GENERATED. <br/>NO SIGNATURE IS REQUIRED.', 'THIS SLIP IS AUTOMATICALLY GENERATED. <br/>NO SIGNATURE IS REQUIRED.', 'depo', ''),
(257, 'depo_confidentiality_remarks', 'Uploaded confidential remarks and wording. (HTML capable)', '<br/>If the thesis is CONFIDENTIAL or RESTRICTED, please scan and attach with the letter from the organization with period and reasons for confidentiality or restriction.', '<br/>If the thesis is CONFIDENTIAL or RESTRICTED, please scan and attach with the letter from the organization with period and reasons for confidentiality or restriction.', 'depo', ''),
(258, 'depo_para_acknowledgement', 'Acknowledgement remarks and wording. (HTML capable)', '<h3 style=\'color:blue;\'>Acknowledgement:</h3>I hereby acknowledged that MY DIGITAL LIBRARY reserves the right as follows:-</em><br/><br/>\r\n<ol>\r\n<li>The thesis is the property of MY DIGITAL LIBRARY.</li><br/>\r\n<li>The Library has the right to make copies for the purpose of reference and research.</li><br/>\r\n<li>The Library has the right to make copies of the thesis for academic exchange.</li><br/>\r\n</ol>', '<h3 style=\'color:blue;\'>Acknowledgement:</h3>I hereby acknowledged that MY DIGITAL LIBRARY reserves the right as follows:-</em><br/><br/>\r\n<ol>\r\n<li>The thesis is the property of MY DIGITAL LIBRARY.</li><br/>\r\n<li>The Library has the right to make copies for the purpose of reference and research.</li><br/>\r\n<li>The Library has the right to make copies of the thesis for academic exchange.</li><br/>\r\n</ol>', 'depo', ''),
(259, 'max_allow_parser_to_work', 'pdf file in MB where a parser engine will parse the pdf, anything bigger pdf will not be indexed.', '20', '20', 'system', ''),
(260, 'strip_tags_fulltext_abstract_composer', 'strip all html tags on full text/abstract composer value', 'true', 'true', 'system', 'true|false'),
(261, 'strip_tags_reference_composer', 'strip all html tags on reference composer value', 'true', 'true', 'system', 'true|false'),
(262, 'item_count_generator', 'browser count generator. for subject, publisher and year browser : daily | live (live will be slower). daily will generate after 24 hours later.', 'daily', 'daily', 'system', 'daily|live'),
(263, 'report_count_generator', 'report statistic generator count : daily | live (live will be slower). daily will generate after 24 hours later.', 'daily', 'daily', 'system', 'daily|live'),
(264, 'table_class_color', '', 'bluishHeader', 'bluishHeader', 'gui', 'yellowHeader|bluishHeader'),
(265, 'table_tr_header_color', '', 'bluishHeaderCenter', 'bluishHeaderCenter', 'gui', 'yellowHeaderCenter|bluishHeaderCenter'),
(266, 'table_tr_hover_color', '', 'bluishHover', 'bluishHover', 'gui', 'yellowHover|bluishHover'),
(267, 'table_td_header_color_alt', '#FFFE96 for yellow | #CCCDEC for bluish', '#CCCDEC', '#CCCDEC', 'gui', '#CCCDEC|#FFFE96'),
(268, 'enable_commercial_api', 'Enable items to be commercialized. Will enable Commercial Token Management and API Access.', 'false', 'false', 'api', 'true|false'),
(269, 'allow_guest_access_to_relatedfiles', 'Allow guest users to access all related additional files that came with an items', 'false', 'false', 'system', 'true|false'),
(270, 'enable_related_files_upload', 'This will enable or disable related files field when viewing details of an item.', 'false', 'false', 'system', 'true|false'),
(271, 'tmpal_delete_method', 'Temporary Access Link Delete Method. delete: will delete after expiry | keep: will keep log in the database', 'delete', 'delete', 'system', 'delete|keep');
ALTER TABLE `config_user` ADD PRIMARY KEY (`id`);
ALTER TABLE `config_user` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;

-- 2024A
CREATE TABLE `eg_loginless` (
  `43tokenid` int(11) NOT NULL,
  `43desc` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `43token` varchar(255) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;
ALTER TABLE `eg_loginless` ADD PRIMARY KEY (`43tokenid`);
ALTER TABLE `eg_loginless` MODIFY `43tokenid` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `eg_loginless` ADD `44totalaccess` INT(11) NOT NULL DEFAULT '0' AFTER `43token`;
ALTER TABLE `eg_loginless` ADD `43iprange` VARCHAR(255) NOT NULL DEFAULT '127.0.0.1' AFTER `43desc`;
ALTER TABLE `eg_item2` ADD `38_terms_of_availability` VARCHAR(25) NOT NULL DEFAULT '0.00' COMMENT 'tag 020 |c' AFTER `eg_item_id`;
CREATE TABLE `eg_commercialize` (`id` INT(11) NOT NULL AUTO_INCREMENT , `eg_item_id` INT(11) NOT NULL , `since` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `eg_item` ADD `41downloads` INT(11) NOT NULL DEFAULT '0' AFTER `41hits`;
CREATE TABLE `eg_commercial_token` (
  `43tokenid` int(11) NOT NULL,
  `43desc` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `43token` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `44totalaccess` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;
ALTER TABLE `eg_commercial_token` ADD PRIMARY KEY (`43tokenid`);
ALTER TABLE `eg_commercial_token` MODIFY `43tokenid` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `eg_downloadkey` DROP PRIMARY KEY;
ALTER TABLE `eg_downloadkey` ADD `id` INT(11) NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);
ALTER TABLE `eg_item_access` ADD `eg_loginless_id` INT(11) NOT NULL DEFAULT '0' AFTER `session_id`;
ALTER TABLE `eg_loginless` ADD `43tokendailylimit` INT(11) NOT NULL DEFAULT '999999' AFTER `43token`;
CREATE TABLE `eg_loginlesslog` (`id` INT(11) NOT NULL AUTO_INCREMENT , `43tokenid` INT(11) NOT NULL , `43date` DATE NOT NULL , `44counts` INT(11) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
CREATE TABLE `eg_relatedfiles` (`id` INT(11) NOT NULL AUTO_INCREMENT , `eg_item_id` INT(11) NOT NULL , `38filename` VARCHAR(255) NOT NULL , `38desc` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `eg_relatedfiles` ADD `38accesstype` VARCHAR(10) NOT NULL DEFAULT 'openaccess' AFTER `38desc`;
CREATE TABLE `eg_tempaccess` (`id` INT(11) NOT NULL AUTO_INCREMENT , `eg_item_id` INT(11) NOT NULL , `since` VARCHAR(255) NOT NULL , `token` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `eg_tempaccess` ADD `usagecount` INT(5) NOT NULL DEFAULT '0' AFTER `token`;
ALTER TABLE `eg_item_depo` ADD `eg_item_id` INT(11) NOT NULL DEFAULT '0' AFTER `grade`;

-- 2024B
ALTER TABLE `eg_publisher` ADD `43sstatus` INT(1) NOT NULL DEFAULT '1' AFTER `43publisher`;

-- 2025A
update `config_user` set cvalue='sw_asset/img/swadah_logo.png' where cname='main_logo' and cvalue='sw_images/swadah_logo.png';
update `config_user` set cvalue='sw_asset/img/bodybackground.jpg' where cname='main_body_background_image' and cvalue='sw_images/bodybackground.jpg';
update `config_user` set cvalue='sw_asset/img/swadah_icon_www.png' where cname='browser_icon' and cvalue='sw_images/swadah_icon_www.png';
update `config_user` set cvalue='sw_asset/img/swadah_big_icon.png' where cname='menu_icon' and cvalue='sw_images/swadah_big_icon.png';
update `config_user` set cvalue='sw_asset/img/watermark.png' where cname='watermark_overlay_file' and cvalue='sw_images/watermark.png';
update `config_user` set cvalue='sw_asset/img/swadah_big_icon.png' where cname='depo_image_institution' and cvalue='sw_images/swadah_big_icon.png';
update `config_user` set cvalue_default='sw_asset/img/swadah_logo.png' where cname='main_logo';
update `config_user` set cvalue_default='sw_asset/img/bodybackground.jpg' where cname='main_body_background_image';
update `config_user` set cvalue_default='sw_asset/img/swadah_icon_www.png' where cname='browser_icon';
update `config_user` set cvalue_default='sw_asset/img/swadah_big_icon.png' where cname='menu_icon';
update `config_user` set cvalue_default='sw_asset/img/watermark.png' where cname='watermark_overlay_file';
update `config_user` set cvalue_default='sw_asset/img/swadah_big_icon.png' where cname='depo_image_institution';
ALTER TABLE `eg_item2` ADD `38geographic_coverage_note_a` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'tag 522 |a' AFTER `38summary_a`, ADD `38original_version_note_t` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'tag 534 |t' AFTER `38geographic_coverage_note_a`, ADD `38terms_governing_use_a` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'tag 540 |a' AFTER `38original_version_note_t`;
ALTER TABLE `eg_item2` ADD `38other_relationship_entry_n` VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'tag 787 |n' AFTER `38source_e`;
ALTER TABLE `eg_item2_indicator` ADD `i_522` VARCHAR(3) NOT NULL AFTER `i_520`, ADD `i_534` VARCHAR(3) NOT NULL AFTER `i_522`, ADD `i_540` VARCHAR(3) NOT NULL AFTER `i_534`;
ALTER TABLE `eg_item2_indicator` ADD `i_787` VARCHAR(3) NOT NULL AFTER `i_710`;
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`) VALUES (NULL, 'tag_522_show', 'show tag 522 on item insert/update page', 'true', 'true', 'metadata', 'true|false'), (NULL, 'tag_534_show', 'show tag 534 on item insert/update page', 'true', 'true', 'metadata', 'true|false'), (NULL, 'tag_540_show', 'show tag 540 on item insert/update page', 'true', 'true', 'metadata', 'true|false'), (NULL, 'tag_787_show', 'show tag 787 on item insert/update page', 'true', 'true', 'metadata', 'true|false'), (NULL, 'tag_522', 'full description of tag 522', 'Geographic Coverage Note 522', 'Geographic Coverage Note 522', 'metadata', ''), (NULL, 'tag_534', 'full description of tag 534', 'Original Version Note 534', 'Original Version Note 534', 'metadata', ''), (NULL, 'tag_540', 'full description of tag 540', 'Terms of Governing Use 540', 'Terms of Governing Use 540', 'metadata', ''), (NULL, 'tag_787', 'full description of tag 787', 'Other Relationship Entry 787', 'Other Relationship Entry 787', 'metadata', '');
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`) VALUES (NULL, 'tag_522_simple', 'simple description of tag 522', 'Geographic Coverage Note', 'Geographic Coverage Note', 'metadata', ''), (NULL, 'tag_534_simple', 'simple description of tag 534', 'Original Version Note', 'Original Version Note', 'metadata', ''), (NULL, 'tag_540_simple', 'simple description of tag 540', 'Terms of Governing Use', 'Terms of Governing Use', 'metadata', ''), (NULL, 'tag_787_simple', 'simple description of tag 787', 'Other Relationship Entry', 'Other Relationship Entry', 'metadata', '');
ALTER TABLE `config_user` ADD `important` VARCHAR(5) NOT NULL DEFAULT 'false' AFTER `possible_values`;
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`) VALUES (NULL, 'tag_700_e_simple', 'simple text for tag 700 |e', 'Role', 'Role', 'metadata', '', 'false');
UPDATE `config_user` set important='true' where cname='default_view_input';
UPDATE `config_user` set important='true' where cname='intro_words';
UPDATE `config_user` set important='true' where cname='main_logo';
UPDATE `config_user` set important='true' where cname='system_function';
UPDATE `config_user` set important='true' where cname='system_identifier';
UPDATE `config_user` set important='true' where cname='system_ip';
UPDATE `config_user` set important='true' where cname='system_owner';
UPDATE `config_user` set important='true' where cname='system_path';
UPDATE `config_user` set important='true' where cname='system_title';
ALTER TABLE `eg_item2` ADD `38pname1_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-1 |e' AFTER `38pname1` ;
ALTER TABLE `eg_item2` ADD `38pname2_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-2 |e' AFTER `38pname2`;
ALTER TABLE `eg_item2` ADD `38pname3_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-3 |e' AFTER `38pname3`;
ALTER TABLE `eg_item2` ADD `38pname4_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-4 |e' AFTER `38pname4`;
ALTER TABLE `eg_item2` ADD `38pname5_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-5 |e' AFTER `38pname5`;
ALTER TABLE `eg_item2` ADD `38pname6_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-6 |e' AFTER `38pname6`;
ALTER TABLE `eg_item2` ADD `38pname7_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-7 |e' AFTER `38pname7`;
ALTER TABLE `eg_item2` ADD `38pname8_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-8 |e' AFTER `38pname8`;
ALTER TABLE `eg_item2` ADD `38pname9_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-9 |e' AFTER `38pname9`;
ALTER TABLE `eg_item2` ADD `38pname10_s` VARCHAR(255) NOT NULL COMMENT 'tag 700-10 |e' AFTER `38pname10`;
ALTER TABLE `eg_item2` DROP `38contenttype_a`, DROP `38contenttype_2`, DROP `38mediatype_a`, DROP `38mediatype_2`, DROP `38carriertype_a`, DROP `38carriertype_2`;
ALTER TABLE `eg_item2_indicator` DROP `i_336`, DROP `i_337`, DROP `i_338`;
DELETE from `config_user` where cname like 'tag_336%' or cname like 'tag_337%' or cname like 'tag_338%';
ALTER TABLE `config_user` ADD `dc_element` VARCHAR(70) NOT NULL DEFAULT 'false' AFTER `important`;
UPDATE `config_user` SET `dc_element` = 'dc.title' WHERE `config_user`.`cname` = 'tag_245';
UPDATE `config_user` SET `dc_element` = 'dc.subject' WHERE `config_user`.`cname` = 'tag_650';
UPDATE `config_user` SET `dc_element` = 'dc.description' WHERE `config_user`.`cname` = 'tag_500';
UPDATE `config_user` SET `dc_element` = 'dc.source' WHERE `config_user`.`cname` = 'tag_534';
UPDATE `config_user` SET `dc_element` = 'dc.relation' WHERE `config_user`.`cname` = 'tag_787';
UPDATE `config_user` SET `dc_element` = 'dc.coverage' WHERE `config_user`.`cname` = 'tag_522';
UPDATE `config_user` SET `dc_element` = 'dc.creator' WHERE `config_user`.`cname` = 'tag_100';
UPDATE `config_user` SET `dc_element` = 'dc.publisher' WHERE `config_user`.`cname` = 'tag_264';
UPDATE `config_user` SET `dc_element` = 'dc.contributor' WHERE `config_user`.`cname` = 'tag_700';
UPDATE `config_user` SET `dc_element` = 'dc.rights' WHERE `config_user`.`cname` = 'tag_540';
UPDATE `config_user` SET `dc_element` = 'dc.format' WHERE `config_user`.`cname` = 'tag_300';
UPDATE `config_user` SET `dc_element` = 'dc.language' WHERE `config_user`.`cname` = 'tag_041';
UPDATE `config_user` SET `dc_element` = 'dc.date' WHERE `config_user`.`cname` = 'publisher_year_of_publication';
ALTER TABLE `eg_downloadkey` DROP `uniqueid`;
UPDATE `eg_composer` SET `45value` = "<table style=\'background-color:white;\'> \r\n<tr>\r\n<td style=\'text-align:center;\'>\r\n<img alt=\'Main Logo\' width=\'250px\' src=\'sw_asset/img/swadah_logo.png\'><br/>\r\nsWADAH is developed by Perpustakaan Tuanku Bainun, Universiti Pendidikan Sultan Idris and it\'s targetted as an alternative digital repository for institutions. It features an easy to deploy system, easy to manage web based file repository system, following Google Scholar inclusion guideline, support OAI-PMH and also with fast, reliable and user-friendly interface.\r\n</td>\r\n</tr>\r\n</table>" WHERE `eg_composer`.`id` = 2;
ALTER TABLE `eg_userlog` ADD FULLTEXT(`37keyword`);
ALTER TABLE `eg_userlog_det` ADD FULLTEXT(`38keyword`);

-- 2025A .0801
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'allow_guest_access_to_imagefile', 'allow access to image file for guest', 'true', 'true', 'system', 'true|false', 'false', 'false');
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'tag_502_b', 'display text for tav 502 |b', 'Degree Type', 'Degree Type', 'metadata', '', 'false', 'false');
UPDATE `config_user` SET `cname` = 'footer_font_size' WHERE `config_user`.`cname` = 'footer_fontSize';
UPDATE `config_user` SET `cname` = 'table_td_header_color' WHERE `config_user`.`cname` = 'table_td_header_color_alt';
UPDATE `config_user` SET `cname` = 'tag_020_c' WHERE `config_user`.`cname` = 'tag_020c';
UPDATE `config_user` SET `cname` = 'tag_020_c_currency' WHERE `config_user`.`cname` = 'tag_020c_currency';
UPDATE `config_user` SET `cname` = 'tag_020_c_show' WHERE `config_user`.`cname` = 'tag_020c_show';
UPDATE `config_user` SET `cname` = 'tag_020_c_simple' WHERE `config_user`.`cname` = 'tag_020c_simple';
DELETE from `config_user` WHERE `config_user`.`cname` = 'allow_depositor_function';
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'color_scheme', 'control color scheme of certain element on sWADAH. bluish is more towards blue and yellow is subtle yellowish color scheme', 'bluish', 'bluish', 'gui', 'bluish | yellow', 'false', 'false');
DELETE from `config_user` WHERE `config_user`.`cname` = 'table_class_color';
DELETE from `config_user` WHERE `config_user`.`cname` = 'table_td_header_color';
DELETE from `config_user` WHERE `config_user`.`cname` = 'table_tr_header_color';
DELETE from `config_user` WHERE `config_user`.`cname` = 'table_tr_hover_color';
DELETE from `config_user` WHERE `config_user`.`cname` = 'putenv';
DELETE FROM `config_user` where `config_user`.`cname` like '%_default_ind';
UPDATE `config_user` set cname='tag_700_e' where cname='tag_700_e_simple';
DELETE FROM `config_user` where cname like '%_simple';
UPDATE `config_user` set cvalue='ISBN', cvalue_default='ISBN' where cname = 'tag_020';
UPDATE `config_user` set cvalue='Term of Availability', cvalue_default='Term of Availability' where cname = 'tag_020_c';
UPDATE `config_user` set cvalue='ISSN', cvalue_default='ISSN' where cname = 'tag_022';
UPDATE `config_user` set cvalue='Language Code', cvalue_default='Language Code' where cname = 'tag_041';
UPDATE `config_user` set cvalue='Call Number', cvalue_default='Call Number' where cname = 'tag_090';
UPDATE `config_user` set cvalue='Main Author', cvalue_default='Main Author' where cname = 'tag_100';
UPDATE `config_user` set cvalue='Title', cvalue_default='Title' where cname = 'tag_245';
UPDATE `config_user` set cvalue='Varying Form of Title', cvalue_default='Varying Form of Title' where cname = 'tag_246';
UPDATE `config_user` set cvalue='Edition', cvalue_default='Edition' where cname = 'tag_250';
UPDATE `config_user` set cvalue='Publication', cvalue_default='Publication' where cname = 'tag_264';
UPDATE `config_user` set cvalue='Physical Description', cvalue_default='Physical Description' where cname = 'tag_300';
UPDATE `config_user` set cvalue='Series', cvalue_default='Series' where cname = 'tag_490';
UPDATE `config_user` set cvalue='Notes', cvalue_default='Notes' where cname = 'tag_500';
UPDATE `config_user` set cvalue='Dissertation Note', cvalue_default='Dissertation Note' where cname = 'tag_502';
UPDATE `config_user` set cvalue='Access Category', cvalue_default='Access Category' where cname = 'tag_506';
UPDATE `config_user` set cvalue='Summary', cvalue_default='Summary' where cname = 'tag_520';
UPDATE `config_user` set cvalue='Subject Added Entry - Personal Name', cvalue_default='Subject Added Entry - Personal Name' where cname = 'tag_600';
UPDATE `config_user` set cvalue='Subject Entry - Topical Term', cvalue_default='Subject Entry - Topical Term' where cname = 'tag_650';
UPDATE `config_user` set cvalue='Additional Authors', cvalue_default='Additional Authors' where cname = 'tag_700';
UPDATE `config_user` set cvalue='Corporate Name', cvalue_default='Corporate Name' where cname = 'tag_710';
UPDATE `config_user` set cvalue='Location', cvalue_default='Location' where cname = 'tag_852';
UPDATE `config_user` set cvalue='HTTP Link', cvalue_default='HTTP Link' where cname = 'tag_856';
UPDATE `config_user` set cvalue='Geographic Coverage Note', cvalue_default='Geographic Coverage Note' where cname = 'tag_522';
UPDATE `config_user` set cvalue='Original Version Note', cvalue_default='Original Version Note' where cname = 'tag_534';
UPDATE `config_user` set cvalue='Terms of Governing Use', cvalue_default='Terms of Governing Use' where cname = 'tag_540';
UPDATE `config_user` set cvalue='Other Relationship Entry', cvalue_default='Other Relationship Entry' where cname = 'tag_787';
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'youtube_detector', 'if HTTP link (tag 856) is sourced from youtube, it will show embedded player on top of detail page.', 'true', 'true', 'gui', 'true|false', 'false', 'false');
UPDATE `config_user` SET `ctype` = 'metadata' WHERE `config_user`.`cname` = 'type_as';
UPDATE `config_user` SET `ctype` = 'metadata' WHERE `config_user`.`cname` = 'subject_heading_as';
UPDATE `config_user` SET `ctype` = 'metadata' WHERE `config_user`.`cname` = 'subject_heading_delimiter';
UPDATE `config_user` SET `ctype` = 'metadata' WHERE `config_user`.`cname` = 'subject_heading_selectable';
ALTER TABLE `eg_item_access` ADD INDEX(`eg_item_id`);
ALTER TABLE `eg_item` ADD INDEX(`38typeid`, `41instimestamp`);
ALTER TABLE `eg_item_access` ADD INDEX(`39logdate`, `39ipaddr`);
ALTER TABLE `eg_item_download` ADD INDEX(`eg_item_id`);
ALTER TABLE `eg_item_download` ADD INDEX(`39logdate`, `39ipaddr`);
ALTER TABLE `eg_photo_access` ADD INDEX(`eg_item_id`);
ALTER TABLE `eg_photo_access` ADD INDEX(`eg_item_id`, `38timestamp`);
ALTER TABLE `eg_item` ADD INDEX(`id`, `38typeid`);
ALTER TABLE `eg_item` ADD INDEX(`38typeid`);
ALTER TABLE `eg_item_download` ADD INDEX(`39logdate`);
ALTER TABLE `eg_item_download` ADD INDEX(`39from`);
ALTER TABLE `eg_item_download` ADD INDEX(`eg_item_id`, `39logdate`, `39from`);
ALTER TABLE `eg_userlog` ADD INDEX(`37lastlog`);
ALTER TABLE `eg_userlog_det` ADD INDEX(`38logdate`);

-- 2025C
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'system_docs_login_warning', 'full text document access warning when not login', 'Login required to access this item.', 'Login required to access this item.', 'dir', '', 'false', 'false');
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'show_meta_oai_link', 'show oai link on index page', 'false', 'false', 'oai', 'true|false', 'false', 'false'), (NULL, 'show_meta_searcherapi_link', 'show searcher api link on index page', 'false', 'false', 'api', 'true|false', 'false', 'false');
UPDATE `config_user` SET `cname` = 'recorded_incidents_directory' WHERE `config_user`.`cname` = 'blocked_file_location';
DELETE FROM `config_user` WHERE `cname` = 'show_client_ip_on_startup';
UPDATE `config_user` set `ctype` = 'dirloca' WHERE `cname` = 'system_statcache_directory' or `cname` = 'recorded_incidents_directory' or `cname` = 'system_docs_directory' or `cname` = 'system_pdocs_directory' or `cname` = 'system_txts_directory' or `cname` = 'system_isofile_directory' or `cname` = 'system_albums_directory' or `cname` = 'system_albums_thumbnail_directory' or `cname` = 'system_albums_watermark_directory' or `cname` = 'system_dfile_directory' or `cname` = 'system_pfile_directory';
ALTER TABLE `eg_item_type` ADD `38gview` INT(2) NOT NULL DEFAULT '0' AFTER `38desc`;
DELETE FROM `config_user` WHERE cname='allow_guest_access_to_ft';
DELETE FROM `config_user` WHERE cname='allow_guest_access_to_pt';
DELETE FROM `config_user` WHERE cname='allow_guest_access_to_imagefile';
DELETE FROM `config_user` WHERE cname='allow_guest_access_to_isofile';
DELETE FROM `config_user` WHERE cname='allow_guest_access_to_relatedfiles';
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'depo_max_deposit', 'max deposit for item submitted through self deposit', '1', '1', 'depo', 'any integer value', 'false', 'false');
UPDATE `config_user` SET `cname` = 'ip_fence_enabled' WHERE `config_user`.`cname` = 'ip_restriction_enabled';
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'tmpal_access_duration', 'access duration in second for the temporary access link for item', '86400', '86400', 'system', 'any integer value, it will represent seconds', 'false', 'false');
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'tmpal_access_count', 'access counts permitted for the temporary access link for item', '3', '3', 'system', 'number of refresh/access for temporary access link detail page', 'false', 'false');
UPDATE `config_user` SET `cvalue` = 'Declaration of submission PDF', `cvalue_default` = 'Declaration of submission PDF' WHERE `config_user`.`cname` = 'depo_txt_declaration_to_library';
UPDATE `config_user` SET `cname` = 'enable_folder' WHERE `config_user`.`cname` = 'enable_secure_folder';
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'system_pdf_viewer', 'default pdf viewer for sWADAH. pdfjs will use pdfjs as viewer, direct will output pdf directly to browser', 'direct', 'direct', 'system', 'pdfjs|direct', 'false', 'false');

-- 2025D
INSERT INTO `config_user` (`id`, `cname`, `cdesc`, `cvalue`, `cvalue_default`, `ctype`, `possible_values`, `important`, `dc_element`) VALUES (NULL, 'searcher_today_popular_keyword', 'show popular keyword of the day at the top of searcher page', 'false', 'false', 'gui', 'true|false', 'false', 'false');

-- 2025F
ALTER TABLE `eg_loginless` ADD `44redirecturl` VARCHAR(1000) NOT NULL AFTER `44totalaccess`;

-- 2025G
DELETE FROM `config_user` WHERE cname='searcher_show_frequency_of_toprateditems';
UPDATE `config_user` set `cname` = 'searcher_active_popular_keyword' WHERE `cname` LIKE 'searcher_today_popular_keyword';
INSERT INTO `eg_auth_eligibility` (`id`, `usertype`, `usertypedesc`, `max_loanitem`) VALUES (NULL, 'LINKP', 'Link Provider', '1');

-- 2025I
ALTER TABLE `eg_item` CHANGE `38author` `38author` VARCHAR(350) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL COMMENT 'tag 100 |a', CHANGE `38title` `38title` VARCHAR(450) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL COMMENT 'tag 245 |a';

-- 2025J
ALTER TABLE `eg_downloadkey` DROP `pdocs`, DROP `docs`, DROP `albums`, DROP `isos`;

-- 2025K
ALTER TABLE `eg_item_access` DROP `session_id`;
ALTER TABLE `eg_item_download` DROP `session_id`;
INSERT INTO `eg_auth_eligibility` (`id`, `usertype`, `usertypedesc`, `max_loanitem`) VALUES (NULL, 'DEPATRON', 'Deactivated Patron (only for Patron)', '0');
CREATE TABLE `eg_item_lastchecked` (`id` int(11) NOT NULL,`item_id` int(11) NOT NULL,`last_checked` datetime NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
ALTER TABLE `eg_item_lastchecked` ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `item_id` (`item_id`);
ALTER TABLE `eg_item_lastchecked` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
DELETE FROM config_user WHERE cname="show_main_body_background_image" or cname="main_body_background_image";

-- Released 2026X --