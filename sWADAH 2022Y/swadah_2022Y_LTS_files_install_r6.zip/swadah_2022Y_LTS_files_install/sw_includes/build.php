<?php
    //version information
    $system_build = "20231231.0800 (2022Y LTS R6)";
    $system_version = "Build $system_build";
?>