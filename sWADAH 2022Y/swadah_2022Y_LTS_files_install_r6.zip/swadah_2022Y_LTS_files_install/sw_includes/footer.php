<?php
	defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>sWADAH HTTP Response Code</em></div>");
	
	echo "<div style='font-size:$footer_fontSize;text-align:center;'><strong>Installed and configured by $system_owner</strong>";	
		echo "<br/>$system_admin_contact_disclaimer";	
	echo "</div>";
?>