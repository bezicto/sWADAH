ALTER TABLE `eg_item` ADD `51_embargo_timestamp` VARCHAR(255) NOT NULL DEFAULT '0' AFTER `51_pagecount`;
ALTER TABLE `eg_subjectheading` ADD `43count` INT(11) NOT NULL DEFAULT '0' AFTER `43subject`, ADD `43lastcount_timestamp` VARCHAR(25) NOT NULL DEFAULT '0' AFTER `43count`;
ALTER TABLE `eg_publisher` ADD `43count` INT(11) NOT NULL DEFAULT '0' AFTER `43publisher`, ADD `43lastcount_timestamp` VARCHAR(25) NOT NULL DEFAULT '0' AFTER `43count`;
CREATE TABLE `eg_stat_year` (`id` int(5) NOT NULL,`43count` int(11) NOT NULL DEFAULT 0,`43lastcount_timestamp` varchar(25) NOT NULL DEFAULT '0') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE `eg_stat_year` ADD PRIMARY KEY(`id`);
ALTER TABLE `eg_auth` ADD `input_count` INT NOT NULL DEFAULT '0' AFTER `num_attempt`, ADD `timestamp_count` VARCHAR(25) NOT NULL DEFAULT '0' AFTER `input_count`;
CREATE TABLE `eg_item_feedback` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `eg_item_id` INT(11) NOT NULL , `eg_auth_username` VARCHAR(255) NOT NULL , `38feedback` TEXT NOT NULL , `38timestamp` VARCHAR(25) NOT NULL , `38upvote` INT(11) NOT NULL , `38downvote` INT(11) NOT NULL , `39moderated_status` VARCHAR(25) NOT NULL , `39moderated_by` VARCHAR(255) NOT NULL , `39moderated_timestamp` VARCHAR(25) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `eg_item_feedback` ADD `38votebys` TEXT NOT NULL AFTER `38downvote`;