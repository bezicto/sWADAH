-- phpMyAdmin SQL Dump
-- version 5.2.0-1.fc36
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 21, 2022 at 03:14 AM
-- Server version: 10.7.4-MariaDB
-- PHP Version: 8.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `swadah_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth`
--

CREATE TABLE `eg_auth` (
  `id` int(5) NOT NULL,
  `username` varchar(15) COLLATE utf8mb3_swedish_ci NOT NULL,
  `syspassword` longtext CHARACTER SET latin1 NOT NULL,
  `usertype` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'FALSE',
  `name` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `division` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `lastlogin` varchar(25) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `online` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'OFF',
  `num_attempt` int(5) NOT NULL DEFAULT 0,
  `input_count` int(11) NOT NULL DEFAULT 0,
  `timestamp_count` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `eg_auth`
--

INSERT INTO `eg_auth` (`id`, `username`, `syspassword`, `usertype`, `name`, `division`, `lastlogin`, `online`, `num_attempt`, `input_count`, `timestamp_count`) VALUES
(1, 'admin', ':0Z‰eàºž §ù“%', 'SUPER', 'Administrator', 'Bahagian Pengurusan Automasi', 'Mon 20/06/2022 12:21 pm', 'OFF', 0, 111, '1654153887');

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_depo`
--

CREATE TABLE `eg_auth_depo` (
  `id` int(5) NOT NULL,
  `useridentity` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL,
  `userpass` varchar(255) CHARACTER SET latin1 NOT NULL,
  `fullname` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `emailaddress` varchar(255) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `phonenum` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'OFF',
  `regtimestamp` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `activation` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'NOTACTIVE',
  `num_attempt` int(5) NOT NULL DEFAULT 0,
  `registerkey` varchar(500) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_eligibility`
--

CREATE TABLE `eg_auth_eligibility` (
  `id` int(11) NOT NULL,
  `usertype` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `usertypedesc` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `max_loanitem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `eg_auth_eligibility`
--

INSERT INTO `eg_auth_eligibility` (`id`, `usertype`, `usertypedesc`, `max_loanitem`) VALUES
(1, 'SUPER', 'For Administrative Purposes', 21),
(2, 'STAFF', 'Basic Administrative Account', 3),
(3, 'FALSE', 'Deactivated Account', 0),
(4, 'PATRON', 'Patron Account', 3);

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_ip`
--

CREATE TABLE `eg_auth_ip` (
  `id` int(11) NOT NULL,
  `ipaddress` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_downloadkey`
--

CREATE TABLE `eg_downloadkey` (
  `uniqueid` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '',
  `eg_item_id` int(11) NOT NULL,
  `ip_address` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `timestamped` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '',
  `downloads` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '0',
  `pdocs` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `docs` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `albums` text COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_forgotpassword_depo`
--

CREATE TABLE `eg_forgotpassword_depo` (
  `id` int(11) NOT NULL,
  `emailaddress` varchar(350) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `timestamp` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item`
--

CREATE TABLE `eg_item` (
  `id` int(11) NOT NULL,
  `38accessnum` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL,
  `38typeid` varchar(10) COLLATE utf8mb3_swedish_ci NOT NULL,
  `38status` varchar(50) COLLATE utf8mb3_swedish_ci NOT NULL,
  `38isbn` varchar(60) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 020 |a',
  `38issn` varchar(60) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 022 |a',
  `38langcode` varchar(5) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'zsm' COMMENT 'tag 041 a|',
  `38localcallnum` varchar(70) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 090 |a',
  `38author` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 100 |a',
  `38title` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 245 |a',
  `38edition` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 250 |a',
  `38publication` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 264 |a',
  `38physicaldesc` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 300 |a',
  `38series` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 490 |a',
  `38notes` text COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 500 |a',
  `38dissertation_note` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 502 |a',
  `38source` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 710 |a',
  `38location` varchar(50) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 852 |a',
  `38link` varchar(255) COLLATE utf8mb3_swedish_ci DEFAULT NULL COMMENT 'tag 856 |u',
  `39inputdate` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39inputby` varchar(50) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39proposedelete` varchar(5) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'FALSE',
  `39proposedeleteby` varchar(50) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `39proposedelete_reason` varchar(255) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `40lastupdateby` varchar(50) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `41instimestamp` varchar(12) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `41hits` int(11) DEFAULT 0,
  `41fulltexta` longtext COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `41reference` longtext COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `41pdfattach` varchar(255) COLLATE utf8mb3_swedish_ci DEFAULT 'FALSE',
  `41pdfattach_fulltext` longtext COLLATE utf8mb3_swedish_ci NOT NULL,
  `41subjectheading` varchar(150) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `41isabstract` int(1) NOT NULL DEFAULT 0,
  `41imageatt` varchar(255) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `41ppdfattach` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'FALSE',
  `50search_cloud` mediumtext COLLATE utf8mb3_swedish_ci NOT NULL,
  `50item_status` varchar(1) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '1',
  `51_pagecount` int(11) NOT NULL DEFAULT 0,
  `51_embargo_timestamp` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item2`
--

CREATE TABLE `eg_item2` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `38localcallnum_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 090 |b',
  `38author_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 100 |c',
  `38author_d` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 100 |d',
  `38author_e` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 100 |e',
  `38author_q` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 100 |q',
  `38title_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 245 |b',
  `38title_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 245 |c',
  `38vtitle_a` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 246_a',
  `38vtitle_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 246_b',
  `38vtitle_g` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 246_g',
  `38publication_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 264 |b',
  `38publication_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 264 |c',
  `38physicaldesc_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 300 |b',
  `38physicaldesc_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 300 |c',
  `38physicaldesc_e` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 300 |e',
  `38contenttype_a` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 336_a',
  `38contenttype_2` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 336_2',
  `38mediatype_a` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 337_a',
  `38mediatype_2` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 337_2',
  `38carriertype_a` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 338_a',
  `38carriertype_2` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 338_2',
  `38series_v` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 490 |v',
  `38dissertation_note_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 502 |b',
  `38dissertation_note_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 502 |c',
  `38dissertation_note_d` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 502 |d',
  `38summary_a` text COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 520_a',
  `38se_pname_a` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 600_a',
  `38se_pname_x` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 600_x',
  `38se_pname_y` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 600_y',
  `38subject_entry1` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 650 |a',
  `38subject_entry2` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 650 |a',
  `38subject_entry3` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 650 |a',
  `38pname1` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-1 a|',
  `38pname2` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-2 a|',
  `38pname3` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-3 a|',
  `38pname4` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-4 a|',
  `38pname5` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-5 a|',
  `38pname6` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-6 a|',
  `38pname7` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-7 a|',
  `38pname8` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-8 a|',
  `38pname9` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-9 a|',
  `38pname10` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 700-10 a|',
  `38source_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 710 |b',
  `38source_e` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 710 |e',
  `38location_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 852 |b',
  `38location_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL COMMENT 'tag 852 |c'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item2_indicator`
--

CREATE TABLE `eg_item2_indicator` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `i_020` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_022` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_041` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_090` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_100` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_245` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_246` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_250` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_264` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_300` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_336` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_337` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_338` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_490` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_500` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_502` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_520` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_600` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_650_1` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_650_2` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_650_3` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_2` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_3` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_4` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_5` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_6` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_7` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_8` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_9` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_700_10` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_710` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_852` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL,
  `i_856` varchar(3) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_access`
--

CREATE TABLE `eg_item_access` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39logdate` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39ipaddr` varchar(15) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_charge`
--

CREATE TABLE `eg_item_charge` (
  `id` int(11) NOT NULL,
  `38accessnum` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39patron` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39charged_on` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39charged_by` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39duedate` int(11) DEFAULT 0,
  `40dc` varchar(2) COLLATE utf8mb3_swedish_ci NOT NULL,
  `40dc_on` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL,
  `40dc_by` varchar(150) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_depo`
--

CREATE TABLE `eg_item_depo` (
  `id` int(11) NOT NULL,
  `29authorname` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `29titlestatement` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29publication_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `29publication_c` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `29dissertation_note_b` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname1` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname2` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname3` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname4` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname5` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname6` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname7` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname8` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname9` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pname10` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `29dfile` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `29pfile` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `29abstract` mediumtext COLLATE utf8mb3_swedish_ci NOT NULL,
  `29accesscategory` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'openaccess',
  `29lastupdated` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `year` int(4) NOT NULL,
  `inputby` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `timestamp` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `itemstatus` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'ENTRY'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_depo_remarks`
--

CREATE TABLE `eg_item_depo_remarks` (
  `id` int(11) NOT NULL,
  `eg_item_depo_id` int(11) NOT NULL,
  `39remarks` text COLLATE utf8mb3_swedish_ci NOT NULL,
  `timestamp` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_download`
--

CREATE TABLE `eg_item_download` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39logdate` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39ipaddr` varchar(15) COLLATE utf8mb3_swedish_ci NOT NULL,
  `39from` varchar(10) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'web'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_feedback`
--

CREATE TABLE `eg_item_feedback` (
  `id` int(11) NOT NULL,
  `eg_item_id` int(11) NOT NULL,
  `eg_auth_username` varchar(255) NOT NULL,
  `38feedback` text NOT NULL,
  `38timestamp` varchar(25) NOT NULL,
  `38upvote` int(11) NOT NULL,
  `38downvote` int(11) NOT NULL,
  `38votebys` text NOT NULL,
  `39moderated_status` varchar(25) NOT NULL,
  `39moderated_by` varchar(255) NOT NULL,
  `39moderated_timestamp` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item_type`
--

CREATE TABLE `eg_item_type` (
  `38typeid` int(4) NOT NULL,
  `38type` varchar(50) COLLATE utf8mb3_swedish_ci NOT NULL,
  `38default` varchar(5) COLLATE utf8mb3_swedish_ci DEFAULT 'FALSE',
  `38defaultlocation` varchar(150) COLLATE utf8mb3_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `eg_item_type`
--

INSERT INTO `eg_item_type` (`38typeid`, `38type`, `38default`, `38defaultlocation`) VALUES
(1, 'Thesis', 'FALSE', NULL),
(2, 'Article', 'FALSE', NULL),
(3, 'Book', 'FALSE', NULL),
(4, 'Book_section', 'FALSE', NULL),
(5, 'Conference_item', 'FALSE', NULL),
(6, 'Monograph', 'FALSE', NULL),
(7, 'Photo', 'FALSE', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `eg_publisher`
--

CREATE TABLE `eg_publisher` (
  `43pubid` int(11) NOT NULL,
  `43acronym` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `43publisher` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `43count` int(11) NOT NULL DEFAULT 0,
  `43lastcount_timestamp` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_publisher`
--

INSERT INTO `eg_publisher` (`43pubid`, `43acronym`, `43publisher`, `43count`, `43lastcount_timestamp`) VALUES
(1, 'FMSP', 'Fakulti Muzik dan Seni Persembahan', 1, '1655423482'),
(2, 'FBK', 'Fakulti Bahasa dan Komunikasi', 2, '1655423482'),
(3, 'FPPM', 'Fakulti Pendidikan dan Pembangunan Manusia', 1, '1655423482'),
(4, 'FSM', 'Fakulti Sains dan Matematik', 3, '1655423482'),
(5, 'FPE', 'Fakulti Pengurusan dan Ekonomi', 2, '1655423482'),
(6, 'FSSK', 'Fakulti Sains Sukan dan Kejurulatihan', 2, '1655423482'),
(7, 'FSK', 'Fakulti Sains Kemanusiaan', 2, '1655423482'),
(8, 'FSKIK', 'Fakulti Seni, Komputeran dan Industri Kreatif', 1, '1655423482'),
(9, 'FPTV', 'Fakulti Pendidikan Teknikal dan Vokasional', 1, '1655423482'),
(18, 'IPM', 'Institut Peradaban Melayu', 1, '1655423482'),
(19, 'IPS', 'Institut Pengajian Siswazah', 0, '1655423482'),
(26, 'PTB', 'Perpustakaan Tuanku Bainun', 0, '1655423482'),
(34, 'UDL', 'UPSI Digital Library', 0, '1655423482');

-- --------------------------------------------------------

--
-- Table structure for table `eg_stat_year`
--

CREATE TABLE `eg_stat_year` (
  `id` int(5) NOT NULL,
  `43count` int(11) NOT NULL DEFAULT 0,
  `43lastcount_timestamp` varchar(25) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `eg_subjectheading`
--

CREATE TABLE `eg_subjectheading` (
  `43subjectid` int(11) NOT NULL,
  `43acronym` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `43subject` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `43count` int(11) NOT NULL DEFAULT 0,
  `43lastcount_timestamp` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_subjectheading`
--

INSERT INTO `eg_subjectheading` (`43subjectid`, `43acronym`, `43subject`, `43count`, `43lastcount_timestamp`) VALUES
(1, 'A', 'General Works', 19, '1655423490'),
(2, 'B', 'Philosophy. Psychology. Religion', 5, '1655423491'),
(3, 'C', 'Auxiliary Sciences of History', 0, '1655423490'),
(4, 'D', 'History General and Old World', 2, '1655423490'),
(5, 'E', 'History America', 3, '1655423490'),
(6, 'F', 'History United States, Canada, Latin America', 1, '1655423490'),
(7, 'G', 'Geography. Anthropology. Recreation', 0, '1655423490'),
(8, 'H', 'Social Sciences', 0, '1655423491'),
(9, 'J', 'Political Science', 1, '1655423491'),
(10, 'K', 'Law', 1, '1655423490'),
(11, 'L', 'Education', 0, '1655423490'),
(12, 'M', 'Music and Books on Music', 1, '1655423490'),
(13, 'N', 'Fine Arts', 1, '1655423490'),
(14, 'P', 'Language and Literature', 1, '1655423490'),
(15, 'Q', 'Science', 0, '1655423491'),
(16, 'R', 'Medicine', 1, '1655423490'),
(17, 'S', 'Agriculture', 1, '1655423490'),
(18, 'T', 'Technology', 2, '1655423491'),
(19, 'U', 'Military Science', 0, '1655423490'),
(20, 'V', 'Naval Science', 0, '1655423490'),
(21, 'Z', 'Bibliography. Library Science. Information Resources', 0, '1655423490');

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog`
--

CREATE TABLE `eg_userlog` (
  `id` int(11) NOT NULL,
  `37keyword` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `37type` varchar(20) COLLATE utf8mb3_swedish_ci NOT NULL DEFAULT 'All Type',
  `37freq` int(11) NOT NULL,
  `37lastlog` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog_det`
--

CREATE TABLE `eg_userlog_det` (
  `id` int(11) NOT NULL,
  `38keyword` varchar(255) COLLATE utf8mb3_swedish_ci NOT NULL,
  `38logdate` varchar(25) COLLATE utf8mb3_swedish_ci NOT NULL,
  `38ipaddr` varchar(15) COLLATE utf8mb3_swedish_ci DEFAULT NULL,
  `38type` varchar(20) COLLATE utf8mb3_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eg_auth`
--
ALTER TABLE `eg_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_auth_depo`
--
ALTER TABLE `eg_auth_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_auth_eligibility`
--
ALTER TABLE `eg_auth_eligibility`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_id` (`usertype`);

--
-- Indexes for table `eg_auth_ip`
--
ALTER TABLE `eg_auth_ip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_downloadkey`
--
ALTER TABLE `eg_downloadkey`
  ADD PRIMARY KEY (`uniqueid`);

--
-- Indexes for table `eg_forgotpassword_depo`
--
ALTER TABLE `eg_forgotpassword_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item`
--
ALTER TABLE `eg_item`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `40lastupdateby` (`40lastupdateby`),
  ADD KEY `39inputby` (`39inputby`),
  ADD KEY `38subjectheading` (`41subjectheading`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38title` (`38title`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38fulltext` (`41fulltexta`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38author` (`38author`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38pdfattach_fulltext` (`41pdfattach_fulltext`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `50search_cloud` (`50search_cloud`);

--
-- Indexes for table `eg_item2`
--
ALTER TABLE `eg_item2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item2_indicator`
--
ALTER TABLE `eg_item2_indicator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_access`
--
ALTER TABLE `eg_item_access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_charge`
--
ALTER TABLE `eg_item_charge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_depo`
--
ALTER TABLE `eg_item_depo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_depo_remarks`
--
ALTER TABLE `eg_item_depo_remarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_download`
--
ALTER TABLE `eg_item_download`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_feedback`
--
ALTER TABLE `eg_item_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_item_type`
--
ALTER TABLE `eg_item_type`
  ADD PRIMARY KEY (`38typeid`),
  ADD KEY `38typeid` (`38typeid`);

--
-- Indexes for table `eg_publisher`
--
ALTER TABLE `eg_publisher`
  ADD PRIMARY KEY (`43pubid`);

--
-- Indexes for table `eg_stat_year`
--
ALTER TABLE `eg_stat_year`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_subjectheading`
--
ALTER TABLE `eg_subjectheading`
  ADD PRIMARY KEY (`43subjectid`);

--
-- Indexes for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_userlog_det`
--
ALTER TABLE `eg_userlog_det`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eg_auth`
--
ALTER TABLE `eg_auth`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `eg_auth_depo`
--
ALTER TABLE `eg_auth_depo`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_auth_eligibility`
--
ALTER TABLE `eg_auth_eligibility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `eg_auth_ip`
--
ALTER TABLE `eg_auth_ip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `eg_forgotpassword_depo`
--
ALTER TABLE `eg_forgotpassword_depo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item`
--
ALTER TABLE `eg_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item2`
--
ALTER TABLE `eg_item2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item2_indicator`
--
ALTER TABLE `eg_item2_indicator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_access`
--
ALTER TABLE `eg_item_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_charge`
--
ALTER TABLE `eg_item_charge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_depo`
--
ALTER TABLE `eg_item_depo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_depo_remarks`
--
ALTER TABLE `eg_item_depo_remarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_download`
--
ALTER TABLE `eg_item_download`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_feedback`
--
ALTER TABLE `eg_item_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item_type`
--
ALTER TABLE `eg_item_type`
  MODIFY `38typeid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `eg_publisher`
--
ALTER TABLE `eg_publisher`
  MODIFY `43pubid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `eg_subjectheading`
--
ALTER TABLE `eg_subjectheading`
  MODIFY `43subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_userlog_det`
--
ALTER TABLE `eg_userlog_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
